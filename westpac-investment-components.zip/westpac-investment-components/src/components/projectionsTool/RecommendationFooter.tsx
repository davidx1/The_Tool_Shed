import React, { FC, useLayoutEffect } from 'react'
import styled from 'styled-components'
import { Box, Typography, Grid } from '@material-ui/core'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import ArrowButton from '../inputs/ArrowButton'
import { DisclaimerText } from '../dataDisplay/HTMLRenderer'
import BasicButton from '../inputs/BasicButton'
import { IKiwisaverProjectionsConfig } from '../../utils/projections-tools/projectionsToolUtils'

export interface Props {
  faqLinkHandler?: () => void
  contactUsLinkHandler?: () => void
  handleOpenAssumptions: () => void
  config: IKiwisaverProjectionsConfig
}
const GridIcon = styled(Grid)`
  max-width: 80px;
`

const RecommendationFooter: FC<Props> = ({
  faqLinkHandler,
  contactUsLinkHandler,
  handleOpenAssumptions,
  config,
}) => {
  useLayoutEffect(() => {
    const assumptionLink = document.getElementById(
      'kiwisaver-projection-calculations-and-assumptions-disclaimer-link'
    )
    if (assumptionLink) {
      assumptionLink.onclick = handleOpenAssumptions
    }
  }, [handleOpenAssumptions])
  const content = config.moreQuestionSectionContent
  return (
    <div>
      <Box mb={[3, 3, 5]}>
        <Typography variant="h2">{content.title}</Typography>
      </Box>
      <Grid container justify="space-around">
        <Grid item xs={12} md={6}>
          <Grid container alignItems="flex-start" spacing={3}>
            <GridIcon item>
              <DynamicIcon icon="faq" />
            </GridIcon>
            <Grid item xs>
              <Typography variant="h4" component="p" gutterBottom>
                {content.faqSubSection.title}
              </Typography>
              <Typography
                variant="body1"
                component="p"
                gutterBottom
                id="readOurFAQs"
              >
                {content.faqSubSection.description.join('')}
              </Typography>
              <ArrowButton
                href={config.links.kiwisaverMoreInfo}
                onClick={faqLinkHandler}
                aria-describedby="readOurFAQs"
                target="_blank"
                rel="noopener noreferrer"
              >
                {content.faqSubSection.arrowLinkText}
              </ArrowButton>
            </Grid>
            <Grid item xs={12} />
          </Grid>
        </Grid>
        <Grid item xs={12} md={6}>
          <Grid container alignItems="flex-start" spacing={3}>
            <GridIcon item>
              <DynamicIcon icon="contact" />
            </GridIcon>
            <Grid item xs>
              <Typography variant="h4" component="p" gutterBottom>
                {content.contactUsSubSection.title}
              </Typography>
              <Typography
                variant="body1"
                component="p"
                gutterBottom
                id="contactLink"
              >
                {content.contactUsSubSection.description.join('')}
              </Typography>
              <BasicButton
                href={config.links.kiwiSaverSpecialistsPhone.url}
                aria-describedby="callOurSpecialists"
                onClick={contactUsLinkHandler}
              >
                {config.links.kiwiSaverSpecialistsPhone.label}
              </BasicButton>
            </Grid>
            <Grid item xs={12} />
          </Grid>
        </Grid>
      </Grid>
      <Box mt={[3, 3, 6]}>
        <DisclaimerText value={config.disclosures?.join('')} />
      </Box>
    </div>
  )
}

export default RecommendationFooter
