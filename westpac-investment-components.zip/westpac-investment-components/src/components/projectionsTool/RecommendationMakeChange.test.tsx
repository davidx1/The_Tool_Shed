import React from 'react'
import RecommendationMakeChange from './RecommendationMakeChange'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { render, fireEvent } from '@testing-library/react'
import ProjectionsConfigMockData from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

describe('<RecommendationMakeChange/>', () => {
  it('should call handlers for link and buttons in the component', () => {
    const makeContributionClickHandler = jest.fn()
    const changeFundClickHandler = jest.fn()
    const { getByText } = render(
      <InvestToolsProvider>
        <RecommendationMakeChange
          onMakeContributionClick={makeContributionClickHandler}
          onChangeFundClick={changeFundClickHandler}
          config={ProjectionsConfigMockData}
        />
      </InvestToolsProvider>
    )
    fireEvent.click(getByText('Making contributions'))
    expect(makeContributionClickHandler).toBeCalledTimes(1)
    fireEvent.click(getByText('Changing funds'))
    expect(changeFundClickHandler).toBeCalledTimes(1)
  })
})
