import React from 'react'

import RecommendationFooter from './RecommendationFooter'
import config from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/RecommendationFooter',
  component: RecommendationFooter,
}

export const Basic = () => (
  <RecommendationFooter config={config} handleOpenAssumptions={() => {}} />
)
