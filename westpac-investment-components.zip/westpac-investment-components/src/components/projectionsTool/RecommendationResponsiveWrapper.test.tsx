import React from 'react'
import { RecommendationResponsiveWrapper } from './RecommendationResponsiveWrapper'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { render, screen } from '@testing-library/react'

import mediaQuery from 'css-mediaquery'

function createMatchMedia(width: number) {
  return (query: string) => ({
    matches: mediaQuery.match(query, { width }),
    addListener: () => {},
    removeListener: () => {},
  })
}

it('The Wrapper renders the child elements', () => {
  const c1Text = 'hello world'
  const c2Text = 'FooBar'
  const child1 = <h1>{c1Text}</h1>
  const child2 = <h2>{c2Text}</h2>

  Object.defineProperty(window, 'matchMedia', {
    value: createMatchMedia(1280),
    writable: true,
    configurable: true,
  })

  render(
    <InvestToolsProvider>
      <RecommendationResponsiveWrapper leftChild={child1} rightChild={child2} />
    </InvestToolsProvider>
  )
  const { getByText } = screen

  expect(getByText(c1Text)).toBeVisible()
  expect(getByText(c2Text)).toBeVisible()
})

it('The Wrapper renders the child elements', () => {
  const c1Text = 'hello world'
  const c2Text = 'FooBar'
  const child1 = <h1>{c1Text}</h1>
  const child2 = <h2>{c2Text}</h2>

  Object.defineProperty(window, 'matchMedia', {
    value: createMatchMedia(500),
  })

  render(
    <InvestToolsProvider>
      <RecommendationResponsiveWrapper leftChild={child1} rightChild={child2} />
    </InvestToolsProvider>
  )
  const { getByText } = screen

  expect(getByText(c1Text)).toBeVisible()
  expect(getByText(c2Text)).toBeVisible()
})
