import React from 'react'
import ChangeFundChoiceDialog from './ChangeFundChoiceDialog'
import user from '@testing-library/user-event'
import { render, screen } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

it('should render and work properly', () => {
  const close = jest.fn()
  const left = jest.fn()
  const right = jest.fn()
  render(
    <InvestToolsProvider>
      <ChangeFundChoiceDialog
        open={true}
        onClose={close}
        onLeftButtonClick={left}
        onRightButtonClick={right}
        contents={projectionsConfigMockData.dialog}
        isShowingFundDisclaimer={false}
        fundDisclaimer={['']}
      />
    </InvestToolsProvider>
  )

  const { getByText, getByLabelText } = screen

  user.click(getByLabelText('Close'))
  expect(close).toHaveBeenCalledTimes(1)

  user.click(getByText('Change fund'))
  expect(left).toHaveBeenCalledTimes(1)

  user.click(getByText('Go to Fund Chooser'))
  expect(right).toHaveBeenCalledTimes(1)
})
