import React, { useState } from 'react'
import Button from '../../inputs/Button'
import ChangeFundLoginChoiceDialog from './ChangeFundLoginChoiceDialog'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Dialog/ChangeFundLoginChoiceDialog',
  component: ChangeFundLoginChoiceDialog,
}

export const Basic = () => {
  const [isOpen, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open</Button>
      <ChangeFundLoginChoiceDialog
        open={isOpen}
        onClose={() => setOpen(false)}
        onLeftButtonClick={() => alert('left Clicked')}
        onRightButtonClick={() => alert('right Clicked')}
        contents={projectionsConfigMockData.dialog}
      />
    </div>
  )
}
