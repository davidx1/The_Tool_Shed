import { Box } from '@material-ui/core'
import React, { useLayoutEffect } from 'react'
import styled, { css } from 'styled-components'
import { IKiwisaverProjectionsDialogContent } from '../../../utils/projections-tools/projectionsToolUtils'
import DynamicIcon from '../../dataDisplay/DynamicIcon'
import HTMLRenderer, { DialogText } from '../../dataDisplay/HTMLRenderer'
import ChoiceDialog, {
  Props as ChoiceDialogProps,
} from '../../dialog/ChoiceDialog'

type Props = Pick<
  ChoiceDialogProps,
  Exclude<
    keyof ChoiceDialogProps,
    | 'title'
    | 'leftButtonTitle'
    | 'rightButtonTitle'
    | 'leftButtonLabel'
    | 'rightButtonLabel'
    | 'children'
  >
> & {
  contents: IKiwisaverProjectionsDialogContent
  isShowingFundDisclaimer: boolean
  fundDisclaimer: string[]
}

const ChangeFundChoiceDialog = ({
  contents,
  isShowingFundDisclaimer,
  fundDisclaimer,
  ...props
}: Props) => {
  const content = contents.choiceDialog.changeFundDialog
  useLayoutEffect(() => {
    let openFundChooserLink = document.getElementById(
      'kiwisaver-projection-fund-too-aggressive-disclaimer-link'
    )
    if (openFundChooserLink) {
      openFundChooserLink.onclick = props.onRightButtonClick
    }
  }, [props.onRightButtonClick])
  return (
    <ChoiceDialog
      {...props}
      title={content.title}
      leftButtonTitle={content.leftButtonTitle}
      rightButtonTitle={content.rightButtonTitle}
      leftButtonLabel={content.leftButtonLabel}
      rightButtonLabel={content.rightButtonLabel}
    >
      {isShowingFundDisclaimer && (
        <DisclosureWrapper>
          <Box mr={2}>
            <StyledDynamicIcon icon="infoFill" height="24" width="24" />
          </Box>
          <HTMLRenderer type="div" value={fundDisclaimer.join('')} />
        </DisclosureWrapper>
      )}
      {content.body && content.body.length && (
        <DialogText type="div" value={content.body.join('')} />
      )}
    </ChoiceDialog>
  )
}

export default ChangeFundChoiceDialog

const DisclosureWrapper = styled(Box).attrs({
  p: 2,
  mb: 2,
})`
  ${({ theme }) => css`
    display: flex;
    background-color: ${theme.palette.primary.dark};
    color: ${theme.palette.primary.contrastText};
    & {
      a {
        cursor: pointer;
        text-decoration: underline;
        color: ${theme.palette.primary.contrastText};
        font-weight: ${theme.typography.fontWeightMedium};
        :hover {
          color: ${theme.palette.primary.contrastText};
        }
      }
    }
  `}
`

const StyledDynamicIcon = styled(DynamicIcon)`
  path {
    fill: white;
  }
`
