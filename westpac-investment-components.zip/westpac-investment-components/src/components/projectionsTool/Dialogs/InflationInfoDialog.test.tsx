import React from 'react'
import InflationInfoDialog from './InflationInfoDialog'
import user from '@testing-library/user-event'
import { render, screen } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

it('should render and work properly', () => {
  const close = jest.fn()

  render(
    <InvestToolsProvider>
      <InflationInfoDialog
        open={true}
        onClose={close}
        contents={projectionsConfigMockData.dialog}
      />
    </InvestToolsProvider>
  )

  const { getByText, getByLabelText } = screen

  expect(getByText('How the calculator deals with inflation.')).toBeVisible()

  user.click(getByLabelText('Close'))
  expect(close).toHaveBeenCalledTimes(1)
})
