import React from 'react'
import { IKiwisaverProjectionsDialogContent } from '../../../utils/projections-tools/projectionsToolUtils'
import { DialogText } from '../../dataDisplay/HTMLRenderer'
import ChoiceDialog, {
  Props as ChoiceDialogProps,
} from '../../dialog/ChoiceDialog'

type Props = Pick<
  ChoiceDialogProps,
  Exclude<
    keyof ChoiceDialogProps,
    | 'title'
    | 'leftButtonTitle'
    | 'rightButtonTitle'
    | 'leftButtonLabel'
    | 'rightButtonLabel'
    | 'children'
  >
> & {
  contents: IKiwisaverProjectionsDialogContent
}

const MakeContributionChoiceDialog = ({ contents, ...props }: Props) => {
  const content = contents.choiceDialog.makeContributionDialog
  return (
    <ChoiceDialog
      {...props}
      title={content.title}
      leftButtonTitle={content.leftButtonTitle}
      rightButtonTitle={content.rightButtonTitle}
      leftButtonLabel={content.leftButtonLabel}
      rightButtonLabel={content.rightButtonLabel}
    >
      {content.body && <DialogText type="div" value={content.body.join('')} />}
    </ChoiceDialog>
  )
}

export default MakeContributionChoiceDialog
