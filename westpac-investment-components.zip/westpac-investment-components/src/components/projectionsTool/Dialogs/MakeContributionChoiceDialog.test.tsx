import React from 'react'
import MakeContributionChoiceDialog from './MakeContributionChoiceDialog'
import user from '@testing-library/user-event'
import { render, screen } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

it('should render and work properly', () => {
  const close = jest.fn()
  const left = jest.fn()
  const right = jest.fn()
  render(
    <InvestToolsProvider>
      <MakeContributionChoiceDialog
        open={true}
        onClose={close}
        onLeftButtonClick={left}
        onRightButtonClick={right}
        contents={projectionsConfigMockData.dialog}
      />
    </InvestToolsProvider>
  )

  const { getByText, getByLabelText } = screen

  user.click(getByLabelText('Close'))
  expect(close).toHaveBeenCalledTimes(1)

  expect(getByText('Making contributions.')).toBeVisible()

  user.click(getByText('Login to Westpac One'))
  expect(left).toHaveBeenCalledTimes(1)

  user.click(getByText('Find out more'))
  expect(right).toHaveBeenCalledTimes(1)
})
