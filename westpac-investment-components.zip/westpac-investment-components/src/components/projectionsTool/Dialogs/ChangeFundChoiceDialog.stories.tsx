import React, { useState } from 'react'
import Button from '../../inputs/Button'
import ChangeFundChoiceDialog from './ChangeFundChoiceDialog'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Dialog/ChangeFundChoiceDialog',
  component: ChangeFundChoiceDialog,
}

export const Basic = () => {
  const [isOpen, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open</Button>
      <ChangeFundChoiceDialog
        open={isOpen}
        onClose={() => setOpen(false)}
        onLeftButtonClick={() => alert('left Clicked')}
        onRightButtonClick={() => alert('right Clicked')}
        contents={projectionsConfigMockData.dialog}
        isShowingFundDisclaimer={true}
        fundDisclaimer={
          projectionsConfigMockData.fundSelectionTooAggressiveDisclaimer
        }
      />
    </div>
  )
}
