import React, { useState } from 'react'
import Button from '../../inputs/Button'
import AssumptionsInfoDialog from './AssumptionsInfoDialog'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Dialog/AssumptionsInfoDialog',
  component: AssumptionsInfoDialog,
}

export const Basic = () => {
  const [isOpen, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open</Button>
      <AssumptionsInfoDialog
        open={isOpen}
        onClose={() => setOpen(false)}
        contents={projectionsConfigMockData.dialog}
      />
    </div>
  )
}
