import React from 'react'
import AssumptionsInfoDialog from './AssumptionsInfoDialog'
import user from '@testing-library/user-event'
import { render, screen } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

it('should render and work properly', () => {
  const close = jest.fn()
  render(
    <InvestToolsProvider>
      <AssumptionsInfoDialog
        open={true}
        onClose={close}
        contents={projectionsConfigMockData.dialog}
      />
    </InvestToolsProvider>
  )

  const { getByText } = screen

  user.click(getByText('Go back to results'))

  expect(close).toHaveBeenCalledTimes(1)
})
