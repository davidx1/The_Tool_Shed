import React, { useState } from 'react'
import Button from '../../inputs/Button'
import InflationInfoDialog from './InflationInfoDialog'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Dialog/InflationInfoDialog',
  component: InflationInfoDialog,
}

export const Basic = () => {
  const [isOpen, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open</Button>
      <InflationInfoDialog
        open={isOpen}
        onClose={() => setOpen(false)}
        contents={projectionsConfigMockData.dialog}
      />
    </div>
  )
}
