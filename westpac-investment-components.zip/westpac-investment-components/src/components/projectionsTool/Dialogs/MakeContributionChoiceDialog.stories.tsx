import React, { useState } from 'react'
import Button from '../../inputs/Button'
import MakeContributionChoiceDialog from './MakeContributionChoiceDialog'
import projectionsConfigMockData from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Dialog/MakeContributionChoiceDialog',
  component: MakeContributionChoiceDialog,
}

export const Basic = () => {
  const [isOpen, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open</Button>
      <MakeContributionChoiceDialog
        open={isOpen}
        onClose={() => setOpen(false)}
        onLeftButtonClick={() => alert('left Clicked')}
        onRightButtonClick={() => alert('right Clicked')}
        contents={projectionsConfigMockData.dialog}
      />
    </div>
  )
}
