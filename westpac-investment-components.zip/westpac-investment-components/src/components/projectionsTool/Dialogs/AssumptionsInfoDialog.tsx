import { Box } from '@material-ui/core'
import React from 'react'
import { IKiwisaverProjectionsDialogContent } from '../../../utils/projections-tools/projectionsToolUtils'
import { DialogText } from '../../dataDisplay/HTMLRenderer'
import DialogInfo, { DialogInfoProps } from '../../dialog/DialogInfo'
import UnderlineBasicButton from '../../inputs/UnderlineBasicButton'

type Props = Pick<
  DialogInfoProps,
  Exclude<keyof DialogInfoProps, 'children'>
> & {
  contents: IKiwisaverProjectionsDialogContent
}

const AssumptionsInfoDialog = ({ contents, ...props }: Props) => {
  const content = contents.infoDialog.assumptionDialog
  return (
    <DialogInfo {...props} dialogTitle={content.title}>
      <Box bgcolor="background.paper" px={[2, 4]} pb={[4, 5]} pt={3}>
        {content.body && (
          <DialogText type="div" value={content.body.join('')} />
        )}
        <UnderlineBasicButton onClick={props.onClose}>
          {content.closeLinkText}
        </UnderlineBasicButton>
      </Box>
    </DialogInfo>
  )
}

export default AssumptionsInfoDialog
