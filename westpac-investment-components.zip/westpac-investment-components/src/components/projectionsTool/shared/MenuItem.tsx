import styled from 'styled-components'
import { MenuItem as OriginalMenuItem } from '@material-ui/core'
import { MenuItemProps } from '@material-ui/core'

export const MenuItem: typeof OriginalMenuItem = styled(OriginalMenuItem)<
  MenuItemProps
>`
  white-space: normal;
  line-height: ${({ theme }) => theme.typography.pxToRem(26)};
`
