import React from 'react'
import { MenuItem } from './MenuItem'

export default {
  title: 'projectionsTool/shared/MenuItem',
  component: MenuItem,
}

export const Basic = () => <MenuItem>This is the title of a panel</MenuItem>
