import React, { useState } from 'react'
import { Select } from './Select'
import { MenuItem } from './MenuItem'

export default {
  title: 'projectionsTool/shared/Select',
  component: Select,
}

export const GenericSelect = () => {
  const [value, setValue] = useState(1)

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    setValue(event.target.value as number)
  }

  return (
    <>
      <Select value={value} onChange={handleChange}>
        <MenuItem value={1}>Item 1</MenuItem>
        <MenuItem value={2}>Item 2</MenuItem>
        <MenuItem value={3}>Item 3</MenuItem>
        <MenuItem value={4}>Item 4</MenuItem>
      </Select>
    </>
  )
}
