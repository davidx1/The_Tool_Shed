import styled, { css } from 'styled-components'

const baseDotStyle = css<{ml?: number, mr?: number, mt?: number, mb?: number}>`
  height: 10px;
  width: 10px;
  border-radius: 50%;
  display: inline-block;
  margin-left: ${({theme, ml = 0}) => theme.spacing(ml)}px;
  margin-right: ${({theme, mr = 0}) => theme.spacing(mr)}px;
  margin-top: ${({theme, mt = 0}) => theme.spacing(mt)}px;
  margin-bottom: ${({theme, mb = 0}) => theme.spacing(mb)}px;
`

export const ChangedDot = styled.span`
  ${baseDotStyle}
  background-color: #9f4585;
`

export const ExistingDot = styled.span`
  ${baseDotStyle}
  background-color: #2a8289;
`
