import { Typography } from '@material-ui/core'
import styled, { css } from 'styled-components'

export const PanelTitle = styled(Typography).attrs({
  component: 'p',
  variant: 'h6',
  gutterBottom: false,
})`
  display: inline-flex;
`

export const PanelTitleWrapper = styled.div(
  ({ theme }) => css`
    display: flex;
    justify-content: space-between;
    margin-bottom: ${theme.spacing(2)}px;
  `
)
