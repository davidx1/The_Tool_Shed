import React from 'react'
import { IKiwisaverContributionFrequencyType } from '../../../utils/projections-tools/projectionsToolUtils'
import { Select } from './Select'
import { MenuItem } from './MenuItem'

export interface Props {
  value: IKiwisaverContributionFrequencyType
  onChange: (frequency: IKiwisaverContributionFrequencyType) => void
  isAllLowerCase: boolean
  ariaLabel: string
}

export const FrequencySelect = ({
  value,
  onChange,
  isAllLowerCase,
  ariaLabel,
}: Props) => {
  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    onChange(event.target.value as IKiwisaverContributionFrequencyType)
  }

  return (
    <Select value={value} onChange={handleChange} aria-label={ariaLabel}>
      {Object.entries(frequencyKeyLabelMap).map(([fValue, fLabel]) => (
        <MenuItem key={fValue} value={fValue}>
          {isAllLowerCase ? fLabel.toLowerCase() : fLabel}
        </MenuItem>
      ))}
    </Select>
  )
}

type FrequencyLabelMap = {
  [key in IKiwisaverContributionFrequencyType]: string
}

const frequencyKeyLabelMap: FrequencyLabelMap = {
  weekly: 'Weekly',
  fortnightly: 'Fortnightly',
  monthly: 'Monthly',
  annually: 'Annually',
}
