import styled, { css } from 'styled-components'
import { Select as OriginalSelect, MenuProps } from '@material-ui/core'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'

const menuProps: Partial<MenuProps> = {
  anchorOrigin: {
    vertical: 'bottom',
    horizontal: 'left',
  },
  transformOrigin: {
    vertical: 'top',
    horizontal: 'left',
  },
  getContentAnchorEl: null,
  PaperProps: {
    style: {
      maxHeight: 280,
      maxWidth: 240,
    },
  },
}

export const Select = styled(OriginalSelect).attrs({
  displayEmpty: true,
  MenuProps: menuProps,
  IconComponent: ExpandMoreIcon,
})`
  display: inline-table;
  ${({ theme }) => css`
    && {
      margin-top: 0px;
    }

    .MuiSelect-icon {
      top: calc(50% - 15px);
      color: ${theme.palette.text.primary};
    }
    .MuiSelect-select {
      white-space: normal;
      color: ${theme.palette.primary.main};
      font-weight: ${theme.typography.fontWeightMedium};
      padding: ${theme.spacing(0, 3, 0.5, 0.5)};
    }

    &::before {
      right: 5px;
      border-color: ${theme.palette.success.main};
    }
  `}
`
