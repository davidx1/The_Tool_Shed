import React, { useState } from 'react'
import { FrequencySelect } from './FrequencySelect'
import { IKiwisaverContributionFrequencyType } from '../../../utils/projections-tools/projectionsToolUtils'

export default {
  title: 'projectionsTool/shared/FrequencySelect',
  component: FrequencySelect,
}

export const Basic = () => {
  const [value, setValue] = useState<IKiwisaverContributionFrequencyType>(
    'weekly'
  )

  return (
    <>
      <div>
        <FrequencySelect
          ariaLabel="demo all lower case"
          value={value}
          onChange={setValue}
          isAllLowerCase
        />
      </div>
      <div>
        <FrequencySelect
          ariaLabel="demo capitalized"
          value={value}
          onChange={setValue}
          isAllLowerCase={false}
        />
      </div>
    </>
  )
}
