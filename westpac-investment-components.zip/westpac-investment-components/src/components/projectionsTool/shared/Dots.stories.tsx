import React from 'react'
import { ChangedDot, ExistingDot } from './Dots'

export default {
  title: 'projectionsTool/shared/Dots',
  component: ChangedDot,
}

export const Basic = () => (
  <>
    <ChangedDot />
    <ExistingDot />
  </>
)
