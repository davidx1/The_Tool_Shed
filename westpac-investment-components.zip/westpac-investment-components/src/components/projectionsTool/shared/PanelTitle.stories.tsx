import React from 'react'
import { PanelTitle } from './PanelTitle'

export default {
  title: 'projectionsTool/shared/PanelTitle',
  component: PanelTitle,
}

export const Basic = () => <PanelTitle>This is the title of a panel</PanelTitle>
