import React from 'react'

import { RecommendationSummary } from './RecommendationSummary'
import config from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/RecommendationSummary',
  component: RecommendationSummary,
}

export const Basic = () => (
  <RecommendationSummary
    currentAge={18}
    retireAge={65}
    firstHomeWithdrawalAge={0}
    isIncludingSuperannuation={true}
    postRetirementIncomeFrequency="weekly"
    handleShowInflationInfo={() => {}}
    balanceAtRetirement={{
      finalAmount: 4657,
      nominalAmount: 11812.431071818422,
      withdrawableAmount: 4263,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}
    balanceAtWithdrawal={{
      finalAmount: 2000,
      nominalAmount: 2000,
      withdrawableAmount: 1000,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}
    config={config}
  />
)

export const SummaryWithWithdrawal = () => (
  <RecommendationSummary
    currentAge={18}
    retireAge={65}
    firstHomeWithdrawalAge={30}
    isIncludingSuperannuation={true}
    handleShowInflationInfo={() => {}}
    postRetirementIncomeFrequency="annually"
    balanceAtRetirement={{
      finalAmount: 4657,
      nominalAmount: 11812.431071818422,
      withdrawableAmount: 4263,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}
    balanceAtWithdrawal={{
      finalAmount: 2000,
      nominalAmount: 2000,
      withdrawableAmount: 1000,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}
    config={config}
  />
)

export const SummaryWithoutSuper = () => (
  <RecommendationSummary
    currentAge={18}
    retireAge={65}
    firstHomeWithdrawalAge={0}
    isIncludingSuperannuation={false}
    handleShowInflationInfo={() => {}}
    postRetirementIncomeFrequency="monthly"
    balanceAtRetirement={{
      finalAmount: 4657,
      nominalAmount: 11812.431071818422,
      withdrawableAmount: 4263,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}
    balanceAtWithdrawal={{
      finalAmount: 2000,
      nominalAmount: 2000,
      withdrawableAmount: 1000,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}
    config={config}
  />
)
