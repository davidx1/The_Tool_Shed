import React, { useLayoutEffect } from 'react'
import styled, { css } from 'styled-components'
import { checkIsWithdrawing } from '../../utils/projections-tools/checkIsWithdrawing'

import { Box, Typography } from '@material-ui/core'

import {
  CONTRIBUTION_FREQUENCY_SUFFIX,
  IKiwisaverContributionFrequencyType,
  IKiwisaverProjectionsConfig,
} from '../../utils/projections-tools/projectionsToolUtils'
import { CalculateReturn } from '../../utils/projections-tools/projectionsCalculation'
import { getCurrencyString } from '../../utils/projections-tools/getCurrencyString'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import { DialogText } from '../dataDisplay/HTMLRenderer'

export interface Prop {
  balanceAtRetirement: CalculateReturn
  balanceAtWithdrawal: CalculateReturn
  currentAge: number
  retireAge: number
  firstHomeWithdrawalAge: number
  postRetirementIncomeFrequency: IKiwisaverContributionFrequencyType
  isIncludingSuperannuation: boolean
  handleShowInflationInfo: () => void
  config: IKiwisaverProjectionsConfig
}

export const RecommendationSummary = ({
  balanceAtRetirement,
  balanceAtWithdrawal,
  retireAge,
  firstHomeWithdrawalAge,
  currentAge,
  postRetirementIncomeFrequency,
  isIncludingSuperannuation,
  handleShowInflationInfo,
  config,
}: Prop) => {
  useLayoutEffect(() => {
    let openDetailedInflationInfo = document.getElementById(
      'kiwisaver-projection-calculator-inflation-disclaimer-link'
    )
    if (openDetailedInflationInfo) {
      openDetailedInflationInfo.onclick = handleShowInflationInfo
    }
  }, [handleShowInflationInfo])

  const isWithdrawing = checkIsWithdrawing(
    currentAge,
    retireAge,
    firstHomeWithdrawalAge
  )

  const withdrawalYearsFromNowValue = firstHomeWithdrawalAge - currentAge
  const withdrawalYearsFromNowUnit =
    withdrawalYearsFromNowValue > 1 ? 'years' : 'year'

  const postRetirementPayments = getCurrencyString(
    balanceAtRetirement.payments[postRetirementIncomeFrequency]
  )

  const withdrawalAmountString = getCurrencyString(
    balanceAtWithdrawal.withdrawableAmount
  )

  const postRetirementIncomePeriodSuffix =
    CONTRIBUTION_FREQUENCY_SUFFIX[postRetirementIncomeFrequency]

  return (
    <div>
      <Typography variant="h2" gutterBottom>
        Your current projection.
      </Typography>
      <Box mt={1} mb={4}>
        <TypographyLead>
          {isWithdrawing ? (
            <React.Fragment>
              In{' '}
              <Emphasize>
                {withdrawalYearsFromNowValue} {withdrawalYearsFromNowUnit}
              </Emphasize>{' '}
              time we estimate you could withdraw{' '}
              <Emphasize>{withdrawalAmountString}</Emphasize> from your
              KiwiSaver savings to help with the purchase of your first home.
              Along with this, you
            </React.Fragment>
          ) : (
            'You'
          )}{' '}
          could have a retirement income of{' '}
          <Emphasize>
            {postRetirementPayments} {postRetirementIncomePeriodSuffix}
          </Emphasize>{' '}
          if you were to retire at <Emphasize>{retireAge}</Emphasize>. This
          income would last you until age{' '}
          <Emphasize>{config.lifeExpectancy}</Emphasize>
          {isIncludingSuperannuation ? '.' : ' and is not including NZ Super.'}
        </TypographyLead>
      </Box>
      <Box display="flex">
        <Box mr={1}>
          <DynamicIcon icon="infoFill" height="16" width="16" />
        </Box>
        <DialogText
          type="div"
          value={config.summaryInflationDisclaimer.join('')}
        />
      </Box>
    </div>
  )
}

const TypographyLead = styled(Typography).attrs({
  component: 'p',
  variant: 'subtitle1',
})`
  ${({ theme }) => css`
    ${theme.breakpoints.down('sm')} {
      font-size: ${theme.typography.pxToRem(20)};
      line-height: ${theme.typography.pxToRem(26)};
    }
  `}
`

const Emphasize = styled(Typography).attrs({
  component: 'span',
  variant: 'subtitle1',
})`
  ${({ theme }) => css`
    font-weight: 700;
    ${theme.breakpoints.down('sm')} {
      font-size: ${theme.typography.pxToRem(20)};
      line-height: ${theme.typography.pxToRem(26)};
    }
  `}
`
