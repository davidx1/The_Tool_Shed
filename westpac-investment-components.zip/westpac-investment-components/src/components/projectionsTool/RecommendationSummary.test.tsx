import React from 'react'
import { render, screen } from '@testing-library/react'
import { RecommendationSummary } from './RecommendationSummary'
import { InvestToolsProvider } from '../InvestToolsProvider'

import ProjectionsConfigMockData from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

it('should render correctly', () => {
  const balanceAtRetirement = {
    finalAmount: 6000,
    nominalAmount: 6500,
    withdrawableAmount: 5500,
    payments: {
      weekly: 100,
      fortnightly: 200,
      monthly: 400,
      annually: 4800,
    },
  }
  const balanceAtWithdrawal = {
    finalAmount: 2000,
    nominalAmount: 2500,
    withdrawableAmount: 1500,
    payments: {
      weekly: 50,
      fortnightly: 100,
      monthly: 200,
      annually: 2400,
    },
  }

  const originalProps = {
    balanceAtRetirement: balanceAtRetirement,
    balanceAtWithdrawal: balanceAtWithdrawal,
    currentAge: 20,
    retireAge: 65,
    firstHomeWithdrawalAge: 30,
    postRetirementIncomeFrequency: 'weekly' as const,
    isIncludingSuperannuation: true,
    handleShowInflationInfo: () => {},
    config: ProjectionsConfigMockData,
  }
  const { rerender } = render(
    <InvestToolsProvider>
      <RecommendationSummary {...originalProps} />
    </InvestToolsProvider>
  )

  const { getByText, queryByText } = screen

  const infoOnSuper = /and is not including NZ Super./

  // Multiple years should use plural form of the unit
  expect(getByText('10 years')).toBeVisible()
  expect(queryByText(infoOnSuper)).toBeNull()

  const newProps = {
    ...originalProps,
    firstHomeWithdrawalAge: 21,
    isIncludingSuperannuation: false,
  }

  rerender(
    <InvestToolsProvider>
      <RecommendationSummary {...newProps} />
    </InvestToolsProvider>
  )

  // Single years should use singular form of the unit
  expect(getByText('1 year')).toBeVisible()
  expect(getByText(infoOnSuper)).toBeVisible()
})
