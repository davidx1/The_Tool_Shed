import React from 'react'

import { GraphFinalProjectionGlyph } from './GraphFinalProjectionGlyph'

export default {
  title: 'projectionsTool/Graph/GraphFinalProjectionGlyph',
  component: GraphFinalProjectionGlyph,
}

export const Basic = () => (
  <svg>
    <GraphFinalProjectionGlyph
      circleColor="#9f4585"
      left={200}
      top={10}
      value={'$100000'}
      isDetailed={false}
    />
    <GraphFinalProjectionGlyph
      circleColor="#00ff51"
      left={200}
      top={40}
      value={'$1000000'}
      isDetailed={false}
    />
    <GraphFinalProjectionGlyph
      circleColor="#003ffc"
      left={200}
      top={70}
      value={'$10000000'}
      isDetailed={false}
    />
    <GraphFinalProjectionGlyph
      circleColor="#fff200"
      left={200}
      top={100}
      value={'$100000000'}
      isDetailed={false}
    />
    <GraphFinalProjectionGlyph
      circleColor="#ff002f"
      left={200}
      top={130}
      value={'$1000000000'}
      isDetailed={false}
    />
  </svg>
)
