import React, { useState } from 'react'
import styled from 'styled-components'
import { RESPONSIVE_GRAPH_PLOT_HEIGHT } from './Graph'
import { GraphPlot } from './GraphPlot'
import { projectionsCalculation } from '../../../utils/projections-tools/projectionsCalculation'
import config from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Graph/GraphPlot',
  component: GraphPlot,
}

export const Basic = () => {
  const [firstHomeWithdrawalAge, setFirstWithdrawalAge] = useState(30)
  const curriedNewCalculation = (projectedAge: number) =>
    projectionsCalculation({
      initialBalance: 2345,
      investmentRate: 0.035,
      currentAge: 18,
      calculationEndAge: projectedAge,
      voluntaryContributionRate: 0,
      voluntaryContributionFrequency: 'annually',
      salary: 50000,
      salaryContributionRate: 0.03,
      firstHomeWithdrawalAge,
      isIncludingSuperannuation: true,
      relationshipStatus: 'single',
      config,
    })

  const curriedOldCalculation = (projectedAge: number) =>
    projectionsCalculation({
      currentAge: 18,
      calculationEndAge: projectedAge,
      initialBalance: 2345,
      investmentRate: 0.045,
      voluntaryContributionRate: 200,
      voluntaryContributionFrequency: 'annually',
      salary: 50000,
      salaryContributionRate: 0.04,
      firstHomeWithdrawalAge,
      isIncludingSuperannuation: true,
      relationshipStatus: 'single',
      config,
    })

  return (
    <Wrapper>
      <GraphPlot
        isControlDirty
        currentAge={18}
        retireAge={65}
        firstHomeWithdrawalAge={firstHomeWithdrawalAge}
        setFirstHomeWithdrawalAge={setFirstWithdrawalAge}
        curriedNewCalculation={curriedNewCalculation}
        curriedOldCalculation={curriedOldCalculation}
        responsiveGraphHeights={RESPONSIVE_GRAPH_PLOT_HEIGHT}
        config={config}
      />
    </Wrapper>
  )
}

const Wrapper = styled.div`
  width: 100%;
  height: 500px;
`
