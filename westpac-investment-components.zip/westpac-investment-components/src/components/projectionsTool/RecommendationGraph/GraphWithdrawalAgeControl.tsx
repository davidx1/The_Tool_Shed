import React, { forwardRef } from 'react'
import KeyboardArrowLeftIcon from '@material-ui/icons/KeyboardArrowLeft'
import KeyboardArrowRightIcon from '@material-ui/icons/KeyboardArrowRight'
import { Drag } from '@visx/drag'

import DynamicIcon from '../../dataDisplay/DynamicIcon'

export interface Point {
  x: number
  y: number
}

export interface Prop {
  x?: number
  y?: number
  /* onDragMove takes a function and passes in delta x as parameter */
  onDragMove: (newX: number) => void
  onDragStart?: () => void
  onDragEnd?: () => void
}

export const GraphWithdrawalAgeControl = forwardRef<SVGCircleElement, Prop>(
  ({ x = 0, y = 0, onDragMove, onDragStart, onDragEnd }: Prop, ref) => {
    return (
      <Drag
        height={500}
        width={500}
        onDragEnd={onDragEnd}
        onDragStart={onDragStart}
        onDragMove={({ dx }) => {
          onDragMove(dx)
        }}
        resetOnStart
      >
        {({ dragStart, dragEnd, dragMove, isDragging }) => {
          const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
            e.stopPropagation()
            e.preventDefault()
            dragStart(e)
          }

          return (
            <React.Fragment>
              <defs>
                <filter
                  id="first-home-purchase-graph-shadow"
                  x={-2}
                  y={-2}
                  width="200"
                  height="200"
                >
                  <feGaussianBlur stdDeviation="2" />
                </filter>
                <linearGradient
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                  id="first-home-withdrawal-indicator-line-gradient"
                  gradientTransform="rotate(45)"
                >
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="50%" stopColor="#f79cdd" />
                  <stop offset="80%" stopColor="#ffffff" />
                </linearGradient>
              </defs>
              <g>
                <rect
                  x={x - 1}
                  y={y - 52}
                  width={2}
                  height={80}
                  fill="url('#first-home-withdrawal-indicator-line-gradient')"
                />

                <circle
                  cx={x}
                  cy={y}
                  r={isDragging ? 20 : 15}
                  fill={isDragging ? '#9F4586' : '#aaaaaa'}
                  fillOpacity={0.3}
                  filter="url('#first-home-purchase-graph-shadow')"
                />
                <circle cx={x} cy={y} r={12.5} fill="white" fillOpacity={1} />
                <DynamicIcon
                  x={x - 7.5}
                  y={y - 7.5}
                  height="15"
                  width="15"
                  icon="houseFill"
                />
                <KeyboardArrowLeftIcon
                  x={x - 30}
                  y={y - 10}
                  height="20"
                  width="20"
                />
                <KeyboardArrowRightIcon
                  x={x + 10}
                  y={y - 10}
                  height="20"
                  width="20"
                />
                <circle
                  cx={x}
                  cy={y}
                  r={500}
                  fillOpacity={0}
                  onTouchMove={dragMove}
                  onTouchEnd={dragEnd}
                  onMouseMove={dragMove}
                  onMouseUp={dragEnd}
                  ref={ref}
                />
                <circle
                  cx={x}
                  cy={y}
                  r={10}
                  fillOpacity={0}
                  onTouchMove={dragMove}
                  onTouchEnd={dragEnd}
                  onTouchStart={handleDragStart}
                  onMouseDown={handleDragStart}
                  onMouseMove={dragMove}
                  onMouseUp={dragEnd}
                  ref={ref}
                />
              </g>
            </React.Fragment>
          )
        }}
      </Drag>
    )
  }
)
