import React from 'react'
import { GraphShowHideBanner } from './GraphShowHideBanner'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import { render, screen } from '@testing-library/react'
import user from '@testing-library/user-event'

it('renders and runs correctly', () => {
  const clickTrigger = jest.fn()
  const { rerender } = render(
    <InvestToolsProvider>
      <GraphShowHideBanner isHiding={true} onClick={clickTrigger} />
    </InvestToolsProvider>
  )

  const { getByText, queryByText } = screen
  user.click(getByText('Show graph'))
  expect(clickTrigger).toHaveBeenCalledTimes(1)

  rerender(
    <InvestToolsProvider>
      <GraphShowHideBanner isHiding={false} onClick={clickTrigger} />
    </InvestToolsProvider>
  )

  expect(queryByText('Show graph')).toBe(null)
  user.click(getByText('Hide graph'))
  expect(clickTrigger).toHaveBeenCalledTimes(2)
})
