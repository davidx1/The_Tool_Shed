import React, { FC } from 'react'
import { Grid, Typography } from '@material-ui/core'
import { getCurrencyString } from '../../../utils/projections-tools/getCurrencyString'
import { ExistingDot, ChangedDot } from '../shared/Dots'
import styled, { css } from 'styled-components'
import { Tooltip as OgTooltip } from '@visx/tooltip'

export interface Prop {
  firstHomeWithdrawalAge: number
  currentAge: number
  retireAge: number
  amountWithdrawnOld: number
  amountWithdrawnNew: number
  x: number
  y: number
  variant?: 'natural' | 'centred' | 'flipped'
  hide: boolean
  isControlDirty: boolean
}

export const GraphWithdrawalTooltip: FC<Prop> = (props) => {
  const {
    firstHomeWithdrawalAge,
    currentAge,
    retireAge,
    amountWithdrawnOld,
    amountWithdrawnNew,
    x,
    y,
    hide,
    isControlDirty
  } = props

  const withdrawalYearsFromNow = firstHomeWithdrawalAge - currentAge

  if (x < 0 && y < 0) {
    return null
  }

  // Calculate, in terms of percentage where the first home withdrawal happens
  // between the current age and retire age.
  // if we are in the first 1/3 of the graph, show the tooltip on top right
  // if we are in the middle 1/3, show it right above the control knob
  // if we are i the right 1/3, show the tooltip on the top left
  const withdrawalAgePercentage =
    withdrawalYearsFromNow / (retireAge - currentAge)

  const yPos = y < 70 ? 'bottom' : 'top'
  const xPos =
    withdrawalAgePercentage < 0.33
      ? 'right'
      : withdrawalAgePercentage < 0.66
      ? 'centre'
      : 'left'

  const yPosMap = {
    top: y - 70,
    bottom: y + 70,
  }

  const xPosMap = {
    right: x,
    centre: x - 95,
    left: x - 170,
  }

  return (
    <Tooltip top={yPosMap[yPos]} left={xPosMap[xPos]} $hide={hide}>
      <Arrow yPos={yPos} xPos={xPos} />
      <Description>
        First home withdrawal in:{' '}
        <Emphasize>
          {withdrawalYearsFromNow}{' '}
          {withdrawalYearsFromNow === 1 ? 'Year' : 'Years'}
        </Emphasize>
      </Description>
      <Grid spacing={4} container>
        <Grid item>
          <Typography variant="overline">ESTIMATED</Typography>
          <Amount>
            <ExistingDot /> {getCurrencyString(amountWithdrawnOld)}*
          </Amount>
        </Grid>
        {isControlDirty && (
          <Grid item>
            <Typography variant="overline">UPDATED</Typography>
            <Amount>
              <ChangedDot /> {getCurrencyString(amountWithdrawnNew)}*
            </Amount>
          </Grid>
        )}
      </Grid>
    </Tooltip>
  )
}

const Tooltip = styled(OgTooltip)<{ $hide: boolean }>`
  ${({ theme, $hide }) => css`
    background-color: ${theme.palette.common.white};
    box-shadow: ${theme.shadows[1]};
    width: 240px;
    color: black;
    z-index: 1300;
    position: absolute;
    padding: ${theme.spacing(1)}px;
    pointer-events: none;
    opacity: ${$hide ? '0' : '1'};
    transition: opacity 250ms;
  `}
`

const arrowSize = 10

const Arrow = styled.div<{
  yPos: 'top' | 'bottom'
  xPos: 'left' | 'centre' | 'right'
}>`
  ${({ xPos, yPos }) => css`
    position: absolute;
    left: ${xPos === 'right' ? '25px' : xPos === 'centre' ? '120px' : '195px'};
    top: ${yPos === 'bottom' && `-${arrowSize}px`};
    bottom: ${yPos === 'top' && `-${arrowSize}px`};
    width: 0;
    height: 0;
    border-left: ${arrowSize}px solid transparent;
    border-right: ${arrowSize}px solid transparent;
    border-top: ${yPos === 'top' && `${arrowSize}px solid white`};
    border-bottom: ${yPos === 'bottom' && `${arrowSize}px solid white`};
    filter: ${yPos === 'top'
      ? `drop-shadow(1px 2px 1px #cccccc)`
      : `drop-shadow(1px -1px 1px #eeeeee)`};
    @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
      /* IE11 Doesn't have the filter option for drop shadow, so you couldn't 
         see the arrow. So turning the arrows black instead*/
      border-top: ${yPos === 'top' && `${arrowSize}px solid black`};
      border-bottom: ${yPos === 'bottom' && `${arrowSize}px solid black`};
    }
  `}
`

const Description = styled(Typography).attrs({
  variant: 'overline',
  gutterBottom: true,
})`
  color: ${({ theme }) => theme.palette.text.primary};
`

const Amount = styled(Typography).attrs({
  variant: 'overline',
  gutterBottom: true,
})`
  color: ${({ theme }) => theme.palette.text.primary};
  font-weight: ${({ theme }) => theme.typography.fontWeightMedium};
`

const Emphasize = styled.span`
  font-weight: ${({ theme }) => theme.typography.fontWeightMedium};
`
