import React, { useState } from 'react'
import { projectionsCalculation } from '../../../utils/projections-tools/projectionsCalculation'
import { IKiwisaverContributionFrequencyType } from '../../../utils/projections-tools/projectionsToolUtils'
import config from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

import { Graph } from './Graph'

export default {
  title: 'projectionsTool/Graph/Graph',
  component: Graph,
}

export const Basic = () => {
  const [retireAge, setRetireAge] = useState(65)
  const [firstHomeWithdrawalAge, setFirstHomeWithdrawalAge] = useState(30)
  const [
    postRetirementIncomeFrequency,
    setPostRetirementIncomeFrequency,
  ] = useState<IKiwisaverContributionFrequencyType>('weekly')

  const curriedNewCalculation = (projectedAge: number) =>
    projectionsCalculation({
      currentAge: 18,
      calculationEndAge: projectedAge,
      initialBalance: 800,
      investmentRate: 0.045,
      voluntaryContributionRate: 20,
      voluntaryContributionFrequency: 'weekly',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      firstHomeWithdrawalAge,
      config,
    })

  const curriedOldCalculation = (projectedAge: number) =>
    projectionsCalculation({
      currentAge: 18,
      calculationEndAge: projectedAge,
      initialBalance: 800,
      investmentRate: 0.035,
      voluntaryContributionRate: 20,
      voluntaryContributionFrequency: 'weekly',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      firstHomeWithdrawalAge,
      config,
    })

  return (
    <Graph
      isControlDirty
      currentAge={18}
      retireAge={retireAge}
      setRetireAge={setRetireAge}
      firstHomeWithdrawalAge={firstHomeWithdrawalAge}
      setFirstHomeWithdrawalAge={setFirstHomeWithdrawalAge}
      curriedNewCalculation={curriedNewCalculation}
      curriedOldCalculation={curriedOldCalculation}
      postRetirementIncomeFrequency={postRetirementIncomeFrequency}
      setPostRetirementIncomeFrequency={setPostRetirementIncomeFrequency}
      config={config}
    />
  )
}
