import React from 'react'
import styled from 'styled-components'
import { GraphWithdrawalTooltip } from './GraphWithdrawalTooltip'

export default {
  title: 'projectionsTool/Graph/GraphWithdrawalTooltip',
  component: GraphWithdrawalTooltip,
}

export const Basic = () => (
  <Wrapper>
    <GraphWithdrawalTooltip
      isControlDirty
      firstHomeWithdrawalAge={40}
      currentAge={18}
      retireAge={65}
      hide={false}
      amountWithdrawnOld={2000}
      amountWithdrawnNew={3000}
      x={0}
      y={0}
    >
      <Item></Item>
    </GraphWithdrawalTooltip>
  </Wrapper>
)

export const EarlyWithdrawal = () => (
  <Wrapper>
    <GraphWithdrawalTooltip
      isControlDirty
      firstHomeWithdrawalAge={20}
      currentAge={18}
      amountWithdrawnOld={2000}
      amountWithdrawnNew={3000}
      retireAge={65}
      hide={false}
      x={0}
      y={0}
    >
      <Item></Item>
    </GraphWithdrawalTooltip>
  </Wrapper>
)

export const MidWithdrawal = () => (
  <Wrapper>
    <GraphWithdrawalTooltip
      isControlDirty
      firstHomeWithdrawalAge={40}
      currentAge={18}
      amountWithdrawnOld={2000}
      amountWithdrawnNew={3000}
      retireAge={65}
      hide={false}
      x={0}
      y={0}
    >
      <Item></Item>
    </GraphWithdrawalTooltip>
  </Wrapper>
)

export const LateWithdrawal = () => (
  <Wrapper>
    <GraphWithdrawalTooltip
      isControlDirty
      firstHomeWithdrawalAge={60}
      currentAge={18}
      amountWithdrawnOld={2000}
      amountWithdrawnNew={3000}
      retireAge={65}
      hide={false}
      x={0}
      y={0}
    >
      <Item></Item>
    </GraphWithdrawalTooltip>
  </Wrapper>
)

export const WithdrawalBeforeCurrentAge = () => (
  <Wrapper>
    <GraphWithdrawalTooltip
      isControlDirty
      firstHomeWithdrawalAge={17}
      currentAge={18}
      amountWithdrawnOld={2000}
      amountWithdrawnNew={3000}
      retireAge={65}
      hide={false}
      x={0}
      y={0}
    >
      <Item></Item>
    </GraphWithdrawalTooltip>
  </Wrapper>
)

export const WithdrawalAfterRetirementAge = () => (
  <Wrapper>
    <GraphWithdrawalTooltip
      isControlDirty
      firstHomeWithdrawalAge={17}
      currentAge={18}
      amountWithdrawnOld={2000}
      amountWithdrawnNew={3000}
      retireAge={65}
      hide={false}
      x={0}
      y={0}
    >
      <Item></Item>
    </GraphWithdrawalTooltip>
  </Wrapper>
)

const Wrapper = styled.div`
  display: flex;
  width: 100%;
  height: 300px;
  justify-content: center;
  align-items: center;
`

const Item = styled.div`
  width: 100px;
  height: 100px;
  background-color: lightgray;
  border: 1px solid black;
`
