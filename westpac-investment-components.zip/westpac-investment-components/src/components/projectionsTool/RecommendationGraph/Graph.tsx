import React, { useLayoutEffect, useMemo, useRef, useState } from 'react'
import styled, { css } from 'styled-components'

import {
  IKiwisaverContributionFrequencyType,
  IKiwisaverProjectionsConfig,
} from '../../../utils/projections-tools/projectionsToolUtils'
import { GraphPlot } from './GraphPlot'
import { GraphWeeklyIncomeBanner } from './GraphWeeklyIncomeBanner'
import {
  Box,
  Container,
  Paper,
  useMediaQuery,
  useTheme,
} from '@material-ui/core'
import { PanelTitle, PanelTitleWrapper } from '../shared/PanelTitle'
import { Select } from '../shared/Select'
import { MenuItem } from '../shared/MenuItem'
import { CalculateReturn } from '../../../utils/projections-tools/projectionsCalculation'
import { Portal } from '@material-ui/core'
import { GraphShowHideBanner } from './GraphShowHideBanner'
import { DisclaimerText } from '../../dataDisplay/HTMLRenderer'
import { useShortScreenState } from '../../../hooks/useShortScreenState'

export const RESPONSIVE_GRAPH_PLOT_HEIGHT = {
  md: 400,
  sm: 350,
  xs: 215,
  default: 500,
}

export interface GraphProps {
  currentAge: number
  retireAge: number
  setRetireAge: (age: number) => void
  firstHomeWithdrawalAge: number
  setFirstHomeWithdrawalAge: (age: number) => void
  curriedNewCalculation: (n: number) => CalculateReturn
  curriedOldCalculation: (n: number) => CalculateReturn
  postRetirementIncomeFrequency: IKiwisaverContributionFrequencyType
  setPostRetirementIncomeFrequency: (
    value: IKiwisaverContributionFrequencyType
  ) => void
  scrollContainerRef?: React.RefObject<HTMLElement>
  isControlDirty: boolean
  config: IKiwisaverProjectionsConfig
}

export const Graph = ({
  currentAge,
  retireAge,
  setRetireAge,
  firstHomeWithdrawalAge,
  setFirstHomeWithdrawalAge,
  curriedNewCalculation,
  curriedOldCalculation,
  postRetirementIncomeFrequency,
  setPostRetirementIncomeFrequency,
  scrollContainerRef,
  isControlDirty,
  config,
}: GraphProps) => {
  const wrapperRef = useRef<HTMLDivElement>(null)
  const theme = useTheme()
  const isMediaLg = useMediaQuery(theme.breakpoints.up('lg'))
  const isMediaMd = useMediaQuery(theme.breakpoints.down('md'))
  const isMediaSm = useMediaQuery(theme.breakpoints.down('sm'))
  const isMediaXs = useMediaQuery(theme.breakpoints.down('xs'))
  const [isPinPlot, setIsPinPlot] = useState(false)

  const onScreenGrow = (delta: number) => scrollTarget.scrollBy(0, -delta)
  const { isShortScreen } = useShortScreenState(500, undefined, onScreenGrow)

  const graphHeightKey = isMediaXs
    ? 'xs'
    : isMediaSm
    ? 'sm'
    : isMediaMd
    ? 'md'
    : 'default'
  const graphHeight = RESPONSIVE_GRAPH_PLOT_HEIGHT[graphHeightKey]

  const scrollTarget = scrollContainerRef?.current || window

  useLayoutEffect(() => {
    const handleScroll = () => {
      const top = wrapperRef?.current?.getBoundingClientRect().top
      if (!isPinPlot && top && top < -graphHeight + 100) {
        setIsPinPlot(true)
      }
      if (isPinPlot && top && top > -graphHeight + 100) {
        setIsPinPlot(false)
      }
    }
    if (scrollTarget) {
      scrollTarget.addEventListener('scroll', handleScroll, false)
      return () =>
        scrollTarget.removeEventListener('scroll', handleScroll, false)
    }
    return
  }, [scrollTarget, graphHeight, isPinPlot, setIsPinPlot])

  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    setRetireAge(event.target.value as number)
  }

  const ageRanges = useMemo(() => {
    const retirementDuration =
      config.lifeExpectancy - config.defaultRetirementAge
    return Array.from(
      { length: retirementDuration },
      (_, i) => config.defaultRetirementAge + i
    )
  }, [config.defaultRetirementAge, config.lifeExpectancy])

  const newResult = curriedNewCalculation(retireAge)
  const oldResult = curriedOldCalculation(retireAge)
  const [isHideGraph, setHideGraph] = useState(true)

  const Banner = (
    <GraphWeeklyIncomeBanner
      retireAge={retireAge}
      incomeFrequency={postRetirementIncomeFrequency}
      setIncomeFrequency={setPostRetirementIncomeFrequency}
      newResult={newResult}
      oldResult={oldResult}
      isControlDirty={isControlDirty}
    />
  )

  const Plot = (
    <GraphPlot
      currentAge={currentAge}
      retireAge={retireAge}
      curriedNewCalculation={curriedNewCalculation}
      curriedOldCalculation={curriedOldCalculation}
      firstHomeWithdrawalAge={firstHomeWithdrawalAge}
      setFirstHomeWithdrawalAge={setFirstHomeWithdrawalAge}
      responsiveGraphHeights={RESPONSIVE_GRAPH_PLOT_HEIGHT}
      isControlDirty={isControlDirty}
      config={config}
    />
  )

  return (
    <Wrapper ref={wrapperRef}>
      <Container disableGutters={!isMediaXs}>
        <PanelTitleWrapper>
          <span>
            <PanelTitle>Your estimated balance at age</PanelTitle>
            <Select
              value={retireAge}
              onChange={handleChange}
              aria-label="retirement age listbox"
            >
              {ageRanges.map((age) => (
                <MenuItem key={age} value={age}>
                  {age}
                </MenuItem>
              ))}
            </Select>
          </span>
        </PanelTitleWrapper>
      </Container>
      <Paper elevation={4}>
        <Box
          display="flex"
          flexDirection={isMediaXs ? 'column-reverse' : 'column'}
        >
          <BoxWithBackground px={2}>{Banner}</BoxWithBackground>
          <Box px={[0, 3]}>
            <div>{Plot}</div>
          </Box>
        </Box>
      </Paper>
      {!isMediaLg && isPinPlot && !isShortScreen && (
        <React.Fragment>
          <Portal>
            <PortalSectionWrapper>
              <Paper elevation={4}>
                <Box p={2}>{Banner}</Box>
                <React.Fragment>
                  <SmallBoxWithBackground p={2}>
                    <GraphShowHideBanner
                      onClick={() => setHideGraph(!isHideGraph)}
                      isHiding={isHideGraph}
                    ></GraphShowHideBanner>
                  </SmallBoxWithBackground>
                  {!isHideGraph && (
                    <Box px={[0, 3]}>
                      <div>{Plot}</div>
                    </Box>
                  )}
                </React.Fragment>
              </Paper>
            </PortalSectionWrapper>
          </Portal>
        </React.Fragment>
      )}
      {!!firstHomeWithdrawalAge && (
        <StyledDisclaimer value={config.projectedAmountDisclaimer.join('')} />
      )}
    </Wrapper>
  )
}

const Wrapper = styled.div`
  ${({ theme }) => css`
    ${theme.breakpoints.down('xs')} {
      width: 100vw;
      margin-left: calc(50% - 50vw);
    }
  `}
`

const PortalSectionWrapper = styled.section`
  z-index: 1300;
  position: fixed;
  background-color: white;
  top: 0;
  left: 0;
  right: 0;
`

const BoxWithBackground = styled(Box)`
  background: ${({ theme }) => theme.palette.background.light};
  height: 76px;
  align-items: center;
  display: flex;
`

const SmallBoxWithBackground = styled(BoxWithBackground)`
  height: 30px;
`

const StyledDisclaimer = styled(DisclaimerText)`
  margin-top: ${({ theme }) => theme.spacing(1)}px;
`
