import React, { useState } from 'react'
import { GraphWithdrawalAgeControl } from './GraphWithdrawalAgeControl'

export default {
  title: 'projectionsTool/Graph/GraphWithdrawalAgeControl',
  component: GraphWithdrawalAgeControl,
}

export const Basic = () => {
  const [x, setX] = useState(100)
  const [startX, setStartX] = useState(0)

  return (
    <svg width="100%">
      <text x={0} y={20}>Position: {x}</text>
      <GraphWithdrawalAgeControl
        onDragMove={(newX) => {
          setX(startX + newX)}
        }
        onDragStart={() => {
          setStartX(x)
        }}
        x={x}
        y={50}
      />
    </svg>
  )
}
