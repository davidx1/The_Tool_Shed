import React from 'react'

import { GraphWeeklyIncomeBanner } from './GraphWeeklyIncomeBanner'

export default {
  title: 'projectionsTool/Graph/GraphWeeklyIncomeBanner',
  component: GraphWeeklyIncomeBanner,
}

export const SameOldAndNewResult = () => (
    <GraphWeeklyIncomeBanner
      isControlDirty
      retireAge={65}
      setIncomeFrequency={()=>{}}
      incomeFrequency="weekly"
      newResult={{
        finalAmount: 1986,
        nominalAmount: 5037.284039154978,
        withdrawableAmount: 1592,
        payments: {
          weekly: 2,
          fortnightly: 3,
          monthly: 7,
          annually: 84,
        },
      }}
      oldResult={{
        finalAmount: 1986,
        nominalAmount: 5037.284039154978,
        withdrawableAmount: 1592,
        payments: {
          weekly: 2,
          fortnightly: 3,
          monthly: 7,
          annually: 84,
        },
      }}

    />
)

export const DifferentOldAndNewResult = () => (
  <GraphWeeklyIncomeBanner
    isControlDirty
    retireAge={65}
    setIncomeFrequency={()=>{}}
    incomeFrequency="weekly"
    newResult={{
      finalAmount: 1986,
      nominalAmount: 5037.284039154978,
      withdrawableAmount: 1592,
      payments: {
        weekly: 2,
        fortnightly: 3,
        monthly: 7,
        annually: 84,
      },
    }}
    oldResult={{
      finalAmount: 4657,
      nominalAmount: 11812.431071818422,
      withdrawableAmount: 4263,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    }}

  />
)
