import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, Grid, Box } from '@material-ui/core'
import { FrequencySelect } from '../shared/FrequencySelect'
import { ExistingDot, ChangedDot } from '../shared/Dots'
import { getCurrencyString } from '../../../utils/projections-tools/getCurrencyString'
import { CalculateReturn } from '../../../utils/projections-tools/projectionsCalculation'
import { IKiwisaverContributionFrequencyType } from '../../../utils/projections-tools/projectionsToolUtils'

export interface Props {
  retireAge: number
  incomeFrequency: IKiwisaverContributionFrequencyType
  setIncomeFrequency: (input: IKiwisaverContributionFrequencyType) => void
  newResult: CalculateReturn
  oldResult: CalculateReturn
  isControlDirty: boolean
}

export const GraphWeeklyIncomeBanner = ({
  newResult,
  oldResult,
  incomeFrequency,
  setIncomeFrequency,
  isControlDirty
}: Props) => {
  const paymentNew = getCurrencyString(newResult.payments[incomeFrequency])
  const paymentOld = getCurrencyString(oldResult.payments[incomeFrequency])

  return (
    <Grid container wrap="nowrap" alignItems="center">
      <Grid item xs={6}>
        <FrequencySelect
          ariaLabel="post retirement payment frequency listbox"
          value={incomeFrequency}
          onChange={setIncomeFrequency}
          isAllLowerCase={false}
        />{' '}
        <InlineTypography>income when retired.</InlineTypography>
      </Grid>
      <Grid item xs={6}>
        <Box display="flex" justifyContent={'flex-end'}>
          <EndAlignedText>
            <IncomeLabel>ESTIMATE</IncomeLabel>
            <NowrapSpan>
              <ExistingDot ml={1} mr={1} />
              <IncomeAmount>{paymentOld}</IncomeAmount>
            </NowrapSpan>
          </EndAlignedText>
          {isControlDirty && (
            <Box ml={[2, 4]}>
              <EndAlignedText>
                <IncomeLabel>UPDATED</IncomeLabel>
                <NowrapSpan>
                  <ChangedDot ml={1} mr={1}/>
                  <IncomeAmount>{paymentNew}</IncomeAmount>
                </NowrapSpan>
              </EndAlignedText>
            </Box>
          )}
        </Box>
      </Grid>
    </Grid>
  )
}

const NowrapSpan = styled.span`
  white-space: nowrap;
`

const InlineTypography = styled(Typography)`
  display: inline-flex;
`

const EndAlignedText = styled(Typography)`
  text-align: end;
`

const IncomeLabel = styled.span`
  ${({ theme }) => css`
    color: ${theme.palette.highlight.secondary};
    font-weight: ${theme.typography.fontWeightMedium};
    font-size: ${theme.typography.pxToRem(14)};
  `}
`

const IncomeAmount = styled.span`
  ${({ theme }) => css`
    font-weight: ${theme.typography.fontWeightMedium};
    font-size: ${theme.typography.pxToRem(16)};
  `}
`
