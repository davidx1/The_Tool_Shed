import { Box, Typography } from '@material-ui/core'
import React from 'react'
import styled, { css } from 'styled-components'
import DynamicIcon from '../../dataDisplay/DynamicIcon'

interface Props {
  onClick: () => void
  isHiding: boolean
}

export const GraphShowHideBanner = ({ onClick, isHiding }: Props) => {
  const text = isHiding ? 'Show graph' : 'Hide graph'
  return (
    <Wrapper onClick={onClick}>
      <StatusText>{text}</StatusText>
      <ArrowIcon $isFlip={!isHiding} />
    </Wrapper>
  )
}

const ArrowIcon = styled(DynamicIcon).attrs({ icon: 'arrowDown' })<{
  $isFlip: boolean
}>`
  ${({ $isFlip, theme }) =>
    css`
      transform: ${$isFlip ? 'rotate(180deg)' : 'rotate(0deg)'};
      transition: transform 500ms;
      width: 18px;
      > path {
        stroke: ${theme.palette.primary.main};
        stroke-width: 3;
      }
    `}
`

const Wrapper = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: flex-start;
  cursor: pointer;
  ${({ theme }) => theme.breakpoints.down('xs')} {
    justify-content: space-between;
  }
`

const StatusText = styled(Typography).attrs({ variant: 'body1' })`
  ${({ theme }) => css`
    color: ${theme.palette.primary.main};
    margin-right: ${theme.spacing(1)}px;
    font-weight: ${theme.typography.fontWeightMedium};
  `}
`
