import React from 'react'
import { Glyph } from '@vx/glyph'
import styled from 'styled-components'

export interface Prop {
  circleColor: string
  /** The Glyph is anchored at the center of the circle in the glyph.
   *  If left is set to 0, then most of the glyph will be off screen left */
  left: number
  /** The Glyph is anchored at the center of the circle in the glyph.
   *  If top is set to 0, then most of the glyph will be off screen top */
  top: number
  /** The value text to display in the glyph */
  value: string
  isDetailed: boolean
}

export const GraphFinalProjectionGlyph = ({
  circleColor,
  left,
  top,
  value,
  isDetailed,
}: Prop) => {
  //Expand glyph horizontally by 5 pixels per character over 8 characters
  const expandBy = value.length > 6 ? (value.length - 6) * 6 : 0
  const spaceForText = 64 + expandBy

  return (
    <Glyph left={left - spaceForText} top={top - 11}>
      <FadingGroup isShowing={isDetailed}>
        <rect
          width={80 + expandBy}
          height="22"
          fill="white"
          stroke="#f3f3f3"
          strokeWidth="2"
          ry="20"
          rx="10"
        />
        <text
          fontSize="12"
          fontWeight="500"
          y="15"
          x="10"
        >
          {value}
        </text>
      </FadingGroup>
      <circle r="7" fill={circleColor} cx={spaceForText} cy="11" />
    </Glyph>
  )
}

const FadingGroup = styled.g<{ isShowing: boolean }>`
  transition: opacity 250ms;
  opacity: ${({ isShowing }) => (isShowing ? '100' : '0')};
`
