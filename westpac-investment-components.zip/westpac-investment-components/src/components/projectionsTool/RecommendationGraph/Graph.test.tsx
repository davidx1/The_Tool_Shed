import React from 'react'
import { Graph } from './Graph'
import { render, screen, waitFor } from '@testing-library/react'

import { projectionsCalculation } from '../../../utils/projections-tools/projectionsCalculation'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import userEvent from '@testing-library/user-event'
import config from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'
import mediaQuery from 'css-mediaquery'

function createMatchMedia(width: number) {
  return (query: string) => ({
    matches: mediaQuery.match(query, { width }),
    addListener: () => {},
    removeListener: () => {},
  })
}

global.document.createRange = () => ({
  setStart: () => {},
  setEnd: () => {},
  commonAncestorContainer: {
    nodeName: 'BODY',
    ownerDocument: document,
  },
})

describe('<Graph/>', () => {
  it('should render and work properly', async () => {
    const firstHomeWithdrawalAge = 18
    const retireAge = 65
    const setRetireAge = jest.fn()
    const setFirstHomeWithdrawalAge = jest.fn()
    const postRetirementIncomeFrequency = 'weekly'
    const setPostRetirementIncomeFrequency = jest.fn()

    Object.defineProperty(window, 'matchMedia', {
      value: createMatchMedia(1920),
      writable: true,
      configurable: true,
    })

    const curriedNewCalculation = (projectedAge: number) =>
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: projectedAge,
        initialBalance: 800,
        investmentRate: 0.045,
        voluntaryContributionRate: 20,
        voluntaryContributionFrequency: 'weekly',
        salary: 50000,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        firstHomeWithdrawalAge,
        config,
      })

    const curriedOldCalculation = (projectedAge: number) =>
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: projectedAge,
        initialBalance: 800,
        investmentRate: 0.035,
        voluntaryContributionRate: 20,
        voluntaryContributionFrequency: 'weekly',
        salary: 50000,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        firstHomeWithdrawalAge,
        config,
      })

    render(
      <InvestToolsProvider>
        <Graph
          currentAge={18}
          retireAge={retireAge}
          setRetireAge={setRetireAge}
          firstHomeWithdrawalAge={firstHomeWithdrawalAge}
          setFirstHomeWithdrawalAge={setFirstHomeWithdrawalAge}
          curriedNewCalculation={curriedNewCalculation}
          curriedOldCalculation={curriedOldCalculation}
          postRetirementIncomeFrequency={postRetirementIncomeFrequency}
          setPostRetirementIncomeFrequency={setPostRetirementIncomeFrequency}
          config={config}
        />
      </InvestToolsProvider>
    )

    const { getByText } = screen

    // Check that the post retirement income frequency can be changed
    userEvent.click(getByText('Weekly'))
    await waitFor(() => {
      expect(getByText('Monthly')).toBeVisible()
    })

    expect(getByText('Monthly')).toBeVisible()
    expect(getByText('Annually')).toBeVisible()

    userEvent.click(getByText('Annually'))
    expect(setPostRetirementIncomeFrequency).toBeCalledWith('annually')

    //Check that the retirement age can be changed
    userEvent.click(getByText('65'))
    await waitFor(() => {
      expect(getByText('66')).toBeVisible()
    })

    userEvent.click(getByText('66'))
    expect(setRetireAge).toBeCalledWith(66)
  })
})
