import React, { useMemo, useState, useCallback } from 'react'
import { AxisBottom } from '@vx/axis'
import { LinePath } from '@vx/shape'
import { Group } from '@vx/group'
import { ParentSize } from '@vx/responsive'
import { scaleLinear } from '@visx/scale'
import { AnimatedAxis, AnimatedGridRows } from '@visx/react-spring'

import { max } from 'd3-array'

import { GraphFinalProjectionGlyph } from './GraphFinalProjectionGlyph'
import { GraphWithdrawalAgeControl } from './GraphWithdrawalAgeControl'
import { GraphWithdrawalTooltip } from './GraphWithdrawalTooltip'
import {
  getCurrencyString,
  getMoneyAbbreviated,
} from '../../../utils/projections-tools/getCurrencyString'

import {
  generateGraphDataArray,
  GraphDataType,
} from '../../../utils/projections-tools/generateGraphDataArray'

import { CalculateReturn } from '../../../utils/projections-tools/projectionsCalculation'
import styled, { css } from 'styled-components'
import { useMediaQuery, useTheme } from '@material-ui/core'
import { IKiwisaverProjectionsConfig } from '../../../utils/projections-tools/projectionsToolUtils'

const margin = {
  top: 45,
  bottom: 45,
  left: 60,
  right: 24,
}

export interface IGraphData {
  currentAge: number
  retireAge: number
  firstHomeWithdrawalAge: number
  setFirstHomeWithdrawalAge: (age: number) => void
  curriedNewCalculation: (age: number) => CalculateReturn
  curriedOldCalculation: (age: number) => CalculateReturn
  isControlDirty: boolean
}

export interface RawProps {
  width: number
  height: number
  data: IGraphData
  config: IKiwisaverProjectionsConfig
}
export interface IResponsiveGraphHeights {
  md: number
  sm: number
  xs: number
  default: number
}

export interface Props extends IGraphData {
  responsiveGraphHeights: IResponsiveGraphHeights
  config: IKiwisaverProjectionsConfig
}

const RawGraphPlot = ({
  width,
  height,
  data: {
    isControlDirty,
    currentAge,
    retireAge,
    firstHomeWithdrawalAge,
    setFirstHomeWithdrawalAge,
    curriedNewCalculation,
    curriedOldCalculation,
  },
  config,
}: RawProps) => {
  const theme = useTheme()

  const isXs = useMediaQuery(theme.breakpoints.down('xs'))

  const {
    isShowingRetirementTooltip,
    isShowingWithdrawalTooltip,
    toggleTooltips,
  } = useTooltips(!!firstHomeWithdrawalAge)

  const [withdrawalAgeOnDragStart, setWithdrawalAgeOnDragStart] = useState(
    firstHomeWithdrawalAge
  )

  const [isWithdrawalAgeDragging, setIsWithdrawalAgeDragging] = useState(false)

  const curriedNewY = useCallback(
    (age: number) => curriedNewCalculation(age).finalAmount,
    [curriedNewCalculation]
  )

  const curriedOldY = useCallback(
    (age: number) => curriedOldCalculation(age).finalAmount,
    [curriedOldCalculation]
  )

  const {
    finalAmount: newBalanceBeforeFirstHomeWithdrawal,
    withdrawableAmount: amountWithdrawnNew,
  } = curriedNewCalculation(firstHomeWithdrawalAge)

  const {
    finalAmount: oldBalanceBeforeFirstHomeWithdrawal,
    withdrawableAmount: amountWithdrawnOld,
  } = curriedOldCalculation(firstHomeWithdrawalAge)

  // The control knob for first home withdrawal
  // should appear above both the original graph
  // and the updated graph. So it's Y position is in relative
  // to whichever graph have the higher balance right before withdrawal
  const highestBalanceBeforeFirstHomeWithdrawal =
    max([
      newBalanceBeforeFirstHomeWithdrawal,
      oldBalanceBeforeFirstHomeWithdrawal,
    ]) || 0

  const ageDiff = retireAge - currentAge + 1

  const data = useMemo(
    () =>
      generateGraphDataArray({
        currentAge,
        firstHomeWithdrawalAge,
        retireAge,
        ageDiff,
        newBalanceBeforeFirstHomeWithdrawal,
        oldBalanceBeforeFirstHomeWithdrawal,
        curriedNewY,
        curriedOldY,
      }),
    [
      currentAge,
      firstHomeWithdrawalAge,
      retireAge,
      ageDiff,
      newBalanceBeforeFirstHomeWithdrawal,
      oldBalanceBeforeFirstHomeWithdrawal,
      curriedNewY,
      curriedOldY,
    ]
  )

  const { oldY: finalIncomeOld, newY: finalIncomeNew } = data[data.length - 1]

  const biggestYValues = (d: GraphDataType) => max([d.newY, d.oldY])
  const biggestXValues = (d: GraphDataType) => d.x

  const yValueMax = max(data, biggestYValues) || 0
  const xValueMax = max(data, biggestXValues) || 0
  const xRangeMax = width - margin.left - margin.right
  const yRangeMax = height - margin.top - margin.bottom

  const xScale = scaleLinear<number>({
    range: [0, xRangeMax],
    domain: [currentAge, xValueMax],
  })

  const yScale = scaleLinear<number>({
    range: [yRangeMax, 0],
    domain: [0, yValueMax * 1.1],
    nice: true,
  })

  const baseTickLabelProps = {
    fill: '#949494',
    fontSize: 14,
  }

  const xTickLabelProps = () => ({
    ...baseTickLabelProps,
  })

  const yTickLabelProps = () =>
    ({
      ...baseTickLabelProps,
      textAnchor: 'end',
      dy: '0.2em',
    } as const)

  const withdrawalControlX = xScale(firstHomeWithdrawalAge)
  const withdrawalControlY =
    yScale(highestBalanceBeforeFirstHomeWithdrawal) - 30

  const handleWithdrawalAgeControlDragStart = () => {
    setIsWithdrawalAgeDragging(true)
    toggleTooltips(true)
    setWithdrawalAgeOnDragStart(firstHomeWithdrawalAge)
  }

  const handleWithdrawalAgeControlDragEnd = () => {
    setIsWithdrawalAgeDragging(false)
  }

  const handleWithdrawalAgeControlMove = (dx: number) => {
    const delta = Math.round(dx / xScale(currentAge + 1))
    const newAge = withdrawalAgeOnDragStart + delta
    //First home withdrawal cannot be larger than the default retirement age(65),
    //And it cannot be larger than the user defined retire age, whatever is smaller.
    //And it cannot be less than the current age;
    const boundedValue =
      newAge >= Math.min(config.defaultRetirementAge, retireAge)
        ? Math.min(config.defaultRetirementAge, retireAge) - 1
        : newAge <= currentAge
        ? currentAge + 1
        : newAge
    setFirstHomeWithdrawalAge(boundedValue)
  }

  return (
    <Wrapper onMouseDown={() => toggleTooltips(false)}>
      <svg width={width} height={height} style={{ touchAction: 'none' }}>
        <Group left={margin.left} top={margin.top}>
          <AxisBottom
            scale={xScale}
            numTicks={3}
            top={yRangeMax}
            tickFormat={(v) => `${v}y`}
            tickLabelProps={xTickLabelProps}
            hideAxisLine
            hideTicks
          />
          <AnimatedAxis
            orientation="left"
            scale={yScale}
            numTicks={isXs ? 2 : 5}
            top={0}
            left={0}
            tickFormat={(amount: number | { valueOf(): number } = 0) =>
              getMoneyAbbreviated(
                typeof amount === 'number' ? amount : amount.valueOf()
              )
            }
            tickLabelProps={yTickLabelProps}
            hideAxisLine
            hideTicks
            animationTrajectory="min"
          />
          <AnimatedGridRows
            scale={yScale}
            width={xRangeMax}
            numTicks={isXs ? 2 : 5}
            stroke={theme.palette.background.grey}
            animationTrajectory="min"
          />
          <LinePath
            key="existingProjections"
            stroke="#2A8289"
            data={data}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={4}
            y={(d: GraphDataType) => yScale(d.oldY)}
            x={(d: GraphDataType) => xScale(d.x)}
          />
          {isControlDirty && (
            <LinePath
              key="newProjection"
              stroke="#9f4585"
              data={data}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={4}
              y={(d: GraphDataType) => yScale(d.newY)}
              x={(d: GraphDataType) => xScale(d.x)}
            />
          )}
          <GraphFinalProjectionGlyph
            circleColor="#2A8289"
            left={xScale(retireAge)}
            top={yScale(finalIncomeOld)}
            value={getCurrencyString(finalIncomeOld)}
            isDetailed={isShowingRetirementTooltip}
          />
          {isControlDirty && (
            <GraphFinalProjectionGlyph
              circleColor="#9f4585"
              left={xScale(retireAge)}
              top={yScale(finalIncomeNew)}
              value={getCurrencyString(finalIncomeNew)}
              isDetailed={isShowingRetirementTooltip}
            />
          )}
          {firstHomeWithdrawalAge && (
            <GraphWithdrawalAgeControl
              x={withdrawalControlX}
              y={withdrawalControlY}
              onDragMove={handleWithdrawalAgeControlMove}
              onDragStart={handleWithdrawalAgeControlDragStart}
              onDragEnd={handleWithdrawalAgeControlDragEnd}
            />
          )}
        </Group>
      </svg>
      <GraphWithdrawalTooltip
        currentAge={currentAge}
        firstHomeWithdrawalAge={firstHomeWithdrawalAge}
        amountWithdrawnNew={amountWithdrawnNew}
        amountWithdrawnOld={amountWithdrawnOld}
        retireAge={retireAge}
        y={withdrawalControlY}
        x={withdrawalControlX + 16}
        hide={!isShowingWithdrawalTooltip || (isXs && isWithdrawalAgeDragging)}
        isControlDirty={isControlDirty}
      />
    </Wrapper>
  )
}

export const GraphPlot = ({
  responsiveGraphHeights,
  config,
  ...props
}: Props) => {
  return (
    <GraphHeightWrapper responsiveGraphHeights={responsiveGraphHeights}>
      <ParentSize>
        {(parent) => (
          <RawGraphPlot
            width={parent.width}
            height={parent.height}
            data={props}
            config={config}
          />
        )}
      </ParentSize>
    </GraphHeightWrapper>
  )
}

const GraphHeightWrapper = styled.div<{
  responsiveGraphHeights: IResponsiveGraphHeights
}>`
  ${({ theme, responsiveGraphHeights }) => css`
    width: 100%;
    height: ${responsiveGraphHeights.default}px;
    ${theme.breakpoints.down('md')} {
      height: ${responsiveGraphHeights.md}px;
    }
    ${theme.breakpoints.down('sm')} {
      height: ${responsiveGraphHeights.sm}px;
    }
    ${theme.breakpoints.down('xs')} {
      height: ${responsiveGraphHeights.xs}px;
    }
  `}
`

const Wrapper = styled.div`
  overflow: hidden;
  position: relative;
`

const useTooltips = (isWithdrawing: boolean) => {
  const [isShowingWithdrawalTooltip, setIsShowingWithdrawalTooltip] = useState(
    true
  )

  const theme = useTheme()
  const isMediaSm = useMediaQuery(theme.breakpoints.down('sm'))

  if (!isWithdrawing) {
    return {
      isShowingWithdrawalTooltip: false,
      isShowingRetirementTooltip: true,
      toggleTooltips: () => {},
    }
  }

  const toggleTooltips = (newVal?: boolean) => {
    if (isMediaSm) {
      const valToSet =
        newVal !== undefined ? newVal : !isShowingWithdrawalTooltip
      setIsShowingWithdrawalTooltip(valToSet)
    }
  }

  const isShowingRetirementTooltip = !isMediaSm || !isShowingWithdrawalTooltip

  return {
    isShowingWithdrawalTooltip,
    isShowingRetirementTooltip,
    toggleTooltips,
  }
}
