import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Grid, Typography, Button } from '@material-ui/core'

import { IKiwisaverProjectionsConfig } from '../../utils/projections-tools/projectionsToolUtils'
import { DialogText } from '../dataDisplay/HTMLRenderer'

export interface Props {
  onChangeFundClick: () => void
  onMakeContributionClick: () => void
  config: IKiwisaverProjectionsConfig
}

const ActionButtons = styled.div(
  ({ theme }) => css`
    display: flex;
    justify-content: flex-end;
    align-items: center;
    width: 100%;

    button:first-child {
      margin: ${theme.spacing(0, 4, 0, 0)};
    }

    ${theme.breakpoints.down('md')} {
      button:first-child {
        margin: ${theme.spacing(0, 2, 0, 0)};
      }
    }

    ${theme.breakpoints.down('sm')} {
      justify-content: flex-start;
    }

    ${theme.breakpoints.down('xs')} {
      flex-direction: column;
      justify-content: flex-start;

      button {
        width: 100%;
      }

      button:first-child {
        margin: ${theme.spacing(0, 0, 3, 0)};
      }
    }
  `
)

const FlexGrid = styled(Grid)`
  ${({ theme }) => css`
    display: flex;
    justify-content: flex-end;
    ${theme.breakpoints.down('sm')} {
      margin-top: ${theme.spacing(5)}px;
      justify-content: flex-start;
    }
  `}
`

const RecommendationMakeChange: FC<Props> = ({
  onChangeFundClick,
  onMakeContributionClick,
  config,
}) => {
  return (
    <Grid container>
      <Grid item xs={12} md={6}>
        <Typography variant="h2" gutterBottom>
          {config.makeChangeSectionContent.title}
        </Typography>
        <DialogText
          value={config.makeChangeSectionContent.description.join('')}
        />
      </Grid>
      <FlexGrid item xs={12} md={6}>
        <ActionButtons>
          <Button
            variant="contained"
            color="primary"
            onClick={onChangeFundClick}
          >
            {config.makeChangeSectionContent.rightButtonText}
          </Button>
          <Button
            variant="outlined"
            color="primary"
            onClick={onMakeContributionClick}
          >
            {config.makeChangeSectionContent.leftButtonText}
          </Button>
        </ActionButtons>
      </FlexGrid>
    </Grid>
  )
}

export default RecommendationMakeChange
