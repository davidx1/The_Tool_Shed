import React from 'react'
import RecommendationFooter from './RecommendationFooter'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { render, fireEvent } from '@testing-library/react'

import config from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

describe('<RecommendationFooter/>', () => {
  it('should call handlers for each link in the component', () => {
    const faqLinkHandler = jest.fn()
    const contactUsLinkHandler = jest.fn()
    const { getByText, getAllByText } = render(
      <InvestToolsProvider>
        <RecommendationFooter
          faqLinkHandler={faqLinkHandler}
          contactUsLinkHandler={contactUsLinkHandler}
          handleOpenAssumptions={() => {}}
          config={config}
        />
      </InvestToolsProvider>
    )
    fireEvent.click(getByText('Read our FAQs'))
    expect(faqLinkHandler).toBeCalledTimes(1)
    fireEvent.click(getAllByText('0508 972 254')[0])
    expect(contactUsLinkHandler).toBeCalledTimes(1)
  })
})
