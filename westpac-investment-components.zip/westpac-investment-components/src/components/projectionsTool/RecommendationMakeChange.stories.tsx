import React from 'react'

import RecommendationMakeChange from './RecommendationMakeChange'
import config from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/RecommendationMakeChange',
  component: RecommendationMakeChange,
}

export const Basic = () => (
  <RecommendationMakeChange
    onMakeContributionClick={() => {}}
    onChangeFundClick={() => {}}
    config={config}
  />
)
