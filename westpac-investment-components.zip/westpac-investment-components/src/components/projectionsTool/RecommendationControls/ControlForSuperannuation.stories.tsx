import React, { useState } from 'react'
import { ControlForSuperannuation } from './ControlForSuperannuation'
import { IRelationshipStatusType } from '../../../utils/projections-tools/projectionsToolUtils'

export default {
  title: 'projectionsTool/Control/ControlForSuperannuation',
  component: ControlForSuperannuation,
}

export const Basic = () => {
  const [rStatus, setRStatus] = useState<IRelationshipStatusType>('single')
  const [isIncludeSuper, setIsIncludeSuper] = useState(false)

  return (
    <ControlForSuperannuation
      relationshipStatus={rStatus}
      isIncludingSuperannuation={isIncludeSuper}
      setIsIncludingSuperannuation={setIsIncludeSuper}
      setRelationshipStatus={setRStatus}
    />
  )
}
