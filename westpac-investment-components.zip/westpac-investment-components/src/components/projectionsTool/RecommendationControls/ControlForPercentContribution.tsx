import React from 'react'
import styled, { css } from 'styled-components'
import { Grid } from '@material-ui/core'
import {
  IKiwisaverSalaryContributionRateType,
  KIWISAVER_CONTRIBUTION_RATES,
  PROJECTION_MOBILE_TABLET_BREAKPOINT,
} from '../../../utils/projections-tools/projectionsToolUtils'

import SelectButton from '../../inputs/SelectButton'

const largeCardStyle = css`
  min-width: 68px;
  padding: 8px;
`

const smallCardStyle = css`
  min-width: 56px;
  padding: 0px;
`

const ContributionCard = styled(SelectButton).attrs({
  variant: 'outlined',
  role: 'radio',
  size: 'large',
  fullWidth: true,
})(
  ({ theme }) => css`
    display: flex;
    height: 50px;
    min-height: 50px;
    ${largeCardStyle}

    ${theme.breakpoints.between(PROJECTION_MOBILE_TABLET_BREAKPOINT, 'sm')} {
      ${smallCardStyle}
    }
    ${theme.breakpoints.between('xs', PROJECTION_MOBILE_TABLET_BREAKPOINT)} {
      ${largeCardStyle}
    }
    ${theme.breakpoints.down('xs')} {
      ${smallCardStyle}
    }
  `
)

export interface Props {
  selectedPercentage: IKiwisaverSalaryContributionRateType
  selectPercentage: (percent: IKiwisaverSalaryContributionRateType) => void
}

export const ControlForPercentContribution = ({
  selectedPercentage,
  selectPercentage,
}: Props) => {
  return (
    <Grid container direction="row" justify="space-between">
      {KIWISAVER_CONTRIBUTION_RATES.map((percent) => (
        <Grid item key={percent}>
          <ContributionCard
            onClick={() => selectPercentage(percent)}
            selected={selectedPercentage === percent}
            aria-checked={false}
            icon={null}
            label={`${percent * 100}%`}
          />
        </Grid>
      ))}
    </Grid>
  )
}
