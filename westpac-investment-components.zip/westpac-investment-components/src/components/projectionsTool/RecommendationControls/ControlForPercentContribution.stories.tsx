import React, { useState } from 'react'
import { ControlForPercentContribution } from './ControlForPercentContribution'
import { IKiwisaverSalaryContributionRateType } from '../../../utils/projections-tools/projectionsToolUtils'

export default {
  title: 'projectionsTool/Control/ControlForPercentContribution',
  component: ControlForPercentContribution,
}

export const Basic = () => {
  const [rate, setRate] = useState<IKiwisaverSalaryContributionRateType>(0.03)

  return (
    <ControlForPercentContribution
      selectedPercentage={rate}
      selectPercentage={setRate}
    />
  )
}
