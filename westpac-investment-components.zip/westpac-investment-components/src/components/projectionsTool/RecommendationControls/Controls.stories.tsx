import React, { useState } from 'react'
import {
  IKiwisaverContributionFrequencyType,
  IKiwisaverSalaryContributionRateType,
  IProjectionsFundType,
  IRelationshipStatusType,
} from '../../../utils/projections-tools/projectionsToolUtils'
import { Controls } from './Controls'
import config from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/Control/Controls',
  component: Controls,
}

export const Basic = () => {
  const originalValue = {
    voluntaryContributionRate: 0,
    fundType: 'conservative',
    relationshipStatus: 'single',
    isIncludingSuperannuation: false,
    salaryContributionRate: 0.03,
    voluntaryContributionFrequency: 'weekly',
  } as const

  const [isEmployed, setIsEmployed] = useState(true)

  const [voluntaryContributionRate, setNewVoluntaryContributionRate] = useState(
    0
  )
  const [fundType, setNewFundType] = useState<IProjectionsFundType>(
    'conservative'
  )
  const [relationshipStatus, setRelationshipStatus] = useState<
    IRelationshipStatusType
  >('single')
  const [isIncludingSuperannuation, setIsIncludingSuperannuation] = useState(
    false
  )
  const [salaryContributionRate, setNewSalaryContributionRate] = useState<
    IKiwisaverSalaryContributionRateType
  >(0.03)
  const [
    voluntaryContributionFrequency,
    setVoluntaryContributionFrequency,
  ] = useState<IKiwisaverContributionFrequencyType>('weekly')

  const isDirty =
    originalValue.voluntaryContributionRate !== voluntaryContributionRate ||
    originalValue.fundType !== fundType ||
    originalValue.relationshipStatus !== relationshipStatus ||
    originalValue.isIncludingSuperannuation !== isIncludingSuperannuation ||
    originalValue.salaryContributionRate !== salaryContributionRate ||
    originalValue.voluntaryContributionFrequency !==
      voluntaryContributionFrequency ||
    originalValue.voluntaryContributionRate !== voluntaryContributionRate

  const resetControls = () => {
    setNewVoluntaryContributionRate(originalValue.voluntaryContributionRate)
    setNewFundType(originalValue.fundType)
    setRelationshipStatus(originalValue.relationshipStatus)
    setIsIncludingSuperannuation(originalValue.isIncludingSuperannuation)
    setNewSalaryContributionRate(originalValue.salaryContributionRate)
    setVoluntaryContributionFrequency(
      originalValue.voluntaryContributionFrequency
    )
  }

  return (
    <React.Fragment>
      <Controls
        fundType={fundType}
        setNewFundType={setNewFundType}
        salaryContributionRate={salaryContributionRate}
        setNewSalaryContributionRate={setNewSalaryContributionRate}
        voluntaryContributionFrequency={voluntaryContributionFrequency}
        setNewVoluntaryContributionFrequency={setVoluntaryContributionFrequency}
        voluntaryContributionRate={voluntaryContributionRate}
        setNewVoluntaryContributionRate={setNewVoluntaryContributionRate}
        isIncludingSuperannuation={isIncludingSuperannuation}
        setIsIncludingSuperannuation={setIsIncludingSuperannuation}
        relationshipStatus={relationshipStatus}
        setRelationshipStatus={setRelationshipStatus}
        salary={isEmployed ? 20_000 : 0}
        isControlDirty={isDirty}
        isShowingFundDisclaimer={fundType === "growth"}
        resetControls={resetControls}
        config={config}
      />
      <button
        style={{ position: 'absolute' }}
        onClick={() => setIsEmployed(!isEmployed)}
      >
        Toggle Employment
      </button>
    </React.Fragment>
  )
}
