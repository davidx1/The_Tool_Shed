import React from 'react'
import { Checkbox, FormControlLabel, Grid } from '@material-ui/core'
import { Select } from '../shared/Select'
import { MenuItem } from '../shared/MenuItem'
import { IRelationshipStatusType } from '../../../utils/projections-tools/projectionsToolUtils'

export interface Props {
  relationshipStatus: IRelationshipStatusType
  isIncludingSuperannuation: boolean
  setRelationshipStatus: (relationshipStatus: IRelationshipStatusType) => void
  setIsIncludingSuperannuation: (isIncludeSuperannuation: boolean) => void
}

export const ControlForSuperannuation = ({
  relationshipStatus,
  isIncludingSuperannuation,
  setRelationshipStatus,
  setIsIncludingSuperannuation,
}: Props) => {
  const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    setRelationshipStatus(event.target.value as IRelationshipStatusType)
  }

  return (
    <Grid container direction="column" alignItems="center">
      <FormControlLabel
        control={
          <Checkbox
            name="Superannuation"
            checked={isIncludingSuperannuation}
            onChange={(e) => setIsIncludingSuperannuation(e.target.checked)}
          />
        }
        label={
          <React.Fragment>
            Include NZ Superannuation{' '}
            <Select
              value={relationshipStatus}
              onChange={handleChange}
              aria-label="superannuation relationship status listbox"
            >
              {Object.entries(relationshipStatusLabelMap).map(
                ([rValue, rLabel]) => (
                  <MenuItem key={rValue} value={rValue}>
                    {rLabel}
                  </MenuItem>
                )
              )}
            </Select>
          </React.Fragment>
        }
      />
    </Grid>
  )
}

type IRelationshipStatusLabelMapType = {
  [key in IRelationshipStatusType]: string
}

const relationshipStatusLabelMap: IRelationshipStatusLabelMapType = {
  single: 'Single',
  couple: 'Couple',
}
