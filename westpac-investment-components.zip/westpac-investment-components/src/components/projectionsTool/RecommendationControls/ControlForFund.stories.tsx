import React, { useState } from 'react'
import { ControlForFund } from './ControlForFund'
import { IProjectionsFundType } from '../../../utils/projections-tools/projectionsToolUtils'

export default {
  title: 'projectionsTool/Control/ControlForFund',
  component: ControlForFund,
}

export const Basic = () => {
  const [fund, setFund] = useState<IProjectionsFundType>('conservative')

  return (
    <ControlForFund
      selectedFund={fund}
      selectFund={setFund}
      extraSidePadding={3}
    />
  )
}
