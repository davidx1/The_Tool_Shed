import React from 'react'
import { Grid, TextField } from '@material-ui/core'

import styled, { css } from 'styled-components'
export interface Props {
  setter: (v: number) => void
  value: number
}

export const ControlForVoluntaryContribution = ({ setter, value }: Props) => {
  const handleInput = (e: { target: { value: string } }) => {
    let val = e.target.value.replace(/[^0-9]/g, '')
    setter(Number(val))
  }

  const valueToDisplay = value > 0 ? value : ''

  return (
    <Grid container direction="row">
      <StyledTextField
        variant="outlined"
        value={valueToDisplay}
        onChange={handleInput}
        InputProps={{
          startAdornment: '$',
        }}
        placeholder="Enter amount"
      />
    </Grid>
  )
}

const StyledTextField = styled(TextField)`
  ${({ theme }) => css`
    width: 100%;
    max-width: 100%;
    ${theme.breakpoints.up('md')} {
      max-width: 450px;
    }
    & {
      .MuiOutlinedInput-input {
        padding: 14px 4px;
      }
      .MuiOutlinedInput-root {
        color: ${theme.palette.text.primary};

        .MuiOutlinedInput-notchedOutline {
          border-width: 1px;
          border-color: ${theme.palette.highlight.secondary};
        }

        &.Mui-focused .MuiOutlinedInput-notchedOutline {
          border-width: 1px;
          border-color: ${theme.palette.primary.dark};
          box-shadow: 0 0 6px ${theme.palette.primary.dark};
        }

        &:hover {
          .MuiOutlinedInput-notchedOutline {
            border-width: 1px;
            border-color: ${theme.palette.primary.dark};
          }
        }
      }
    }
  `}
`
