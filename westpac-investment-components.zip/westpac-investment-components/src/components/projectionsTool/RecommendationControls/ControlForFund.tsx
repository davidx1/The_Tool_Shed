import React, { useMemo } from 'react'
import styled, { css } from 'styled-components'
import { IconButton } from '@material-ui/core'
import NavigateNextIcon from '@material-ui/icons/NavigateNext'
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore'
import {
  IProjectionsFundType,
  PROJECTION_MOBILE_TABLET_BREAKPOINT,
} from '../../../utils/projections-tools/projectionsToolUtils'
import SelectButton from '../../inputs/SelectButton'
import Carousel from '../../layout/Carousel'

interface Fund {
  label: string
  value: IProjectionsFundType
}

const PlanCards = styled(SelectButton).attrs({
  variant: 'outlined',
  role: 'radio',
  size: 'large',
  fullWidth: true,
})`
  ${({ theme }) => css`
    width: 130px;
    min-height: 123px;
    height: 123px;
    ${theme.breakpoints.between(PROJECTION_MOBILE_TABLET_BREAKPOINT, 'sm')} {
      width: 120px;
    }
  `}
`

const baseButtonStyle = css`
  width: 30px;
  height: 46px;
  margin: auto;
  box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
  z-index: 2;
  transition: transform 0.3s ease;
  border-radius: 50px;
  padding: 0px;
  color: ${({ theme }) => theme.palette.tertiary.main};
  &:hover {
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
    @media (hover: none) {
      color: ${({ theme }) => theme.palette.tertiary.main};
      box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
    }
  }
  &:focus:not(:hover) {
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
    color: ${({ theme }) => theme.palette.tertiary.main};
  }
`

const StyledIconButtonLeft = styled(IconButton).attrs({ color: 'secondary' })`
  ${baseButtonStyle}
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  padding-right: 8px;
`

const StyledIconButtonRight = styled(IconButton).attrs({ color: 'secondary' })`
  ${baseButtonStyle}
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  padding-left: 8px;
`

export interface Props {
  selectFund: (fund: IProjectionsFundType) => void
  selectedFund: IProjectionsFundType
  extraSidePadding?: number[] | number
}

export const ControlForFund = ({
  selectFund,
  selectedFund,
  extraSidePadding = 0,
}: Props) => {
  const funds: Fund[] = [
    {
      label: 'Cash',
      value: 'cash',
    },
    {
      label: 'Conservative',
      value: 'conservative',
    },
    {
      label: 'Moderate',
      value: 'moderate',
    },
    {
      label: 'Balanced',
      value: 'balanced',
    },
    {
      label: 'Growth',
      value: 'growth',
    },
  ]
  const selectedIndex = funds.findIndex((fund) => fund.value === selectedFund)

  return useMemo(
    () => (
      <Carousel
        cardSpacing={[1, 1, 2]}
        renderRightButton={(handleClick) => (
          <StyledIconButtonRight
            aria-label="See more fund right"
            onClick={handleClick}
          >
            <NavigateNextIcon color="inherit" />
          </StyledIconButtonRight>
        )}
        renderLeftButton={(handleClick) => (
          <StyledIconButtonLeft
            aria-label="See more fund left"
            onClick={handleClick}
          >
            <NavigateBeforeIcon color="inherit" />
          </StyledIconButtonLeft>
        )}
        selectedChildIndex={selectedIndex}
        extraSidePadding={extraSidePadding}
      >
        {funds.map((fund) => (
          <PlanCards
            key={fund.value}
            onClick={() => selectFund(fund.value)}
            selected={fund.value === selectedFund}
            aria-checked={false}
            icon={fund.value}
            label={fund.label}
            customIconSize={80}
          />
        ))}
      </Carousel>
    ),
    [extraSidePadding, funds, selectFund, selectedFund, selectedIndex]
  )
}
