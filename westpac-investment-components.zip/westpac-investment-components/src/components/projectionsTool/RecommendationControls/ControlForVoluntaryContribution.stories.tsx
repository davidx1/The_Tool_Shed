import React, { useState } from 'react'
import { ControlForVoluntaryContribution } from './ControlForVoluntaryContribution'

export default {
  title: 'projectionsTool/Control/ControlForVoluntaryContribution',
  component: ControlForVoluntaryContribution,
}

export const Basic = () => {
  const [value, setValue] = useState(0)

  return <ControlForVoluntaryContribution value={value} setter={setValue} />
}
