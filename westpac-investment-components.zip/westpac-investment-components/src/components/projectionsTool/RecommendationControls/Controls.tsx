import React from 'react'
import styled, { css } from 'styled-components'
import {
  Typography,
  Box,
  Paper,
  Divider,
  FormGroup,
  Grid,
  useMediaQuery,
  useTheme,
} from '@material-ui/core'

import { ControlForFund } from './ControlForFund'
import { ControlForPercentContribution } from './ControlForPercentContribution'
import { ControlForVoluntaryContribution } from './ControlForVoluntaryContribution'
import { ControlForSuperannuation } from './ControlForSuperannuation'
import { FrequencySelect } from '../shared/FrequencySelect'
import { PanelTitle, PanelTitleWrapper } from '../shared/PanelTitle'

import { getCurrencyString } from '../../../utils/projections-tools/getCurrencyString'
import {
  CONTRIBUTION_FREQUENCY_SUFFIX,
  IKiwisaverContributionFrequencyType,
  IKiwisaverProjectionsConfig,
  IKiwisaverSalaryContributionRateType,
  IProjectionsFundType,
  IRelationshipStatusType,
  PROJECTION_MOBILE_TABLET_BREAKPOINT,
} from '../../../utils/projections-tools/projectionsToolUtils'
import DynamicIcon from '../../../components/dataDisplay/DynamicIcon'
import { DialogText } from '../../dataDisplay/HTMLRenderer'

const StyledFormGroup = styled(FormGroup)`
  flex-wrap: inherit;
  justify-content: space-between;
  flex-grow: 1;
`
const SectionNumber = styled(Typography).attrs({
  variant: 'h6',
  component: 'span',
})`
  color: ${({ theme }) => theme.palette.text.hint};
  margin-right: ${({ theme }) => theme.spacing(1)}px;
`

const SectionTitle = styled(Typography).attrs({
  variant: 'body1',
  gutterBottom: false,
})`
  ${({ theme }) => css`
    color: ${theme.palette.text.primary};
    font-weight: 500;
    display: inline-flex;
  `}
`

const EmphasiseBody = styled(Typography).attrs({
  variant: 'body1',
  component: 'span',
  gutterBottom: true,
})`
  ${({ theme }) => css`
    color: ${theme.palette.text.primary};
    font-weight: ${theme.typography.fontWeightBold};
    margin-bottom: ${theme.spacing(2)}px;
    display: inline-flex;
  `}
`

const ContributionsWrapper = styled(Box).attrs({
  component: 'section',
})`
  ${({ theme }) =>
    theme.breakpoints.between(PROJECTION_MOBILE_TABLET_BREAKPOINT, 'md')} {
    display: flex;
  }
`

const ResetActionLink = styled(Typography).attrs({
  variant: 'body1',
})`
  ${({ theme }) => css`
    width: 40%;
    font-weight: ${theme.typography.fontWeightMedium};
    margin-left: ${theme.spacing(1)}px;
    text-decoration: underline;
    text-underline-position: under;
  `}
`

const ResetOptionWrapper = styled.div<{ disabled: boolean }>(
  ({
    theme: {
      palette: {
        text: { hint, primary },
      },
    },
    disabled,
  }) => css`
    display: flex;
    white-space: nowrap;
    align-items: center;
    cursor: ${disabled ? 'default' : 'pointer'};
    color: ${disabled ? hint : primary};
    path {
      fill: ${disabled ? hint : primary};
    }
  `
)

const SectionWrapper = styled(Paper)`
  ${({ theme }) => css`
    display: flex;
    flex-direction: column;
    min-height: 577px;
    ${theme.breakpoints.down('md')} {
      min-height: 0;
    }
  `}
`

function formatIndex(index: number) {
  return String(index).padStart(2, '0')
}

export interface Props {
  fundType: IProjectionsFundType
  salaryContributionRate: IKiwisaverSalaryContributionRateType
  voluntaryContributionFrequency: IKiwisaverContributionFrequencyType
  voluntaryContributionRate: number
  isIncludingSuperannuation: boolean
  relationshipStatus: IRelationshipStatusType
  salary: number
  setNewFundType: (value: IProjectionsFundType) => void
  setNewSalaryContributionRate: (
    value: IKiwisaverSalaryContributionRateType
  ) => void
  setNewVoluntaryContributionRate: (value: number) => void
  setNewVoluntaryContributionFrequency: (
    value: IKiwisaverContributionFrequencyType
  ) => void
  setRelationshipStatus: (value: IRelationshipStatusType) => void
  setIsIncludingSuperannuation: (value: boolean) => void
  isControlDirty: boolean
  isShowingFundDisclaimer: boolean
  resetControls: () => void
  config: IKiwisaverProjectionsConfig
}

export const Controls = ({
  fundType,
  salaryContributionRate,
  voluntaryContributionFrequency,
  voluntaryContributionRate,
  isIncludingSuperannuation,
  relationshipStatus,
  salary,
  setNewFundType,
  setNewSalaryContributionRate,
  setNewVoluntaryContributionRate,
  setNewVoluntaryContributionFrequency,
  setRelationshipStatus,
  setIsIncludingSuperannuation,
  isControlDirty,
  isShowingFundDisclaimer,
  resetControls,
  config,
}: Props) => {
  const frequency = 'weekly'
  const weeklyContribution =
    (salary * salaryContributionRate) /
    config.voluntaryContributionFrequencyRates[frequency]
  const contributionSuffix = CONTRIBUTION_FREQUENCY_SUFFIX[frequency]

  let index = 1
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down('xs'))

  return (
    <div>
      <PanelTitleWrapper>
        <PanelTitle>Other scenarios</PanelTitle>
        <ResetOptionWrapper
          disabled={!isControlDirty}
          onClick={isControlDirty ? resetControls : undefined}
        >
          <DynamicIcon icon="reset" />
          <ResetActionLink>Reset selections</ResetActionLink>
        </ResetOptionWrapper>
      </PanelTitleWrapper>
      <SectionWrapper elevation={isMobile ? 0 : 4}>
        {isShowingFundDisclaimer && (
          <BoxWithBackground component="section" p={2} mx={[-2, 0]}>
            <Box mr={2} lineHeight={0}>
              <DynamicIcon icon="infoFill" height="24" width="24" />
            </Box>
            <DialogText
              type="div"
              value={config.fundSelectionTooAggressiveDisclaimer.join('')}
            />
          </BoxWithBackground>
        )}
        <Box component="section" px={[0, 3]} py={3}>
          <Typography variant="body1" gutterBottom>
            {config.controlPanelDescription.join('')}
          </Typography>
        </Box>
        <StyledFormGroup>
          <Box>
            <Box component="section" mb={3}>
              <Box px={[0, 3, 4]}>
                <SectionNumber>{formatIndex(index)}</SectionNumber>
                <SectionTitle>Your fund</SectionTitle>
              </Box>
              <Box mx={[-2, 0]}>
                <ControlForFund
                  selectFund={setNewFundType}
                  selectedFund={fundType}
                  extraSidePadding={[2, 3, 4]}
                />
              </Box>
            </Box>
            <ContributionsWrapper>
              {salary > 0 && (
                <Box component="section" px={[0, 3, 4]} mb={3} width="100%">
                  <Grid container direction="row" justify="space-between">
                    <span>
                      <SectionNumber>{formatIndex(++index)}</SectionNumber>
                      <SectionTitle>Your contributions</SectionTitle>
                    </span>
                    <Typography variant="body1">
                      This is{' '}
                      <EmphasiseBody>
                        {getCurrencyString(weeklyContribution.toFixed(2))}{' '}
                        {contributionSuffix}
                      </EmphasiseBody>
                    </Typography>
                  </Grid>
                  <ControlForPercentContribution
                    selectPercentage={setNewSalaryContributionRate}
                    selectedPercentage={salaryContributionRate}
                  />
                </Box>
              )}
              <Box
                component="section"
                id="contribution-slider"
                px={[0, 3, 4]}
                width="100%"
              >
                <span>
                  <SectionNumber>{formatIndex(++index)}</SectionNumber>
                  <SectionTitle>
                    {salary > 0 ? 'Additional ' : 'Your '}
                  </SectionTitle>
                  <FrequencySelect
                    ariaLabel="voluntary contribution frequency listbox"
                    value={voluntaryContributionFrequency}
                    onChange={setNewVoluntaryContributionFrequency}
                    isAllLowerCase
                  />{' '}
                  <SectionTitle>contributions</SectionTitle>
                </span>
                <Box py={[1, 2, 2, 2]}>
                  <ControlForVoluntaryContribution
                    setter={setNewVoluntaryContributionRate}
                    value={voluntaryContributionRate}
                  />
                </Box>
              </Box>
            </ContributionsWrapper>
          </Box>
          <Box component="section" px={[0, 3, 4]}>
            <Divider />
            <Box py={[1, 1.5, 1.5]}>
              <ControlForSuperannuation
                setRelationshipStatus={setRelationshipStatus}
                setIsIncludingSuperannuation={setIsIncludingSuperannuation}
                isIncludingSuperannuation={isIncludingSuperannuation}
                relationshipStatus={relationshipStatus}
              />
            </Box>
          </Box>
        </StyledFormGroup>
      </SectionWrapper>
    </div>
  )
}

const BoxWithBackground = styled(Box)`
  background: ${({ theme }) => theme.palette.background.grey};
  display: flex;
`
