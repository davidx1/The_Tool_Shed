import React from 'react'
import { Controls } from './Controls'
import { render, screen, waitFor } from '@testing-library/react'

import { InvestToolsProvider } from '../../InvestToolsProvider'
import userEvent from '@testing-library/user-event'
import config from '../../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'
//The Carousel component have its own unit tests, so mocking it here
jest.mock('../../layout/Carousel')
//The Slider requires real DOM test, mocking it here to test its interface
jest.mock('../../inputs/Slider')

describe('<Graph/>', () => {
  it('should render and work properly', async () => {
    const setNewVoluntaryContributionRate = jest.fn()
    const setNewFundType = jest.fn()
    const setRelationshipStatus = jest.fn()
    const setIsIncludingSuperannuation = jest.fn()
    const setNewSalaryContributionRate = jest.fn()
    const setVoluntaryContributionFrequency = jest.fn()
    const reset = jest.fn()

    const originalProps = {
      fundType: 'conservative' as const,
      setNewFundType: setNewFundType,
      salaryContributionRate: 0.03 as const,
      setNewSalaryContributionRate: setNewSalaryContributionRate,
      voluntaryContributionFrequency: 'weekly' as const,
      setNewVoluntaryContributionFrequency: setVoluntaryContributionFrequency,
      voluntaryContributionRate: 0,
      setNewVoluntaryContributionRate: setNewVoluntaryContributionRate,
      isIncludingSuperannuation: false,
      setIsIncludingSuperannuation: setIsIncludingSuperannuation,
      relationshipStatus: 'single' as const,
      setRelationshipStatus: setRelationshipStatus,
      salary: 20_000,
      config: config,
      isControlDirty: false,
      resetControls: reset,
      openFundChooser: () => {},
      isShowingFundDisclaimer: false,
    }

    const { rerender } = render(
      <InvestToolsProvider>
        <Controls {...originalProps} />
      </InvestToolsProvider>
    )

    const { getByText, getByPlaceholderText } = screen

    //Reset doesn't work in the beginning
    userEvent.click(getByText('Reset selections'))
    expect(reset).toBeCalledTimes(0)

    const dirtyProps = {
      ...originalProps,
      isControlDirty: true,
    }

    //Reset only works if the form is dirty
    rerender(
      <InvestToolsProvider>
        <Controls {...dirtyProps} />
      </InvestToolsProvider>
    )

    //Reset
    userEvent.click(getByText('Reset selections'))
    expect(reset).toBeCalledTimes(1)

    // Set New Fund
    userEvent.click(getByText('Moderate'))
    expect(setNewFundType).toBeCalledWith('moderate')

    //Set Contribution Percentage
    userEvent.click(getByText('4%'))
    expect(setNewSalaryContributionRate).toBeCalledWith(0.04)

    //Set Contribution Frequency
    userEvent.click(getByText('weekly'))
    await waitFor(() => {
      expect(getByText('fortnightly')).toBeVisible()
    })

    userEvent.click(getByText('fortnightly'))
    expect(setVoluntaryContributionFrequency).toBeCalledWith('fortnightly')

    //Set Relationship Status
    userEvent.click(getByText('Single'))
    await waitFor(() => {
      expect(getByText('Couple')).toBeVisible()
    })
    userEvent.click(getByText('Couple'))
    expect(setRelationshipStatus).toBeCalledWith('couple')

    //Set Superannuation
    userEvent.click(getByText('Include NZ Superannuation'))
    expect(setIsIncludingSuperannuation).toBeCalledWith(true)

    //Set Voluntary Contribution
    userEvent.type(getByPlaceholderText('Enter amount'), '1')
    expect(setNewVoluntaryContributionRate).toBeCalledWith(1)
  })
})
