import { Container, Grid } from '@material-ui/core'
import React from 'react'
import styled from 'styled-components'
export interface Props {
  leftChild: React.ReactElement
  rightChild: React.ReactElement
}

export const RecommendationResponsiveWrapper = ({
  leftChild,
  rightChild,
}: Props) => {
  return (
    <Container>
      <IEFriendlyGrid container spacing={4}>
        <GridItem item xs={12} lg={7}>
          {leftChild}
        </GridItem>
        <GridItem item xs={12} lg={5}>
          {rightChild}
        </GridItem>
      </IEFriendlyGrid>
    </Container>
  )
}

const GridItem = styled(Grid).attrs({ item: true })`
  width: 100%;
  min-width: 290px;
`

const IEFriendlyGrid = styled(Grid)`
  display: flex;

  ${({ theme }) => theme.breakpoints.down('md')} {
    display: inline-block;
  }
`
