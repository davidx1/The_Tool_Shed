import React from 'react'

import { RecommendationResponsiveWrapper } from './RecommendationResponsiveWrapper'
import styled from 'styled-components'
import { Basic as Control } from './RecommendationControls/Controls.stories'
import { projectionsCalculation } from '../../utils/projections-tools/projectionsCalculation'
import { Graph } from './RecommendationGraph/Graph'
import config from '../../utils/projections-tools/__mocks__/ProjectionsConfigMockData'

export default {
  title: 'projectionsTool/RecommendationResponsiveWrapper',
  component: RecommendationResponsiveWrapper,
}

const Solid = styled.div`
  height: 500px;
  width: 100%;
`

const WhiteSolid = styled(Solid)`
  height: 50px;
  background-color: white;
`

const BlueSolid = styled(Solid)`
  background-color: blue;
`
const YellowSolid = styled(Solid)`
  background-color: yellow;
`

export const Basic = () => {
  const curriedNewCalculation = (projectedAge: number) =>
    projectionsCalculation({
      currentAge: 18,
      calculationEndAge: projectedAge,
      initialBalance: 800,
      investmentRate: 0.045,
      voluntaryContributionRate: 20,
      voluntaryContributionFrequency: 'weekly',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      firstHomeWithdrawalAge: 20,
      config,
    })

  const curriedOldCalculation = (projectedAge: number) =>
    projectionsCalculation({
      currentAge: 18,
      calculationEndAge: projectedAge,
      initialBalance: 800,
      investmentRate: 0.035,
      voluntaryContributionRate: 20,
      voluntaryContributionFrequency: 'weekly',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      firstHomeWithdrawalAge: 20,
      config,
    })

  return (
    <div>
      <WhiteSolid />
      <RecommendationResponsiveWrapper
        leftChild={
          <Graph
            isControlDirty
            currentAge={18}
            retireAge={65}
            setRetireAge={() => {}}
            firstHomeWithdrawalAge={20}
            setFirstHomeWithdrawalAge={() => {}}
            curriedNewCalculation={curriedNewCalculation}
            curriedOldCalculation={curriedOldCalculation}
            postRetirementIncomeFrequency="weekly"
            setPostRetirementIncomeFrequency={() => {}}
            config={config}
          />
        }
        rightChild={<Control></Control>}
      ></RecommendationResponsiveWrapper>
      <WhiteSolid></WhiteSolid>
      <YellowSolid></YellowSolid>
    </div>
  )
}

export const Basic1 = () => {
  return (
    <RecommendationResponsiveWrapper
      leftChild={<BlueSolid></BlueSolid>}
      rightChild={<YellowSolid></YellowSolid>}
    ></RecommendationResponsiveWrapper>
  )
}
