import React from 'react'

import KiwiSaverRecommendationFeeDetails from './KiwiSaverRecommendationFeeDetails'
import { IKiwisaverFundItem } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

const recommendation = {
  shortname: 'Growth',
  feeDetails: [
    '4.78% average annual return over five years (after annual fund charges fees and before tax)',
    'Annual fund charge of 0.59% (59c per $100 per year)',
    'Administration fee of $12 per year',
  ],
} as IKiwisaverFundItem

export default {
  title: 'KiwiSaver/KiwiSaverRecommendationFeeDetails',
  component: KiwiSaverRecommendationFeeDetails,
}

export const Basic = () => (
  <KiwiSaverRecommendationFeeDetails recommendation={recommendation} />
)

export const WithButtons = () => (
  <KiwiSaverRecommendationFeeDetails
    recommendation={recommendation}
    changeFund={() => {}}
    showOtherfunds={() => {}}
  />
)
