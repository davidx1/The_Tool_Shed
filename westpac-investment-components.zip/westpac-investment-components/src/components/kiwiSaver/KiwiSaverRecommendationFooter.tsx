import React from 'react'
import { Typography, Grid } from '@material-ui/core'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import ArrowButton from '../inputs/ArrowButton'
import BasicButton from '../inputs/BasicButton'
import { IKiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

export interface Props {
  faqLinkHandler?: () => void
  contactUsLinkHandler?: () => void
  config: IKiwisaverFundChooserConfig
}

const ResultsFooter: React.FC<Props> = ({
  faqLinkHandler,
  contactUsLinkHandler,
  config,
}) => {
  return (
    <React.Fragment>
      <Typography variant="h2" component="p" gutterBottom>
        Need more information?
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} />
        <Grid item xs={12} sm>
          <Grid container spacing={3} alignItems="flex-start">
            <Grid item>
              <DynamicIcon icon="faq" />
            </Grid>
            <Grid item xs md={8} lg={6}>
              <Typography variant="h4" component="p" gutterBottom>
                FAQs
              </Typography>
              <Typography
                variant="body1"
                component="p"
                gutterBottom
                id="readOurFAQs"
              >
                Need more info? Have a read through our FAQs about KiwiSaver.
              </Typography>
              <ArrowButton
                href={config.links.kiwiSaverFAQs}
                onClick={faqLinkHandler}
                aria-describedby="readOurFAQs"
                target="_blank"
                rel="noopener noreferrer"
              >
                Read our FAQs
              </ArrowButton>
            </Grid>
            <Grid item xs={12} />
          </Grid>
        </Grid>
        <Grid item xs={12} sm>
          <Grid container spacing={3} alignItems="flex-start">
            <Grid item>
              <DynamicIcon icon="phone" />
            </Grid>
            <Grid item xs md={8} lg={6}>
              <Typography variant="h4" component="p" gutterBottom>
                Contact Us
              </Typography>
              <Typography
                variant="body1"
                component="p"
                gutterBottom
                id="callOurSpecialists"
              >
                Call one of our KiwiSaver specialists on our free to phone
                number.
              </Typography>
              <BasicButton
                href={config.links.kiwiSaverSpecialistsPhone.url}
                aria-describedby="callOurSpecialists"
                onClick={contactUsLinkHandler}
              >
                {config.links.kiwiSaverSpecialistsPhone.label}
              </BasicButton>
            </Grid>
            <Grid item sm={12} />
          </Grid>
        </Grid>
      </Grid>
    </React.Fragment>
  )
}

export default ResultsFooter
