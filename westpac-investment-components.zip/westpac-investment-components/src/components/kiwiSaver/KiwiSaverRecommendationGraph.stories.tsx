import React from 'react'

import KiwiSaverRecommendationGraph from './KiwiSaverRecommendationGraph'
import {
  kiwisaverFundChooserConfig,
  recommendationDetails,
} from '../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'

export default {
  title: 'KiwiSaver/KiwiSaverRecommendationGraph',
  component: KiwiSaverRecommendationGraph,
}

export const Basic = () => (
  <KiwiSaverRecommendationGraph
    showMoreInfoHandler={() => {}}
    recommendation={kiwisaverFundChooserConfig.fundItems.growth}
    recommendationDetails={recommendationDetails}
  />
)

Basic.parameters = {
  storyshots: false,
}
