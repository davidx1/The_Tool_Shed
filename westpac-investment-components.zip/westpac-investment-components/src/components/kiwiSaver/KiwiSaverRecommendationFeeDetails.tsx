import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, Button, Box, List, ListItem } from '@material-ui/core'

import { IKiwisaverFundItem } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import ListDisc from '../dataDisplay/ListDisc'

const StyledBox = styled(Box)`
  ${({ theme }) => css`
    display: flex;
    justify-content: space-between;
    width: 100%;
    ${theme.breakpoints.down('md')} {
      display: block;
    }
  `}
`

const TypographyBenefits = styled(Typography)(
  ({ theme }) => css`
    flex: 1;
    margin-bottom: ${theme.spacing(3)}px;
    font-size: ${theme.typography.pxToRem(28)};
    ${theme.breakpoints.up('md')} {
      margin-bottom: ${theme.spacing(2.625)}px;
      font-size: ${theme.typography.pxToRem(40)};
    }
  `
)

const TypographySubtitle = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(24)};
    font-weight: ${theme.typography.fontWeightBold};
    line-height: ${theme.typography.pxToRem(30)};
  `
)

const StyledListItem = styled((props) => <ListItem {...props} />)`
  ${({ theme }) => css`
    color: ${theme.palette.text.primary};
    padding-left: 0;
  `}
`

const StyledListItemText = styled.span`
  ${({ theme }) => css`
    font-size: ${theme.typography.pxToRem(18)};
    line-height: ${theme.typography.pxToRem(25)};
    color: ${theme.palette.text.primary};
  `}
`

const StyledButton = styled(Button)`
  ${({ theme }) => css`
    margin: ${theme.spacing(1, 3, 2, 0)};
    ${theme.breakpoints.down('xs')} {
      width: 100%;
      margin: ${theme.spacing(1, 0, 1)};
    }
  `}
`

export interface Props {
  recommendation: IKiwisaverFundItem
  changeFund?: (fundItem: IKiwisaverFundItem) => void
  showOtherfunds?: () => void
}

const KiwisaverRecommendationFeeDetails: React.FC<Props> = ({
  recommendation,
  changeFund,
  showOtherfunds,
}) => {
  const { feeDetails, shortname } = recommendation
  if (!feeDetails) return null
  return (
    <StyledBox>
      <TypographyBenefits variant="h2">Returns &amp; fees.</TypographyBenefits>
      <Box flex={2}>
        <TypographySubtitle variant="h3">
          The finer details of the {shortname} Fund.
        </TypographySubtitle>
        <List>
          {feeDetails.map((fee) => (
            <StyledListItem key={fee} alignItems="flex-start">
              <ListDisc color="inherit" />
              <StyledListItemText>{fee}</StyledListItemText>
            </StyledListItem>
          ))}
        </List>
        {changeFund && (
          <StyledButton
            color="primary"
            variant="contained"
            onClick={() => changeFund(recommendation)}
          >
            Change to {shortname} Fund
          </StyledButton>
        )}
        {showOtherfunds && (
          <StyledButton
            variant="outlined"
            color="primary"
            onClick={showOtherfunds}
          >
            Explore other fund options
          </StyledButton>
        )}
      </Box>
    </StyledBox>
  )
}

export default KiwisaverRecommendationFeeDetails
