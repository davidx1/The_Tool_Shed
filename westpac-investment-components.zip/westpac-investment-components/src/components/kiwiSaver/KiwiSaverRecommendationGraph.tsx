import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Typography, Grid, Box, Paper } from '@material-ui/core'
import {
  IKiwisaverFundType,
  IKiwisaverFundItem,
  IKiwisaverRecommendationDetails,
} from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import UnderlineButton from '../inputs/UnderlineButton'
import KiwiSaverNavGraph from './graph/KiwiSaverNavGraph'

const ButtonContainer = styled(Grid)(
  ({ theme }) => css`
    ${theme.breakpoints.down('sm')} {
      && {
        text-align: center;
        padding: ${theme.spacing(1)}px;
      }
    }
  `
)

export interface Props {
  recommendation: IKiwisaverFundItem
  recommendationDetails: IKiwisaverRecommendationDetails
  showMoreInfoHandler: (
    type: IKiwisaverFundType,
    showAllDetails?: boolean
  ) => void
}

const KiwiSaverRecommendationHeader: FC<Props> = ({
  recommendation,
  recommendationDetails,
  showMoreInfoHandler,
}) => (
  <React.Fragment>
    <Typography variant="h4" component="p" gutterBottom>
      See how the {recommendation?.shortname} Fund has performed
    </Typography>
    <Typography variant="body2" component="p">
      {recommendationDetails?.chartDescription}
    </Typography>
    <Box pt={3} pb={2} mx={{ xs: -2, sm: -3, md: 0 }}>
      <Paper elevation={4}>
        <KiwiSaverNavGraph
          resultFundType={recommendation.type}
          chart={recommendationDetails}
          showMoreInfo={showMoreInfoHandler}
        />
      </Paper>
    </Box>
    <Grid container spacing={4} justify="space-between" direction="row">
      <Grid item xs={12} md={8}>
        <Typography variant="overline" color="textSecondary" component="div">
          <p>
            This graph shows actual returns for funds in the Westpac KiwiSaver
            Scheme since {recommendationDetails?.initialYear}. Its purpose is to
            show you how different funds may go up and down along the way. The
            information is net of annual fund charges* and tax at the highest
            PIR (tax rate) but it doesn’t include the administration fee. It is
            updated quarterly . Past returns are not a reliable indication of
            future returns. Future returns for any fund will vary and may be
            negative at times, which means your balance can be less than what
            you invested.
          </p>
          <p>
            Both the Moderate and Default Funds started on 2 July 2014. For
            these two funds, the returns shown in the graph prior to this date
            have been created using actual returns for other funds in the
            Westpac KiwiSaver Scheme, which have then been adjusted to match the
            benchmark allocation to growth assets and income assets for the
            Moderate and Default Funds.
          </p>
        </Typography>
      </Grid>
      <ButtonContainer item xs={12} md="auto">
        <UnderlineButton
          onClick={() => showMoreInfoHandler(recommendation.type, true)}
        >
          See fund comparison table
        </UnderlineButton>
      </ButtonContainer>
    </Grid>
  </React.Fragment>
)

export default KiwiSaverRecommendationHeader
