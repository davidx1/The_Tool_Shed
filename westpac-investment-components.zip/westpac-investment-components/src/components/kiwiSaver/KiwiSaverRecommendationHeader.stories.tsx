import React from 'react'

import KiwiSaverRecommendationHeader from './KiwiSaverRecommendationHeader'

export default {
  title: 'KiwiSaver/KiwiSaverRecommendationHeader',
  component: KiwiSaverRecommendationHeader,
}

export const Basic = () => (
  <KiwiSaverRecommendationHeader
    title="Westpac recommends:"
    recommendation={{
      type: 'growth',
      title: 'Westpac KiwiSaver Scheme Growth Fund',
      shortname: 'Growth',
      description: [
        'For people with 10 years or more before they want to use their savings we recommend the Growth Fund. This fund aims to provide higher returns over the long term, but you should expect big ups and downs in your balance along the way.',
      ],
      shortDescription: [],
      feeDetails: [],
      averageAnnualReturn: 8.2,
      adminFeePerYear: 12,
      annualFundChargePercent: 0.79,
      annualFundChargeDescription: 'so that’s 79¢ for every $100 per year',
    }}
  />
)
