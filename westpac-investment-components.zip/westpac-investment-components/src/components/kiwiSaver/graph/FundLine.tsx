import React from 'react'
// import { getFundColor } from 'src/utils/fundUtils'
import {
  IKiwisaverFundType,
  IKiwisaverRecommendationDetails,
} from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { yScale, x, y, FundSet } from './FundGraph'
import FundLineGradient from './FundLineGradient'
import FundLineDashed from './FundLineDashed'
import { getFundColor } from './graphFundUtils'

export interface LineProps {
  lineType?: 'solid' | 'dashed'
  color: string
  fund: IKiwisaverFundType
  x: x
  y: y
  yScale: yScale
  playAnimation: boolean
  data: FundSet[]
}

export interface AnimationProps {
  playAnimation: boolean
}

interface Props extends Omit<LineProps, 'color' | 'lastDataSet' | 'data'> {
  chart: IKiwisaverRecommendationDetails
}

const FundLine: React.FC<Props> = ({
  lineType,
  chart,
  fund,
  yScale,
  x,
  y,
  playAnimation,
}) => {
  const color = getFundColor(fund)
  const data = chart.monthlyData.map((set) => ({
    date: set.date,
    value: set[fund],
  }))

  switch (lineType) {
    case 'solid':
      return (
        <FundLineGradient
          fund={fund}
          color={color}
          data={data}
          yScale={yScale}
          x={x}
          y={y}
          playAnimation={playAnimation}
        />
      )
    case 'dashed':
      return (
        <FundLineDashed
          fund={fund}
          color={color}
          data={data}
          x={x}
          y={y}
          playAnimation={playAnimation}
        />
      )
    default:
      return null
  }
}

export default FundLine
