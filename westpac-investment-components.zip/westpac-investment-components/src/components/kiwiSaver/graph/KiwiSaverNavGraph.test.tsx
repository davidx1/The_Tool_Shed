import React from 'react'
import KiwiSaverNavGraph from './KiwiSaverNavGraph'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'

import { IKiwisaverFundType } from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { recommendationDetails } from '../../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'

const CASH = { index: 0, testId: 'graph-line-cash' }
const CONSERVATIVE = { index: 1, testId: 'graph-line-conservative' }
const MODERATE = { index: 2, testId: 'graph-line-moderate' }
const BALANCED = { index: 3, testId: 'graph-line-balanced' }
const GROWTH = { index: 4, testId: 'graph-line-growth' }

const checkSelected = (
  checkbox: HTMLElement,
  graphLine: HTMLElement | null,
  isRecommended?: boolean
) => {
  if (isRecommended) {
    expect(checkbox).toBeDisabled()
  } else {
    expect(checkbox).toBeEnabled()
  }
  expect(checkbox).toBeChecked()
  expect(graphLine).toBeVisible()
}

const checkDeselected = (
  checkbox: HTMLElement,
  graphLine: HTMLElement | null
) => {
  expect(checkbox).toBeEnabled()
  expect(checkbox).not.toBeChecked()
  expect(graphLine).not.toBeTruthy()
}

const setup = (resultFund: IKiwisaverFundType) => {
  const utils = render(
    <InvestToolsProvider>
      <KiwiSaverNavGraph
        resultFundType={resultFund}
        chart={recommendationDetails}
        showMoreInfo={() => {}}
      />
    </InvestToolsProvider>
  )
  const cbs = utils.getAllByRole('checkbox')
  return { cbs, ...utils }
}

describe('KiwiSaverNavGraph', () => {
  it('should render the graph with conservative and moderate funds selected for cash fund', () => {
    const { cbs, queryByTestId } = setup('cash')
    checkSelected(cbs[CASH.index], queryByTestId(CASH.testId), true)
    checkSelected(cbs[CONSERVATIVE.index], queryByTestId(CONSERVATIVE.testId))
    checkSelected(cbs[MODERATE.index], queryByTestId(MODERATE.testId))
    checkDeselected(cbs[BALANCED.index], queryByTestId(BALANCED.testId))
    checkDeselected(cbs[GROWTH.index], queryByTestId(GROWTH.testId))
  })

  it('should render the graph with cash and moderate funds selected for conservative fund', () => {
    const { cbs, queryByTestId } = setup('conservative')
    checkSelected(cbs[CASH.index], queryByTestId(CASH.testId))
    checkSelected(
      cbs[CONSERVATIVE.index],
      queryByTestId(CONSERVATIVE.testId),
      true
    )
    checkSelected(cbs[MODERATE.index], queryByTestId(MODERATE.testId))
    checkDeselected(cbs[BALANCED.index], queryByTestId(BALANCED.testId))
    checkDeselected(cbs[GROWTH.index], queryByTestId(GROWTH.testId))
  })

  it('should render the graph with conservative and balanced funds selected for moderate fund', () => {
    const { cbs, queryByTestId } = setup('moderate')
    checkDeselected(cbs[CASH.index], queryByTestId(CASH.testId))
    checkSelected(cbs[CONSERVATIVE.index], queryByTestId(CONSERVATIVE.testId))
    checkSelected(cbs[MODERATE.index], queryByTestId(MODERATE.testId), true)
    checkSelected(cbs[BALANCED.index], queryByTestId(BALANCED.testId))
    checkDeselected(cbs[GROWTH.index], queryByTestId(GROWTH.testId))
  })

  it('should render the graph with moderate and growth funds selected for balanced fund', () => {
    const { cbs, queryByTestId } = setup('balanced')
    checkDeselected(cbs[CASH.index], queryByTestId(CASH.testId))
    checkDeselected(cbs[CONSERVATIVE.index], queryByTestId(CONSERVATIVE.testId))
    checkSelected(cbs[MODERATE.index], queryByTestId(MODERATE.testId))
    checkSelected(cbs[BALANCED.index], queryByTestId(BALANCED.testId), true)
    checkSelected(cbs[GROWTH.index], queryByTestId(GROWTH.testId))
  })

  it('should render the graph with moderate and balanced funds selected for growth fund', () => {
    const { cbs, queryByTestId } = setup('growth')
    checkDeselected(cbs[CASH.index], queryByTestId(CASH.testId))
    checkDeselected(cbs[CONSERVATIVE.index], queryByTestId(CONSERVATIVE.testId))
    checkSelected(cbs[MODERATE.index], queryByTestId(MODERATE.testId))
    checkSelected(cbs[BALANCED.index], queryByTestId(BALANCED.testId))
    checkSelected(cbs[GROWTH.index], queryByTestId(GROWTH.testId), true)
  })

  it('should allow the user to show other funds', () => {
    const { cbs, queryByTestId } = setup('growth')
    const checkboxCash = cbs[CASH.index]
    checkDeselected(checkboxCash, queryByTestId(CASH.testId))
    fireEvent.click(checkboxCash)
    checkSelected(checkboxCash, queryByTestId(CASH.testId))
  })

  it('should display the formatted values for each fund', () => {
    const { getAllByText } = setup('growth')
    expect(getAllByText('$10,106')[0]).toBeInTheDocument()
    expect(getAllByText('$9,891')[0]).toBeInTheDocument()
    expect(getAllByText('$9,791')[0]).toBeInTheDocument()
    expect(getAllByText('$9,655')[0]).toBeInTheDocument()
    expect(getAllByText('$9,554')[0]).toBeInTheDocument()
  })
})
