import React from 'react'
import styled, { css, StyledProps } from 'styled-components'
import { PopoverProps } from './FundPopover'
import Pill from '../../dataDisplay/Pill'
import { getFundColor } from './graphFundUtils'

const Tooltip = styled(Pill)(
  ({ top, left }: StyledProps<PopoverProps>) => css`
    position: absolute;
    top: ${top}px;
    left: ${left}px;
    transform: translateX(3px) translateY(-100%);
  `
)

const FundTooltip: React.FC<PopoverProps> = ({
  top,
  left,
  fund,
  isOpen,
  children,
}) => {
  return (
    <Tooltip
      bgColor={getFundColor(fund)}
      top={top}
      left={left}
      fund={fund}
      isOpen={isOpen}
    >
      {children}
    </Tooltip>
  )
}

export default FundTooltip
