import { filterAxisRange, getFundColor } from './graphFundUtils'

describe('graphFundUtils', () => {
  it('filterAxisRange', () => {
    const max2Ticks = filterAxisRange([2010, 2011, 2012, 2013, 2014], 2)
    expect(max2Ticks).toEqual([2010, 2014])

    const max4Ticks = filterAxisRange(
      [2010, 2011, 2012, 2013, 2014, 2015, 2016],
      4
    )
    expect(max4Ticks).toEqual([2010, 2012, 2014, 2016])
  })

  it('getFundColor', () => {
    expect(getFundColor('cash')).toBe('#636363')
    expect(getFundColor('defensive')).toBe('#E94E1B')
    expect(getFundColor()).toBe('#E94E1B')
  })
})
