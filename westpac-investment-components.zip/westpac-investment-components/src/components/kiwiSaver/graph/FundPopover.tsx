import React, { useRef, useEffect } from 'react'
import styled, { css, keyframes, StyledProps } from 'styled-components'
import ClickAwayListener from '@material-ui/core/ClickAwayListener'
import { IKiwisaverFundType } from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { togglePopover } from './FundGraph'
import { fade } from '@material-ui/core'

export interface PopoverProps {
  top: number | undefined
  left: number | undefined
  isOpen: boolean
  fund: IKiwisaverFundType
  handlePopover?: togglePopover
  autoFocus?: boolean
}

const scaleInSlideInitial = css`
  transform: translateX(-15px) translateY(-50%) scale(0.95); /* IE 11 & Edge < 14 - no calc inside transform */
`

const scaleInSlide = keyframes`
  from {
      ${scaleInSlideInitial}
  }
  to {
    transform: translateX(-25px) translateY(-50%) scale(1);
  }
`

const Popover = styled.div(
  ({
    theme,
    top,
    left,
    isOpen,
  }: StyledProps<Omit<PopoverProps, 'autoFocus' | 'fund'>>) => css`
    display: flex;
    align-items: center;
    font-size: ${theme.typography.pxToRem(16)};
    font-weight: ${theme.typography.fontWeightMedium};
    background: ${fade(theme.palette.background.paper, 0.7)};
    line-height: 1;
    border-radius: 3px;
    position: absolute;
    border: 1px solid ${theme.palette.background.darkGrey};
    top: ${top}px;
    left: ${left}px;
    width: ${theme.typography.pxToRem(240)};
    /* 
      pull left by its width, otherwise Edge and IE11 uses the width 
      to calculate extra parent width despite the absolute position 
    */
    margin-left: ${theme.typography.pxToRem(-240)};
    box-shadow: 0 0 6px rgba(0, 0, 0, 0.15);
    transform-origin: right center;
    ${scaleInSlideInitial}

    ${isOpen
      ? css`
          visibility: visible;
          animation: ${scaleInSlide} 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        `
      : css`
          visibility: hidden;
        `}

    &:focus {
      outline: none;
    }
  `
)

const PopoverInner = styled.div`
  width: 100%;
  position: relative;
  border-radius: 3px;
`

const Arrow = styled.span(
  ({ theme }) => css`
    width: 10px;
    height: 30px;
    position: absolute;
    top: 50%;
    right: -10px;
    overflow: hidden;
    transform: translateY(-50%);

    &:after {
      content: '';
      display: inline-flex;
      position: absolute;
      width: 14px;
      height: 14px;
      background: ${theme.palette.background.paper};
      border-top: 1px solid ${theme.palette.background.darkGrey};
      border-right: 1px solid ${theme.palette.background.darkGrey};
      transform: translateY(-50%) rotate(45deg);
      top: 50%;
      left: -7px;
      box-shadow: 1px -1px 2px rgba(0, 0, 0, 0.1);
    }
  `
)

const FundPopover: React.FC<PopoverProps> = ({
  top,
  left,
  fund,
  isOpen,
  autoFocus,
  handlePopover,
  children,
}) => {
  const popoverRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (isOpen && autoFocus) {
      popoverRef.current?.focus()
    }
  }, [isOpen, autoFocus])

  const handleClose = (e: React.MouseEvent<Document, MouseEvent>) => {
    if (
      isOpen &&
      handlePopover &&
      !(
        e.target instanceof HTMLButtonElement &&
        e.target.dataset?.popover === fund
      )
    )
      handlePopover(fund, false)
  }

  return (
    <ClickAwayListener onClickAway={handleClose}>
      <Popover
        ref={popoverRef}
        top={top}
        left={left}
        isOpen={isOpen}
        role="dialog"
        id={`popoverFund${fund}`}
        tabIndex={-1}
      >
        <Arrow />
        <PopoverInner>{children}</PopoverInner>
      </Popover>
    </ClickAwayListener>
  )
}

export default FundPopover
