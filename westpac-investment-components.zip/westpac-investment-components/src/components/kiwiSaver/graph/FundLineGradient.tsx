import React from 'react'
import styled, { css } from 'styled-components'
import {
  fadeInInitial,
  fadeIn,
  pathAnimation,
} from '../../../styles/sharedStyles'
import { LinearGradient } from '@vx/gradient'
import { AreaClosed, LinePath } from '@vx/shape'
import { curveBasis } from '@vx/curve'
import { ScaleType } from '@vx/shape/lib/types'
import { LineProps, AnimationProps } from './FundLine'

const AnimatedLinePath = styled.path(
  ({ playAnimation }: AnimationProps) => css`
    @media (prefers-reduced-motion: no-preference) {
      ${pathAnimation}
      animation-play-state: ${playAnimation ? 'running' : 'paused'};
    }
  `
)

const AnimatedAreaClosedPath = styled.path(
  ({ playAnimation }: AnimationProps) => css`
    @media (prefers-reduced-motion: no-preference) {
      ${fadeInInitial}
      animation: ${fadeIn} 0.8s 1s ease forwards;
      animation-play-state: ${playAnimation ? 'running' : 'paused'};
    }
  `
)

const FundLineGradient: React.FC<LineProps> = ({
  fund,
  color,
  data,
  yScale,
  x,
  y,
  playAnimation,
}) => {
  return (
    <React.Fragment>
      <LinearGradient
        id={`areaGradient${fund}`}
        from={color}
        fromOpacity={0.3}
        to={color}
        toOpacity={0}
      />

      <g>
        <AreaClosed
          data={data}
          x={x}
          y={y}
          yScale={yScale as ScaleType}
          curve={curveBasis}
        >
          {({ path }) => {
            const d = path(data)
            return (
              d && (
                <AnimatedAreaClosedPath
                  d={d}
                  fill={`url(#areaGradient${fund})`}
                  fillOpacity={0.2}
                  playAnimation={playAnimation}
                />
              )
            )
          }}
        </AreaClosed>

        <LinePath data={data} x={x} y={y} curve={curveBasis}>
          {({ path }) => {
            const d = path(data)
            return (
              d && (
                <AnimatedLinePath
                  d={d}
                  strokeLinecap="round"
                  strokeWidth={3}
                  stroke={color}
                  fill="none"
                  playAnimation={playAnimation}
                  data-testid={`graph-line-${fund}`}
                />
              )
            )
          }}
        </LinePath>
      </g>
    </React.Fragment>
  )
}

export default FundLineGradient
