import React, { useRef, useEffect } from 'react'
import styled, { css, StyledProps } from 'styled-components'
import {
  Box,
  Grid,
  Typography,
  Checkbox,
  Hidden,
  ButtonBase,
} from '@material-ui/core'
import useMediaQuery from '@material-ui/core/useMediaQuery'
import { IKiwisaverFundType } from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { FundsResultData, showMoreInfo } from './KiwiSaverNavGraph'
import { getFundColor } from './graphFundUtils'
import BigCheckbox from '../../inputs/BigCheckbox'
import { spacing } from '../../../styles/theme'

interface CheckboxFundProps {
  fund: IKiwisaverFundType
}

interface Props {
  checkedFunds: IKiwisaverFundType[]
  resultFundType: IKiwisaverFundType
  fundsResultData: FundsResultData[]
  onToggleItem: (item: IKiwisaverFundType) => void
  showMoreInfo: showMoreInfo
}

const GridForm = styled(Grid)(
  ({ theme }) => css`
    margin: 0;
    width: auto;
    flex-grow: 1;

    ${theme.breakpoints.down('xs')} {
      scroll-snap-type: x mandatory;
    }

    ${theme.breakpoints.down('sm')} {
      overflow-x: auto;
      overflow-y: hidden;
    }
  `
)

const GridFormHeader = styled(Grid)(
  ({ theme }) => css`
    width: 100%;
    padding: ${theme.spacing(2, 2, 0)};

    ${theme.breakpoints.up('md')} {
      display: flex;
      width: auto;
      white-space: nowrap;
      padding: ${theme.spacing(2, 4, 0, 0)};
    }

    ${theme.breakpoints.up('lg')} {
      padding: ${theme.spacing(2, 8, 0, 0)};
    }

    ${theme.breakpoints.up('xl')} {
      padding: ${theme.spacing(2, 10, 0, 0)};
    }
  `
)

const TypographySmall = styled(Typography).attrs({
  component: 'p',
})`
  font-weight: ${({ theme }) => theme.typography.fontWeightMedium};
`

const CheckboxFund = styled(Checkbox)(
  ({ theme, fund }: StyledProps<CheckboxFundProps>) => css`
    &.Mui-disabled {
      opacity: 1;
    }
    svg {
      width: ${theme.typography.pxToRem(32)};
      height: ${theme.typography.pxToRem(32)};
    }

    &.Mui-checked svg {
      fill: ${getFundColor(fund)};
    }

    input {
      border: 0;
    }

    ${theme.breakpoints.down('xs')} {
      margin-bottom: ${spacing(-1)}px;
    }
  `
)

const LabelFund = styled.label(
  ({ theme, disabled }: StyledProps<{ disabled: boolean }>) => css`
    font-size: ${theme.typography.pxToRem(16)};
    position: relative;
    display: inline-flex;
    align-items: center;
    vertical-align: middle;
    cursor: ${disabled ? 'not-allowed' : 'pointer'};
  `
)

const LabelFundText = styled.span`
  text-transform: capitalize;

  .Mui-disabled ~ & {
    opacity: 0.7;
  }
`

const GridCheckBoxes = styled(Grid)(
  ({ theme }) => css`
    && {
      margin: 0;

      ${theme.breakpoints.down('xs')} {
        padding: ${theme.spacing(1, 1.5, 1.625)};
        width: auto;
      }

      ${theme.breakpoints.down('sm')} {
        flex-wrap: nowrap;
      }
    }
  `
)

const GridCardSmall = styled(Grid)(
  ({ theme }) => css`
    scroll-snap-align: center;
    min-width: 235px;
    ${theme.breakpoints.up('sm')} {
      min-width: 0;

      &:first-child {
        margin-left: ${theme.spacing(-1)}px;
      }
    }
  `
)

const GridCardInner = styled.div(
  ({ theme }) => css`
    background: ${theme.palette.background.paper};
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.15);
    border: 1px solid ${theme.palette.background.darkGrey};
  `
)

const StyledButton = styled(ButtonBase)(
  ({ theme }) => css`
    font-weight: ${theme.typography.fontWeightMedium};
    font-size: ${theme.typography.pxToRem(16)};
    line-height: ${theme.typography.pxToRem(22)};
    width: 100%;
    justify-content: flex-start;
    padding: ${theme.spacing(1, 2)};
  `
)

const FundNav: React.FC<Props> = ({
  resultFundType,
  showMoreInfo,
  checkedFunds,
  fundsResultData,
  onToggleItem,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null)
  const gridCardSizerRef = useRef<HTMLDivElement | null>(null)
  const isOverSmWidth = useMediaQuery('@media (min-width: 959.95px)')
  const fundIndex = fundsResultData.map((x) => x.fund).indexOf(resultFundType)

  // Small screens: set initial scroll of GridCheckBoxes to show resultFundType
  useEffect(() => {
    const itemSpacing = spacing(3)
    const itemWidth = gridCardSizerRef.current?.offsetWidth
    if (
      !isOverSmWidth &&
      scrollContainerRef.current &&
      itemWidth &&
      fundIndex
    ) {
      const scrollDistToCenter =
        itemWidth * fundIndex - itemWidth / 2 + itemSpacing
      scrollContainerRef.current.scrollLeft = scrollDistToCenter
    }
  }, [fundIndex, isOverSmWidth])

  return (
    <Grid item container alignItems="flex-start">
      <GridFormHeader item container alignContent="center">
        <Hidden smUp>
          <TypographySmall variant="h6" id="selectToCompare">
            Select to compare funds in the graph:
          </TypographySmall>
        </Hidden>
        <Hidden xsDown>
          <Typography variant="h6" component="p" id="selectToCompare">
            Select to compare<Typography variant="srOnly"> funds</Typography>:
          </Typography>
        </Hidden>
      </GridFormHeader>
      <GridForm item container spacing={2} ref={scrollContainerRef}>
        <GridCheckBoxes
          item
          container
          justify="space-between"
          role="group"
          aria-labelledby="selectToCompare"
          spacing={isOverSmWidth ? 0 : 1}
        >
          {fundsResultData.map(({ fund, shortname, formattedValue }) => {
            const disabled = fund === resultFundType
            const CheckboxBase = (
              <CheckboxFund
                checked={checkedFunds.includes(fund)}
                onChange={() => onToggleItem(fund)}
                name={fund}
                fund={fund}
                color="primary"
                disabled={disabled}
              />
            )
            return (
              <React.Fragment key={`f-group-${fund}`}>
                <Hidden smUp>
                  <GridCardSmall item ref={gridCardSizerRef}>
                    <GridCardInner>
                      <BigCheckbox
                        label={`${shortname} Fund`}
                        description={
                          <Box mt={-1}>
                            <Typography
                              variant="h3"
                              component="p"
                              color="primary"
                            >
                              {formattedValue}
                            </Typography>
                          </Box>
                        }
                        checkboxProps={{ disabled }}
                        content={
                          <Box mt={1.5} width={1} bgcolor="disabled.xlight">
                            <StyledButton
                              onClick={() => showMoreInfo(fund)}
                              disableTouchRipple
                              focusRipple
                            >
                              More about this fund
                            </StyledButton>
                          </Box>
                        }
                      >
                        {CheckboxBase}
                      </BigCheckbox>
                    </GridCardInner>
                  </GridCardSmall>
                </Hidden>

                <Hidden xsDown>
                  <GridCardSmall item>
                    <LabelFund disabled={disabled}>
                      {CheckboxBase}
                      <LabelFundText>
                        {shortname}{' '}
                        <Typography variant="srOnly">fund</Typography>
                      </LabelFundText>
                    </LabelFund>
                  </GridCardSmall>
                </Hidden>
              </React.Fragment>
            )
          })}
        </GridCheckBoxes>
      </GridForm>
    </Grid>
  )
}

export default FundNav
