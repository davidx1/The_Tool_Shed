import React from 'react'
import styled, { css, keyframes, StyledProps } from 'styled-components'
import { fade } from '@material-ui/core/styles/colorManipulator'
import { IKiwisaverFundType } from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { AnimationProps } from './FundLine'
import { togglePopover } from './FundGraph'
import { Typography, ButtonBase } from '@material-ui/core'

interface GlyphProps extends AnimationProps {
  color: string
  x: number
  y: number
}

interface Props extends GlyphProps {
  fund: IKiwisaverFundType
  openPopover: IKiwisaverFundType | undefined
  handlePopover: togglePopover
}

const borderWidth = 3
const initialTransform = `translateX(-${borderWidth}px) translate(-50%, -50%)`
const scaleUpInitial = css`
  transform: ${initialTransform} scale(0);
`

const scaleUp = keyframes`
  from {
      ${scaleUpInitial}
  }
  to {
      transform: ${initialTransform} scale(1);
  }
`

const GlyphButton = styled(({ playAnimation, color, x, y, ...props }) => (
  <ButtonBase {...props} />
))(
  ({ playAnimation, color, x, y }: StyledProps<GlyphProps>) => css`
    position: absolute;
    left: ${x}px;
    top: ${y}px;
    width: 21px;
    height: 21px;
    border-radius: 50%;
    background: ${color};
    border: ${borderWidth}px solid white;
    transform: ${initialTransform};
    box-shadow: 0 0 12px ${fade(color, 0.5)};

    @media (prefers-reduced-motion: no-preference) {
        ${scaleUpInitial}
        animation: ${scaleUp} 0.26s 1s cubic-bezier(0.0, 0.0, 0.2, 1) forwards;
        animation-play-state: ${playAnimation ? 'running' : 'paused'};
    }

    &:hover,
    &:focus {
      background: ${color};
      border: ${borderWidth}px solid white;
      border-width: ${borderWidth + 1}px;
    }
`
)

const FundGlyph: React.FC<Props> = ({
  fund,
  color,
  playAnimation,
  openPopover,
  handlePopover,
  x,
  y,
}) => (
  <GlyphButton
    x={x}
    y={y}
    onMouseEnter={() => handlePopover(fund, true)}
    onClick={() => handlePopover(fund, true, true)}
    data-popover={fund}
    aria-haspopup="true"
    aria-controls={`popoverFund${fund}`}
    aria-expanded={openPopover === fund}
    playAnimation={playAnimation}
    color={color}
    disableTouchRipple
    focusRipple
  >
    <Typography variant="srOnly">{`Toggle details about ${fund} fund`}</Typography>
  </GlyphButton>
)

export default FundGlyph
