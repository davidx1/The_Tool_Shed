import '../../../polyfills'

import React, { useState } from 'react'
import styled, { css } from 'styled-components'
import { ParentSize } from '@vx/responsive'
import { Box } from '@material-ui/core'
import useMediaQuery from '@material-ui/core/useMediaQuery'
import { format } from 'd3-format'
import {
  IKiwisaverFundType,
  IKiwisaverRecommendationDetails,
} from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

import FundNav from './FundNav'
import FundGraph from './FundGraph'
import {
  getLastFundSet,
  sortFundsByChartFundOrder,
  getFundsAdjacentToFund,
} from './graphFundUtils'
import ErrorBoundaryMessage from '../../error/ErrorBoundaryMessage'

export type showMoreInfo = (type: IKiwisaverFundType) => void
export interface FundProps {
  resultFundType: IKiwisaverFundType
  chart: IKiwisaverRecommendationDetails
  showMoreInfo: showMoreInfo
}

export interface FundsResultData {
  title: string
  shortname: string
  fund: IKiwisaverFundType
  formattedValue: string
}

const graphMinWidth = 716
const graphMinHeight = 410

const FundContainer = styled(Box)(
  ({ theme }) => css`
    background: ${theme.palette.primary.contrastText};
    border-radius: 3px;
    overflow: hidden;
    padding: ${theme.spacing(2, 0, 0)};
    display: flex;
    flex-direction: column;

    ${theme.breakpoints.up('sm')} {
      padding: ${theme.spacing(3, 0)};
    }
    ${theme.breakpoints.up('md')} {
      padding: ${theme.spacing(4)}px;
    }
    ${theme.breakpoints.up('lg')} {
      padding: ${theme.spacing(5)}px;
    }
  `
)

const GridContainer = styled.div`
  width: ${graphMinWidth}px;
  height: ${graphMinHeight}px;
  position: relative;

  ${({ theme }) => theme.breakpoints.down('xs')} {
    order: -1;
  }

  /* Custom breakpoint to fit graph width */
  @media (min-width: ${graphMinWidth}px) {
    width: 100%;
    padding-bottom: ${(graphMinHeight / graphMinWidth) * 100}%;
  }
`

const GridInner = styled.div`
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;

  & > div {
    display: flex;
    overflow: hidden;
  }
`

const Fund: React.FC<FundProps> = ({ resultFundType, showMoreInfo, chart }) => {
  const isOverMinWidth = useMediaQuery(`(min-width:${graphMinWidth}px)`)
  const resultAndClosestFund = getFundsAdjacentToFund(
    resultFundType,
    chart.comparisonTable
  )
  const [checkedFunds, setCheckedFunds] = useState<IKiwisaverFundType[]>(
    resultAndClosestFund
  )

  const toggleItem = (item: IKiwisaverFundType) => {
    if (item === resultFundType) return
    let fundsToCheck

    if (checkedFunds.includes(item)) {
      fundsToCheck = checkedFunds.filter((x) => x !== item)
    } else {
      fundsToCheck = [...checkedFunds, item]
    }

    setCheckedFunds(
      sortFundsByChartFundOrder(fundsToCheck, chart.comparisonTable)
    )
  }

  // Prepare funds result data to be passed down
  const formatCommaNoDecimal = format(',.0f')
  const fundsResultData: FundsResultData[] = chart.comparisonTable.map(
    ({ title, shortname, type }) => {
      const lastFundSet = getLastFundSet(type, chart.monthlyData)
      return {
        title,
        shortname,
        fund: type,
        formattedValue: `$${formatCommaNoDecimal(lastFundSet?.value || 0)}`,
      }
    }
  )

  return (
    <FundContainer>
      <FundNav
        resultFundType={resultFundType}
        showMoreInfo={showMoreInfo}
        checkedFunds={checkedFunds}
        fundsResultData={fundsResultData}
        onToggleItem={toggleItem}
      />
      <GridContainer>
        <GridInner>
          <ErrorBoundaryMessage>
            <ParentSize>
              {({ width: w, height: h }) => {
                if (!isOverMinWidth) {
                  w = graphMinWidth
                  h = graphMinHeight
                }

                return (
                  <FundGraph
                    graphMinWidth={graphMinWidth}
                    width={w}
                    height={h}
                    chart={chart}
                    resultFundType={resultFundType}
                    showMoreInfo={showMoreInfo}
                    checkedFunds={checkedFunds}
                    fundsResultData={fundsResultData}
                  />
                )
              }}
            </ParentSize>
          </ErrorBoundaryMessage>
        </GridInner>
      </GridContainer>
    </FundContainer>
  )
}

export default Fund
