import React, { useState } from 'react'
import FundPopover from './FundPopover'
import { render } from '@testing-library/react'
import { act } from 'react-dom/test-utils'
import { InvestToolsProvider } from '../../InvestToolsProvider'

let clickAway = jest.fn()
const MockClickAwayListener = ({ onClickAway, ...props }) => {
  clickAway = jest.fn(() => {
    onClickAway({ target: null })
  })
  return <div {...props} />
}

jest.mock('@material-ui/core/ClickAwayListener', () => (props: any) => (
  <MockClickAwayListener {...props} />
))

const SampleFundPopover = () => {
  const [open, setOpen] = useState(true)
  return (
    <InvestToolsProvider>
      <FundPopover
        isOpen={open}
        autoFocus
        top={0}
        left={0}
        fund="cash"
        handlePopover={() => setOpen(false)}
      >
        Popover content
      </FundPopover>
    </InvestToolsProvider>
  )
}

describe('FundPopover', () => {
  it('should hide popover after clicking away', () => {
    const { getByText } = render(<SampleFundPopover />)
    expect(getByText('Popover content')).toBeVisible()
    act(() => {
      clickAway()
    })
    expect(getByText('Popover content')).not.toBeVisible()
  })
})
