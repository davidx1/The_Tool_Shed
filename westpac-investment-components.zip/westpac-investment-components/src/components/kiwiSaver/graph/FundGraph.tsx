import React, { useState } from 'react'
import styled, { css, StyledProps } from 'styled-components'
import Scrollbar from 'react-scrollbars-custom'
import useMediaQuery from '@material-ui/core/useMediaQuery'
import { Box, Typography, useTheme } from '@material-ui/core'
import { GridRows } from '@vx/grid'
import { scaleTime, scaleLinear } from '@vx/scale'
import { Group } from '@vx/group'
import { AxisBottom, AxisLeft } from '@vx/axis'
import { useInView } from 'react-intersection-observer'
import {
  IKiwisaverFundType,
  IKiwisaverMonthlyData,
} from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { FundProps, FundsResultData } from './KiwiSaverNavGraph'
import FundLine from './FundLine'
import FundGlyph from './FundGlyph'
import Popover from './FundPopover'
import Tooltip from './FundTooltip'
import {
  sortFundsByResultFundTypeLast,
  filterAxisRange,
  getLastFundSet,
  getFundColor,
} from './graphFundUtils'
import ArrowButton from '../../inputs/ArrowButton'

export interface FundSet {
  date: string
  value: number
}

interface WrapperProps {
  graphMinWidth: number
}

interface Props extends FundProps, WrapperProps {
  width: number
  height: number
  checkedFunds: IKiwisaverFundType[]
  fundsResultData: FundsResultData[]
}

export type togglePopover = (
  fund: IKiwisaverFundType,
  override?: boolean,
  autoFocus?: boolean
) => void
export type yScale = (value: number | { valueOf(): number }) => number
export type x = (d: FundSet) => number
export type y = (d: FundSet) => number

const tickLabelSize = 16
const scalePadding = 50
const xMaxTicks = 5
const yTickStep = 50

const margin = {
  top: 60,
  right: 20,
  bottom: 50,
  left: 80,
}

const WrapperAxis = styled.div(
  ({ theme, graphMinWidth }: StyledProps<WrapperProps>) => css`
    padding-left: 15px;

    ${theme.breakpoints.up('sm')} {
      padding-left: 10px;
    }
    ${theme.breakpoints.up('md')} {
      padding-left: 0;
      box-shadow: none;
    }

    @media (max-width: ${graphMinWidth - 1}px) {
      background: ${theme.palette.background.paper};
      box-shadow: 15px 0 15px -15px rgba(0, 0, 0, 0.15);
      z-index: 3;
      transform: translateZ(0);
    }
  `
)

const StyledAxisLeftText = styled.text(
  ({ theme }) => css`
    font-weight: ${theme.typography.fontWeightBold};
    fill: ${theme.palette.text.secondary};
  `
)

// use important as && doesn't apply to Scrollbar children with injected inline styles
const StyledScrollbar = styled(({ graphMinWidth, ...props }) => (
  <Scrollbar {...props} />
))(
  ({ theme, graphMinWidth }: StyledProps<WrapperProps>) => css`
    width: 100%;
    height: 100%;

    .ScrollbarsCustom-Wrapper {
      top: 0;
      left: 0;
      right: 0;
      bottom: 10px;
    }
    .ScrollbarsCustom-Scroller {
      overflow: visible !important;
      padding-bottom: 20px;
      margin-bottom: -21px;
    }

    .ScrollbarsCustom-Content {
      min-height: 100%;
      min-width: 100%;
    }

    .ScrollbarsCustom-Track {
      position: absolute;
      overflow: hidden;
      user-select: none;
      background: none;
    }

    @media (max-width: ${graphMinWidth - 1}px) {
      .ScrollbarsCustom-Scroller {
        overflow-x: scroll !important;
        overflow-y: hidden !important;
      }
      .ScrollbarsCustom-Content {
        padding-left: ${theme.spacing(2)}px !important;
      }
      .ScrollbarsCustom-TrackX {
        height: 7px;
        bottom: 0;
        right: ${theme.spacing(2)}px;
        width: calc(100% - 20px);
      }
      .ScrollbarsCustom-Thumb {
        cursor: pointer;
        border-radius: 4px;
        height: 100%;
        background: ${theme.palette.disabled.light};
      }
    }
  `
)

const WrapperGraph = styled.div`
  position: relative;
`

const RecommendedLabel = styled.div`
  display: block;
  min-width: 83px; /* IE 11 prevent collapse */
  width: 100%;
  flex-grow: 1;
`

const WrapperScroll = styled.div`
  width: calc(100vw - 105px); /*  Window width - yAxis width */
  height: 100%;
`

const TypographyValue = styled(Typography).attrs({ component: 'p' })`
  font-family: ${({ theme }) => theme.typography.fontFamilySecondary};
`

// Ensures the x-axis range includes full years if the first data point is in Jan and the last in Dec
const getXDomain = (monthlyData: IKiwisaverMonthlyData[]) => {
  const xDates = monthlyData.map((x) => new Date(x.date).getTime())
  const minMaxDateRange = [
    new Date(Math.min.apply(null, xDates)),
    new Date(Math.max.apply(null, xDates)),
  ]

  const getFirstDayOfMonth = (date: Date, month?: number) =>
    new Date(date.getFullYear(), month ?? date.getMonth(), 1)

  // X-axis needs 01.01 to include the year
  return minMaxDateRange.map((date) => {
    // January
    if (date.getMonth() === 0 && date.getDate() > 1) {
      return getFirstDayOfMonth(date)
    }
    // December
    else if (date.getMonth() === 11) {
      return getFirstDayOfMonth(date, date.getMonth() + 1)
    }
    return date
  })
}

const Graph: React.FC<Props> = ({
  graphMinWidth,
  width,
  height,
  chart,
  resultFundType,
  checkedFunds,
  showMoreInfo,
  fundsResultData,
}) => {

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('xs'));
  
  const widthInner = width - margin.left - margin.right
  const heightInner = height - margin.top - margin.bottom
  const heightScale = heightInner - scalePadding

  const xYears = chart.monthlyData
    .map((x) => new Date(x.date).getFullYear())
    .filter((x, i, arr) => arr.indexOf(x) === i)
  const xDomain = getXDomain(chart.monthlyData)

  const yDomainMax = chart.monthlyData.reduce((a, c) => {
    const { date, ...rest } = c
    const arr = Object.values(rest)

    return Math.max(a, Math.max(...arr))
  }, 0)

  // Ceil to nearest number divisible by yTickStep to get enough ticks on the y axis
  const yDomainRounded = Math.ceil(yDomainMax / yTickStep) * yTickStep
  const yDomain = [0, yDomainRounded]
  const yNumTicks = 6

  const xScale = scaleTime({
    domain: xDomain,
    range: [0, widthInner],
  })

  const yScale = scaleLinear({
    domain: yDomain,
    range: [heightInner, 0],
  })

  // Accessors
  const date = (d: FundSet) => new Date(d.date)
  const value = (d: FundSet) => d.value

  // Positions
  const x: x = (d) => xScale(date(d))
  const y: y = (d) => yScale(value(d))

  const getFundSetPoint = (set: FundSet) => ({
    value: set.value,
    x: x(set),
    y: y(set) + margin.top,
  })

  // Sort the result fund type last to get the highest stacking order in svg (doesn't support z-index)
  const funds =
    checkedFunds.length > 1
      ? sortFundsByResultFundTypeLast(checkedFunds, resultFundType)
      : checkedFunds

  // Coords for "Recommended" label
  const resultFundData =
    chart.monthlyData[Math.round(chart.monthlyData.length / 2)]
  const recommendedCoords = resultFundData
    ? getFundSetPoint({
        value: resultFundData[resultFundType],
        date: resultFundData.date,
      })
    : null

  const isOverMinWidth = useMediaQuery(`(min-width:${graphMinWidth}px)`, {
    noSsr: true,
  })

  // Popovers
  const [autoFocus, setAutoFocus] = useState(false)
  const [openPopover, setOpenPopover] = useState<
    IKiwisaverFundType | undefined
  >(isOverMinWidth ? resultFundType : undefined)
  const togglePopover: togglePopover = (fund, override, autoFocus = false) => {
    const defaultValue = isOverMinWidth ? resultFundType : undefined
    setAutoFocus(false)
    if (override !== undefined) {
      setOpenPopover(override ? fund : defaultValue)
    } else {
      setOpenPopover(openPopover !== fund ? fund : defaultValue)
    }
    setAutoFocus(autoFocus)
  }

  // Toggle graph animation with an intersectionObserver when intersecting viewport
  const [svgGraphRef, inView] = useInView({
    triggerOnce: true,
  })

  return (
    <React.Fragment>
      <WrapperAxis graphMinWidth={graphMinWidth}>
        <svg width={margin.left} height={height}>
          <AxisLeft scale={yScale} hideAxisLine hideTicks numTicks={yNumTicks}>
            {(axis) => (
              <g transform={`translate(${margin.left},${margin.top})`}>
                {axis.ticks.map((tick, i) => (
                  <g
                    key={`vx-tick-y-${tick.value}-${i}`}
                    transform={`translate(${tick.to.x}, ${tick.to.y})`}
                  >
                    <StyledAxisLeftText
                      dx="-6px"
                      dy="0.25em"
                      fontSize={tickLabelSize}
                      textAnchor="end"
                    >
                      ${tick.formattedValue}
                    </StyledAxisLeftText>
                  </g>
                ))}
              </g>
            )}
          </AxisLeft>
        </svg>
      </WrapperAxis>

      <WrapperScroll>
        <StyledScrollbar
          noScrollX={isOverMinWidth}
          noScrollY
          noDefaultStyles
          scrollLeft={500}
          graphMinWidth={graphMinWidth}
        >
          <WrapperGraph>
            <svg
              width={width > margin.left ? width - margin.left : width}
              height={height}
              ref={svgGraphRef}
            >
              <g transform={`translate(0,${margin.top})`}>
                <GridRows
                  scale={yScale}
                  stroke="#dadada"
                  width={widthInner}
                  height={heightScale}
                  numTicks={yNumTicks}
                />

                {funds.map((fund) => (
                  <FundLine
                    key={`scale-${fund}-`}
                    lineType={fund === resultFundType ? 'solid' : 'dashed'}
                    chart={chart}
                    fund={fund}
                    yScale={yScale}
                    x={x}
                    y={y}
                    playAnimation={inView}
                  />
                ))}

                {/* At the moment the axis accepts a minimum of 1 full year (Jan-Dec) */}
                <AxisBottom
                  top={heightScale + margin.bottom}
                  numTicks={xYears.length} // Must be equal to the amount of unique years otherwise @vx might omit data
                  scale={xScale}
                >
                  {(axis) =>
                    filterAxisRange(axis.ticks, xMaxTicks).map(
                      (tick, i, arr) => {
                        const alignment =
                          i === 0
                            ? 'start'
                            : i !== arr.length - 1
                            ? 'middle'
                            : 'end'

                        // Do not use tick.formattedValue, it sometimes returns time instead of year
                        const formattedValue = new Date(
                          tick.value
                        ).getFullYear()

                        return (
                          <Group key={`vx-tick-x-${tick.value}-${i}`}>
                            <StyledAxisLeftText
                              transform={`translate(${tick.to.x}, ${
                                tick.to.y + tickLabelSize + axis.tickLength
                              })`}
                              fontSize={tickLabelSize}
                              textAnchor={alignment}
                            >
                              {formattedValue}
                            </StyledAxisLeftText>
                          </Group>
                        )
                      }
                    )
                  }
                </AxisBottom>
              </g>
            </svg>

            {recommendedCoords && (
              <Tooltip
                fund={resultFundType}
                top={recommendedCoords.y}
                left={recommendedCoords.x}
                isOpen
              >
                <RecommendedLabel>
                  <span aria-hidden="true">Recommended</span>
                  <Typography variant="srOnly">
                    {`Recommended for you: ${resultFundType} fund`}
                  </Typography>
                </RecommendedLabel>
              </Tooltip>
            )}

            {funds.map((fund) => {
              const lastChartData =
                chart.monthlyData[chart.monthlyData.length - 1]
              if (!lastChartData) {
                return null
              }
              const lastDataSet = {
                date: lastChartData.date,
                value: lastChartData[fund],
              }
              const color = getFundColor(fund)
              const { x, y } = getFundSetPoint({
                value: lastDataSet.value,
                date: lastDataSet.date,
              })
              return (
                <FundGlyph
                  key={`glyph${fund}`}
                  fund={fund}
                  color={color}
                  x={x}
                  y={y}
                  playAnimation={inView}
                  openPopover={openPopover}
                  handlePopover={togglePopover}
                />
              )
            })}

            {!isMobile && fundsResultData.map(({ fund, shortname, formattedValue }) => {
              const lastFundSet = getLastFundSet(fund, chart.monthlyData)
              if (!lastFundSet) {
                return null
              }
              const { x, y } = getFundSetPoint(lastFundSet)
              return (
                <Popover
                  key={`popover-${fund}`}
                  top={y}
                  left={x}
                  fund={fund}
                  isOpen={openPopover === fund}
                  autoFocus={autoFocus}
                  handlePopover={togglePopover}
                >
                  <Box py={2.5} px={3}>
                    <Typography variant="h6" gutterBottom>
                      {shortname} Fund
                    </Typography>
                    <TypographyValue variant="h3" color="primary">
                      {formattedValue}
                    </TypographyValue>
                    <Box mt={1.5}>
                      <ArrowButton
                        fontWeight="fontWeightMedium"
                        onClick={() => showMoreInfo(fund)}
                      >
                        More about this fund
                      </ArrowButton>
                    </Box>
                  </Box>
                </Popover>
              )
            })}
          </WrapperGraph>
        </StyledScrollbar>
      </WrapperScroll>
    </React.Fragment>
  )
}

export default Graph
