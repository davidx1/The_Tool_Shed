import React from 'react'
import styled, { css } from 'styled-components'
import { LinePath } from '@vx/shape'
import { curveBasis } from '@vx/curve'
import { LineProps, AnimationProps } from './FundLine'
import { pathAnimation } from '../../../styles/sharedStyles'

const AnimatedMask = styled.path(
  ({ playAnimation }: AnimationProps) => css`
    fill: none;
    stroke: white;
    stroke-width: 10;

    @media (prefers-reduced-motion: no-preference) {
      ${pathAnimation}
      animation-play-state: ${playAnimation ? 'running' : 'paused'};
    }
  `
)

const FundLineDashed: React.FC<Omit<LineProps, 'yScale'>> = ({
  fund,
  color,
  data,
  x,
  y,
  playAnimation,
}) => {
  return (
    <React.Fragment>
      {/* 
      Create a mask to animate the length of the dashed path, 
      otherwise the dashes would just offset indefinitely along the entire path
      */}
      <defs>
        <mask id={`pathDashMask${fund}`}>
          <LinePath data={data} x={x} y={y} curve={curveBasis}>
            {({ path }) => {
              const d = path(data)
              return d && <AnimatedMask playAnimation={playAnimation} d={d} />
            }}
          </LinePath>
        </mask>
      </defs>

      <g>
        <LinePath data={data} x={x} y={y} curve={curveBasis}>
          {({ path }) => {
            const d = path(data)
            return (
              d && (
                <path
                  d={d}
                  strokeLinecap="round"
                  strokeWidth={3}
                  strokeDasharray="3,10"
                  stroke={color}
                  fill="none"
                  mask={`url(#pathDashMask${fund})`}
                  data-testid={`graph-line-${fund}`}
                />
              )
            )
          }}
        </LinePath>
      </g>
    </React.Fragment>
  )
}

export default FundLineDashed
