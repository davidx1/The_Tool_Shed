import {
  IKiwisaverFundItem,
  IKiwisaverFundType,
  IKiwisaverMonthlyData,
} from '../../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

/**
 * Get an array of funds in the correct order
 * @param comparisonTable The chart comparison table - the basis for the funds sort order
 */
export const getAllFundsInOrder = (comparisonTable: IKiwisaverFundItem[]) =>
  comparisonTable.map(({ type }) => type)

/**
 * Gets the last FundSet data for a given FundType
 * @param fund
 * @param chartData
 */
export const getLastFundSet = (
  fund: IKiwisaverFundType,
  chartData: IKiwisaverMonthlyData[]
) =>
  chartData?.length > 0
    ? {
        date: chartData[chartData.length - 1].date,
        value: chartData[chartData.length - 1][fund],
      }
    : null

/**
 * Sorts an array of funds to match the chart data order for consistency
 * @param arr Array of funds to sort
 * @param comparisonTable The chart comparison table - the basis for the funds sort order
 */
export const sortFundsByChartFundOrder = (
  arr: IKiwisaverFundType[],
  comparisonTable: IKiwisaverFundItem[]
) => {
  const fundsOrder = getAllFundsInOrder(comparisonTable)
  return [...arr].sort((a, b) => fundsOrder.indexOf(a) - fundsOrder.indexOf(b))
}

/**
 * Sorts the result fund type last
 * @param arr Array to sort
 * @param order FundType to sort last
 */
export const sortFundsByResultFundTypeLast = (
  arr: IKiwisaverFundType[],
  order: IKiwisaverFundType
) => [...arr].sort((a) => (a === order ? 1 : -1))

/**
 * Gets an array of numAdjacent adjacent FundTypes to fund, plucked from the comparisonTable
 * @param fund
 * @param comparisonTable The chart comparison table - the basis for the funds sort order
 * @param numAdjacent number of other funds to include
 * @returns KiwisaverFundType[] including fund
 */
export const getFundsAdjacentToFund = (
  fund: IKiwisaverFundType,
  comparisonTable: IKiwisaverFundItem[],
  numAdjacent = 2
): IKiwisaverFundType[] => {
  const fundsOrder = getAllFundsInOrder(comparisonTable)
  const idx = fundsOrder.indexOf(fund)
  const n = numAdjacent + 1
  const offset = Math.floor(n / 2)
  const offsetStart = idx - offset > -1 ? idx - offset : 0

  const end =
    offsetStart + n < fundsOrder.length ? offsetStart + n : fundsOrder.length
  const start = end < fundsOrder.length ? offsetStart : end - n

  return fundsOrder.slice(start, end)
}

/**
 * Gets a start and end inclusive range for an axis array
 * @param arr
 * @param maxTicks
 */
export const filterAxisRange = (arr: any[], maxTicks: number) => {
  if (arr.length <= maxTicks) return arr

  const totalItems = arr.length - 2
  const step = Math.floor(totalItems / (maxTicks - 2))
  let nums = [arr[0]]

  for (let i = 1; i < maxTicks - 1; i++) {
    if (i * step - 2 <= totalItems - step) nums.push(arr[i * step])
  }
  nums.push(arr[arr.length - 1])

  return nums
}

export const getFundColor = (fund?: IKiwisaverFundType) => {
  switch (fund) {
    case 'cash':
      return '#636363'
    case 'conservative':
      return '#007A1C'
    case 'moderate':
      return '#40BBC4'
    case 'balanced':
      return '#222222'
    case 'growth':
      return '#2A8289'
    case 'defensive':
    default:
      return '#E94E1B'
  }
}
