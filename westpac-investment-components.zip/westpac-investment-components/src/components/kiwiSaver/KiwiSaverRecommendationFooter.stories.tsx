import React from 'react'
import { kiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'

import KiwiSaverRecommendationFooter from './KiwiSaverRecommendationFooter'

export default {
  title: 'KiwiSaver/KiwiSaverRecommendationFooter',
  component: KiwiSaverRecommendationFooter,
}

export const Basic = () => (
  <KiwiSaverRecommendationFooter
    faqLinkHandler={() => {}}
    contactUsLinkHandler={() => {}}
    config={kiwisaverFundChooserConfig}
  />
)
