import React, { FC } from 'react'
import styled, { css, useTheme } from 'styled-components'
import { Typography, Grid, Box, useMediaQuery } from '@material-ui/core'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import { IKiwisaverFundItem } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

const IconWrapper = styled.div`
  ${({ theme }) => css`
    height: 60px;
    width: 60px;
    ${theme.breakpoints.down('xs')} {
      height: 80px;
      width: 80px;
    }
  `}
`
const TypographyLead = styled(Typography).attrs({
  component: 'p',
})`
  ${({ theme }) => css`
    &:not(:last-child) {
      margin-bottom: ${theme.spacing(2)}px;
    }
    ${theme.breakpoints.down('sm')} {
      font-size: ${theme.typography.pxToRem(20)};
      line-height: ${theme.typography.pxToRem(26)};
    }
  `}
`

const TypographyFund = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(24)};
    line-height: ${theme.typography.pxToRem(31)};
  `
)

export interface Props {
  title: string
  recommendation: IKiwisaverFundItem
}

const KiwiSaverRecommendationHeader: FC<Props> = ({
  title,
  recommendation,
}) => {
  const theme = useTheme()
  const desktopDown = useMediaQuery(theme.breakpoints.down('xs'))
  const iconSize = desktopDown ? 80 : 60
  return (
    <React.Fragment>
      <Typography variant="h2" gutterBottom>
        {title}
      </Typography>

      <Grid container direction="row" wrap="nowrap" alignItems="center">
        <TypographyFund variant="h3">{recommendation.title}</TypographyFund>

        <IconWrapper>
          <DynamicIcon
            icon={recommendation.type}
            height={iconSize}
            width={iconSize}
          />
        </IconWrapper>
      </Grid>

      <Box mt={1} mb={4}>
        {recommendation.description.map((descriptionBlock, iBlock) => (
          <TypographyLead variant="subtitle1" key={iBlock}>
            {descriptionBlock}
          </TypographyLead>
        ))}
      </Box>
    </React.Fragment>
  )
}

export default KiwiSaverRecommendationHeader
