import React from 'react'
import KiwiSaverRecommendationFooter from './KiwiSaverRecommendationFooter'
import { kiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { render, fireEvent } from '@testing-library/react'

describe('<KiwiSaverRecommendationFooter/>', () => {
  it('should call handlers for each link in the component', () => {
    const faqLinkHandler = jest.fn()
    const contactUsLinkHandler = jest.fn()
    const { getByText } = render(
      <InvestToolsProvider>
        <KiwiSaverRecommendationFooter
          faqLinkHandler={faqLinkHandler}
          contactUsLinkHandler={contactUsLinkHandler}
          config={kiwisaverFundChooserConfig}
        />
      </InvestToolsProvider>
    )
    fireEvent.click(getByText('Read our FAQs'))
    expect(faqLinkHandler).toBeCalledTimes(1)
    fireEvent.click(getByText('0508 972 254'))
    expect(contactUsLinkHandler).toBeCalledTimes(1)
  })
})
