import React from 'react'
import { Box, Typography, Grid, Button, Paper } from '@material-ui/core'
import styled, { css } from 'styled-components'
import { IKiwisaverFundItem } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import LinkButton from '../../components/inputs/LinkButton'

const BREAKPOINT_MIN = 768

const GridItem = styled(Grid).attrs({
  item: true,
})`
  @media (max-width: ${BREAKPOINT_MIN - 1}px) {
    flex-grow: 0;
    max-width: 100%;
    flex-basis: 100%;
  }
`

const GridDivider = styled(GridItem)(
  ({ theme }) => css`
    position: relative;

    @media (max-width: ${BREAKPOINT_MIN - 1}px) {
      margin-top: ${theme.spacing(2)}px;
      margin-bottom: ${theme.spacing(2)}px;
    }

    &:before {
      content: '';
      display: block;
      position: absolute;
      background: ${theme.palette.text.hint};
      left: 20%;
      width: 60%;
      height: 1px;

      @media (min-width: ${BREAKPOINT_MIN}px) {
        margin-bottom: 0px;
        bottom: ${theme.spacing(1)}px;
        left: 50%;
        width: 1px;
        height: 70%;
      }
    }
  `
)

const FixedHeightGridItem = styled(GridItem)`
  ${({ theme }) => css`
    ${theme.breakpoints.up(BREAKPOINT_MIN)} {
      height: 115px;
    }
  `}
`

const ItemDescription = styled(Typography).attrs({ component: 'p' })(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(16)};
    padding: ${theme.spacing(0, 6)};
    margin-bottom: ${theme.spacing(1)}px;
    &:last-child {
      margin-bottom: ${theme.spacing(1)}px;
    }
  `
)

export interface Props {
  recommendedFund: IKiwisaverFundItem
  isContained?: boolean
  changeUrl: string
  joinUrl: string
  showOtherOptions?: () => void
}

const ResultsJoinOrChange: React.FC<Props> = ({
  recommendedFund,
  isContained,
  changeUrl,
  joinUrl,
  showOtherOptions,
}) => {
  return (
    <Box mx={isContained ? [0, 2, 4] : [-2, -3, 0]} mt={3}>
      <Paper elevation={isContained ? 0 : 4}>
        {!isContained && (
          <Box bgcolor="background.grey" py={3} px={2}>
            <Typography variant="h2" component="p" align="center" gutterBottom>
              Make a change.
            </Typography>
          </Box>
        )}
        <Box p={3}>
          <Box pt={2}>
            <Grid container spacing={1} justify="space-between">
              <FixedHeightGridItem sm>
                <HalfTallDiv>
                  <ItemDescription variant="h6" align="center">
                    Already a Westpac KiwiSaver Scheme customer?
                  </ItemDescription>
                </HalfTallDiv>
                <HalfTallDiv>
                  <Button color="primary" variant="contained" href={changeUrl}>
                    Change to {recommendedFund.shortname} Fund
                  </Button>
                </HalfTallDiv>
              </FixedHeightGridItem>
              <GridDivider item xs={12} sm="auto" />
              <FixedHeightGridItem sm>
                <HalfTallDiv>
                  <ItemDescription variant="h6" align="center">
                    Join the Westpac KiwiSaver Scheme?
                  </ItemDescription>
                </HalfTallDiv>

                <HalfTallDiv>
                  <Button color="primary" variant="contained" href={joinUrl}>
                    Join now
                  </Button>
                </HalfTallDiv>
              </FixedHeightGridItem>
              {showOtherOptions && (
                <Grid item xs={12}>
                  <Box mt={[2, 3]}>
                    <Typography align="center">
                      Not sure about this fund?
                    </Typography>
                    <Box textAlign="center">
                      <LinkButton onClick={showOtherOptions}>
                        Explore other fund options
                      </LinkButton>
                    </Box>
                  </Box>
                </Grid>
              )}
            </Grid>
          </Box>
        </Box>
      </Paper>
    </Box>
  )
}

const HalfTallDiv = styled.div`
  height: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
`

export default ResultsJoinOrChange
