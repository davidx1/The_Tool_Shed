import React from 'react'
import { kiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'

import KiwiSaverRecommendationDisclaimer from './KiwiSaverRecommendationDisclaimer'

export default {
  title: 'KiwiSaver/KiwiSaverRecommendationDisclaimer',
  component: KiwiSaverRecommendationDisclaimer,
}

export const Basic = () => (
  <KiwiSaverRecommendationDisclaimer
    kiwisaverFundChooserConfig={kiwisaverFundChooserConfig}
  />
)

Basic.parameters = {
  storyshots: false,
}
