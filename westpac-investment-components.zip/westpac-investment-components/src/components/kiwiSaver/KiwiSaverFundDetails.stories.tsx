import React from 'react'

import KiwiSaverFundDetails from './KiwiSaverFundDetails'
import { IKiwisaverFundItem } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { kiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'

const recommendation = {
  type: 'defensive',
  title: 'Westpac KiwiSaver Scheme Default Fund',
  shortname: 'Default',
  description: ['description'],
  feeDetails: ['feeDetails'],
  shortDescription: ['shortDescription'],
  averageAnnualReturn: 0,
  adminFeePerYear: 12,
  annualFundChargePercent: 0,
  annualFundChargeDescription: 'so that’s 0¢ for every $100 per year',
}

export default {
  title: 'KiwiSaver/KiwiSaverFundDetails',
  component: KiwiSaverFundDetails,
}

export const Basic = () => (
  <KiwiSaverFundDetails
    fundItem={recommendation as IKiwisaverFundItem}
    config={kiwisaverFundChooserConfig}
    changeFund={() => {}}
    goBack={() => {}}
  />
)
