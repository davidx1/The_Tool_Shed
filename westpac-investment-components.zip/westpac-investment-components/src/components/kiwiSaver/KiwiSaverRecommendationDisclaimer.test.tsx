import React from 'react'
import KiwiSaverRecommendationDisclaimer from './KiwiSaverRecommendationDisclaimer'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { render } from '@testing-library/react'

import { kiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/__mocks__/kiwiSaverFundMockData'
import { IKiwisaverFundChooserConfig } from '../..'

describe('<KiwiSaverRecommendationDisclaimer/>', () => {
  it('should render the disclaimer with the dynamic content', () => {
    const { container } = render(
      <InvestToolsProvider>
        <KiwiSaverRecommendationDisclaimer
          kiwisaverFundChooserConfig={kiwisaverFundChooserConfig}
        />
      </InvestToolsProvider>
    )
    expect(container.firstChild).toMatchSnapshot()
  })

  it('should not render if empty', () => {
    const { container } = render(
      <KiwiSaverRecommendationDisclaimer
        kiwisaverFundChooserConfig={{} as IKiwisaverFundChooserConfig}
      />
    )
    expect(container.firstChild).toBeNull()
  })
})
