import React from 'react'

import KiwiSaverJoinOrChange from './KiwiSaverJoinOrChange'
import { IKiwisaverFundItem } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

const recommendation = {
  type: 'growth',
} as IKiwisaverFundItem

export default {
  title: 'KiwiSaver/KiwiSaverJoinOrChange',
  component: KiwiSaverJoinOrChange,
}

export const Basic = () => (
  <KiwiSaverJoinOrChange
    recommendedFund={recommendation}
    changeUrl="https://"
    joinUrl="https://"
  />
)

export const Contained = () => (
  <KiwiSaverJoinOrChange
    recommendedFund={recommendation}
    changeUrl="https://"
    joinUrl="https://"
    isContained
    showOtherOptions={() => {}}
  />
)
