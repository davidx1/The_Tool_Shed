import React, { FC } from 'react'
import styled from 'styled-components'

import { Typography } from '@material-ui/core'
import { IKiwisaverFundChooserConfig } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import HTMLRenderer from '../dataDisplay/HTMLRenderer'
import { urlCss } from '../../styles/sharedStyles'

export interface Props {
  kiwisaverFundChooserConfig: IKiwisaverFundChooserConfig
}

const Description = styled(Typography).attrs({
  component: 'div',
  variant: 'overline',
  color: 'textSecondary',
})`
  ${urlCss}
`

const KiwisaverRecommendationDisclaimer: FC<Props> = ({
  kiwisaverFundChooserConfig,
}) => {
  const disclaimer = kiwisaverFundChooserConfig?.recommendationDisclosures?.join(
    ''
  )
  return disclaimer ? (
    <Description>
      <HTMLRenderer value={disclaimer} />
    </Description>
  ) : null
}

export default KiwisaverRecommendationDisclaimer
