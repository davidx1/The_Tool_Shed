import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Typography, Box, Button, Grid } from '@material-ui/core'
import UnderlineButton from '../inputs/UnderlineButton'
import {
  IKiwisaverFundItem,
  IKiwisaverFundChooserConfig,
} from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { DisclaimerText } from '../dataDisplay/HTMLRenderer'

export interface Props {
  fundItem: IKiwisaverFundItem
  changeFund?: (fundItem: IKiwisaverFundItem) => void
  config: IKiwisaverFundChooserConfig
  goBack: () => void
}

const AverageReturnLabel = styled(Typography).attrs({ component: 'p' })`
  ${({ theme }) => ({
    fontSize: theme.typography.pxToRem(64),
    lineHeight: theme.typography.pxToRem(70),
  })}
`

const PerYearLabel = styled(Typography)`
  ${({ theme }) => css`
    font-weight: ${theme.typography.fontWeightBold};
    margin-top: -6px;
  `}
`

const ValueLabel = styled(Typography).attrs({ variant: 'body1' })`
  ${({ theme }) => css`
    color: ${theme.palette.secondary.main};
    font-weight: ${theme.typography.fontWeightBold};
  `}
`

const StyledButton = styled(Button)`
  ${({ theme }) => css`
    margin: ${theme.spacing(1, 4, 0, 0)};
    ${theme.breakpoints.down('xs')} {
      width: 100%;
      margin: ${theme.spacing(1, 0, 0)};
    }
  `}
`

const CloseButton = styled(UnderlineButton)`
  ${({ theme }) => css`
    margin: ${theme.spacing(1, 0)};
    ${theme.breakpoints.down('xs')} {
      margin: 20px auto 0;
      display: block;
    }
  `}
`

const KiwiSaverFundDetails: FC<Props> = ({
  fundItem,
  config,
  changeFund,
  goBack,
}) => (
  <Box bgcolor="background.paper" px={[2, 4]} pb={[4, 5]} pt={3}>
    <Grid container alignItems="center" spacing={1}>
      <Grid item>
        <AverageReturnLabel variant="h1" color="primary">
          {fundItem.averageAnnualReturn}
        </AverageReturnLabel>
      </Grid>
      <Grid item>
        <Typography variant="h3" component="p">
          %
        </Typography>
        <PerYearLabel>per year</PerYearLabel>
      </Grid>
    </Grid>
    <Box mt={1} mb={3}>
      <Typography variant="body1">
        This is the average annual return over five years (after annual fund
        charges and taxes) as at {config.returnsUpdatedAt}.
      </Typography>
    </Box>

    <Typography variant="h6" component="h3" gutterBottom>
      Who's it for?
    </Typography>
    {fundItem.shortDescription?.map((targetBlock, iBlock) => (
      <Typography variant="body1" gutterBottom key={iBlock}>
        {targetBlock}
      </Typography>
    ))}

    <Box my={3} maxWidth={520}>
      <Typography variant="h6" component="h3" gutterBottom>
        What do I pay?
      </Typography>
      <Grid container spacing={1}>
        <Grid item xs={6}>
          <Typography variant="body1">Administration Fee</Typography>
        </Grid>
        <Grid item xs={6}>
          <ValueLabel>${fundItem.adminFeePerYear} per year</ValueLabel>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="body1">Estimated annual fund charge*</Typography>
          <Typography variant="overline">
            ({fundItem.annualFundChargeDescription})
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <ValueLabel>{fundItem.annualFundChargePercent}%</ValueLabel>
        </Grid>
      </Grid>
    </Box>

    {changeFund && (
      <StyledButton
        color="primary"
        variant="contained"
        onClick={() => changeFund(fundItem)}
      >
        Change to this fund
      </StyledButton>
    )}
    <CloseButton onClick={goBack}>Go back</CloseButton>
    <Box mt={[3, 4, 5]}>
      <DisclaimerText value="* Annual fund charges are percentages of the net asset values of a fund. These include estimates of manager and supervisor expenses and applicable underlying fund charges. Actual fund charges will depend on the expenses incurred and performance of the underlying funds and their investment managers and will vary from the estimates. Actual fund charges are available in the latest fund updates. The estimate is as at the date of the most recent Product Disclosure Statement." />
    </Box>
  </Box>
)

export default KiwiSaverFundDetails
