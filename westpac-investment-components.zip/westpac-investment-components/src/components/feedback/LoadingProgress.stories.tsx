import React from 'react'

import LoadingProgress from './LoadingProgress'

export default {
  title: 'Feedback/LoadingProgress',
  component: LoadingProgress,
}

export const Basic = () => {
  return <LoadingProgress isActive fullWidth />
}
