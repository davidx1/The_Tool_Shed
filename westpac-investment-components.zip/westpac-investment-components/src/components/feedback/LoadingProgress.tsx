import React, { FC } from 'react'
import styled, { css, StyledProps } from 'styled-components'
import { fadeIn, fadeInUp, fadeInUpInitial } from '../../styles/sharedStyles'
import { spacing } from '../../styles/theme'
import CircularProgress from '@material-ui/core/CircularProgress'
import { Typography } from '@material-ui/core'
import { DIALOG_HEADER_HEIGHT } from '../dialog/DialogFullScreen'

interface OverlayProps {
  isFixed?: boolean
}

interface ContainerProps {
  fullWidth?: boolean
}

export interface Props extends OverlayProps, ContainerProps {
  isActive: boolean
}

const sharedOverlayStyles = css`
  width: 100%;
  top: 0;
  left: 0;
`

const ProgressOverlay = styled.div(
  ({ isFixed }: StyledProps<OverlayProps>) => css`
    ${sharedOverlayStyles}
    position: ${isFixed ? 'absolute' : 'relative'};
    display: flex;
    align-items: center;
    ${
      isFixed
        ? css`
            height: 100%;
            padding-top: ${DIALOG_HEADER_HEIGHT}px;
          `
        : css`
            flex-grow: 1;
          `
    }

    &:before {
      ${sharedOverlayStyles}
      height: 100%;
      position: ${isFixed ? 'fixed' : 'relative'};
      content: '';
      background: rgba(255, 255, 255, 0.7);
      animation: ${fadeIn} 0.74s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    }
  `
)

const ProgressTitle = styled(Typography).attrs({
  variant: 'h6',
  component: 'p',
  align: 'center',
})`
    margin: ${spacing(2)}px 0;
    ${fadeInUpInitial}
    animation: ${fadeInUp} 0.36s cubic-bezier(0.0, 0.0, 0.2, 1) forwards;
`

const ProgressContainer = styled.div(
  ({ fullWidth }: StyledProps<ContainerProps>) =>
    fullWidth &&
    css`
      min-width: 100%;
    `
)

const ProgressInner = styled.div(
  ({ theme, fullWidth }: StyledProps<ContainerProps>) =>
    css`
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin: ${fullWidth ? 'auto' : ' 0 auto 0 0'};

      ${theme.breakpoints.up('md')} {
        max-width: ${fullWidth ? 100 : 50}%;
      }
    `
)

const LoadingProgress: FC<Props> = ({
  isActive,
  isFixed,
  fullWidth,
  children,
}) => {
  return isActive ? (
    <ProgressOverlay role="status" aria-live="assertive" isFixed={isFixed}>
      <ProgressContainer
        className="MuiContainer-root MuiContainer-maxWidthLg"
        fullWidth={fullWidth}
      >
        <ProgressInner
          className="MuiContainer-root MuiContainer-maxWidthLg"
          fullWidth={fullWidth}
        >
          <CircularProgress />
          <ProgressTitle>{children}</ProgressTitle>
        </ProgressInner>
      </ProgressContainer>
    </ProgressOverlay>
  ) : null
}

export default LoadingProgress
