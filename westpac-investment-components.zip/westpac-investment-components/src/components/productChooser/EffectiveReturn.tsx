import React from 'react'
import { IProductChooserInterestEffectiveReturn } from '../../utils/product-chooser/productChooserUtils'
import { Typography, Box } from '@material-ui/core'
import styled, { css } from 'styled-components'

export interface Props {
  effectiveReturn: IProductChooserInterestEffectiveReturn
}

const StyledReturnContainer = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`

const StyledTypography = styled(Typography)(
  ({ theme }) => css`
    font-weight: ${theme.typography.fontWeightMedium};
  `
)

const EffectiveReturn = ({ effectiveReturn }: Props) => {
  const { thirty, thirtyThree } = effectiveReturn
  return (
    <Box mb={5}>
      <StyledTypography>Effective return^</StyledTypography>
      <StyledReturnContainer>
        <Typography>Income Tax Rate is 30%^^</Typography>
        <StyledTypography>{thirty}% p.a.</StyledTypography>
      </StyledReturnContainer>
      <StyledReturnContainer>
        <Typography>Income Tax Rate is 33%^^^</Typography>
        <StyledTypography>{thirtyThree}% p.a.</StyledTypography>
      </StyledReturnContainer>
    </Box>
  )
}

export default EffectiveReturn
