import React from 'react'
import { Typography, Container, Box, Grid, IconButton } from '@material-ui/core'
import styled, { css } from 'styled-components'
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore'
import NavigateNextIcon from '@material-ui/icons/NavigateNext'
import ColumnsCTA from './ColumnsCTA'
import Carousel from '../layout/Carousel'
import ProductChooserInterestRateCard from './ProductChooserInterestRateCard'
import UnderlineButton from '../inputs/UnderlineButton'
import PercentageNumber from '../dataDisplay/PercentageNumber'
import {
  IProductChooserConfig,
  IProductChooserProductItem,
  IProductChooserProductType,
} from '../../utils/product-chooser/productChooserUtils'
import { DisclaimerText } from '../dataDisplay/HTMLRenderer'

export interface Props {
  recommendation: IProductChooserProductItem
  config: IProductChooserConfig
  findInterestFrequency: (
    recommendationType: IProductChooserProductType
  ) => void
}

const StyledSection = styled.section`
  width: 100%;
`

const StyledIconButton = styled(IconButton).attrs({ color: 'secondary' })`
  width: 50px;
  height: 50px;
  padding: 18px; /* Per design = 50x50px */
  margin: auto;
  box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
  z-index: 2;
  transition: transform 0.3s ease;
`

const GridFrequency = styled(Grid)(
  ({ theme }) => css`
    order: 2;
    margin-bottom: ${theme.spacing(3)}px;

    ${theme.breakpoints.up('md')} {
      order: inherit;
      margin: 0 0 0 auto;
    }
  `
)

const TypographyTitle = styled(Typography).attrs({
  variant: 'h2',
})`
  ${({ theme }) => css`
    font-size: ${theme.typography.pxToRem(28)};
    ${theme.breakpoints.up('md')} {
      font-size: ${theme.typography.pxToRem(40)};
    }
  `}
`

const TypographyLead = styled(Typography).attrs({
  component: 'p',
})`
  ${({ theme }) => css`
    font-size: ${theme.typography.pxToRem(18)};
    line-height: ${theme.typography.pxToRem(25)};
    margin-bottom: ${theme.typography.pxToRem(25)};
  `}
`

const StyledImage = styled.img`
  width: 100%;
  height: auto;
  display: block;
`

const ProductChooserRecommendationInterest: React.FC<Props> = ({
  recommendation,
  config,
  findInterestFrequency,
}) => {
  if (!recommendation || !recommendation.interestRates.length) return null

  const handleFindInterest = () => {
    findInterestFrequency(recommendation.type)
  }

  const {
    interestRatesDescription,
    interestRatesTitle,
    interestRatesDisclaimer,
    type,
  } = recommendation
  const {
    annualRatePercent,
    description,
    effectiveReturn,
    disclosure,
  } = recommendation.interestRates[0]

  const showDecorator = type === 'bonusSaverAccount' || type === 'bonusSaverPIE'

  const ButtonRatesAndTerms = (
    <UnderlineButton
      href={config.links.interestRates}
      target="_blank"
      rel="noopener noreferrer"
    >
      See all rates and terms
    </UnderlineButton>
  )
  return (
    <StyledSection>
      {recommendation.interestRates.length > 1 ? (
        <Box pt={[5, 5, 9]} pb={[3, 4, 5]}>
          <Container>
            <Grid container>
              <Grid item xs={12} md="auto">
                <TypographyTitle>{interestRatesTitle}</TypographyTitle>
              </Grid>

              <GridFrequency item xs={12} md="auto">
                <UnderlineButton onClick={handleFindInterest}>
                  Find your {type === 'termPIE' ? 'return' : 'interest'} pay-out
                  frequency
                </UnderlineButton>
              </GridFrequency>

              <Grid item xs={12}>
                <Box mt={[1, 2]} mb={[2, 2, 4]}>
                  {typeof interestRatesDescription === 'string' ? (
                    <TypographyLead variant="subtitle1">
                      {interestRatesDescription}
                    </TypographyLead>
                  ) : (
                    interestRatesDescription?.map((d, i) => (
                      <TypographyLead
                        variant="subtitle1"
                        key={`${d.length}-${i}`}
                      >
                        {d}
                      </TypographyLead>
                    ))
                  )}
                </Box>
              </Grid>
            </Grid>
          </Container>
          <Container>
            <Carousel
              renderRightButton={(handleClick: any) => (
                <StyledIconButton aria-label="See more" onClick={handleClick}>
                  <NavigateNextIcon />
                </StyledIconButton>
              )}
              renderLeftButton={(handleClick: any) => (
                <StyledIconButton aria-label="See more" onClick={handleClick}>
                  <NavigateBeforeIcon />
                </StyledIconButton>
              )}
            >
              {recommendation.interestRates.map(
                (
                  {
                    annualRatePercent,
                    durationInMonths,
                    description,
                    effectiveReturn,
                  },
                  i
                ) => {
                  return (
                    <ProductChooserInterestRateCard
                      key={`${annualRatePercent}-${i}`}
                      durationInMonths={durationInMonths}
                      annualRatePercent={annualRatePercent}
                      actionText="More about rates &amp; terms"
                      actionUrl={config.links.interestRates}
                      description={description}
                      effectiveReturn={effectiveReturn}
                    />
                  )
                }
              )}
            </Carousel>
            {interestRatesDisclaimer && (
              <DisclaimerText value={interestRatesDisclaimer} />
            )}
          </Container>

          <Box display="flex" justifyContent="center" mt={[3.5, 4.5]}>
            {ButtonRatesAndTerms}
          </Box>
        </Box>
      ) : (
        <ColumnsCTA
          title={interestRatesTitle}
          description={description}
          effectiveReturn={effectiveReturn}
          disclosure={disclosure}
          disclosureBottom={interestRatesDisclaimer}
          columnLeft={
            <StyledImage
              src={config.productItems[recommendation.type].ratesImageUrl}
              role="presentation"
              alt=""
            />
          }
          columnRight={
            <Box mb={2} mt={{ xs: 2.25, lg: 3.5 }}>
              <PercentageNumber
                value={annualRatePercent}
                suffix="p.a."
                decorator={showDecorator ? 'Up to' : undefined}
              />
            </Box>
          }
        />
      )}
    </StyledSection>
  )
}

export default ProductChooserRecommendationInterest
