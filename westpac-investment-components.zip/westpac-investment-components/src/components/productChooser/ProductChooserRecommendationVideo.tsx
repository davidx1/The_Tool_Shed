import React, { FC, useState } from 'react'
import styled, { css } from 'styled-components'
import { Typography, ButtonBase } from '@material-ui/core'
import UnderlineButton from '../inputs/UnderlineButton'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import DialogSlim from '../dialog/DialogSlim'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'
import ColumnsCTA from './ColumnsCTA'

export interface ProductChooserRecommendationVideoProps {
  recommendation: IProductChooserProductItem
  findPIRRate: () => void
  videoRenderer?: React.ReactNode
}

const StyledSection = styled.section(
  ({ theme }) => css`
    width: 100%;
    margin-top: ${theme.spacing(4)}px;
    ${theme.breakpoints.up('sm')} {
      margin-top: ${theme.spacing(5)}px;
    }
    ${theme.breakpoints.up('md')} {
      margin-top: ${theme.spacing(7)}px;
    }
  `
)

const PosterButton = styled(ButtonBase)`
  position: relative;
  width: 100%;
  height: 100%;
`
const PosterIcon = styled(DynamicIcon)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
`

const PosterImage = styled.img`
  width: 100%;
  height: auto;
  display: block;
`

const Video = styled.iframe(
  ({ theme }) => css`
    height: 211px;
    ${theme.breakpoints.up('sm')} {
      height: 387px;
    }
    ${theme.breakpoints.up('md')} {
      height: 485px;
    }
  `
)

const ProductChooserRecommendationVideo: FC<ProductChooserRecommendationVideoProps> = ({
  recommendation,
  findPIRRate,
  videoRenderer,
}) => {
  const [openVideoDialog, setOpenVideoDialog] = useState(false)

  if (!recommendation.video) return null
  const { title, description, url, posterImageUrl } = recommendation.video

  const ButtonFindYourPIR = (
    <UnderlineButton onClick={findPIRRate}>
      Find out your Prescribed Investor Rate.
    </UnderlineButton>
  )

  const renderVideo = () => {
    if (videoRenderer) {
      return videoRenderer
    }

    if (url.includes('youtu')) {
      return (
        <Video title="Video" src={url} width="100%" height="100%" />
      )
    }

    return (
      <video width="100%" height="100%">
        <source src={url} type="video/mp4" />
        <source src={url} type="video/ogg" />
      </video>
    )
  }

  return (
    <StyledSection>
      <ColumnsCTA
        title={title}
        lead={description}
        button={ButtonFindYourPIR}
        columnLeft={
          <React.Fragment>
            {posterImageUrl ? (
              <React.Fragment>
                <PosterButton
                  disableTouchRipple
                  focusRipple
                  onClick={() => setOpenVideoDialog(true)}
                >
                  <Typography variant="srOnly">Watch video</Typography>
                  <PosterImage
                    src={posterImageUrl}
                    role="presentation"
                    alt=""
                  />
                  <PosterIcon icon="play" />
                </PosterButton>

                <DialogSlim
                  open={openVideoDialog}
                  onClose={() => setOpenVideoDialog(false)}
                  dialogClose="Close video dialog"
                >
                  {renderVideo()}
                </DialogSlim>
              </React.Fragment>
            ) : (
                renderVideo()
              )}
          </React.Fragment>
        }
        callToAction
        reverseColumns
      />
    </StyledSection>
  )
}

export default ProductChooserRecommendationVideo
