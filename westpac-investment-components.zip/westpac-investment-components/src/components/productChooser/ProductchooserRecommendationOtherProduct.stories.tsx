import React from 'react'

import ProductChooserRecommendationOtherProduct from './ProductChooserRecommendationOtherProduct'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'
import simpleSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserSimpleSaverRecommendationMockData'
import termPIERecommendation from '../../utils/product-chooser/__mocks__/ProductChooserTermPIERecommendationMockData'
export default {
  title: 'productChooser/ProductChooserRecommendationOtherProduct',
  component: ProductChooserRecommendationOtherProduct,
}

export const Basic = () => (
  <ProductChooserRecommendationOtherProduct
    recommendation={bonusSaverRecommendation}
    recommendations={[bonusSaverRecommendation, simpleSaverRecommendation]}
    openCompareProducts={() => {}}
  />
)

export const Multi = () => (
  <ProductChooserRecommendationOtherProduct
    recommendation={bonusSaverRecommendation}
    recommendations={[
      bonusSaverRecommendation,
      termPIERecommendation,
      simpleSaverRecommendation,
    ]}
    openCompareProducts={() => {}}
  />
)
