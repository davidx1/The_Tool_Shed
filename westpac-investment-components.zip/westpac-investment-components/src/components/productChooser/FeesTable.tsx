import React from 'react'
import { IProductChooserFee } from '../../utils/product-chooser/productChooserUtils'
import {
  Table,
  TableHead,
  TableCell,
  TableBody,
  TableRow,
  Typography,
} from '@material-ui/core'
import styled, { css } from 'styled-components'
import { DisclaimerText } from '../dataDisplay/HTMLRenderer'

const StyledTable = styled(Table)(
  ({ theme }) => css`
    margin-bottom: ${theme.spacing(3)}px;
  `
)

const StyledTableHeadCell = styled(TableCell)(
  ({ theme }) => css`
    border-top: solid 0.5px ${theme.palette.highlight.secondary};
    border-bottom: solid 0.5px ${theme.palette.highlight.secondary};
    color: ${theme.palette.primary.main};
    font-weight: ${theme.typography.fontWeightBold};
    width: 60%;
  `
)

const StyledTableRow = styled(TableRow)(
  ({ theme }) => css`
    &:nth-child(2n + 1) {
      background-color: ${theme.palette.disabled.light};
    }
    &:nth-child(2n) {
      background-color: ${theme.palette.background.default};
    }
    &:last-child > td {
      border-bottom: solid 0.5px ${theme.palette.highlight.secondary};
    }
  `
)

const StyledTableCellAmount = styled(TableCell)(
  ({ theme }) => css`
    width: 40%;
    font-weight: ${theme.typography.fontWeightMedium};
  `
)

const EmptyFeesCaption = styled.caption(
  ({ theme }) => css`
    && {
      border-top: 1px solid ${theme.palette.highlight.secondary};
      padding: ${theme.spacing(2, 0, 0)};
    }
  `
)

export interface Props {
  feeName: string
  fees: IProductChooserFee[]
  emptyState?: string
}

const FeesTable = ({ feeName, fees, emptyState }: Props) => {
  return (
    <React.Fragment>
      <Typography variant="h3" gutterBottom>
        {feeName} fees
      </Typography>
      <StyledTable>
        {fees.length > 0 ? (
          <React.Fragment>
            <TableHead>
              <TableRow>
                <StyledTableHeadCell>Fee type</StyledTableHeadCell>
                <StyledTableHeadCell>Fee amount</StyledTableHeadCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {fees.map(({ type, amount }) => (
                <StyledTableRow key={`${type}-${amount}`}>
                  <TableCell>{type}</TableCell>
                  <StyledTableCellAmount>{amount}</StyledTableCellAmount>
                </StyledTableRow>
              ))}
            </TableBody>
          </React.Fragment>
        ) : (
          <EmptyFeesCaption>
            <DisclaimerText
              value={emptyState || `No ${feeName.toLowerCase()} fees apply.`}
            />
          </EmptyFeesCaption>
        )}
      </StyledTable>
    </React.Fragment>
  )
}

export default FeesTable
