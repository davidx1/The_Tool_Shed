import React, { FC, useState } from 'react'
import styled, { css } from 'styled-components'

import Box from '@material-ui/core/Box'
import Button from '@material-ui/core/Button'
import Container from '@material-ui/core/Container'
import Typography from '@material-ui/core/Typography'

import DialogInfo from '../dialog/DialogInfo'
import ProductChooserApplyDialogContent from './ProductChooserApplyDialogContent'
import { IProductChooserProductItem, IProductChooserConfig, IProductChooserProductType } from '../../utils/product-chooser/productChooserUtils'

const DIALOG_PRODUCT_TYPES: IProductChooserProductType[] = ['bonusSaverPIE', 'noticeSaver', 'termPIE']
export interface Props {
  recommendation: IProductChooserProductItem
  config: IProductChooserConfig
  applyHandler?: () => void
}

const StyledSection = styled.section`
  width: 100%;
`

const StyledBox = styled(Box)(
  ({ theme }) => css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;

    ${theme.breakpoints.down('xs')} {
      display: block;
      text-align: center;
    }
  `
)

const StyledTypography = styled(Typography)(
  ({ theme }) => css`
    flex: 1;
    margin-bottom: ${theme.spacing(3)}px;
    font-size: ${theme.typography.pxToRem(28)};

    ${theme.breakpoints.up('sm')} {
      margin-bottom: 0;
    }

    ${theme.breakpoints.up('md')} {
      font-size: ${theme.typography.pxToRem(40)};
    }
  `
)

const StyledButton = styled(Button)(
  ({ theme }) => css`
    ${theme.breakpoints.down('xs')} {
      width: 100%;
    }
  `
)

const ProductChooserRecommendationApply: FC<Props> = ({ recommendation, applyHandler, config }) => {
  const [dialogOpen, setDialogOpen] = useState<boolean>(false)
  const { applyTitle, applyUrl, type } = recommendation
  const showDialogInstead = DIALOG_PRODUCT_TYPES.includes(type)

  const handleClose = () => {
    setDialogOpen(false)
  }

  const handleApply = () => {
    if (showDialogInstead || !applyUrl) {
      setDialogOpen(true)
    } else {
      applyHandler && applyHandler()
    }
  }

  return (
    <StyledSection>
      <Container>
        <StyledBox pt={[5, 6.8, 8]} pb={[5, 6.8, 8]}>
          <StyledTypography variant="h2">
            {applyTitle}
          </StyledTypography>
          <StyledButton
            variant="contained"
            color="primary"
            href={showDialogInstead ? undefined : applyUrl}
            onClick={handleApply}
          >
            Apply now
          </StyledButton>
        </StyledBox>
      </Container>
      <DialogInfo open={dialogOpen} onClose={handleClose} dialogTitle="Get in touch." maxWidth="md">
        <ProductChooserApplyDialogContent config={config} showCallUsSection={type !== 'termPIE'} />
      </DialogInfo>
    </StyledSection>
  )
}

export default ProductChooserRecommendationApply
