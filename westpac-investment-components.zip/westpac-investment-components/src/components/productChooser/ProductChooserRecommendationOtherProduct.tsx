import React from 'react'
import styled, { css } from 'styled-components'
import { Container, Typography, Grid, Box } from '@material-ui/core'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import ArrowButton from '../inputs/ArrowButton'
import UnderlineButton from '../inputs/UnderlineButton'

export interface Props {
  recommendation: IProductChooserProductItem
  recommendations: IProductChooserProductItem[]
  openCompareProducts: () => void
}

const StyledSection = styled.section`
  ${({ theme }) => css`
    width: 100%;
    background: ${theme.palette.background.default};
  `}
`

const GridIcon = styled(Grid)`
  max-width: 80px;
`

const RecommendationIcon = styled(DynamicIcon)`
  transform: scale(1.6);
`

const ProductChooserRecommendationOtherProduct: React.FC<Props> = ({
  recommendation,
  recommendations,
  openCompareProducts,
}) => {
  const otherRecommendations = recommendations.slice(1)
  const hasOnlyOneOtherRecommendation = otherRecommendations.length === 1
  return (
    <StyledSection>
      <Container>
        <Box pt={5} pb={6}>
          <Grid container item xs={12} spacing={3}>
            <Grid
              container
              item
              xs={12}
              md={hasOnlyOneOtherRecommendation ? 4 : 12}
              justify="space-between"
            >
              <Grid item>
                <Typography variant="h2" component="p">
                  Other options.
                </Typography>
                <Typography variant="body2" component="p" gutterBottom>
                  You can also consider some of our other accounts and
                  investment options that may suit you.
                </Typography>
              </Grid>
              <Grid item>
                <UnderlineButton onClick={openCompareProducts}>
                  Compare options
                </UnderlineButton>
              </Grid>
            </Grid>

            {otherRecommendations.map(({ type, title, shortDescription }) => (
              <Grid
                item
                xs={12}
                md={hasOnlyOneOtherRecommendation ? 8 : 6}
                key={type}
              >
                <Grid container alignItems="flex-start" spacing={3}>
                  <GridIcon item>
                    <RecommendationIcon icon={type} />
                  </GridIcon>
                  <Grid item xs>
                    <Typography variant="h4" component="p" gutterBottom>
                      {title}.
                    </Typography>
                    <Typography
                      variant="body1"
                      component="p"
                      gutterBottom
                      id={`${type}Description`}
                    >
                      {shortDescription}
                    </Typography>
                    <ArrowButton
                      href={recommendation.applyUrl}
                      aria-describedby={`${type}Description`}
                      fontWeight="fontWeightMedium"
                    >
                      Find out more
                    </ArrowButton>
                  </Grid>
                  <Grid item xs={12} />
                </Grid>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserRecommendationOtherProduct
