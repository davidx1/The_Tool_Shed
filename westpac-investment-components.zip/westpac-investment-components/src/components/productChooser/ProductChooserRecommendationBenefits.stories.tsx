import React from 'react'

import ProductChooserRecommendationBenefits from './ProductChooserRecommendationBenefits'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationBenefits',
  component: ProductChooserRecommendationBenefits,
}

export const Basic = () => (
  <ProductChooserRecommendationBenefits
    recommendation={bonusSaverRecommendation}
  />
)
