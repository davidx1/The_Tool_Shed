import React, { FC } from 'react'
import styled from 'styled-components'
import { Container, Box, Typography, Grid } from '@material-ui/core'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import ArrowButton from '../inputs/ArrowButton'
import BasicButton from '../inputs/BasicButton'
import { IProductChooserConfig } from '../../utils/product-chooser/productChooserUtils'

export interface Props {
  glossaryLinkHandler?: () => {}
  callUsLinkHandler?: () => {}
  config: IProductChooserConfig
}

const StyledSection = styled.section`
  width: 100%;
`

const GridIcon = styled(Grid)`
  max-width: 80px;
`

const ProductChooserRecommendationFooter: FC<Props> = ({
  glossaryLinkHandler,
  callUsLinkHandler,
  config,
}) => {
  return (
    <StyledSection>
      <Container>
        <Box pt={[5, 5, 9]} pb={[6, 5, 9]}>
          <Box mb={[3, 3, 5]}>
            <Typography variant="h2">Have more questions?</Typography>
          </Box>
          <Grid container justify="space-around">
            <Grid item xs={12} md={6}>
              <Grid container alignItems="flex-start" spacing={3}>
                <GridIcon item>
                  <DynamicIcon icon="contact" />
                </GridIcon>
                <Grid item xs>
                  <Typography variant="h4" component="p" gutterBottom>
                    Contact us
                  </Typography>
                  <Typography
                    variant="body1"
                    component="p"
                    gutterBottom
                    id="ContactLink"
                  >
                    Call us to discuss your savings and investment needs.
                  </Typography>
                  <BasicButton
                    href={config.links.contactUsPhone.url}
                    aria-describedby="ContactLink"
                    fontWeight="fontWeightMedium"
                    onClick={callUsLinkHandler}
                  >
                    {config.links.contactUsPhone.label}
                  </BasicButton>
                </Grid>
                <Grid item xs={12} />
              </Grid>
            </Grid>
            <Grid item xs={12} md={6}>
              <Grid container alignItems="flex-start" spacing={3}>
                <GridIcon item>
                  <DynamicIcon icon="glossary" />
                </GridIcon>
                <Grid item xs>
                  <Typography variant="h4" component="p" gutterBottom>
                    Glossary
                  </Typography>
                  <Typography
                    variant="body1"
                    component="p"
                    gutterBottom
                    id="GlossaryLink"
                  >
                    Need to understand some of the terms we use? Have a read
                    through our glossary.
                  </Typography>
                  <ArrowButton
                    href={config.links.glossary}
                    aria-describedby="GlossaryLink"
                    fontWeight="fontWeightMedium"
                    onClick={glossaryLinkHandler}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Read our glossary
                  </ArrowButton>
                </Grid>
                <Grid item xs={12} />
              </Grid>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserRecommendationFooter
