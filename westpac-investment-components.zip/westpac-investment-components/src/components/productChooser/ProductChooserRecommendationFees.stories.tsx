import React from 'react'

import ProductChooserRecommendationFees from './ProductChooserRecommendationFees'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationFees',
  component: ProductChooserRecommendationFees,
}

export const Basic = () => (
  <ProductChooserRecommendationFees
    recommendation={bonusSaverRecommendation}
    allFeesUrl=""
  />
)
