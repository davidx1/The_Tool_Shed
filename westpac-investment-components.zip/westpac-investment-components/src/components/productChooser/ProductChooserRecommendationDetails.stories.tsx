import React from 'react'

import ProductChooserRecommendationDetails from './ProductChooserRecommendationDetails'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationDetails',
  component: ProductChooserRecommendationDetails,
}

export const Basic = () => (
  <ProductChooserRecommendationDetails
    recommendation={bonusSaverRecommendation}
  />
)
