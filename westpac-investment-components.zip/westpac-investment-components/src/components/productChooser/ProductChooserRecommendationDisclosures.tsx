import React from 'react'
import styled, { css } from 'styled-components'
import { Container, Box, Typography } from '@material-ui/core'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'
import { urlCss } from '../../styles/sharedStyles'
import HTMLRenderer from '../dataDisplay/HTMLRenderer'

export interface Props {
  recommendation: IProductChooserProductItem
}

const StyledSection = styled.section`
  width: 100%;
`

const StyledTypography = styled(Typography).attrs({
  variant: 'overline',
  color: 'textSecondary',
})`
  ${({ theme }) => css`
    margin: ${theme.typography.pxToRem(10)} 0;
    ${urlCss}
  `}
`

const ProductChooserRecommendationDisclosures = ({ recommendation }: Props) => {
  const disclosure = recommendation.disclosures?.join('')
  return (
    <StyledSection>
      <Container>
        <Box pt={[2]} pb={[5, 6, 7]}>
          <StyledTypography>
            <HTMLRenderer value={disclosure} />
          </StyledTypography>
        </Box>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserRecommendationDisclosures
