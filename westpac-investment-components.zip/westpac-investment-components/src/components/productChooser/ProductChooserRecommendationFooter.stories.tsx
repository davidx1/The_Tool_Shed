import React from 'react'

import ProductChooserRecommendationFooter from './ProductChooserRecommendationFooter'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationFooter',
  component: ProductChooserRecommendationFooter,
}

export const Basic = () => (
  <ProductChooserRecommendationFooter config={config} />
)
