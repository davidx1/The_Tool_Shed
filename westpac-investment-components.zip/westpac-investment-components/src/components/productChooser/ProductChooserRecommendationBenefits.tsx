import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, Container, Box, List, ListItem } from '@material-ui/core'
import ListDisc from '../dataDisplay/ListDisc'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'

const StyledSection = styled.section`
  width: 100%;
`

const StyledBox = styled(Box)`
  ${({ theme }) => css`
    display: flex;
    justify-content: space-between;
    width: 100%;
    ${theme.breakpoints.down('md')} {
      display: block;
      padding-top: ${theme.spacing(7)}px;
      padding-bottom: ${theme.spacing(5)}px;
    }
    ${theme.breakpoints.down('xs')} {
      padding-top: ${theme.spacing(5)}px;
    }
  `}
`

const TypographyBenefits = styled(Typography)(
  ({ theme }) => css`
    flex: 1;
    margin-bottom: ${theme.spacing(3)}px;
    font-size: ${theme.typography.pxToRem(28)};
    ${theme.breakpoints.up('md')} {
      margin-bottom: ${theme.spacing(2.625)}px;
      font-size: ${theme.typography.pxToRem(40)};
    }
  `
)

const StyledListItem = styled(ListItem).attrs((props) => ({
  ...props,
}))`
  ${({ theme }) => css`
    color: ${theme.palette.text.primary};
    padding-left: 0;
  `}
`

const StyledListItemText = styled.span`
  ${({ theme }) => css`
    font-size: ${theme.typography.pxToRem(18)};
    line-height: ${theme.typography.pxToRem(25)};
    color: ${theme.palette.text.primary};
  `}
`

export interface Props {
  recommendation: IProductChooserProductItem
}

const ProductChooserRecommendationBenefits: React.FC<Props> = ({
  recommendation,
}) => {
  const { benefits } = recommendation
  if (!benefits) return null
  return (
    <StyledSection>
      <Container>
        <StyledBox pt={[5, 5, 10]} pb={[4.5, 5, 9]}>
          <TypographyBenefits variant="h2">Benefits.</TypographyBenefits>
          <Box flex={2}>
            <List>
              {benefits.map((benefit) => (
                <StyledListItem key={benefit} alignItems="flex-start">
                  <ListDisc color="inherit" />
                  <StyledListItemText>{benefit}</StyledListItemText>
                </StyledListItem>
              ))}
            </List>
          </Box>
        </StyledBox>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserRecommendationBenefits
