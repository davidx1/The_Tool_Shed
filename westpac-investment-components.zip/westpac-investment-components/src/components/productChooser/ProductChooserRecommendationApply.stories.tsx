import React from 'react'

import ProductChooserRecommendationApply from './ProductChooserRecommendationApply'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'
import termPIERecommendation from '../../utils/product-chooser/__mocks__/ProductChooserTermPIERecommendationMockData'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationApply',
  component: ProductChooserRecommendationApply,
}

export const Basic = () => (
  <ProductChooserRecommendationApply
    recommendation={bonusSaverRecommendation}
    config={config}
  />
)

export const TermPIEVariant = () => (
  <ProductChooserRecommendationApply
    recommendation={termPIERecommendation}
    config={config}
  />
)
