import React from 'react'

import FeesTable from './FeesTable'

export default {
  title: '🔸 Internal/productChooser/FeesTable',
  component: FeesTable,
}

export const Basic = () => (
  <div style={{ height: '400px' }}>
    <FeesTable
      feeName="Service"
      fees={[
        { type: 'Phone Banking call', amount: 'Free' },
        { type: 'Email alerts', amount: 'Free' },
        { type: 'Online automatic payments set up and amend', amount: 'Free' },
        { type: 'Branch and phone payments set up and amend', amount: '$5' },
      ]}
    />
  </div>
)
