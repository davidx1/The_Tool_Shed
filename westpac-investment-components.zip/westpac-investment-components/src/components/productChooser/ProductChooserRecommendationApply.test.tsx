import React from 'react'
import { render, fireEvent } from '@testing-library/react'

import ProductChooserRecommendationApply from './ProductChooserRecommendationApply'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'
import termPIERecommendation from '../../utils/product-chooser/__mocks__/ProductChooserTermPIERecommendationMockData'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'
import { InvestToolsProvider } from '../InvestToolsProvider'

describe('<ProductChooserRecommendationApply/>', () => {
  it('should call handler for apply button', () => {
    const applyLinkHandler = jest.fn()
    const { getByText } = render(
      <InvestToolsProvider>
        <ProductChooserRecommendationApply
          recommendation={bonusSaverRecommendation}
          applyHandler={applyLinkHandler}
          config={config}
        />
      </InvestToolsProvider>
    )
    fireEvent.click(getByText('Apply now'))
    expect(applyLinkHandler).toBeCalledTimes(1)
  })
  it('should open dialog for termPIE type', () => {
    const { getByText } = render(
      <InvestToolsProvider>
        <ProductChooserRecommendationApply
          recommendation={termPIERecommendation}
          config={config}
        />
      </InvestToolsProvider>
    )
    fireEvent.click(getByText('Apply now'))
    expect(getByText('Get in touch.')).toBeVisible()
  })
})
