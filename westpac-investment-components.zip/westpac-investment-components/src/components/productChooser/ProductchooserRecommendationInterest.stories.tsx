import React from 'react'

import ProductChooserRecommendationInterest from './ProductChooserRecommendationInterest'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'
import termPIERecommendation from '../../utils/product-chooser/__mocks__/ProductChooserTermPIERecommendationMockData'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationInterest',
  component: ProductChooserRecommendationInterest,
}

export const Basic = () => (
  <ProductChooserRecommendationInterest
    recommendation={bonusSaverRecommendation}
    findInterestFrequency={() => {}}
    config={config}
  />
)

export const Multi = () => (
  <ProductChooserRecommendationInterest
    recommendation={termPIERecommendation}
    findInterestFrequency={() => {}}
    config={config}
  />
)
