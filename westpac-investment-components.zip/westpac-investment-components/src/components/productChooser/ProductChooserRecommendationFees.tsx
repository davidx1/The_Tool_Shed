import React from 'react'
import styled, { css } from 'styled-components'
import { Box, Typography, Container } from '@material-ui/core'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'
import FeesTable from './FeesTable'
import UnderlineButton from '../inputs/UnderlineButton'
import { DisclaimerText } from '../dataDisplay/HTMLRenderer'

const StyledSection = styled.section`
  width: 100%;
`

const StyledBox = styled(Box)`
  ${({ theme }) => css`
    width: 100%;
    ${theme.breakpoints.up('md')} {
      display: flex;
      justify-content: space-between;
    }
  `}
`

const TypographyBenefits = styled(Typography)(
  ({ theme }) => css`
    flex: 1;
    margin-bottom: ${theme.spacing(3)}px;
    font-size: ${theme.typography.pxToRem(28)};
    ${theme.breakpoints.up('md')} {
      margin-bottom: ${theme.spacing(2.625)}px;
      font-size: ${theme.typography.pxToRem(40)};
    }
  `
)

const Disclaimer = styled.div`
  ${({ theme }) => css`
    margin-bottom: ${theme.spacing(4)}px;
  `}
`

const ButtonWrapper = styled.div(
  ({ theme }) => css`
    text-align: center;
    ${theme.breakpoints.up('md')} {
      text-align: left;
    }
  `
)

export interface Props {
  recommendation: IProductChooserProductItem
  allFeesUrl: string
}

const ProductChooserRecommendationFees = ({
  recommendation,
  allFeesUrl,
}: Props) => {
  const {
    fees: {
      accountFees,
      serviceFees,
      accountFeesDisclaimer,
      serviceFeesDisclaimer,
      accountFeesEmptyState,
      serviceFeesEmptyState,
    },
  } = recommendation
  return (
    <StyledSection>
      <Container>
        <StyledBox pt={[5, 5, 10]} pb={[4, 5, 10]}>
          <TypographyBenefits variant="h2">Fees.</TypographyBenefits>
          <Box flex={2}>
            <FeesTable
              feeName={'Account'}
              fees={accountFees}
              emptyState={accountFeesEmptyState}
            />
            {accountFeesDisclaimer && (
              <Disclaimer>
                <DisclaimerText value={accountFeesDisclaimer} />
              </Disclaimer>
            )}
            <FeesTable
              feeName={'Service'}
              fees={serviceFees}
              emptyState={serviceFeesEmptyState}
            />
            {serviceFeesDisclaimer && (
              <Disclaimer>
                <DisclaimerText value={serviceFeesDisclaimer} />
              </Disclaimer>
            )}
            <ButtonWrapper>
              <UnderlineButton
                target="_blank"
                rel="noopener noreferrer"
                href={allFeesUrl}
              >
                View all fees
              </UnderlineButton>
            </ButtonWrapper>
          </Box>
        </StyledBox>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserRecommendationFees
