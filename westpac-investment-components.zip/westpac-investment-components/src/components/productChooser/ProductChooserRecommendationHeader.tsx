import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Typography, Container, Box, Button } from '@material-ui/core'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'
import HeaderShape from '../decorations/HeaderShape'

export interface Props {
  recommendation: IProductChooserProductItem
}

const StyledHeader = styled.header`
  ${({ theme }) => css`
    position: relative;
    background: ${theme.palette.disabled.xlight};
    overflow: hidden;
  `}
`

const ContainerBackground = styled(Box)(
  ({ theme }) => css`
    position: absolute;
    display: none;
    overflow: hidden;
    ${theme.breakpoints.up('sm')} {
      width: 100%;
      height: 100%;
      display: block;
    }
  `
)

const StyledHeaderShape = styled(HeaderShape)(
  ({ theme }) => css`
    position: absolute;
    height: 100%;
    right: -180px;
    ${theme.breakpoints.up('md')} {
      right: 0;
    }
  `
)

// Widths per design
const HeaderContent = styled.div`
  position: relative;
  ${({ theme }) => css`
    ${theme.breakpoints.up('sm')} {
      max-width: 628px;
    }
    ${theme.breakpoints.up('md')} {
      max-width: 712px;
    }
    ${theme.breakpoints.up('lg')} {
      max-width: 867px;
    }
  `}
`

const TypographyDescription = styled(Typography).attrs({
  component: 'p',
})`
  ${({ theme }) => css`
    max-width: 100%;
    font-size: ${theme.typography.pxToRem(18)};
    line-height: ${theme.typography.pxToRem(25)};
    margin-bottom: ${theme.typography.pxToRem(25)};
  `}
`

export const StyledOutlinedButton = styled(Button)(
  ({ theme }) => css`
    margin-left: ${theme.spacing(2)}px;
    ${theme.breakpoints.down('xs')} {
      margin-left: 0px;
      width: 100%;
    }
  `
)

const ProductChooserRecommendationHeader: FC<Props> = ({
  recommendation,
}) => {
  const { title, description } = recommendation
  return (
    <StyledHeader>
      <ContainerBackground>
        <StyledHeaderShape />
      </ContainerBackground>
      <Container>
        <Box pt={[5, 6, 10]} pb={[2, 6, 9]}>
          <HeaderContent>
            <Box mb={[2, 3, 4]}>
              <Typography variant="h2">We recommend.</Typography>
            </Box>
            <Typography variant="h4" component="h3">
              {title}.
            </Typography>
            <Box mb={[2, 4]} mt={1}>
              {typeof description === 'string' ? (
                <TypographyDescription variant="subtitle1">
                  {description}
                </TypographyDescription>
              ) : (
                  description.map((d) => (
                    <TypographyDescription variant="subtitle1" key={d.length}>
                      {d}
                    </TypographyDescription>
                  ))
                )}
            </Box>
          </HeaderContent>
        </Box>
      </Container>
    </StyledHeader>
  )
}

export default ProductChooserRecommendationHeader
