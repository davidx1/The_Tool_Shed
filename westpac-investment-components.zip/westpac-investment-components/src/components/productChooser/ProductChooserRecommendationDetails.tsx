import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, Container, Box, List } from '@material-ui/core'
import { IProductChooserProductItem } from '../../utils/product-chooser/productChooserUtils'
import ListItemExpandable from '../dataDisplay/ListItemExpandable'
import ListWithDisclosures from '../dataDisplay/ListWithDisclosures'

const StyledSection = styled.section`
  width: 100%;
`

const StyledBox = styled(Box)`
  ${({ theme }) => css`
    display: flex;
    justify-content: space-between;
    width: 100%;
    padding-top: ${theme.spacing(9)}px;
    ${theme.breakpoints.down('md')} {
      display: block;
      padding-top: ${theme.spacing(7)}px;
      padding-bottom: ${theme.spacing(5)}px;
    }
    ${theme.breakpoints.down('xs')} {
      padding-top: ${theme.spacing(5)}px;
    }
  `}
`

const TypographyDetails = styled(Typography)(
  ({ theme }) => css`
    flex: 1;
    margin-bottom: ${theme.spacing(3)}px;
    font-size: ${theme.typography.pxToRem(28)};
    ${theme.breakpoints.up('md')} {
      margin-bottom: ${theme.spacing(2.625)}px;
      font-size: ${theme.typography.pxToRem(40)};
    }
  `
)

const StyledList = styled(List)(
  ({ theme }) => css`
    border-top: solid ${theme.palette.text.primary} 1px;
    padding: 0;
  `
)

export interface Props {
  recommendation: IProductChooserProductItem
}

const ProductChooserRecommendationDetails: React.FC<Props> = ({
  recommendation,
}) => {
  const { details } = recommendation

  return (
    <StyledSection id="more-details">
      <Container>
        <StyledBox pt={12.5} pb={9}>
          <TypographyDetails variant="h2">More details.</TypographyDetails>
          <Box flex={2}>
            <StyledList>
              {details?.map(
                (detail) =>
                  detail.details.length > 0 && (
                    <ListItemExpandable title={detail.title} key={detail.title}>
                      <ListWithDisclosures
                        items={detail.details!}
                        disclosures={detail.disclosures}
                      />
                    </ListItemExpandable>
                  )
              )}
            </StyledList>
          </Box>
        </StyledBox>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserRecommendationDetails
