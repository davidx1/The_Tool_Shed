import React from 'react'

import ProductChooserRecommendationDisclosures from './ProductChooserRecommendationDisclosures'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationDisclosures',
  component: ProductChooserRecommendationDisclosures,
}

export const Basic = () => (
  <ProductChooserRecommendationDisclosures
    recommendation={bonusSaverRecommendation}
  />
)
