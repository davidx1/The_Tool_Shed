import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, Box } from '@material-ui/core'
import theme from '../../styles/theme'
import ArrowButton from '../inputs/ArrowButton'
import PercentageNumber from '../dataDisplay/PercentageNumber'
import { IProductChooserInterestEffectiveReturn } from '../../utils/product-chooser/productChooserUtils'

export interface Props {
  durationInMonths?: string
  actionText: string
  actionUrl: string
  description?: string
  effectiveReturn?: IProductChooserInterestEffectiveReturn
  annualRatePercent: string
}

const InterestRateCard = styled(Box)(
  ({ theme }) => css`
    display: flex;
    flex-direction: column;
    align-items: center;
    background: ${theme.palette.background.paper};
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
    text-align: center;
    min-width: 312px;
  `
)

const SmallBoldDescription = styled(Typography).attrs({ component: 'span' })`
  ${({ theme }) => css`
    font-size: ${theme.typography.pxToRem(14)};
    line-height: ${theme.typography.pxToRem(20)};
    font-weight: ${theme.typography.fontWeightMedium};
    margin-top: ${theme.typography.pxToRem(3)};
    max-width: 100%; /* IE11 text-wrapping */
  `}
`

const SmallDescription = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(14)};
    line-height: ${theme.typography.pxToRem(20)};
    margin-top: ${theme.typography.pxToRem(3)};
    max-width: 100%; /* IE11 text-wrapping */
  `
)

const ProductChooserInterestRateCard: React.FC<Props> = ({
  durationInMonths,
  actionText,
  actionUrl,
  description,
  annualRatePercent,
  effectiveReturn,
}) => {
  const duration = (durationInMonths || ' ')
    .split(' ')
    .map((word) => `${word.charAt(0).toUpperCase()}${word.substr(1)}`) // to capitalise words
    .join(' ')
  return (
    <InterestRateCard p={[3, 3, 4]}>
      <Typography variant="h4" component="p">
        {duration}
      </Typography>
      <Box
        mt={4}
        mb={3.5}
        display="flex"
        flexDirection="column"
        alignItems="center"
      >
        <PercentageNumber
          value={annualRatePercent}
          suffix={'p.a.'}
          colorSymbols={theme.palette.text.primary}
        />
        {effectiveReturn && (
          <React.Fragment>
            <SmallBoldDescription>Effective return^</SmallBoldDescription>
            <SmallDescription>
              If your income tax rate is 30%¹:{' '}
              <SmallBoldDescription>
                {effectiveReturn.thirty}%
              </SmallBoldDescription>
            </SmallDescription>
            <SmallDescription>
              If your income tax rate is 33%²:{' '}
              <SmallBoldDescription>
                {effectiveReturn.thirtyThree}%
              </SmallBoldDescription>
            </SmallDescription>
          </React.Fragment>
        )}
      </Box>
      <ArrowButton href={actionUrl}>{actionText}</ArrowButton>
      {description && <SmallDescription>{description}</SmallDescription>}
    </InterestRateCard>
  )
}

export default React.memo(ProductChooserInterestRateCard)
