import React from 'react'

import ProductChooserInterestRateCard from './ProductChooserInterestRateCard'

export default {
  title: 'productChooser/ProductChooserInterestRateCard',
  component: ProductChooserInterestRateCard,
}

export const Basic = () => (
  <ProductChooserInterestRateCard
    actionText={'See more'}
    annualRatePercent="0.50"
    actionUrl=""
  />
)
