import React from 'react'

import ProductChooserApplyDialogContent from './ProductChooserApplyDialogContent'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'

export default {
  title: 'productChooser/ProductChooserApplyDialogContent',
  component: ProductChooserApplyDialogContent,
}

export const Basic = () => (
  <ProductChooserApplyDialogContent config={config} />
)

export const TermPIEVariant = () => (
  <ProductChooserApplyDialogContent config={config} showCallUsSection={false} />
)
