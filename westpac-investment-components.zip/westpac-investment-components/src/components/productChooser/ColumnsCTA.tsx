import React from 'react'
import styled, { StyledProps, css } from 'styled-components'
import { Typography, Container, Box } from '@material-ui/core'
import Hidden from '@material-ui/core/Hidden'
import { IProductChooserInterestEffectiveReturn } from '../../utils/product-chooser/productChooserUtils'
import EffectiveReturn from './EffectiveReturn'
import HTMLRenderer, { DisclaimerText } from '../dataDisplay/HTMLRenderer'

interface ComponentProps {
  reverseColumns?: boolean
}

export interface Props extends ComponentProps {
  title?: string
  description?: string
  effectiveReturn?: IProductChooserInterestEffectiveReturn
  disclosure?: string
  disclosureBottom?: string
  lead?: string
  button?: React.ReactNode
  columnLeft: React.ReactNode
  columnRight?: React.ReactNode
  callToAction?: boolean
  colPadding?: number[]
}

const StyledBox = styled(Box)`
  width: 100%;
  ${({ theme }) => theme.breakpoints.up('sm')} {
    display: flex;
    justify-content: space-between;
  }
`

const ContainerImage = styled(Box)`
  ${({ theme }) => css`
    display: flex;
    flex: 2;
    align-items: center;
    justify-content: flex-start;
    max-width: 667px;

    ${theme.breakpoints.down('xs')} {
      margin-bottom: ${theme.spacing(2)}px;
    }
  `}
`

const TypographyTitle = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(28)};
    line-height: ${theme.typography.pxToRem(36)};
    margin-bottom: ${theme.spacing(2)}px;

    ${theme.breakpoints.up('md')} {
      font-size: ${theme.typography.pxToRem(40)};
      line-height: ${theme.typography.pxToRem(50)};
      margin-bottom: ${theme.spacing(3)}px;
    }
  `
)

const TypographyText = styled(Typography).attrs({
  component: 'p',
})`
  ${({ theme }) => css`
    max-width: 365px; /* as per design */
    margin-bottom: ${theme.spacing(5)}px;

    ${theme.breakpoints.down('sm')} {
      max-width: none;
      width: 100%;
      margin-bottom: ${theme.spacing(3.5)}px;
    }
  `}
`

const TypographyDescription = styled.div(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(16)};
    font-family: ${theme.typography.fontFamily};
    margin-bottom: ${theme.spacing(2.5)}px;
  `
)

const TypographyLead = styled(TypographyText)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(18)};
    line-height: ${theme.typography.pxToRem(25)};
  `
)

const ColumnText = styled(({ reverseColumns, ...props }) => <Box {...props} />)(
  ({ theme, reverseColumns }: StyledProps<ComponentProps>) => css`
    ${theme.breakpoints.up('sm')} {
      min-width: 50%;
      max-width: 50%;
      ${reverseColumns
        ? css`
            order: -1;
          `
        : css`
            justify-content: flex-end;
          `}
    }
    ${theme.breakpoints.up('lg')} {
      width: 100%;
    }
  `
)

const ContainerText = styled(Box)`
  align-items: flex-start;
`

const ColumnsCTA: React.FC<Props> = ({
  title,
  description,
  effectiveReturn,
  disclosure,
  disclosureBottom,
  lead,
  button,
  columnLeft,
  columnRight,
  callToAction,
  reverseColumns,
  colPadding = [0, 4, 6.875, 16.875],
}) => (
  <Container>
    <StyledBox pt={[5, 6.25, 11]} pb={[5, 6.25, 11]}>
      <ContainerImage>{columnLeft}</ContainerImage>
      <ColumnText
        flex={1}
        display="flex"
        alignItems="center"
        pr={reverseColumns ? colPadding : 0}
        pl={!reverseColumns ? colPadding : 0}
        reverseColumns={reverseColumns}
      >
        <ContainerText>
          {title && <TypographyTitle variant="h2">{title}</TypographyTitle>}
          {columnRight}
          {lead && <TypographyLead>{lead}</TypographyLead>}
          {description && (
            <TypographyDescription>
              <HTMLRenderer value={description} />
            </TypographyDescription>
          )}
          {disclosure && <DisclaimerText value={disclosure} />}
          {effectiveReturn && (
            <EffectiveReturn effectiveReturn={effectiveReturn} />
          )}
          {button && !callToAction && button}
          {button && callToAction && <Hidden only={['sm']}>{button}</Hidden>}
        </ContainerText>
      </ColumnText>
    </StyledBox>
    {button && callToAction && (
      <Hidden xsDown mdUp>
        <Box pb={4} display="flex" justifyContent="center">
          {button}
        </Box>
      </Hidden>
    )}
    {disclosureBottom && <DisclaimerText value={disclosureBottom} />}
  </Container>
)

export default ColumnsCTA
