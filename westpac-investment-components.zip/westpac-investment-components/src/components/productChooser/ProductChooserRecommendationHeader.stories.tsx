import React from 'react'

import ProductChooserRecommendationHeader from './ProductChooserRecommendationHeader'
import bonusSaverRecommendation from '../../utils/product-chooser/__mocks__/ProductChooserBonusSaverRecommendationMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationHeader',
  component: ProductChooserRecommendationHeader,
}

export const Basic = () => (
  <ProductChooserRecommendationHeader
    recommendation={bonusSaverRecommendation}
  />
)
