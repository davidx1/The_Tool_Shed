import React from 'react'

import ProductChooserRecommendationVideo from './ProductChooserRecommendationVideo'
import termPIERecommendation from '../../utils/product-chooser/__mocks__/ProductChooserTermPIERecommendationMockData'

export default {
  title: 'productChooser/ProductChooserRecommendationVideo',
  component: ProductChooserRecommendationVideo,
}

export const Basic = () => (
  <ProductChooserRecommendationVideo
    recommendation={termPIERecommendation}
    findPIRRate={() => {}}
  />
)
