import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Container, Box, Typography, Grid } from '@material-ui/core'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import ArrowButton from '../inputs/ArrowButton'
import BasicButton from '../inputs/BasicButton'
import { IProductChooserConfig } from '../../utils/product-chooser/productChooserUtils'

export interface Props {
  findBranchLinkHandler?: () => void
  callUsLinkHandler?: () => void
  showCallUsSection?: boolean
  config: IProductChooserConfig
}

const StyledSection = styled.section`
  width: 100%;
`

const GridIcon = styled(Grid)`
  max-width: 80px;
`

const Subtitle = styled(Typography)(
  ({ theme }) => css`
    margin-bottom: ${theme.spacing(4)};
    ${theme.breakpoints.up('lg')} {
      margin-bottom: ${theme.spacing(5)}px;
    }
  `
)

const ProductChooserApplyDialogContent: FC<Props> = ({
  findBranchLinkHandler,
  callUsLinkHandler,
  showCallUsSection = true,
  config,
}) => {
  return (
    <StyledSection>
      <Container>
        <Box pt={[1.5, 2, 3]} pb={[4, 6, 7.5]}>
          <Subtitle variant="body2">
            Setting up this account is currently unavailable online for both new and existing customers. To do this you’ll have to visit one of our branches or call our contact centre.
          </Subtitle>
          <Grid container spacing={3}>
            <Grid item xs={12} md={showCallUsSection ? 6 : 12}>
              <Grid container alignItems="flex-start" spacing={3}>
                <GridIcon item>
                  <DynamicIcon icon="branch" />
                </GridIcon>
                <Grid item xs>
                  <Typography variant="h4" component="p" gutterBottom>
                    Find a branch
                  </Typography>
                  <Typography
                    variant="body1"
                    component="p"
                    gutterBottom
                    id="BranchLocator"
                  >
                    For new and existing customers, please make an appointment at your local Westpac branch.
                  </Typography>
                  <ArrowButton
                    href={config.links.branchLocator}
                    aria-describedby="BranchLocator"
                    fontWeight="fontWeightMedium"
                    onClick={findBranchLinkHandler}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Westpac Branch Locator
                  </ArrowButton>
                </Grid>
                <Grid item xs={12} />
              </Grid>
            </Grid>
            {showCallUsSection && <Grid item xs={12} md={6}>
              <Grid container alignItems="flex-start" spacing={3}>
                <GridIcon item>
                  <DynamicIcon icon="contact" />
                </GridIcon>
                <Grid item xs>
                  <Typography variant="h4" component="p" gutterBottom>
                    Contact us
                  </Typography>
                  <Typography
                    variant="body1"
                    component="p"
                    gutterBottom
                    id="ContactLink"
                  >
                    Call us to discuss your savings and investment needs.
                  </Typography>
                  <BasicButton
                    href={config.links.contactUsPhone.url}
                    aria-describedby="ContactLink"
                    fontWeight="fontWeightMedium"
                    onClick={callUsLinkHandler}
                  >
                    {config.links.contactUsPhone.label}
                  </BasicButton>
                </Grid>
                <Grid item xs={12} />
              </Grid>
            </Grid>}
          </Grid>
        </Box>
      </Container>
    </StyledSection>
  )
}

export default ProductChooserApplyDialogContent
