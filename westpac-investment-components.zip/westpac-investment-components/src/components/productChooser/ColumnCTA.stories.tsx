import React from 'react'

import ColumnsCTA from './ColumnsCTA'

export default {
  title: '🔸 Internal/productChooser/ColumnsCTA',
  component: ColumnsCTA,
}

export const Basic = () => (
  <ColumnsCTA
    columnLeft={
      <div>
        <h1>Title</h1>
        <p>blablabla</p>
      </div>
    }
  />
)
