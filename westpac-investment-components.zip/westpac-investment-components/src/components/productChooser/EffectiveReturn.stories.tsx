import React from 'react'

import EffectiveReturn from './EffectiveReturn'

export default {
  title: '🔸 Internal/productChooser/EffectiveReturn',
  component: EffectiveReturn,
}

export const Basic = () => (
  <EffectiveReturn effectiveReturn={{ thirty: '0.12', thirtyThree: '0.14' }} />
)
