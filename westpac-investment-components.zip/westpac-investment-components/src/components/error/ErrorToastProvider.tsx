import React, { useCallback, Dispatch, FC } from 'react'
import styled, { css } from 'styled-components'

import CloseIcon from '@material-ui/icons/Close'
import IconButton from '@material-ui/core/IconButton'
import Snackbar, { SnackbarOrigin } from '@material-ui/core/Snackbar'
import InfoIcon from '@material-ui/icons/Info'
import Typography from '@material-ui/core/Typography'
import SnackbarContent from '@material-ui/core/SnackbarContent'
import { Container, Box } from '@material-ui/core'
import UnderlineButton from '../inputs/UnderlineButton'

const anchorOrigin = {
  vertical: 'top',
  horizontal: 'left',
} as SnackbarOrigin

const ToastBar = styled(Snackbar)`
  width: 100%;
  top: 0;
  left: 0;
  padding: 0;
`

const ToastContent = styled(SnackbarContent)(
  ({ theme }) => css`
    padding: 0;
    width: 100%;
    border-radius: 0;
    min-height: ${theme.spacing(9)}px;
    background: ${theme.palette.secondary.main};
    .MuiSnackbarContent-message {
      width: 100%;
      padding: ${theme.spacing(2, 0)};
    }
  `
)

const StyledTypography = styled(Typography)(
  ({ theme }) => css`
    margin: ${theme.spacing(0.25, 4, 0, 2)};
  `
)

const MessageContainer = styled(Container)(
  ({ theme }) => css`
    margin: 0 auto;
    position: relative;
    ${theme.breakpoints.up('sm')} {
      display: flex;
      align-items: flex-start;
    }
  `
)

const ReloadButton = styled(UnderlineButton)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(16)};
    line-height: ${theme.typography.pxToRem(30)};
    margin: ${theme.spacing(1, 5, 0)};
    white-space: nowrap;
    ${theme.breakpoints.up('sm')} {
      margin: ${theme.spacing(0, 8)};
    }
  `
)

const CloseButton = styled(IconButton)(
  ({ theme }) => css`
    top: ${theme.spacing(-2)}px;
    position: absolute;
    right: 0;
    ${theme.breakpoints.up('sm')} {
      right: ${theme.spacing(2)}px;
      top: ${theme.spacing(-1)}px;
    }
  `
)

interface ToastState {
  messageId: number
  open: boolean
  message: string
  hideReload?: boolean
}

const initialState: ToastState = {
  messageId: 0,
  open: false,
  message: '',
  hideReload: false,
}

type ToastActions =
  | { type: 'close' }
  | { type: 'open'; message: string; hideReload?: boolean }

function toastReducer(state: ToastState, action: ToastActions): ToastState {
  switch (action.type) {
    case 'close': {
      return { ...state, open: false }
    }
    case 'open': {
      return {
        open: true,
        message: action.message,
        hideReload: action.hideReload,
        messageId: Math.random(),
      }
    }
    default:
      return state
  }
}

const ErrorToastContext = React.createContext(initialState)
export const ErrorToastActionsContext = React.createContext<
  Dispatch<ToastActions> | undefined
>(undefined)

/**
 * Add ErrorToastProvider to the root of your component tree, or at
 * the highest level you wish the errorToastProvider to be available.
 *
 * ```<ErrorToastProvider>Your components</ErrorToastProvider>```
 *
 * The provider will enable the toast component and the `useErrorToaster` hook.
 */
const ErrorToastProvider: FC = ({ children }) => {
  const [state, dispatch] = React.useReducer(toastReducer, initialState)

  const onReloadPage = () => {
    window.location.reload()
  }

  const onCloseToast = useCallback(() => {
    dispatch({ type: 'close' })
  }, [])

  return (
    <ErrorToastContext.Provider value={state}>
      <ErrorToastActionsContext.Provider value={dispatch}>
        {children}
        <ToastBar
          anchorOrigin={anchorOrigin}
          onClose={onCloseToast}
          open={state.open}
          key={state.messageId}
          TransitionProps={{
            appear: !process.env.JEST_WORKER_ID,
          }}
        >
          <ToastContent
            elevation={0}
            message={
              <MessageContainer>
                <Box flexGrow={1} display="flex">
                  <InfoIcon />
                  <StyledTypography variant="body1">
                    {state.message ||
                      'Sorry our system has encountered an unexpected error trying to load this. Reloading your page might help.'}
                  </StyledTypography>
                </Box>
                {!state.hideReload && (
                  <ReloadButton onClick={onReloadPage} color="secondary">
                    Reload page
                  </ReloadButton>
                )}
                <CloseButton
                  color="inherit"
                  aria-label="Close"
                  onClick={onCloseToast}
                >
                  <CloseIcon />
                </CloseButton>
              </MessageContainer>
            }
          />
        </ToastBar>
      </ErrorToastActionsContext.Provider>
    </ErrorToastContext.Provider>
  )
}

export default ErrorToastProvider
