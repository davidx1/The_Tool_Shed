import React from 'react'
import { shallow } from 'enzyme'
import toJson from 'enzyme-to-json'
import { act } from 'react-dom/test-utils'
import ErrorBoundary, {
  ErrorBoundaryMessageNotConnected as ErrorBoundaryMessage,
} from './ErrorBoundaryMessage'

const testProps = {
  onReset: jest.fn(),
}

describe('Error Boundary', () => {
  it('should render without crashing', () => {
    const wrapper = shallow(<ErrorBoundaryMessage {...testProps} />)
    expect(toJson(wrapper)).toMatchSnapshot()
  })

  it('generates a error message when an error is caught', () => {
    const component = shallow(<ErrorBoundary />)
    component.setState({
      error: 'error name',
      errorInfo: 'error info',
    })
    expect(component.text()).toMatch('<ErrorBoundaryMessage />')
  })

  it('should call onReset when link is clicked', () => {
    const wrapper = shallow(<ErrorBoundaryMessage {...testProps} />)
    const link = wrapper.find('a')
    //@ts-ignore
    act(() => link.props().onClick())
    expect(testProps.onReset).toBeCalled()
  })
})
