import React from 'react'

const MISSING_ERROR = 'Error was swallowed during propagation.'

const withErrorBoundary = <BaseProps extends {}>(
  BaseComponent: React.ComponentType<BaseProps>
) => {
  type HocState = {
    readonly error: Error | null | undefined
  }

  return class Hoc extends React.Component {
    static displayName = `withErrorBoundary(${BaseComponent.name})`
    static readonly WrappedComponent = BaseComponent

    readonly state: HocState = {
      error: undefined,
    }

    componentDidCatch(error: Error | null) {
      this.setState({ error: error || new Error(MISSING_ERROR) })
    }

    render() {
      const { children, ...restProps } = this.props
      const { error } = this.state

      if (error) {
        return <BaseComponent {...(restProps as BaseProps)} />
      }

      return children
    }
  }
}

export default withErrorBoundary
