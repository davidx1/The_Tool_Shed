import React from 'react'
import withErrorBoundary from './withErrorBoundary'

const ErrorBoundaryMessage: React.FC<{ onReset: () => void }> = ({
  onReset,
}) => {
  return (
    <div>
      <h2>Sorry there was an unexpected error</h2>
      To continue:{' '}
      <a
        href="/"
        onClick={() => {
          onReset()
        }}
      >
        go to home page
      </a>
    </div>
  )
}

export default withErrorBoundary(ErrorBoundaryMessage)
export { ErrorBoundaryMessage as ErrorBoundaryMessageNotConnected }
