import React from 'react'

import { BoxDoc as Box } from './Box'

export default {
  title: 'Layout/Box',
  component: Box,
}

export const Basic = () => {
  return (
    <Box bgcolor="primary.main" color="primary.contrastText" p={6}>
      Test Box
    </Box>
  )
}
