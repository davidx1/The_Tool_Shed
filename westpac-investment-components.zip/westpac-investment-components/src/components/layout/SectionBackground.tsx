import styled, { css } from 'styled-components'

const SectionBackground = styled.div(
  ({ theme }) => css`
    width: 100%;
    margin: 0;
    padding: 0;
    & > section:nth-child(2n + 1) {
      background-color: ${theme.palette.background.default};
    }
    & > section:nth-child(2n) {
      background-color: ${theme.palette.background.grey};
    }
  `
)

export default SectionBackground