import React from 'react'

import { ContainerDoc as Container } from './Container'
import { Typography } from '@material-ui/core'

export default {
  title: 'Layout/Container',
  component: Container,
}

export const Basic = () => (
  <Container maxWidth="sm">
    <Typography
      component="div"
      style={{ backgroundColor: '#cfe8fc', height: '50vh' }}
    />
  </Container>
)
