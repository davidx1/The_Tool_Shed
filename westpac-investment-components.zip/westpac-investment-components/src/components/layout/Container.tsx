import React, { FC } from 'react'
import { Container as ContainerBase, ContainerProps } from '@material-ui/core'

/**
 * Extends Material UI Container component
 * https://material-ui.com/components/container/
 */
export const ContainerDoc: FC<ContainerProps> = (props) => (
  <ContainerBase {...props} />
)

export default ContainerBase
