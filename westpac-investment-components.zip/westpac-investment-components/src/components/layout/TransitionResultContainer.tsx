import styled, { css } from 'styled-components'
import { DIALOG_HEADER_HEIGHT } from '../dialog/DialogFullScreen'

export interface TransitionProps {
  isTransitioning: boolean
}

/**
 * Auxiliar container that adds animation when showing results
 */
const TransitionResultContainer = styled.div<TransitionProps>`
  background: ${({ theme }) => theme.palette.background.grey};
  top: ${DIALOG_HEADER_HEIGHT}px;
  position: fixed;
  bottom: 0;
  overflow-y: auto;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch; /* Fixes iOS 12.4 broken vertical scrolling over the fund graph */
  width: 100%;
  ${({ isTransitioning }) =>
    isTransitioning
      ? css`
          transform: translate3d(0, 0, 0);
          opacity: 1;
          @media (prefers-reduced-motion: no-preference) {
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1),
              opacity 0.6s cubic-bezier(0.4, 0, 0.2, 1);
          }
        `
      : css`
          pointer-events: none;
          transform: translate3d(67%, 0, 0);
          opacity: 0;
          @media (prefers-reduced-motion: no-preference) {
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1),
              opacity 0.6s cubic-bezier(0.4, 0, 0.2, 1);
          }
        `}
`

export default TransitionResultContainer
