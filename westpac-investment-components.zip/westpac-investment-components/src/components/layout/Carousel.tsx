import React, {
  useRef,
  useState,
  useLayoutEffect,
  useCallback,
  useMemo,
} from 'react'
import styled, { css } from 'styled-components'
import { Grid, useTheme } from '@material-ui/core'
import useMediaQuery from '@material-ui/core/useMediaQuery'

const Wrapper = styled(Grid)<{ $height: number }>`
  height: ${({ $height }) => $height}px;
  overflow: hidden;
  display: block;
  position: relative;
  -ms-overflow-style: none;
`
const buttonWrapperStyle = css`
  position: absolute;
  margin: auto;
  top: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  z-index: 2;
  cursor: pointer;
`
const RightButtonWrapper = styled.div`
  ${buttonWrapperStyle}
  right: 0;
`
const LeftButtonWrapper = styled.div`
  ${buttonWrapperStyle}
  left: 0;
`

type spacing = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10

// This function takes an index and a collection that's either a single thing, or an array
// If it's a single thing then it returns it
// If it's an array then it tries to get the item at the given index
// If said index is out of bound then return the last item in the array
function getNum(index: number, collection: spacing | spacing[]): spacing
function getNum(index: number, collection: number | number[]): number
function getNum(index: any, collection: any): any {
  if (typeof collection !== 'object') {
    return collection
  }
  if (collection.length <= index) {
    return collection[collection.length - 1]
  }
  return collection[index]
}

export interface IProps {
  renderLeftButton?: (handleClick: () => void) => JSX.Element
  renderRightButton?: (handleClick: () => void) => JSX.Element
  cardSpacing?: spacing | spacing[]
  selectedChildIndex?: number
  extraSidePadding?: number | number[]
}

const Carousel: React.FunctionComponent<IProps> = ({
  children,
  renderLeftButton = (handleClick) => (
    <button onClick={handleClick}>left</button>
  ),
  renderRightButton = (handleClick) => (
    <button onClick={handleClick}>right</button>
  ),
  cardSpacing = [2, 2, 4, 4],
  selectedChildIndex = 0,
  extraSidePadding = 0,
}) => {
  const [scrollPos, setScrollPos] = useState({ left: 0, right: 0 })
  const [childSize, setChildSize] = useState({ width: 0, height: 0 })
  const theme = useTheme()
  const isMediaXs = useMediaQuery(theme.breakpoints.down('xs'))
  const isMediaSm = useMediaQuery(theme.breakpoints.down('sm'))
  const isMediaMd = useMediaQuery(theme.breakpoints.down('md'))

  //curried function for getting card spacing and extra side padding
  const getCardSpacing = useCallback(
    (index: number) => getNum(index, cardSpacing),
    [cardSpacing]
  )
  const getExtraSidePadding = useCallback(
    (index: number) => getNum(index, extraSidePadding),
    [extraSidePadding]
  )

  const mediaIndex = useMemo(
    () => (isMediaXs ? 0 : isMediaSm ? 1 : isMediaMd ? 2 : 3),
    [isMediaXs, isMediaSm, isMediaMd]
  )
  const finalExtraSidePadding = useMemo(() => getExtraSidePadding(mediaIndex), [
    getExtraSidePadding,
    mediaIndex,
  ])

  const finalCardSpacing = useMemo(() => getCardSpacing(mediaIndex), [
    getCardSpacing,
    mediaIndex,
  ])

  // This reference is used to check the scroll position of the wrapper
  const scrollContainerRef = useRef<HTMLDivElement | null>(null)

  const updateScrollPos = useCallback(() => {
    const container = scrollContainerRef.current
    const numberOfChildren = container?.children.length || 0
    const scrollWidth = container?.scrollWidth || 1
    const finalExtraSidePaddingNum = theme.spacing(finalExtraSidePadding)
    const finalCardSpacingNum = theme.spacing(finalCardSpacing)

    // Assume all the child sizes are the same.
    // ie. the scrollWidth of container minus the extra side paddings,
    // divide by number of children gives the size of any one child.
    const newChildWidth =
      (scrollWidth - 2 * finalExtraSidePaddingNum + 2 * finalCardSpacingNum) /
      numberOfChildren
    const newChildHeight = container?.scrollHeight || 0

    setChildSize({ width: newChildWidth, height: newChildHeight })

    const selectedScrollPosition = newChildWidth * selectedChildIndex

    //How much to scroll is the difference of where we are and where we should be.
    scrollContainerRef.current?.scrollBy({
      top: 0,
      left: selectedScrollPosition - (container?.scrollLeft || 0),
    })
    setScrollPos(calculateScrollPos())
  }, [finalCardSpacing, finalExtraSidePadding, selectedChildIndex, theme])

  // Return an object that represents how far the object have scrolled from
  // left and from the right hand side
  const calculateScrollPos = () => {
    const element = scrollContainerRef?.current
    const scrollWidth = element?.scrollWidth || 0
    const left = element?.scrollLeft || 0
    const right = scrollWidth - (element?.offsetWidth || 0) - left
    return { left, right }
  }

  //Recalculate scroll position and re-render when user re-sizes the window
  useLayoutEffect(() => {
    updateScrollPos()
    window.addEventListener('resize', updateScrollPos)
    return () => {
      window.removeEventListener('resize', updateScrollPos)
    }
  }, [updateScrollPos])

  const handleScroll = () => {
    setScrollPos(calculateScrollPos())
  }

  // When a direction arrow have been clicked, find which child element
  // is being displayed. And scroll by the size of the element if going right
  // or scroll by the negative of the size of the previous element if going left
  const handleClick = (direction: 'left' | 'right') => {
    const scrollByObject =
      direction === 'left'
        ? {
            top: 0,
            left: -childSize.width,
          }
        : { top: 0, left: childSize.width }

    scrollContainerRef.current?.scrollBy(scrollByObject)
  }

  return (
    <Wrapper container $height={childSize.height}>
      {scrollPos.left > 0 && (
        <LeftButtonWrapper>
          {renderLeftButton(() => handleClick('left'))}
        </LeftButtonWrapper>
      )}
      <GridContainer
        item
        spacing={finalCardSpacing}
        xs={12}
        container
        ref={scrollContainerRef}
        onScroll={handleScroll}
        wrap="nowrap"
        aria-label="carousel-container"
      >
        {React.Children.map(children, (child, index) => (
          <GridItem
            item
            $extraLeftPadding={index === 0 ? finalExtraSidePadding : 0}
            $extraRightPadding={
              index === React.Children.count(children) - 1
                ? finalExtraSidePadding
                : 0
            }
          >
            {child}
          </GridItem>
        ))}
      </GridContainer>
      {scrollPos.right > 0 && (
        <RightButtonWrapper>
          {renderRightButton(() => handleClick('right'))}
        </RightButtonWrapper>
      )}
    </Wrapper>
  )
}

const GridContainer = styled(Grid)`
  overflow: auto;
  scroll-snap-type: x mandatory;
  scroll-behavior: smooth;
  margin: unset;
`

const GridItem = styled(Grid)<{
  $extraLeftPadding?: number
  $extraRightPadding?: number
}>`
  ${({ theme, $extraLeftPadding = 0, $extraRightPadding = 0 }) => css`
    && {
      padding-left: ${$extraLeftPadding
        ? `${theme.spacing($extraLeftPadding)}px`
        : ''};
      padding-right: ${$extraRightPadding
        ? `${theme.spacing($extraRightPadding)}px`
        : ''};
    }
    position: relative;
    flex-grow: 1;
  `}
`
export default Carousel
