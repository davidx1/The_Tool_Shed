import React, { FC } from 'react'
import { Box as BoxBase, BoxProps } from '@material-ui/core'

/**
 * Extends Material UI Box component
 * https://material-ui.com/components/box/
 */
export const BoxDoc: FC<BoxProps> = (props) => <BoxBase {...props} />

export default BoxBase
