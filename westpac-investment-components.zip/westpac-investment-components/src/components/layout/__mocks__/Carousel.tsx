import React from 'react'
import { IProps } from '../Carousel'

const Carousel: React.FunctionComponent<IProps> = ({ children }) => (
  <ul>
    {React.Children.map(children, (child) => (
      <li>{child}</li>
    ))}
  </ul>
)

export default Carousel
