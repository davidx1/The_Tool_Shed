import React from 'react'

import TransitionResultContainer from './TransitionResultContainer'

export default {
  title: '🔸 Internal/Layout/TransitionResultContainer',
  component: TransitionResultContainer,
}

export const Basic = () => <TransitionResultContainer isTransitioning={false} />
