import styled, { css, StyledProps } from 'styled-components'
import React from 'react'

interface InertProps {
  isInert: boolean
  delay?: number
  timingFunction?: string
}

interface Props extends InertProps {
  component?: React.ElementType
}

const InertWrapper = styled.div(
  ({ isInert, delay, timingFunction }: StyledProps<InertProps>) => css`
    visibility: ${isInert ? 'hidden' : 'visible'};
    transition: ${delay
      ? `visibility ${delay}s ${timingFunction || 'ease'}`
      : 'none'};
  `
)

const Inert: React.FC<Props> = ({ isInert, component, children, ...props }) => {
  return (
    <InertWrapper isInert={isInert} as={component} {...props}>
      {children}
    </InertWrapper>
  )
}

export default Inert
