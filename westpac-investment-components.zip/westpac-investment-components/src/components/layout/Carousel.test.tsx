import React from 'react'
import styled from 'styled-components'
import { render, screen, fireEvent } from '@testing-library/react'
import Carousel from './Carousel'

const Wrapper = styled.div`
  width: 300px;
  height: 300px;
`

const CarouselItem = styled.div`
  height: 100px;
  width: 100px;
`

const items = ['item1', 'item2', 'item3', 'item4', 'item5', 'item6']

const MyCarousel = () => {
  return (
    <Wrapper>
      <Carousel
        renderLeftButton={(handleClick) => (
          <button onClick={handleClick}>Left</button>
        )}
        renderRightButton={(handleClick) => (
          <button onClick={handleClick}>Right</button>
        )}
      >
        {items.map((item) => (
          <CarouselItem key={item}>{item}</CarouselItem>
        ))}
      </Carousel>
    </Wrapper>
  )
}

test('If we are part way through, both button should appear', async () => {
  initializeHTMLProperty()
  render(<MyCarousel />)
  setSizes()

  //Initially only the right button appears
  expect(screen.queryAllByText(/right/i)).toHaveLength(1)
  expect(screen.queryAllByText(/left/i)).toHaveLength(0)

  triggerResize()
  fireEvent.click(screen.getByText(/right/i))

  //When you scroll a little, both button appears
  expect(screen.queryAllByText(/right/i)).toHaveLength(1)
  expect(screen.queryAllByText(/left/i)).toHaveLength(1)

  fireEvent.click(screen.getByText(/right/i))
  fireEvent.click(screen.getByText(/right/i))
  fireEvent.click(screen.getByText(/right/i))
  fireEvent.click(screen.getByText(/right/i))
  fireEvent.click(screen.getByText(/right/i))

  //If you keep scrolling to the end, the right button disappears
  expect(screen.queryAllByText(/right/i)).toHaveLength(0)
  expect(screen.queryAllByText(/left/i)).toHaveLength(1)

  fireEvent.click(screen.getByText(/left/i))

  //If you scroll back a little both appears
  expect(screen.queryAllByText(/right/i)).toHaveLength(1)
  expect(screen.queryAllByText(/left/i)).toHaveLength(1)

  fireEvent.click(screen.getByText(/left/i))
  fireEvent.click(screen.getByText(/left/i))
  fireEvent.click(screen.getByText(/left/i))
  fireEvent.click(screen.getByText(/left/i))
  fireEvent.click(screen.getByText(/left/i))

  //If you keep scrolling the left button disappears
  expect(screen.queryAllByText(/right/i)).toHaveLength(1)
  expect(screen.queryAllByText(/left/i)).toHaveLength(0)
})

//This function just makes sure all HTML property have the scrollBy property.
function initializeHTMLProperty() {
  Object.defineProperty(Element.prototype, 'scrollBy', {
    writable: true,
    value: () => {},
  })
}

//Things rendered in JS dom by default don't have any sizes
//Here we are mocking up the scroll widths and triggering the resize event
//It's as if we just manually resized a browser window from having 0 width
//To it's proper width;
function setSizes() {
  Object.defineProperty(
    screen.queryByLabelText('carousel-container'),
    'scrollWidth',
    {
      configurable: true,
      get: () => 1000,
    }
  )

  Object.defineProperty(
    screen.queryByLabelText('carousel-container'),
    'scrollLeft',
    {
      configurable: true,
      writable: true,
      value: 0,
    }
  )

  Object.defineProperty(
    screen.queryByLabelText('carousel-container'),
    'offsetWidth',
    {
      configurable: true,
      writable: true,
      value: 0,
    }
  )

  Object.defineProperty(
    screen.queryByLabelText('carousel-container'),
    'scrollBy',
    {
      configurable: true,
      value: (obj: { left: number }) => {
        const value =
          screen.queryByLabelText('carousel-container')!.scrollLeft + obj.left
        const maxScroll = screen.queryByLabelText('carousel-container')!
          .scrollWidth
        screen.queryByLabelText('carousel-container')!.scrollLeft = Math.min(
          maxScroll,
          value
        )
        fireEvent.scroll(screen.getByLabelText('carousel-container'))
      },
    }
  )

  triggerResize()
}

function triggerResize() {
  const resizeEvent = document.createEvent('Event')
  resizeEvent.initEvent('resize', true, true)
  window.dispatchEvent(resizeEvent)
}
