import React from 'react'
import styled from 'styled-components'
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore'
import NavigateNextIcon from '@material-ui/icons/NavigateNext'
import Carousel from './Carousel'

export default {
  title: 'Layout/Carousel',
  component: Carousel,
}

const Item = styled.div`
  width: 250px;
  height: 150px;
  border: 1px solid black;
`

export const Basic = () => (
  <Carousel>
    <Item>0</Item>
    <Item>1</Item>
    <Item>2</Item>
    <Item>3</Item>
    <Item>4</Item>
    <Item>5</Item>
    <Item>6</Item>
    <Item>7</Item>
  </Carousel>
)

export const AutoScrollToPreselectedItemOnLoad = () => (
  <Carousel selectedChildIndex={4}>
    <Item>0</Item>
    <Item>1</Item>
    <Item>2</Item>
    <Item>3</Item>
    <Item>4</Item>
    <Item>5</Item>
    <Item>6</Item>
    <Item>7</Item>
  </Carousel>
)

export const CustomLeftAndRightButtons = () => (
  <Carousel
    renderLeftButton={(handleClick) => (
      <button onClick={handleClick}>
        <NavigateBeforeIcon />
      </button>
    )}
    renderRightButton={(handleClick) => (
      <button onClick={handleClick}>
        <NavigateNextIcon />
      </button>
    )}
  >
    <Item>0</Item>
    <Item>1</Item>
    <Item>2</Item>
    <Item>3</Item>
    <Item>4</Item>
    <Item>5</Item>
    <Item>6</Item>
    <Item>7</Item>
  </Carousel>
)

export const WithFewerItems = () => (
  <Carousel
    renderLeftButton={(handleClick) => (
      <button onClick={handleClick}>
        <NavigateBeforeIcon />
      </button>
    )}
    renderRightButton={(handleClick) => (
      <button onClick={handleClick}>
        <NavigateNextIcon />
      </button>
    )}
  >
    <Item>0</Item>
    <Item>1</Item>
    <Item>2</Item>
  </Carousel>
)
