import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, List, ListItem, ListItemText } from '@material-ui/core'
import HTMLRenderer from './HTMLRenderer'

const TypographyItems = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(16)};
    line-height: ${theme.typography.pxToRem(22)};
  `
)

const StyledList = styled(List)`
  padding-bottom: ${({ theme }) => theme.spacing(2)}px;
`

export interface Props {
  items: string[]
  disclosures: string[]
}

const ListWithDisclosures: React.FC<Props> = ({ items, disclosures }) => {
  if (!items || items.length === 0) return null
  return (
    <StyledList disablePadding>
      {items.map((item) => (
        <ListItem key={item}>
          <ListItemText
            disableTypography
            primary={<TypographyItems variant="body1"><HTMLRenderer value={item} /></TypographyItems>}
          />
        </ListItem>
      ))}
      {disclosures?.map((item) => (
        <ListItem key={item}>
          <ListItemText
            disableTypography
            primary={
              <TypographyItems variant="body1" color="textSecondary">
                {item}
              </TypographyItems>
            }
          />
        </ListItem>
      ))}
    </StyledList>
  )
}

export default ListWithDisclosures
