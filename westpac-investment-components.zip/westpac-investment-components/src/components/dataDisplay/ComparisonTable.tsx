import React from 'react'
import styled, { StyledProps, css } from 'styled-components'
import {
  Table,
  TableCell,
  TableBody,
  TableHead,
  TableRow,
  Typography,
  Box,
} from '@material-ui/core'
import {
  IHighlightProps,
  IComparisonProps,
  CellBase,
  IItemBase,
  CellValue,
  LabelIndicator,
  TypographyComparisonItem,
  ComparisonActionButtonWrapper,
} from './ComparisonBase'
import HTMLRenderer from './HTMLRenderer'

const TableStyled = styled(Table)`
  table-layout: fixed; /* IE: Calc size of rows and cols correctly, allowing text to wrap (is responsive) */
  border-top: 0;
  margin: 0;
`
// heights per designs
const TableCellStyled = styled(
  ({ stickyHeader, showHighlight, alignment, ...props }) => (
    <TableCell {...props} />
  )
)(
  ({
    theme,
    showHighlight,
    alignment = 'top',
    stickyHeader,
  }: StyledProps<IHighlightProps & { stickyHeader?: boolean }>) =>
    css`
      border-bottom: 1px solid ${theme.palette.disabled.light};
      max-width: 16.666%;
      font-size: ${theme.typography.body1.fontSize};
      font-weight: 400;
      padding: 0;
      vertical-align: ${alignment};
      position: relative;
      height: 100px;
      background: ${showHighlight
        ? theme.palette.highlight.main
        : theme.palette.background.paper};

      thead & {
        height: 71px;
        ${stickyHeader &&
        css`
          position: sticky;
          top: 0;
          background-color: ${theme.palette.background.paper};
          box-shadow: 10px 0px 10px 0px rgba(0, 0, 0, 0.15);
          z-index: 1;
        `}
      }
    `
)

const BoxTitle = styled(Box)`
  font-weight: 500;
`

const ComparisonTable = <
  Item extends IItemBase<Type>,
  Type,
  DataFields extends keyof Item
>({
  actionButtonRender,
  cellBodyAlignment,
  columns,
  comparisonData,
  comparisonItemTitle,
  getItemIndicatorColor,
  indicatorColor,
  recommendationType,
  rowTitleField,
  rowTitleValueRender,
  rowTitleWidth = 200,
  title,
}: IComparisonProps<Item, Type, DataFields>) => {
  if (!columns || !comparisonData) return null

  return (
    <TableStyled aria-label={title}>
      <TableHead>
        <TableRow>
          <TableCellStyled width={rowTitleWidth} stickyHeader>
            <CellBase>
              <Typography variant="srOnly">{comparisonItemTitle}</Typography>
            </CellBase>
          </TableCellStyled>
          {columns.map((column) => (
            <TableCellStyled
              key={`th-${column.dataField}`}
              width={column.width}
              stickyHeader
            >
              <CellBase alignment="center">
                <BoxTitle>{column.title}</BoxTitle>
              </CellBase>
            </TableCellStyled>
          ))}
        </TableRow>
      </TableHead>
      <TableBody>
        {comparisonData.map((item) => {
          const isRecommendedType = item.type === recommendationType
          const title = rowTitleField ? item[rowTitleField] : item.title

          return (
            <TableRow key={`tr-${item.type}`}>
              <TableCellStyled
                variant="head"
                component="th"
                scope="row"
                alignment={cellBodyAlignment}
                showHighlight={isRecommendedType}
              >
                <CellBase isContainer>
                  <TypographyComparisonItem>
                    <LabelIndicator
                      showHighlight={isRecommendedType}
                      indicatorColor={
                        getItemIndicatorColor
                          ? getItemIndicatorColor(item.type)
                          : indicatorColor
                      }
                    >
                      {rowTitleValueRender ? rowTitleValueRender(title) : title}
                    </LabelIndicator>
                  </TypographyComparisonItem>
                  {actionButtonRender && (
                    <ComparisonActionButtonWrapper>
                      {actionButtonRender(item, item.type)}{' '}
                    </ComparisonActionButtonWrapper>
                  )}
                </CellBase>
              </TableCellStyled>

              {columns.map((column) => {
                const value = item[column.dataField]

                return (
                  <TableCellStyled
                    key={`${item.type}-${column.dataField}`}
                    alignment={cellBodyAlignment}
                    showHighlight={isRecommendedType}
                  >
                    <CellBase>
                      <CellValue>
                        {column.renderColumnValue ? (
                          column.renderColumnValue(value)
                        ) : (
                          <HTMLRenderer value={(value as unknown) as string} />
                        )}
                      </CellValue>
                    </CellBase>
                  </TableCellStyled>
                )
              })}
            </TableRow>
          )
        })}
      </TableBody>
    </TableStyled>
  )
}

export default ComparisonTable
