import React, { FC } from 'react'

import cashFundIcon from '../../icons/cashFund'
import conservativeFundIcon from '../../icons/conservativeFund'
import balancedFundIcon from '../../icons/balancedFund'
import briefCaseIcon from '../../icons/briefCase'
import growthFundIcon from '../../icons/growthFund'
import piggyIcon from '../../icons/piggy'
import houseOnlyIcon from '../../icons/houseOnly'
import houseFillIcon from '../../icons/houseFill'
import palmTreeIcon from '../../icons/palmTree'
import calendarIcon from '../../icons/calendar'
import moneyIcon from '../../icons/money'
import moneyCoinIcon from '../../icons/moneyCoin'
import dollarLessIcon from '../../icons/dollarLess'
import dollarMoreIcon from '../../icons/dollarMore'
import handUpIcon from '../../icons/handUp'
import handDownIcon from '../../icons/handDown'
import faqIcon from '../../icons/faq'
import questionMarkIcon from '../../icons/questionMark'
import phoneIcon from '../../icons/phone'
import playIcon from '../../icons/play'
import infoIcon from '../../icons/info'
import infoFillIcon from '../../icons/infoFill'
import timelineIcon from '../../icons/timeline'
import plantGrowthIcon from '../../icons/plantGrowth'
import piggyTaxIcon from '../../icons/piggyTax'
import taxPaymentIcon from '../../icons/taxPayment'
import handCoinIcon from '../../icons/handCoin'
import handGrowthIcon from '../../icons/handGrowth'
import longTermInvestmentIcon from '../../icons/longTermInvestment'
import noticeSaverIcon from '../../icons/noticeSaver'
import termPIEIcon from '../../icons/termPIE'
import bonusPIEIcon from '../../icons/bonusPIE'
import piggySavingIcon from '../../icons/piggySaving'
import umbrellaIcon from '../../icons/umbrella'
import houseDollarIcon from '../../icons/houseDollar'
import kiwiSaverIcon from '../../icons/kiwiSaver'
import arrowRightIcon from '../../icons/arrowRight'
import arrowDownIcon from '../../icons/arrowDown'
import westpacIcon from '../../icons/westpac'
import glossaryIcon from '../../icons/glossary'
import contactIcon from '../../icons/contact'
import linkOutIcon from '../../icons/linkOut'
import resetIcon from '../../icons/reset'
import branchIcon from '../../icons/branch'
import moderateFundIcon from '../../icons/moderateFund'

import { IKiwisaverFundType } from '../../utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import { IProductChooserProductType } from '../../utils/product-chooser/productChooserUtils'

import { SvgIconProps } from '@material-ui/core'

export type AllIconsType =
  | IconType
  | ExtraIconType
  | IKiwisaverFundType
  | IProductChooserProductType

export type IconType =
  | 'briefCase'
  | 'info'
  | 'infoFill'
  | 'piggy'
  | 'houseOnly'
  | 'palmTree'
  | 'calendar'
  | 'money'
  | 'moneyCoin'
  | 'dollarLess'
  | 'dollarMore'
  | 'handUp'
  | 'handDown'
  | 'handGrowth'
  | 'faq'
  | 'questionMark'
  | 'phone'
  | 'timeline'
  | 'plantGrowth'
  | 'piggyTax'
  | 'taxPayment'
  | 'handCoin'
  | 'longTermInvestment'
  | 'noticeSaver'
  | 'piggySaving'
  | 'umbrella'
  | 'houseDollar'
  | 'kiwiSaver'
  | 'glossary'
  | 'contact'
  | 'houseFill'
  | 'linkOut'
  | 'reset'
  | 'branch'

type ExtraIconType = 'arrowRight' | 'arrowDown' | 'play' | 'westpac'

export const icons: {
  [key in AllIconsType]: React.ComponentType<SvgIconProps>
} = {
  briefCase: briefCaseIcon,
  cash: cashFundIcon,
  defensive: conservativeFundIcon,
  conservative: conservativeFundIcon,
  moderate: moderateFundIcon,
  balanced: balancedFundIcon,
  growth: growthFundIcon,
  termPIE: termPIEIcon,
  faq: faqIcon,
  questionMark: questionMarkIcon,
  phone: phoneIcon,
  piggy: piggyIcon,
  houseOnly: houseOnlyIcon,
  houseFill: houseFillIcon,
  palmTree: palmTreeIcon,
  calendar: calendarIcon,
  money: moneyIcon,
  moneyCoin: moneyCoinIcon,
  dollarLess: dollarLessIcon,
  dollarMore: dollarMoreIcon,
  handUp: handUpIcon,
  handDown: handDownIcon,
  timeline: timelineIcon,
  plantGrowth: plantGrowthIcon,
  piggyTax: piggyTaxIcon,
  taxPayment: taxPaymentIcon,
  handCoin: handCoinIcon,
  handGrowth: handGrowthIcon,
  longTermInvestment: longTermInvestmentIcon,
  piggySaving: piggySavingIcon,
  umbrella: umbrellaIcon,
  houseDollar: houseDollarIcon,
  kiwiSaver: kiwiSaverIcon,
  noticeSaver: noticeSaverIcon,
  bonusSaverAccount: piggySavingIcon,
  simpleSaver: piggyIcon,
  bonusSaverPIE: bonusPIEIcon,
  termDeposit: longTermInvestmentIcon,
  info: infoIcon,
  infoFill: infoFillIcon,
  arrowRight: arrowRightIcon,
  arrowDown: arrowDownIcon,
  play: playIcon,
  westpac: westpacIcon,
  glossary: glossaryIcon,
  contact: contactIcon,
  linkOut: linkOutIcon,
  reset: resetIcon,
  branch: branchIcon,
}

export interface Props extends SvgIconProps {
  icon: AllIconsType | null
}

const DynamicIcon: FC<Props> = ({ icon, ...props }) => {
  const Icon = icon && icons[icon]
  return Icon ? <Icon {...props} /> : null
}

export default DynamicIcon
