import React, { useState } from 'react'
import styled, { css } from 'styled-components'
import {
  Grid,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@material-ui/core'
import {
  IComparisonProps,
  IItemBase,
  LabelIndicator,
  CellBase,
  CellValue,
  TypographyComparisonItem,
  ComparisonActionButtonWrapper,
} from './ComparisonBase'
import HTMLRenderer from './HTMLRenderer'

const pseudoBorderBottomBase = css`
  content: '';
  display: block;
  position: absolute;
  bottom: 0;
  height: 1px;
`

const pseudoBorderBottomFullWidth = css(
  ({ theme }) => css`
    ${pseudoBorderBottomBase}
    left: ${theme.spacing(2)}px;
    /* stylelint-disable-next-line */
    width: calc(100% - ${theme.spacing(4)}px);
    ${theme.breakpoints.up('sm')}{
      left: ${theme.spacing(4)}px;
      /* stylelint-disable-next-line */
      width: calc(100% - ${theme.spacing(8)}px);
    }
  `
)

const ExpansionPanelStyled = styled(Accordion)`
  width: 100%;
  box-shadow: none;
  border-radius: 0;
  display: flex;
  flex-direction: column;

  && .MuiCollapse-hidden {
    display: none; /* Bugfix for overflowing invisible content in dialog */
  }

  .MuiCollapse-container,
  .MuiCollapse-wrapper,
  .MuiCollapse-wrapperInner,
  .MuiCollapse-wrapperInner > * {
    display: flex;
    flex-grow: 1;
  }

  .MuiCollapse-container {
    &:after {
      ${pseudoBorderBottomFullWidth}
      background: ${({ theme }) => theme.palette.highlight.secondary};
    }
  }
`

const ExpansionPanelSummaryStyled = styled(AccordionSummary)(
  ({ theme }) => css`
    display: flex;
    align-items: center;
    min-height: 76px; /* Per designs */
    padding: 0 ${theme.spacing(2)}px;
    ${theme.breakpoints.up('sm')}{
        padding: 0 ${theme.spacing(4)}px;
    }


    &:not(.Mui-expanded) {
      &:after {
        ${pseudoBorderBottomFullWidth}
        background: ${theme.palette.highlight.secondary};
      }
    }

    &.Mui-expanded {
      min-height: 76px; /* Per designs */
    }

    .MuiSvgIcon-root {
      font-size: ${theme.typography.pxToRem(32)};
    }

    .MuiIconButton-root {
      box-shadow: none;
      color: ${theme.palette.primary.dark};
    }
    .MuiIconButton-edgeEnd {
      margin-right: 0;
    }
  `
)

const ExpansionPanelDetailsStyled = styled(AccordionDetails)`
  padding: 0;
  display: flex;
  flex-grow: 1;
`

const GridStyled = styled(Grid).attrs({
  xs: 12,
  item: true,
})`
  display: flex;
  position: relative;
`

const Cell = styled((props) => <CellBase {...props} />)`
  ${({ theme }) =>
    css`

      ${theme.breakpoints.down('xs')} {
        padding: ${theme.spacing(1)}px ${theme.spacing(2)}px;

        ${GridStyled}:nth-child(odd) & {
          padding-bottom: 0;
        }
        
        ${GridStyled}:nth-child(even):not(:last-child) & {
          &:after {
            ${pseudoBorderBottomFullWidth}
            background: ${theme.palette.disabled.light};
          }
        }
      }

      ${theme.breakpoints.up('sm')} {
        padding: ${theme.spacing(3)}px ${theme.spacing(4)}px;

        ${GridStyled}:not(:last-child):not(:nth-last-child(2)) & {
          &:after {
            ${pseudoBorderBottomBase}
            background: ${theme.palette.disabled.light};
            /* stylelint-disable-next-line */
            width: calc(100% - ${theme.spacing(3)}px);
          }
        }
        ${GridStyled}:nth-child(odd):not(:last-child):not(:nth-last-child(2)) & {
          &:after {
            left: ${theme.spacing(4)}px;
          }
        }
        ${GridStyled}:nth-child(even):not(:last-child):not(:nth-last-child(2)) & {
          &:after {
            right: ${theme.spacing(4)}px;
          }
        }
      }
    `}
`

const ChevronDown = styled.span(
  ({ theme }) => css`
    border: solid ${theme.palette.primary.dark};
    border-width: 0 ${theme.typography.pxToRem(2)}
      ${theme.typography.pxToRem(2)} 0;
    transform: translateY(-${theme.typography.pxToRem(2)}) rotate(45deg);
    width: ${theme.typography.pxToRem(12)};
    height: ${theme.typography.pxToRem(12)};
  `
)

const ComparisonCollapse = <
  Item extends IItemBase<Type>,
  Type,
  DataFields extends keyof Item
>({
  actionButtonRender,
  columns,
  comparisonData,
  getItemIndicatorColor,
  rowTitleValueRender,
  indicatorColor,
  recommendationType,
  rowTitleField,
}: IComparisonProps<Item, Type, DataFields>) => {
  const [expanded, setExpanded] = useState<string[]>([])

  const handleChange = (panelId: string) => () => {
    if (expanded.includes(panelId)) {
      setExpanded(expanded.filter((x) => x !== panelId))
    } else {
      setExpanded([...expanded, panelId])
    }
  }

  if (!columns || !comparisonData) return null

  return (
    <Grid container>
      {columns.map((column) => {
        const panelId = `panel-${column.dataField}`
        return (
          <Grid key={panelId} item container xs={12}>
            <ExpansionPanelStyled
              expanded={expanded.includes(panelId)}
              onChange={handleChange(panelId)}
            >
              <ExpansionPanelSummaryStyled
                expandIcon={<ChevronDown />}
                aria-controls={`content-${panelId}`}
                id={`header-${panelId}`}
              >
                <Typography variant="subtitle2" component="p">
                  {column.title}
                </Typography>
              </ExpansionPanelSummaryStyled>

              <ExpansionPanelDetailsStyled>
                <Grid container>
                  {comparisonData.map((item) => {
                    const value = item[column.dataField]
                    const title = rowTitleField
                      ? item[rowTitleField]
                      : item.title
                    const isRecommendedType = item.type === recommendationType

                    return (
                      <React.Fragment
                        key={`label-${column.dataField}-${item.type}`}
                      >
                        <GridStyled sm={4} md={12}>
                          <Cell showHighlight={isRecommendedType} isContainer>
                            <TypographyComparisonItem>
                              <LabelIndicator
                                showHighlight={isRecommendedType}
                                indicatorColor={
                                  getItemIndicatorColor
                                    ? getItemIndicatorColor(item.type)
                                    : indicatorColor
                                }
                              >
                                {rowTitleValueRender
                                  ? rowTitleValueRender(title)
                                  : title}
                              </LabelIndicator>
                            </TypographyComparisonItem>
                            {actionButtonRender && (
                              <ComparisonActionButtonWrapper>
                                {actionButtonRender(item, item.type)}
                              </ComparisonActionButtonWrapper>
                            )}
                          </Cell>
                        </GridStyled>
                        <GridStyled sm={8} md={12}>
                          <Cell showHighlight={isRecommendedType}>
                            <CellValue>
                              {column.renderColumnValue ? (
                                column.renderColumnValue(value)
                              ) : (
                                <HTMLRenderer
                                  value={(value as unknown) as string}
                                />
                              )}
                            </CellValue>
                          </Cell>
                        </GridStyled>
                      </React.Fragment>
                    )
                  })}
                </Grid>
              </ExpansionPanelDetailsStyled>
            </ExpansionPanelStyled>
          </Grid>
        )
      })}
    </Grid>
  )
}

export default ComparisonCollapse
