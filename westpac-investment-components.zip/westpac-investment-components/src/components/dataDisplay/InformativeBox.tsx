import React, { FC, useMemo } from 'react'
import styled, { css, StyledProps } from 'styled-components'
import {
  Typography,
  Grid,
  Hidden,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Box,
} from '@material-ui/core'
import ExpandIcon from '@material-ui/icons/ExpandLess'

import { IStep } from '../navigation/IQuestionnaire'
import { fadeIn } from '../../utils/animations'
import ArrowButton from '../inputs/ArrowButton'

import DynamicIcon from './DynamicIcon'
import LinkButton from '../inputs/LinkButton'

export interface Props {
  step: IStep
  paddingTop: number
}

const CollapsibleInformativeContainer = styled(Accordion)(
  ({ theme }) => css`
    position: fixed;
    width: 100%;
    min-height: 60px;
    bottom: 0px;
    left: 0px;
    right: 0px;
    background: ${theme.palette.background.light};
    z-index: 3;
    box-shadow: none;
    &::before {
      height: 0px;
    }
    &.Mui-expanded {
      box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.15);
      margin: 0px;
    }
  `
)

const StyledExpansionPanelDetails = styled(AccordionDetails)`
  padding-top: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
`

const InformativeContainer = styled(({ paddingTop, ...props }) => (
  <aside {...props} />
))(
  ({ theme, paddingTop }: StyledProps<{ paddingTop: number }>) => css`
    display: none;
    pointer-events: none;
    ${theme.breakpoints.up('md')} {
      display: flex;
      position: absolute;
      background: ${theme.palette.background.light};
      right: 0;
      bottom: 0;
      min-width: 404px;
      width: 33%;
      padding: 0 60px 0 40px;
      top: ${paddingTop}px;
      z-index: 1;
    }
  `
)

const Transition = styled.div`
  max-width: 400px;
  width: 100%;
  margin: 0 auto;
  @media (prefers-reduced-motion: no-preference) {
    animation: ${fadeIn} 0.5s cubic-bezier(0, 0, 0.2, 1) forwards;
  }
`

const Title = styled(Typography).attrs({
  variant: 'h4',
  component: 'h3',
})`
  ${({ theme }) => css`
    font-size: ${theme.typography.pxToRem(18)};
    font-weight: ${theme.typography.fontWeightMedium};
    ${theme.breakpoints.up('md')} {
      font-weight: ${theme.typography.fontWeightBold};
      margin-top: ${theme.spacing(1)}px;
    }
  `}
`

const Description = styled(Typography)`
  ${({ theme }) => css`
    margin-bottom: ${theme.spacing(2)}px;
  `}
`

const GridText = styled(Grid)`
  padding-left: ${({ theme }) => theme.spacing(1)}px;
`

const StyledDynamicIcon = styled(DynamicIcon)`
  transform: scale(1.3);
`

const FindOutMoreButton = styled(ArrowButton)`
  pointer-events: all;
`

const ContainerCallUs = styled(Box)`
  ${({ theme }) => css`
    display: flex;
    margin-top: ${theme.spacing(1.5)}px;
    flex-direction: row;
    align-items: center;
    ${theme.breakpoints.up('md')} {
      justify-content: center;
      position: absolute;
      bottom: ${theme.spacing(3)}px;
      left: 0;
      right: 0;
    }
    a {
      pointer-events: all;
    }
  `}
`

const CallUsIcon = styled(DynamicIcon)`
  margin-right: ${({ theme }) => theme.spacing(0.5)}px;
`

const InformativeBox: FC<Props> = ({ step, paddingTop }) => {
  const callUs = useMemo(() => {
    const callUsData = step?.question?.information?.callUs
    return callUsData ? (
      <ContainerCallUs>
        <CallUsIcon icon="questionMark" />
        <Typography>Need help? Call us on&nbsp;</Typography>
        <LinkButton href={callUsData.url}>{callUsData.label}</LinkButton>
      </ContainerCallUs>
    ) : null
  }, [step])

  if (!step?.question?.information) return null

  return (
    <React.Fragment>
      <Hidden smDown>
        <InformativeContainer paddingTop={paddingTop}>
          <Grid container alignItems="center">
            <Transition key={step.question.id}>
              <Grid container alignItems="flex-start">
                <Grid item>
                  <StyledDynamicIcon
                    icon={step.question.information.icon || 'info'}
                  />
                </Grid>
                <GridText item xs>
                  <Title gutterBottom>Things to know</Title>
                  {step.question.information.body?.map(
                    (bodyItem, bodyItemIndex) => (
                      <Description variant="body1" key={bodyItemIndex}>
                        {bodyItem}
                      </Description>
                    )
                  )}
                  {step.question.information.moreInfoUrl && (
                    <FindOutMoreButton
                      href={step.question.information.moreInfoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Find out more
                    </FindOutMoreButton>
                  )}
                </GridText>
              </Grid>
            </Transition>
          </Grid>
          {callUs}
        </InformativeContainer>
      </Hidden>
      <Hidden mdUp>
        <CollapsibleInformativeContainer key={step.question.id}>
          <AccordionSummary expandIcon={<ExpandIcon />}>
            <Title>Things to know</Title>
          </AccordionSummary>
          <StyledExpansionPanelDetails>
            {step.question.information.body?.map((bodyItem, bodyItemIndex) => (
              <Description variant="body1" key={bodyItemIndex}>
                {bodyItem}
              </Description>
            ))}
            {step.question.information.moreInfoUrl && (
              <FindOutMoreButton
                href={step.question.information.moreInfoUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                Find out more
              </FindOutMoreButton>
            )}
            {callUs}
          </StyledExpansionPanelDetails>
        </CollapsibleInformativeContainer>
      </Hidden>
    </React.Fragment>
  )
}

export default InformativeBox
