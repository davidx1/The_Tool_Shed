import React from 'react'
import ComparisonTable from './ComparisonTable'
import { IColumnProps } from './ComparisonBase'
import LinkButton from '../inputs/LinkButton'

export default {
  title: '🔸 Internal/Data Display/ComparisonTable',
  component: ComparisonTable,
}

export const FundComparison = () => {
  const getItemIndicatorColor = (type?: string) =>
    type === 'cash' ? '#ff0000' : '#000000'
  const recommendationType = 'cash'

  const comparisonColumns: IColumnProps<'description' | 'total'>[] = [
    {
      title: 'Description',
      dataField: 'description',
    },
    {
      title: 'Total',
      dataField: 'total',
      renderColumnValue: (value: number) => <strong>{value}%</strong>,
    },
  ]

  const funds = [
    {
      type: 'cash',
      title: 'Title',
      description: 'description',
      total: 100,
    },
    {
      type: 'cash2',
      title: 'Title2',
      description: 'description2',
      total: 44,
    },
  ]
  return (
    <ComparisonTable
      actionButtonRender={(item) => (
        <LinkButton
          onClick={() => {
            console.log(item)
          }}
        >
          Action Button
        </LinkButton>
      )}
      cellBodyAlignment="middle"
      title={'test'}
      comparisonData={funds}
      comparisonItemTitle={'test'}
      getItemIndicatorColor={getItemIndicatorColor}
      recommendationType={recommendationType}
      columns={comparisonColumns}
      rowTitleField="title"
    />
  )
}
