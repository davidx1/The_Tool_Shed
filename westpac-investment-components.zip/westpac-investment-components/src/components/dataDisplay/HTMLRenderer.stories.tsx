import React from 'react'

import HTMLRenderer from './HTMLRenderer'

export default {
  title: 'Data Display/HTMLRenderer',
  component: HTMLRenderer,
}

export const Basic = () => (
  <HTMLRenderer value="<a href='http://'>Link example</a>" />
)

Basic.parameters = {
  storyshots: false,
}
