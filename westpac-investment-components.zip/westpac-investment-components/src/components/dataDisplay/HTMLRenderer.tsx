import React, { useEffect, useRef, useMemo } from 'react'
import styled, { css } from 'styled-components'
import DOMPurify from 'dompurify'
import { isExternalLink, isNativeApp } from '../../utils/deviceUtils'

DOMPurify.addHook('afterSanitizeAttributes', function (node) {
  // set all elements owning target to target=_blank
  const href = node.getAttribute('href') || ''
  if (node.tagName === 'A' && isExternalLink(href)) {
    node.setAttribute('target', '_blank')
    node.setAttribute('rel', 'noopener noreferrer')
  }
})

export interface HTMLRendererProps {
  value: string
  type?: 'div' | 'span'
  linkHandler?: (event: MouseEvent) => void
}

/**
 * Use DOMPurify library to sanitize a html before rendering it.
 */
const HTMLRenderer: React.FC<HTMLRendererProps> = ({
  type = 'span',
  value,
  linkHandler,
}) => {
  const ref = useRef<HTMLElement | null>(null)
  const PurifiedHTML = useMemo(
    () =>
      React.createElement(type, {
        dangerouslySetInnerHTML: { __html: DOMPurify.sanitize(value) },
        ref,
      }),
    [type, value]
  )

  // override onclick methods on all the rendered links
  useEffect(() => {
    if (ref.current) {
      const links = ref.current.getElementsByTagName('a')
      for (let i = 0; i < links.length; i++) {
        const link = links[i]
        link.onclick = function (event) {
          // allow to track clicks in any <a> element, it can be used for analytics
          if (linkHandler) {
            linkHandler(event)
          }

          // use target _system for any native apps
          const href = link.getAttribute('href') || ''
          if (isNativeApp() && isExternalLink(href)) {
            event.preventDefault()
            window.open(href, '_system')
          }
        }
      }
    }
  }, [linkHandler])
  return PurifiedHTML
}

const DisclaimerWrapper = styled.div`
  ${({ theme }) => css`
    &,
    p {
      color: ${theme.palette.text.secondary};
      font-size: ${theme.typography.pxToRem(14)};
    }
    a {
      cursor: pointer;
      font-weight: ${theme.typography.fontWeightMedium};
      text-decoration: underline;
    }
  `}
`

export const DisclaimerText: React.FC<
  HTMLRendererProps & React.HTMLProps<HTMLDivElement>
> = ({ type, value, className }) => (
  <DisclaimerWrapper className={className}>
    <HTMLRenderer type={type} value={value} />
  </DisclaimerWrapper>
)

const DialogWrapper = styled.div`
  ${({ theme }) => css`
    &,
    p {
      color: ${theme.palette.text.primary};
      font-size: ${theme.typography.pxToRem(18)};
      margin-bottom: ${theme.spacing(2)}px;
    }
    h6 {
      font-weight: ${theme.typography.fontWeightBold};
    }
    a {
      cursor: pointer;
      font-weight: ${theme.typography.fontWeightMedium};
      text-decoration: underline;
    }
    ul {
      padding-left: ${theme.spacing(2.5)}px;
      li {
        > p {
          margin: 0;
        }
      }
    }
  `}
`

export const DialogText = ({ type, value }: HTMLRendererProps) => (
  <DialogWrapper>
    <HTMLRenderer type={type} value={value} />
  </DialogWrapper>
)

export default HTMLRenderer
