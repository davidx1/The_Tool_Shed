import React from 'react'
import styled, { css } from 'styled-components'
import { ListItemIcon } from '@material-ui/core'
import FiberManualRecordIcon from '@material-ui/icons/FiberManualRecord'

interface StyledContainerDiscProps {
  mt?: number
  size?: number
}

export const StyledContainerDisc = styled(ListItemIcon)<
  StyledContainerDiscProps
>(
  ({ theme, mt, size }) => css`
    min-width: 0;
    width: ${theme.typography.pxToRem(size ?? 7)};
    margin: ${theme.spacing(mt ?? 1.5, 2, 0, 0)};
  `
)

interface StyledDiscProps {
  color?: string
  size?: number
}

export const StyledDisc = styled(FiberManualRecordIcon)<StyledDiscProps>(
  ({ theme, size }) => css`
    font-size: ${theme.typography.pxToRem(size ?? 7)};
  `
)

export interface Props {
  marginTop?: number
  color?:
    | 'inherit'
    | 'primary'
    | 'secondary'
    | 'action'
    | 'disabled'
    | 'error'
    | undefined
  size?: number
}

const ListDisc: React.FC<Props> = ({ marginTop, color = 'primary', size }) => {
  return (
    <StyledContainerDisc mt={marginTop} size={size}>
      <StyledDisc color={color} size={size} />
    </StyledContainerDisc>
  )
}

export default ListDisc
