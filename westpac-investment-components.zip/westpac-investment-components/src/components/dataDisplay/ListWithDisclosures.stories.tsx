import React from 'react'

import ListWithDisclosures from './ListWithDisclosures'

export default {
  title: 'Data Display/ListWithDisclosures',
  component: ListWithDisclosures,
}

export const Basic = () => (
  <ListWithDisclosures
    items={['a', 'b¹', 'c']}
    disclosures={['¹: blablabla']}
  />
)
