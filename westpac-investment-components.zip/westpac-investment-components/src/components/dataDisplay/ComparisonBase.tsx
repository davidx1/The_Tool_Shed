import styled, { StyledProps, css } from 'styled-components'
import { indicatorDot } from '../../styles/sharedStyles'
import { Box, Typography } from '@material-ui/core'
import React from 'react'

export interface IComparisonProps<Item, Type, DataFields> {
  actionButtonRender?: (item: Item, itemType: Type) => React.ReactNode
  cellBodyAlignment?: string
  columns?: IColumnProps<DataFields>[]
  comparisonData: Item[]
  comparisonItemTitle?: string
  getItemIndicatorColor?: (itemType?: Type) => string | undefined
  indicatorColor?: string | undefined
  recommendationType: Type
  rowTitleField?: DataFields
  rowTitleValueRender?: (values?: any | undefined) => React.ReactNode
  rowTitleWidth?: number
  title?: string
}

export interface IColumnProps<DataFields> {
  title: string
  dataField: DataFields
  renderColumnValue?: (values?: any | undefined) => React.ReactNode
  width?: number
}

export interface IItemBase<Type> {
  title: string
  type: Type
}

export interface IHighlightProps {
  showHighlight?: boolean
  indicatorColor?: string
  isContainer?: boolean
  alignment?: string
}

export const CellBase = styled.div(
  ({
    theme,
    showHighlight,
    isContainer,
    alignment = 'flex-start',
  }: StyledProps<IHighlightProps>) =>
    css`
      padding: ${theme.spacing(3)}px;
      box-sizing: content-box;
      display: flex;
      flex-grow: 1;
      flex-wrap: ${isContainer ? 'wrap' : 'nowrap'};

      ${isContainer
        ? css`
            align-content: ${alignment};
          `
        : css`
            align-items: ${alignment};
          `}

      ${showHighlight &&
      css`
        &:before {
          content: '';
          display: block;
          width: 100%;
          height: 100%;
          position: absolute;
          top: 0;
          left: 0;
          background: ${theme.palette.highlight.main};
        }
        & > div {
          z-index: 1;
        }
      `}
    `
)

export const TypographyComparisonItem = styled(Typography)(
  ({ theme }) =>
    css`
      display: flex;
      align-items: center;
      font-weight: ${theme.typography.fontWeightMedium};
      margin-right: auto;

      ${theme.breakpoints.up('sm')} {
        margin-bottom: ${theme.typography.pxToRem(4)};
        width: 100%;
        margin-right: 0;
      }
    `
)

export const ComparisonActionButtonWrapper = styled.div`
  ${({ theme }) =>
    css`
      font-weight: ${theme.typography.fontWeightMedium};
      font-size: ${theme.typography.pxToRem(16)}
    `}
`

export const LabelIndicator = styled.span(
  ({ theme, showHighlight, indicatorColor }: StyledProps<IHighlightProps>) =>
    showHighlight &&
    css`
        position: relative;
  
        &:before {
          ${indicatorDot}
          background: ${indicatorColor || theme.palette.primary.dark};
          margin-left: -13px; /* Per designs */
        }
      `
)

export const CellValue = styled((props) => <Box {...props} />)(
  ({ theme }) => css`
    font-size: ${theme.typography.body1.fontSize};
    line-height: 22px;

    strong,
    b {
      font-weight: ${theme.typography.fontWeightMedium};
    }

    p,
    span {
      margin-top: 0;
      line-height: 22px;
    }
  `
)
