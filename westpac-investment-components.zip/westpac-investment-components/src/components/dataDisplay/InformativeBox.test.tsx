import React, { useState } from 'react'
import InformativeBox from './InformativeBox'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { IStep, IQuestion } from '../navigation/IQuestionnaire'

const question = {
  id: '',
  type: 'text',
  title: '',
  information: { body: ['Info 1'] },
} as IQuestion

const BasicExample = () => {
  const [step, setStep] = useState<IStep>({
    type: 'question',
    question,
  })
  return (
    <InvestToolsProvider>
      <button
        onClick={() =>
          setStep({
            type: 'question',
            question: { ...question, information: { body: ['Info 2'] } },
          })
        }
      >
        Next Question
      </button>
      <InformativeBox paddingTop={0} step={step} />
    </InvestToolsProvider>
  )
}

describe('<InformativeBox/>', () => {
  it('should render without crashing', () => {
    const { getByText } = render(<BasicExample />)
    expect(getByText('Info 1')).toBeInTheDocument()

    fireEvent.click(getByText('Next Question'))
    expect(getByText('Info 2')).toBeInTheDocument()
  })
})
