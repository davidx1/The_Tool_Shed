import React from 'react'

import ListDisc from './ListDisc'

export default {
  title: 'Data Display/ListDisc',
  component: ListDisc,
}

export const Basic = () => <ListDisc color="inherit" />
