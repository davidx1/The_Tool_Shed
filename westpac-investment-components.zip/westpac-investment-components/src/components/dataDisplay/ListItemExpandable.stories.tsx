import React from 'react'

import ListItemExpandable from './ListItemExpandable'

export default {
  title: 'Data Display/ListItemExpandable',
  component: ListItemExpandable,
}

export const Basic = () => (
  <ListItemExpandable title="Title">
    <p>Content</p>
  </ListItemExpandable>
)
