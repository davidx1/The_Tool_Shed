import React from 'react'
import ComparisonCollapse from './ComparisonCollapse'
import { IColumnProps } from './ComparisonBase'
import LinkButton from '../inputs/LinkButton'
import styled from 'styled-components'

export default {
  title: '🔸 Internal/Data Display/ComparisonCollapse',
  component: ComparisonCollapse,
}

export const FundComparison = () => {
  const getItemIndicatorColor = (type?: string) =>
    type === 'cash' ? '#ff0000' : '#000000'
  const recommendationType = 'cash'

  const comparisonColumns: IColumnProps<'description' | 'total'>[] = [
    {
      title: 'Description',
      dataField: 'description',
    },
    {
      title: 'Total',
      dataField: 'total',
      renderColumnValue: (value: number) => <strong>{value}%</strong>,
    },
  ]

  const funds = [
    {
      type: 'cash',
      title: 'Title',
      description: 'description',
      total: 100,
    },
    {
      type: 'cash2',
      title: 'Title2',
      description: 'description2',
      total: 44,
    },
  ]
  return (
    <ComparisonCollapse
      actionButtonRender={(item) => (
        <ActionButton
          onClick={() => {
            console.log(item)
          }}
        >
          Action Button
        </ActionButton>
      )}
      comparisonData={funds}
      getItemIndicatorColor={getItemIndicatorColor}
      recommendationType={recommendationType}
      columns={comparisonColumns}
      rowTitleField="title"
    />
  )
}

const ActionButton = styled(LinkButton)`
  font-size: ${({theme}) => theme.typography.pxToRem(16)}
`
