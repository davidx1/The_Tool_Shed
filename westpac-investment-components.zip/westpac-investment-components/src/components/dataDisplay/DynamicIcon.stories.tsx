import React from 'react'

import DynamicIcon, { icons, AllIconsType } from './DynamicIcon'
import { Grid } from '@material-ui/core'

export default {
  title: 'Data Display/DynamicIcon',
  component: DynamicIcon,
}

export const Basic = () => <DynamicIcon icon="cash" />

export const AllIcons = () => (
  <Grid direction="row" container alignItems="center" spacing={6}>
    {Object.keys(icons).map((icon) => (
      <Grid item key={icon} style={{ textAlign: 'center' }}>
        <DynamicIcon icon={icon as AllIconsType} />
        <p>{icon}</p>
      </Grid>
    ))}
  </Grid>
)

export const Empty = () => <DynamicIcon icon={null} />
