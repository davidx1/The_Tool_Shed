import React from 'react'

import { TypographyDoc as Typography } from './Typography'

export default {
  title: 'Data Display/Typography',
  component: Typography,
}

export const Basic = () => {
  return (
    <div>
      <Typography variant="h1">h1. Heading</Typography>
      <Typography variant="h2">h2. Heading</Typography>
      <Typography variant="h3">h3. Heading</Typography>
      <Typography variant="h4">h4. Heading</Typography>
      <Typography variant="h5">h5. Heading</Typography>
      <Typography variant="h6">h6. Heading</Typography>
      <Typography variant="subtitle1">
        subtitle1. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Quos blanditiis tenetur
      </Typography>
      <Typography variant="subtitle2">
        subtitle2. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Quos blanditiis tenetur
      </Typography>
      <Typography>
        default. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur
      </Typography>
      <hr />
      <Typography variant="h1">Colors</Typography>
      <Typography variant="h2" color="primary">
        Primary
      </Typography>
      <Typography variant="h2" color="secondary">
        Secondary
      </Typography>
      <Typography variant="h2" color="textSecondary">
        Text secondary
      </Typography>
    </div>
  )
}
