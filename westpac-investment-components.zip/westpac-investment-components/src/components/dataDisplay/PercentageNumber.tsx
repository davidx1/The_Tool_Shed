import React from 'react'
import styled, { StyledProps, css } from 'styled-components'
import { Typography, Box } from '@material-ui/core'

interface SymbolProps {
  colorSymbols?: string
}

export interface Props extends SymbolProps {
  value: string
  suffix?: string
  decorator?: string
}

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: row;
  align-items: center;
`

const StyledContainerSymbols = styled(({ colorSymbols, ...props }) => (
  <Box {...props} />
))(
  ({ theme, colorSymbols }: StyledProps<SymbolProps>) => css`
    display: flex;
    flex-direction: column;
    padding-left: ${theme.typography.pxToRem(9)};
    color: ${colorSymbols || theme.palette.text.primary};
  `
)

const Decorator = styled(Typography)(
  ({ theme }) => css`
    font-weight: ${theme.typography.fontWeightMedium};
    font-size: ${theme.typography.pxToRem(16)};
    line-height: ${theme.typography.pxToRem(22)};
    color: ${theme.palette.primary.main};
  `
)

const StyledNumber = styled(Typography)(
  ({ theme }) => css`
    font-family: ${theme.typography.fontFamilySecondary};
    font-weight: ${theme.typography.fontWeightBold};
    font-style: normal;
    font-size: ${theme.typography.pxToRem(64)};
    line-height: ${theme.typography.pxToRem(38)};
    color: ${theme.palette.primary.main};
  `
)

const StyledPercent = styled(Typography)(
  ({ theme }) => css`
    font-family: ${theme.typography.fontFamily};
    font-weight: ${theme.typography.fontWeightBold};
    font-size: ${theme.typography.pxToRem(28)};
    line-height: ${theme.typography.pxToRem(32)};
  `
)

const StyledTime = styled(Typography)(
  ({ theme }) => css`
    font-family: ${theme.typography.fontFamily};
    font-weight: ${theme.typography.fontWeightBold};
    font-size: ${theme.typography.pxToRem(18)};
    line-height: ${theme.typography.pxToRem(25)};
  `
)

const PercentageNumber: React.FC<Props> = ({
  value,
  suffix,
  colorSymbols,
  decorator
}) => {
  return (
    <div>
      {decorator && <Decorator variant="body2">{decorator}</Decorator>}
      <StyledContainer>
        <StyledNumber>{value}</StyledNumber>
        <StyledContainerSymbols colorSymbols={colorSymbols}>
          <StyledPercent>%</StyledPercent>
          {suffix && <StyledTime>{suffix}</StyledTime>}
        </StyledContainerSymbols>
      </StyledContainer>
    </div>
  )
}
export default PercentageNumber
