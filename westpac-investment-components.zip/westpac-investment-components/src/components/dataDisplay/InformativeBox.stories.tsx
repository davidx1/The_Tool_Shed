import React from 'react'

import InformativeBox from './InformativeBox'

export default {
  title: '🔸 Internal/Data Display/InformativeBox',
  component: InformativeBox,
}

export const Basic = () => (
  <div style={{ height: 400 }}>
    <div style={{ maxWidth: '50%' }}>
      The informative box will be displayed on the right side when viewing on
      larger resolutions and in the bottom on mobile/tablet devices.
    </div>
    <InformativeBox
      paddingTop={0}
      step={{
        type: 'question',
        question: {
          id: 'Q1',
          type: 'text',
          label: 'bob',
          title: 'Question 1',
          inputOptions: {
            type: 'text'
          },
          information: {
            body: [
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.',
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.',
            ],
            icon: 'calendar',
            moreInfoUrl: 'https://',
            callUs: { url: 'tel:0800000000', label: '0800 000 000' },
          },
        },
      }}
    />
  </div>
)
