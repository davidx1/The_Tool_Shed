import React from 'react'

import PercentageNumber from './PercentageNumber'

export default {
  title: 'Data Display/PercentageNumber',
  component: PercentageNumber,
}

export const Basic = () => <PercentageNumber value="34" />
export const Suffix = () => <PercentageNumber value="34" suffix="p.a" />
export const Fraction = () => (
  <PercentageNumber value="34.666666" />
)
export const WithDecorator = () => <PercentageNumber value="34" decorator="Up to" />
