import React, { FC } from 'react'
import styled, { css, StyledProps } from 'styled-components'
import { indicatorDot } from '../../styles/sharedStyles'

export interface Props {
  bgColor?: string
}

const PillLabel = styled.div(
  ({ theme, bgColor }: StyledProps<Props>) => css`
    display: inline-flex;
    align-items: center;
    font-size: ${theme.typography.pxToRem(12)};
    font-weight: ${theme.typography.fontWeightMedium};
    background: ${theme.palette.background.paper};
    line-height: 1;
    padding: 0.4em 0.8em;
    border-radius: 10em;
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.15);

    &:before {
      ${indicatorDot}
      flex-grow: 1;
      background: ${bgColor || theme.palette.primary.dark};
    }
  `
)

const Pill: FC<Props> = ({ bgColor, children, ...other }) => {
  return (
    <PillLabel bgColor={bgColor} {...other}>
      {children}
    </PillLabel>
  )
}

export default Pill
