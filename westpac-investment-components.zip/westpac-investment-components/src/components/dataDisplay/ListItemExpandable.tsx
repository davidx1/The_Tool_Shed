import React, { useState, FC } from 'react'
import styled, { css } from 'styled-components'
import {
  Typography,
  ListItem,
  ListItemText,
  Collapse,
  Box,
} from '@material-ui/core'
import ExpandLess from '@material-ui/icons/ExpandLess'
import ExpandMore from '@material-ui/icons/ExpandMore'

const StyledContainer = styled(Box)(
  ({ theme }) => css`
    border-bottom: solid 1px ${theme.palette.text.primary};
  `
)

const StyledListItem = styled(ListItem)(
  ({ theme }) => css`
    padding-top: ${theme.spacing(2)}px;
    padding-bottom: ${theme.spacing(2)}px;
  `
)

const TypographyTitle = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(18)};
    font-weight: ${theme.typography.fontWeightBold};
    line-height: ${theme.typography.pxToRem(25)};
  `
)

export interface Props {
  title: string
}

const ProductChooserRecommendationDetailsListItem: FC<Props> = ({
  title,
  children,
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const handleClick = () => {
    setIsOpen(!isOpen)
  }
  return (
    <StyledContainer>
      <StyledListItem button onClick={handleClick}>
        <ListItemText
          disableTypography
          primary={<TypographyTitle>{title}</TypographyTitle>}
        />
        {isOpen ? (
          <ExpandLess color="secondary" />
        ) : (
            <ExpandMore color="secondary" />
          )}
      </StyledListItem>
      <Collapse in={isOpen} timeout="auto" unmountOnExit>
        {children}
      </Collapse>
    </StyledContainer>
  )
}

export default ProductChooserRecommendationDetailsListItem
