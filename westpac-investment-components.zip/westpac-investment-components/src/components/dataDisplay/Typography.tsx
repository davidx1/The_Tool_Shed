import React, { FC } from 'react'
import {
  Typography as TypographyBase,
  TypographyProps,
} from '@material-ui/core'

/**
 * Extends Material UI Typography component
 * https://material-ui.com/components/typography/
 */
export const TypographyDoc: FC<TypographyProps> = (props) => (
  <TypographyBase {...props} />
)

export default TypographyBase
