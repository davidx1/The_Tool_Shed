import React from 'react'
import Hidden from '@material-ui/core/Hidden'
import ComparisonCollapse from './ComparisonCollapse'
import ComparisonTable from './ComparisonTable'
import { IItemBase, IComparisonProps } from './ComparisonBase'

/**
 * Shows ComparisonCollapse for mobile and ComparisonTable for Desktop
 */
const Comparison = <
  Item extends IItemBase<Type>,
  Type,
  DataFields extends keyof Item
>({
  title,
  comparisonItemTitle,
  cellBodyAlignment,
  rowTitleWidth,
  ...props
}: IComparisonProps<Item, Type, DataFields>) => {
  return (
    <React.Fragment>
      <Hidden mdUp>
        <ComparisonCollapse {...props} />
      </Hidden>
      <Hidden smDown>
        <ComparisonTable
          title={title}
          comparisonItemTitle={comparisonItemTitle}
          cellBodyAlignment={cellBodyAlignment}
          rowTitleWidth={rowTitleWidth}
          {...props}
        />
      </Hidden>
    </React.Fragment>
  )
}

export default Comparison
