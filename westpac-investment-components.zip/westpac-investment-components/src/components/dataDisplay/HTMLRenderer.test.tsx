import React from 'react'
import HTMLRenderer, { HTMLRendererProps } from './HTMLRenderer'
import { render, fireEvent } from '@testing-library/react'

const mockOpen = jest.fn()
Object.defineProperty(global, 'open', {
  value: mockOpen,
  writable: true,
})

const setURL = (URL: string) => {
  Object.defineProperty(window.document, 'URL', {
    value: URL,
    writable: true,
  })
}

const setup = (props?: Partial<HTMLRendererProps>) =>
  render(
    <HTMLRenderer
      value="<a href='https://www.fakeurl.com'>Link example</a>"
      {...props}
    />
  )

let originalURL = window.document.URL
afterEach(() => {
  setURL(originalURL)
})

describe('<HTMLRenderer/>', () => {
  it('should render properly', () => {
    const { container } = setup()
    expect(container.firstChild).toMatchSnapshot()
  })

  it('should render removing malicious code "<img src=x onerror=alert(1)//>"', () => {
    const { container } = setup({ value: '<img src=x onerror=alert(1)//>' })
    expect(container.firstChild).toMatchSnapshot()
  })

  it('should call window.open if native device detected', () => {
    setURL('')
    const { getByText } = setup()

    fireEvent.click(getByText('Link example'))
    expect(mockOpen).toBeCalledWith('https://www.fakeurl.com', '_system')
  })

  it('should have default link behaviour if native device NOT detected', () => {
    setURL('http://localhost')
    mockOpen.mockClear()

    const { getByText } = setup()

    const link = getByText('Link example')
    expect(link).toHaveAttribute('href', 'https://www.fakeurl.com')
    expect(link).toHaveAttribute('target', '_blank')

    fireEvent.click(link)
    expect(mockOpen).not.toBeCalled()
  })

  it('should have called linkHandler', () => {
    const mockLinkHandler = jest.fn()
    const { getByText } = setup({ linkHandler: mockLinkHandler })

    const link = getByText('Link example')
    fireEvent.click(link)
    expect(mockLinkHandler.mock.calls[0][0].target).toBe(link)
  })
})
