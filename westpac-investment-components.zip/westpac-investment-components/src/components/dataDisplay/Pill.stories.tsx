import React from 'react'

import Pill from './Pill'

export default {
  title: 'Data Display/Pill',
  component: Pill,
}

export const Basic = () => (
  <>
    <Pill>Default Color</Pill>
    <Pill bgColor="#40BBC4">Other color</Pill>
  </>
)
