import styled, { css } from 'styled-components'
import React, { FC } from 'react'
import BasicButton, { Props } from './BasicButton'

const StyledButton = styled(BasicButton)(
  ({ theme, color }) => css`
    && {
      font-weight: ${theme.typography.fontWeightMedium};
      font-size: ${theme.typography.pxToRem(18)};
      line-height: ${theme.typography.pxToRem(40)};
      color: ${color === 'primary'
        ? theme.palette.text.primary
        : theme.palette.primary.contrastText};
      position: relative;
      &:after {
        content: '';
        position: absolute;
        height: 2px;
        width: 100%;
        background: ${color === 'primary'
          ? theme.palette.tertiary.main
          : theme.palette.primary.contrastText};
        left: 0;
        bottom: 2px;
      }
      &&:hover {
        color: ${color === 'primary'
          ? theme.palette.tertiary.main
          : theme.palette.primary.contrastText};
        opacity: ${color === 'primary' ? 1 : 0.7};
        background-color: transparent;
      }
      &&:focus {
        color: ${color === 'primary'
          ? theme.palette.tertiary.main
          : theme.palette.primary.contrastText};
        background-color: transparent;
      }
    }
  `
)

const UnderlineButton: FC<Props> = ({ children, ...props }) => {
  return (
    <StyledButton color="primary" {...props} disableTouchRipple focusRipple>
      {children}
    </StyledButton>
  )
}

export default UnderlineButton
