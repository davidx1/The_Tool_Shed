import React from 'react'
import styled from 'styled-components'
import {
  ButtonSemicircleLeft,
  ButtonSemicircleRight,
} from './ButtonSemicircleDirection'

export default {
  title: 'Inputs/Buttons/Button Semicircle Direction',
  component: ButtonSemicircleRight,
}

export const Basic = () => {
  return (
    <Wrapper>
      <ButtonSemicircleLeft onClick={() => console.log('left')} />
      <ButtonSemicircleRight onClick={() => console.log('right')} />
    </Wrapper>
  )
}

const Wrapper = styled.div`
  display: flex;
  justify-content: space-between;
`
