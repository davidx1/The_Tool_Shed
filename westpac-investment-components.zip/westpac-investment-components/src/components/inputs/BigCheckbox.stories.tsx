import React from 'react'

import BigCheckbox from './BigCheckbox'

export default {
  title: 'Inputs/BigCheckbox',
  component: BigCheckbox,
}

export const Basic = () => {
  return (
    <div>
      <BigCheckbox
        label="Label"
        description="Description"
        checkboxProps={{ checked: true }}
      />
      <BigCheckbox label="Label" description="Description" content="content" />
    </div>
  )
}
