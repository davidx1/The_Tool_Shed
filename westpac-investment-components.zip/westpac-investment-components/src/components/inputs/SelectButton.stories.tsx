import React from 'react'

import SelectButton from './SelectButton'
import { Grid } from '@material-ui/core'

export default {
  title: 'Inputs/Buttons/SelectButton',
  component: SelectButton,
}

export const Basic = () => {
  return (
    <Grid container direction="row" spacing={4}>
      <Grid item>
        <SelectButton label="Normal" icon="dollarMore" />
      </Grid>
      <Grid item>
        <SelectButton label="Selected" icon="dollarMore" selected />
      </Grid>
    </Grid>
  )
}
