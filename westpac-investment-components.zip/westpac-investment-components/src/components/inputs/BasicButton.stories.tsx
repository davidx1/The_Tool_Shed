import React from 'react'

import BasicButton from './BasicButton'

export default {
  title: 'Inputs/Buttons/BasicButton',
  component: BasicButton,
}

export const Basic = () => {
  return <BasicButton>Button</BasicButton>
}
