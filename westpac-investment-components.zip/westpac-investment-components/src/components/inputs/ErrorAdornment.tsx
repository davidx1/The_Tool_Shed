import React from 'react'
import styled from 'styled-components'

const ErrorAdornment = styled((props) => (
  <svg width="23" height="25" viewBox="0 0 23 25" fill="none" {...props}>
    <circle cx="11.5" cy="12.5" r="11.5" fill="#D5002B" />
    <path
      d="M11.57 19.032C12.362 19.032 12.956 18.474 12.956 17.7C12.956 16.926 12.362 16.368 11.57 16.368C10.778 16.368 10.166 16.926 10.166 17.7C10.166 18.474 10.778 19.032 11.57 19.032ZM10.454 6L10.454 15.054L12.668 15.054L12.668 6L10.454 6Z"
      fill="white"
    />
  </svg>
))`
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto;
  right: ${({ theme }) => theme.spacing(2)}px;
  pointer-events: none;
`

export default React.memo(ErrorAdornment)
