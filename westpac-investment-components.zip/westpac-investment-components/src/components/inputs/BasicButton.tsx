import React from 'react'
import styled, { css } from 'styled-components'
import { ButtonProps, ButtonBase } from '@material-ui/core'
import { isNativeApp } from '../../utils/deviceUtils'

export interface Props extends ButtonProps {
  fontWeight?:
    | 'fontWeightLight'
    | 'fontWeightRegular'
    | 'fontWeightMedium'
    | 'fontWeightBold'
  target?: string
  rel?: string
}

const StyledBaseButton = styled(ButtonBase)<Props>(
  ({ fontWeight, theme }) => css`
    &&,
    &&:visited {
      color: ${theme.palette.text.primary};
      font-weight: ${theme.typography[fontWeight || 'fontWeightBold']};
    }
    &&:focus {
      color: ${theme.palette.text.primary};
    }
    && {
      font-size: ${theme.typography.pxToRem(16)};
      line-height: ${theme.typography.pxToRem(22)};
      text-decoration: none;
      &:hover {
        color: ${theme.palette.tertiary.main};
        background: inherit;
        svg path {
          fill: ${theme.palette.tertiary.main};
        }
      }
    }
  `
)

const BasicButton = (props: Props) => {
  const onClick = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    if (props.onClick) {
      event.persist()
      props.onClick(event)
    }
    // use target _system for any native apps
    if (isNativeApp() && props.target === '_blank') {
      event.preventDefault()
      window.open(props.href, '_system')
    }
  }

  return (
    <StyledBaseButton
      disableTouchRipple
      focusRipple
      {...props}
      onClick={onClick}
    />
  )
}

export default BasicButton
