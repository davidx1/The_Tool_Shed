import React from 'react'
import BasicButton, { Props } from './BasicButton'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'

const mockOpen = jest.fn()
Object.defineProperty(global, 'open', {
  value: mockOpen,
  writable: true,
})

const setURL = (URL: string) => {
  Object.defineProperty(window.document, 'URL', {
    value: URL,
    writable: true,
  })
}

const setup = (props?: Partial<Props>) =>
  render(
    <InvestToolsProvider>
      <BasicButton
        {...{ href: 'https://www.fakeurl.com', target: '_blank', ...props }}
      >
        Button label
      </BasicButton>
    </InvestToolsProvider>
  )

let originalURL = window.document.URL
afterEach(() => {
  setURL(originalURL)
})

describe('<BasicButton/>', () => {
  it('should render properly', () => {
    const { container } = setup()
    expect(container.firstChild).toMatchSnapshot()
  })

  it('should call window.open if native device detected', () => {
    setURL('')
    const { getByText } = setup()
    fireEvent.click(getByText('Button label'))
    expect(mockOpen).toBeCalledWith('https://www.fakeurl.com', '_system')
  })

  it('should have default link behaviour if native device NOT detected', () => {
    setURL('http://localhost')
    mockOpen.mockClear()
    const { getByText } = setup()
    const button = getByText('Button label')
    expect(button).toHaveAttribute('href', 'https://www.fakeurl.com')
    expect(button).toHaveAttribute('target', '_blank')
    fireEvent.click(button)
    expect(mockOpen).not.toBeCalled()
  })

  it('should have called onClick', () => {
    const mockOnClick = jest.fn()
    const { getByText } = setup({ onClick: mockOnClick })
    const button = getByText('Button label')
    fireEvent.click(button)
    expect(mockOnClick.mock.calls[0][0].target).toBe(button)
  })
})
