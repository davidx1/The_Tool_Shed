import styled from 'styled-components'
import React, { FC } from 'react'
import DynamicIcon from '../dataDisplay/DynamicIcon'
import BasicButton, { Props } from './BasicButton'

const StyledIcon = styled(DynamicIcon)`
  margin-left: 10px;
`

const ArrowButton: FC<Props> = ({ children, ...props }) => {
  return (
    <BasicButton {...props}>
      {children}
      <StyledIcon icon="arrowRight" />
    </BasicButton>
  )
}

export default ArrowButton
