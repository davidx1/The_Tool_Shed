import React from 'react'

import AnswerDropdownText from './AnswerDropdownText'
import { useState } from '@storybook/addons'
import { IQuestionDropdownText } from '../../navigation/IQuestionnaire'

export default {
  title: '🔸 Internal/Inputs/Answer/AnswerDropdownText',
  component: AnswerDropdownText,
}

export const Basic = () => {
  const [values, setValues] = useState<string[]>(['per year::'])
  const changeValueText = (index: number) => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
  ) => {
    const value = values[index] as string
    const dropdownValue = value.split('::')[0]
    setValues([`${dropdownValue}::${event.target.value}`])
  }

  const changeValueDropdown = (index: number) => (
    e: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
  ) => {
    const value = values[index] as string
    const textValue = value.split('::')[1]
    setValues([`${e.target.value}::${textValue}`])
  }

  const question: IQuestionDropdownText = {
    id: 'Q1',
    type: 'dropdownText',
    title: 'Question',
    dropdown: {
      label: 'Choose option',
      options: ['per week', 'per month', 'per year'],
    },
    text: {
      label: 'Enter income',
      inputOptions: {
        type: 'currency',
      },
      suffix: '(before tax)',
    },
    information: {
      body: [
        `This will help us give you a detailed projection, if unsure you can ask your employer(s).`,
      ],
      icon: 'moneyCoin',
    },
  }

  return (
    <div>
      <AnswerDropdownText
        question={question}
        values={values}
        index={0}
        size="large"
        changeValueTextInTextDropdown={changeValueText}
        changeValueDropdownInTextDropdown={changeValueDropdown}
        nextHandler={() => {}}
        isLastStep={false}
      />
    </div>
  )
}
