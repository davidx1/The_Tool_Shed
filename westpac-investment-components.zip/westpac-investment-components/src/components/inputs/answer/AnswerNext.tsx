import React, { FC } from 'react'
import { Button } from '@material-ui/core'

export interface Props {
  disabled?: boolean
  index: number
  nextHandler?: (index: number, e?: React.FormEvent<HTMLFormElement>) => void
  isLastStep?: boolean
}

const AnswerNext: FC<Props> = ({
  index,
  isLastStep,
  nextHandler,
  disabled,
}) => (
  <Button
    variant="contained"
    color="primary"
    type="submit"
    onClick={() => nextHandler && nextHandler(index)}
    disabled={disabled}
  >
    {isLastStep ? 'Get Your Results' : 'Next Question'}
  </Button>
)

export default AnswerNext
