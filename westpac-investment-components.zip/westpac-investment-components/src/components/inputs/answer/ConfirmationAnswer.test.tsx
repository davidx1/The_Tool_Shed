import React from 'react'
import {
  ACTION_BUTTON_CLOSE_VALUE,
  IQuestion,
} from '../../navigation/IQuestionnaire'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'
import ConfirmationAnswer from './ConfirmationAnswer'

const question: IQuestion = {
  id: 'questionId',
  title: 'Question',
  type: 'confirmationModal',
  confirmationModalOptions: {
    body: ['Confirmation text'],
    actionButtons: [
      {
        description: 'action description',
        value: 'call action',
      },
      {
        value: ACTION_BUTTON_CLOSE_VALUE,
        label: 'close',
      },
    ],
  },
}

describe('<ConfirmationAnswer/>', () => {
  it('should show confirmation answer and allow actions', async () => {
    const confirmStepMock = jest.fn()
    const closeToolHandler = jest.fn()
    const { getByText } = render(
      <InvestToolsProvider>
        <ConfirmationAnswer
          question={question}
          confirmStep={confirmStepMock}
          closeToolHandler={closeToolHandler}
        />
      </InvestToolsProvider>
    )

    expect(getByText('Confirmation text')).toBeInTheDocument()
    expect(getByText('action description')).toBeInTheDocument()

    expect(confirmStepMock).toBeCalledTimes(0)
    fireEvent.click(getByText('call action'))
    expect(confirmStepMock).toBeCalledWith('call action')

    expect(closeToolHandler).toBeCalledTimes(0)
    fireEvent.click(getByText('close'))
    expect(closeToolHandler).toBeCalled()
  })

  it('should not render if missing configuration', async () => {
    const { container } = render(
      <ConfirmationAnswer question={{} as IQuestion} confirmStep={() => {}} />
    )
    expect(container.firstChild).toBeNull()
  })
})
