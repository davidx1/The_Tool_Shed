import React from 'react'
import styled, { css } from 'styled-components'
import { Typography, Box, Button } from '@material-ui/core'
import {
  IQuestionConfirmationModal,
  ACTION_BUTTON_CLOSE_VALUE,
} from '../../navigation/IQuestionnaire'
import HTMLRenderer from '../../dataDisplay/HTMLRenderer'
import { urlCss } from '../../../styles/sharedStyles'

const StyledButton = styled(Button)`
  ${({ theme }) => css`
    margin-top: ${theme.spacing(3)}px;
    ${theme.breakpoints.down('xs')} {
      width: 100%;
    }
  `}
`

const Description = styled(Typography)`
  ${urlCss}
  ${({ theme }) => css`
    margin: ${theme.spacing(4, 0, 0)};
  `}
  &:first-child {
    margin: 0;
  }
`

export interface Props {
  question: IQuestionConfirmationModal
  confirmStep: (value: string) => void
  closeToolHandler?: () => void
}

/**
 * Used to display a confirmationModal question and allow the user to call a number or confirm the question
 */
const ConfirmationAnswer: React.FC<Props> = ({
  question,
  confirmStep,
  closeToolHandler,
}) => {
  if (!question.confirmationModalOptions) {
    return null
  }
  const makeConfirmStepHandler = (value: string) => () => {
    if (closeToolHandler && value === ACTION_BUTTON_CLOSE_VALUE) {
      return closeToolHandler()
    }
    return confirmStep(value)
  }
  return (
    <Box px={[2, 4]} pt={3} pb={[4, 5]}>
      {question.confirmationModalOptions.body?.map(
        (bodyItem, bodyItemIndex) => (
          <Description key={bodyItemIndex} variant="subtitle1">
            <HTMLRenderer value={bodyItem} />
          </Description>
        )
      )}
      {question.confirmationModalOptions.actionButtons?.map(
        (button, iButton) => {
          return (
            <React.Fragment key={iButton}>
              {button.description && (
                <Description variant="subtitle1">
                  <HTMLRenderer value={button.description} />
                </Description>
              )}
              <StyledButton
                color="primary"
                variant="contained"
                onClick={makeConfirmStepHandler(button.value)}
              >
                {button.label || button.value}
              </StyledButton>
            </React.Fragment>
          )
        }
      )}
    </Box>
  )
}

export default ConfirmationAnswer
