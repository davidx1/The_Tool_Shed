import { Box } from '@material-ui/core'
import React from 'react'
import { IQuestionDropdownText } from '../../navigation/IQuestionnaire'
import { AnswerSizes } from './Answer'
import AnswerDropdown from './AnswerDropdown'
import AnswerText from './AnswerText'

export interface Props {
  question: IQuestionDropdownText
  values: (string | number)[]
  valueOverride?: string | number
  index: number
  size?: AnswerSizes
  changeValueTextInTextDropdown: (
    index: number
  ) => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
  ) => void
  changeValueDropdownInTextDropdown: (
    index: number
  ) => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>,
    child: React.ReactNode
  ) => void
  nextHandler: (index: number, e?: React.FormEvent<HTMLFormElement>) => void
  isLastStep: boolean
}

const AnswerDropdownText = ({
  question,
  values,
  index,
  size,
  changeValueTextInTextDropdown,
  changeValueDropdownInTextDropdown,
  nextHandler,
  isLastStep,
}: Props) => {
  const textQuestion = {
    id: question.id,
    type: 'text' as const,
    title: question.title,
    ...question.text,
    information: question.information,
  }

  const dropdownQuestion = {
    id: question.id,
    type: 'dropdown' as const,
    title: question.title,
    ...question.dropdown,
    information: question.information,
  }

  const value = values[index] as string
  const [dropdownValue, textValue] = value.split('::')
  return (
    <React.Fragment>
      <Box mb={3} display="inline">
        <AnswerDropdown
          index={index}
          values={[]}
          changeValueDropdown={changeValueDropdownInTextDropdown}
          size={size}
          question={dropdownQuestion}
          valueOverride={dropdownValue}
        />
      </Box>
      <Box>
        <AnswerText
          index={index}
          values={[]}
          changeValueText={changeValueTextInTextDropdown}
          nextHandler={nextHandler}
          isLastStep={isLastStep}
          question={textQuestion}
          valueOverride={textValue}
        />
      </Box>
    </React.Fragment>
  )
}

export default AnswerDropdownText
