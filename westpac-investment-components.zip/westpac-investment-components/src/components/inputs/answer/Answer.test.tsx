import React from 'react'
import { shallow } from 'enzyme'
import toJson from 'enzyme-to-json'
import Answer, { Props } from './Answer'
import AnswerRadioGroup from './AnswerRadioGroup'
import AnswerDropdown from './AnswerDropdown'
import { IQuestionTypes } from '../../navigation/IQuestionnaire'
import { mountWithProvider } from '../../../setupTests'
import AnswerNext from './AnswerNext'
import AnswerText from './AnswerText'

const testProps = (type: IQuestionTypes = 'text'): Props => ({
  changeValue: jest.fn(),
  moveToNextStep: jest.fn(),
  values: ['test'],
  index: 0,
  isLastStep: false,
  question: {
    id: '',
    type,
    title: '',
  },
})

describe('Answer', () => {
  it('should render without crashing', () => {
    const wrapper = shallow(<Answer {...testProps()} />)
    expect(toJson(wrapper)).toMatchSnapshot()
  })

  it('should display a AnswerText and call the move to next step action', () => {
    const props = testProps()
    const wrapper = mountWithProvider(<Answer {...props} />)
    const answerText = wrapper.find(AnswerText)
    expect(answerText.length).toBe(1)

    wrapper.find(AnswerNext).find('button').simulate('submit')
    expect(props.moveToNextStep).toBeCalled()
  })

  it('should display a AnswerRadioGroup when the answer exect a radioGroup', () => {
    const wrapper = shallow(<Answer {...testProps('radioGroup')} />)
    const answerRadioGroup = wrapper.find(AnswerRadioGroup)
    expect(answerRadioGroup.length).toBe(1)
  })

  it('should display a AnswerDropdown when the answer exect a dropdown', () => {
    const wrapper = shallow(<Answer {...testProps('dropdown')} />)
    const answerDropdown = wrapper.find(AnswerDropdown)
    expect(answerDropdown.length).toBe(1)
  })
})
