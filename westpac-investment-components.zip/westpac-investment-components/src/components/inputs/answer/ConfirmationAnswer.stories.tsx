import React from 'react'
import { ACTION_BUTTON_CLOSE_VALUE } from '../../navigation/IQuestionnaire'

import ConfirmationAnswer from './ConfirmationAnswer'

export default {
  title: 'Inputs/Answer/ConfirmationAnswer',
  component: ConfirmationAnswer,
}

export const Basic = () => {
  return (
    <ConfirmationAnswer
      question={{
        id: 'questionId',
        title: 'Question',
        type: 'confirmationModal',
        confirmationModalOptions: {
          body: [
            'Because you’re nearing an age where you can withdraw your funds for retirement, we recommend talking to one of our financial advisers. They can talk to you about your plans and help you manage your KiwiSaver savings in the way that’s best for you.',
            'Disclosure statements under the Financial Advisers Act are available free of charge on request from Westpac or your Westpac financial adviser <a href="tel:0800173222">088 111 777</a>.',
          ],
          actionButtons: [
            {
              description:
                'No thanks, I don’t want personalised financial advice. I want to continue and I understand the recommendation I get won’t take into account how long I want my money to last in retirement.',
              value: 'I want to continue',
            },
            {
              value: ACTION_BUTTON_CLOSE_VALUE,
              label: 'close',
            },
          ],
        },
      }}
      confirmStep={() => {}}
      closeToolHandler={() => {}}
    />
  )
}
