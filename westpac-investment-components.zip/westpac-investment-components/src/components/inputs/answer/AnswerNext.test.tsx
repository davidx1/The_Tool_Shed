import React from 'react'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'

import AnswerNext from './AnswerNext'

describe('<AnswerNext/>', () => {
  it('should call next handler function', async () => {
    const nextHandler = jest.fn()
    const { getByText } = render(
      <InvestToolsProvider>
        <AnswerNext index={0} nextHandler={nextHandler} />
      </InvestToolsProvider>
    )
    fireEvent.click(getByText('Next Question'))

    expect(nextHandler).toBeCalled()
  })
})
