import React, { useState } from 'react'
import AnswerText from './AnswerText'
import { IQuestion } from '../../navigation/IQuestionnaire'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'

const nextHandlerMock = jest.fn()

const Sample = () => {
  const [values, setValues] = useState<string[]>([])
  const changeValueText = () => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
  ) => {
    setValues([event.target.value as string])
  }

  const nextHandler = (index: number, e?: React.FormEvent<HTMLFormElement>) => {
    e?.preventDefault()
    nextHandlerMock(index, e)
  }

  const question: IQuestion = {
    id: 'Q1',
    type: 'dropdown',
    title: 'Question',
    options: ['Option 1', 'Option 2', 'Option 3'],
    icons: ['calendar'],
    inputOptions: {
      type: 'number',
      min: 0,
      max: 99,
    },
    label: 'Placeholder',
  }

  return (
    <InvestToolsProvider>
      <AnswerText
        index={0}
        values={values}
        question={question}
        changeValueText={changeValueText}
        nextHandler={nextHandler}
        isLastStep={false}
      />
    </InvestToolsProvider>
  )
}

describe('<AnswerText/>', () => {
  it('should enable next button after valid input', async () => {
    const { getByLabelText, getByRole } = render(<Sample />)

    const nextQuestionButton = getByRole('button')
    expect(nextQuestionButton).toBeDisabled()

    const input = getByLabelText('Question') as HTMLInputElement
    fireEvent.change(input, { target: { value: '23' } })
    expect(input.value).toBe('23')
    expect(nextQuestionButton).toBeEnabled()

    fireEvent.click(nextQuestionButton)
    expect(nextHandlerMock).toBeCalled()
  })

  it('should not enable next button after invalid input', async () => {
    const { getByLabelText, getByRole } = render(<Sample />)

    const input = getByLabelText('Question') as HTMLInputElement
    const nextQuestionButton = getByRole('button')

    fireEvent.change(input, { target: { value: '-1' } })
    expect(nextQuestionButton).toBeDisabled()

    fireEvent.change(input, { target: { value: '100' } })
    expect(nextQuestionButton).toBeDisabled()

    fireEvent.change(input, { target: { value: '10' } })
    expect(nextQuestionButton).toBeEnabled()
  })
})
