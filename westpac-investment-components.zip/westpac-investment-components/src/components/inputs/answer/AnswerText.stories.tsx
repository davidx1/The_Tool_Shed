import React, { useState } from 'react'

import AnswerText from './AnswerText'
import { IQuestion } from '../../navigation/IQuestionnaire'

export default {
  title: '🔸 Internal/Inputs/Answer/AnswerText',
  component: AnswerText,
}

export const Basic = () => {
  const [values, setValues] = useState<string[]>([])
  const changeValueText = (index: number) => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValues = [...values.slice(0, index)]
    newValues[index] = e.target.value
    setValues(newValues)
  }

  const nextHandler = (index: number, e?: React.FormEvent<HTMLFormElement>) => {
    if (e) {
      e.preventDefault()
    }
    console.log(index)
  }

  const question: IQuestion = {
    id: 'Q1',
    type: 'text',
    title: 'Question',
    inputOptions: {
      type: 'number',
    },
    label: 'Placeholder',
  }

  return (
    <AnswerText
      index={1}
      values={values}
      question={question}
      changeValueText={changeValueText}
      nextHandler={nextHandler}
      isLastStep
    />
  )
}
