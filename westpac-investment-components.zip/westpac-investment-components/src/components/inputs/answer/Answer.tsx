import React, { useCallback } from 'react'

// Answer types
import AnswerText from './AnswerText'
import AnswerRadioGroup from './AnswerRadioGroup'
import AnswerDropdown from './AnswerDropdown'
import AnswerDropdownText from './AnswerDropdownText'

import { IQuestion } from '../../navigation/IQuestionnaire'

export type AnswerSizes = 'normal' | 'large'

export interface Props {
  changeValue: (
    index: number,
    value: number | string,
    submitValue: boolean
  ) => void
  moveToNextStep: (index: number) => void
  values: (string | number)[]
  index: number
  question: IQuestion
  isLastStep: boolean
  size?: AnswerSizes
}

const Answer: React.FC<Props> = ({
  changeValue,
  moveToNextStep,
  isLastStep,
  size,
  ...props
}) => {
  const changeValueText = useCallback(
    (index: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
      changeValue(index, e.target.value, false)
    },
    [changeValue]
  )

  const changeValueDropdown = useCallback(
    (index: number) => (
      event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
    ) => {
      changeValue(index, event.target.value as string | number, true)
    },
    [changeValue]
  )

  const changeValueRadioGroup = useCallback(
    (index: number, option: string | number) => () => {
      changeValue(index, option, true)
    },
    [changeValue]
  )

  const changeValueTextInTextDropdown = useCallback(
    (index: number) => (
      event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
    ) => {
      const value = props.values[index] as string
      const dropdownValue = value.split('::')[0]
      changeValue(index, `${dropdownValue}::${event.target.value}`, false)
    },
    [changeValue, props.values]
  )

  const changeValueDropdownInTextDropdown = useCallback(
    (index: number) => (
      e: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
    ) => {
      const value = props.values[index] as string
      const textValue = value.split('::')[1]
      changeValue(index, `${e.target.value}::${textValue}`, false)
    },
    [changeValue, props.values]
  )

  const nextHandler = useCallback(
    (index: number, e?: React.FormEvent<HTMLFormElement>) => {
      if (e) {
        e.preventDefault()
      }
      moveToNextStep(index)
    },
    [moveToNextStep]
  )
  switch (props.question.type) {
    case 'text':
      return (
        <AnswerText
          {...props}
          changeValueText={changeValueText}
          nextHandler={nextHandler}
          isLastStep={isLastStep}
          question={props.question}
        />
      )
    case 'dropdown':
      return (
        <AnswerDropdown
          {...props}
          changeValueDropdown={changeValueDropdown}
          size={size}
          question={props.question}
        />
      )
    case 'radioGroup':
      return (
        <AnswerRadioGroup
          {...props}
          changeValueRadioGroup={changeValueRadioGroup}
          size={size}
          question={props.question}
        />
      )
    case 'dropdownText':
      return (
        <AnswerDropdownText
          {...props}
          changeValueDropdownInTextDropdown={changeValueDropdownInTextDropdown}
          changeValueTextInTextDropdown={changeValueTextInTextDropdown}
          size={size}
          question={props.question}
          nextHandler={nextHandler}
          isLastStep={isLastStep}
        ></AnswerDropdownText>
      )
    default:
      return null
  }
}

export default React.memo(Answer)
