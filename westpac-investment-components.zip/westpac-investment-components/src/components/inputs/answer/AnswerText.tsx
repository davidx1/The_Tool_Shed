import React, { useState, useEffect, useRef, useCallback, FC } from 'react'
import styled, { css, CSSObject, StyledProps } from 'styled-components'
import { srOnly } from '../../../styles/sharedStyles'
import {
  Input,
  Box,
  InputBaseComponentProps,
  Typography,
} from '@material-ui/core'
import AnswerNext from './AnswerNext'
import { IQuestionText } from '../../navigation/IQuestionnaire'
import { getCurrencyString } from '../../../utils/projections-tools/getCurrencyString'

export interface Props {
  question: IQuestionText
  values: (string | number)[]
  valueOverride?: string | number
  index: number
  nextHandler: (index: number, e?: React.FormEvent<HTMLFormElement>) => void
  changeValueText: (
    index: number
  ) => (e: React.ChangeEvent<HTMLInputElement>) => void
  isLastStep: boolean
}

interface InputStyledProps {
  width?: number
}

const LabelStyled = styled.label`
  ${srOnly}
`

const InputStyled = styled(Input)(
  ({ width }: StyledProps<InputStyledProps>) => css`
    max-width: 340px;
    min-width: 0.6em;
    width: ${width ? `${width}px` : 'auto'};
    ${({ theme }) => ({
      ...(theme.typography.h2 as CSSObject),
    })}
  `
)

const Sizer = styled.div`
  display: inline-block;
  width: auto;
  white-space: nowrap;
  position: absolute;
  user-select: none;
  visibility: hidden;
  ${({ theme }) => ({
    ...(theme.typography.h2 as CSSObject),
  })}
`

const AnswerText: FC<Props> = ({
  question,
  values,
  valueOverride,
  index,
  nextHandler,
  changeValueText,
  isLastStep,
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null)
  const sizerRef = useRef<HTMLDivElement | null>(null)
  const [width, setWidth] = useState<number | undefined>()
  const isNumeric = question?.inputOptions?.type === 'number'
  const isCurrency = question?.inputOptions?.type === 'currency'
  const value = valueOverride || values[index]
  let disabled = !value
  let inputProps: InputBaseComponentProps = {
    id: `text-${question.id}`,
  }

  const handleInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const onChange = changeValueText(index)
      if (isCurrency) {
        e.target.value = e.target.value.replace(/[^0-9]/g, '')
      }
      onChange(e)
    },
    [index, changeValueText, isCurrency]
  )

  const formatValue = useCallback(
    (value: string | number) => {
      return value === null || value === undefined
        ? ''
        : isCurrency
        ? getCurrencyString(value)
        : value
    },
    [isCurrency]
  )

  if (isNumeric) {
    inputProps = {
      ...inputProps,
      maxLength: 3,
      inputMode: 'numeric',
      pattern: '[0-9]*',
    }
  }

  if (isCurrency) {
    inputProps = {
      ...inputProps,
      maxLength: 15,
      inputMode: 'numeric',
    }
  }

  if (
    !inputRef.current?.validity?.valid ||
    (!disabled &&
      isNumeric &&
      ((value as number) < (question?.inputOptions?.min ?? -Infinity) ||
        (value as number) > (question?.inputOptions?.max ?? Infinity)))
  ) {
    disabled = true
  }

  useEffect(() => {
    const sizerWidth = sizerRef.current?.clientWidth
    setWidth(sizerWidth ? sizerWidth + 2 : 0)
  }, [index, values])

  const valueToDisplay = formatValue(value)

  return (
    <form onSubmit={(e) => nextHandler(index, e)}>
      <Box mb={4}>
        <LabelStyled htmlFor={`text-${question.id}`}>
          {question.title || question.label}
        </LabelStyled>
        <Sizer ref={sizerRef}>{valueToDisplay || question.label}</Sizer>
        <InputStyled
          value={valueToDisplay}
          onChange={handleInput}
          placeholder={question.label}
          autoComplete="off"
          type="text"
          inputRef={inputRef}
          inputProps={inputProps}
          width={width}
        />
        {question.suffix && <Suffix>{question.suffix}</Suffix>}
      </Box>
      <AnswerNext disabled={disabled} index={index} isLastStep={isLastStep} />
    </form>
  )
}

export default AnswerText

const Suffix = styled(Typography).attrs({
  variant: 'body1',
})`
  display: inline-block;
  margin-left: ${({ theme }) => theme.spacing(1)}px;
  font-weight: ${({ theme }) => theme.typography.fontWeightMedium};
`
