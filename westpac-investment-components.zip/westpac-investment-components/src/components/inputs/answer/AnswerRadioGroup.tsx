import React, { FC } from 'react'
import styled from 'styled-components'
import { Grid, RadioGroup, FormControlLabel, Radio } from '@material-ui/core'
import SelectButton from '../SelectButton'
import { IQuestionRadio } from '../../navigation/IQuestionnaire'
import { AnswerSizes } from './Answer'

import RadioChecked from '../../../icons/RadioChecked'
import RadioUnchecked from '../../../icons/RadioUnchecked'

export interface Props {
  question: IQuestionRadio
  values: (string | number)[]
  index: number
  size?: AnswerSizes
  changeValueRadioGroup: (index: number, option: string | number) => () => void
}

const StyledGridContainer = styled(Grid)(
  ({ theme }) => `
    width: calc(100% + ${theme.spacing(2)}px);
    margin: 20px -${theme.spacing(1)}px 0;
    ${theme.breakpoints.up('sm')} {
      margin: 20px -${theme.spacing(3) / 2}px 0;
    }
  `
)

const StyledRadio = styled((props) => (
  <Radio icon={<RadioUnchecked />} checkedIcon={<RadioChecked />} {...props} />
))`
  margin-right: ${({ theme }) => theme.spacing(1)}px;
`

const SelectButtonItem = styled(SelectButton)(
  ({ theme }) => `
    flex-grow: 0;
    margin: ${theme.spacing(1)}px;
    max-width: calc(50% - ${theme.spacing(2)}px);
    flex-basis: calc(50% - ${theme.spacing(3)}px);

    /* Two buttons plus spacing and container padding */
    @media (min-width: ${200 * 2 + theme.spacing(8)}px) {
      max-width: 200px;
    }

    ${theme.breakpoints.up('sm')} {
      margin: ${theme.spacing(3) / 2}px;
    }
  `
)

const AnswerRadioGroup: FC<Props> = ({
  question,
  values,
  index,
  changeValueRadioGroup,
  size = 'normal',
}) => {
  if (!question.options) {
    return null
  }

  return size === 'normal' ? (
    <RadioGroup
      aria-label={question.label || question.title}
      value={values[index] || ''}
    >
      {question.options.map((option) => (
        <FormControlLabel
          key={option}
          name={option as string}
          value={option}
          control={<StyledRadio />}
          label={option as string}
          onChange={changeValueRadioGroup(index, option)}
        />
      ))}
    </RadioGroup>
  ) : (
    <StyledGridContainer
      container
      role="radioGroup"
      aria-label={question.label || question.title}
    >
      {question.options.map((option, iOption) => (
        <SelectButtonItem
          key={option}
          variant="outlined"
          onClick={changeValueRadioGroup(index, option)}
          selected={option === values[index]}
          aria-checked={option === values[index]}
          role="radio"
          size="large"
          icon={question.icons ? question.icons[iOption] : null}
          label={option as string}
          fullWidth
        />
      ))}
    </StyledGridContainer>
  )
}

export default AnswerRadioGroup
