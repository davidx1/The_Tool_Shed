import React, { FC } from 'react'
import styled, { css, CSSObject, StyledProps } from 'styled-components'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import { IQuestionDropdown } from '../../navigation/IQuestionnaire'
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  MenuProps,
  SelectProps,
} from '@material-ui/core'
import { AnswerSizes } from './Answer'
import DynamicIcon from '../../dataDisplay/DynamicIcon'
import { inputFocus } from '../../../styles/sharedStyles'

export interface Props {
  question: IQuestionDropdown
  values: (string | number)[]
  valueOverride?: string | number
  index: number
  size?: AnswerSizes
  changeValueDropdown: (
    index: number
  ) => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>,
    child: React.ReactNode
  ) => void
}

interface SelectExtraProps extends SelectProps {
  size?: AnswerSizes
}

const SelectStyled = styled(({ size, ...props }: SelectExtraProps) => (
  <Select {...props} />
))(
  ({ size, theme, value }: StyledProps<SelectExtraProps>) => css`
    && {
      margin-top: 0px;
    }
    ${size === 'large'
      ? css`
          .MuiSelect-icon {
            margin-top: 6px;
            ${theme.breakpoints.up('sm')} {
              margin-top: 10px;
            }
          }
          .MuiSelect-select {
            white-space: normal;
            padding-right: 40px;
            padding-top: 0;
            color: ${theme.palette.primary.main};
            opacity: ${value ? 1 : 0.5};
            ${{ ...(theme.typography.h2 as CSSObject) }}
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 3;
            max-height: 120px;
            ${theme.breakpoints.up('sm')} {
              -webkit-line-clamp: 2;
              max-height: 110px;
            }
          }
        `
      : css`
          .MuiSelect-icon {
            margin-right: 7px;
            color: ${theme.palette.secondary.main};
          }
          .MuiSelect-select {
            white-space: normal;
            color: ${theme.palette.text.primary};
            background: ${theme.palette.background.paper};
            border: 1px solid ${theme.palette.highlight.secondary};
            border-radius: 3px;
            ${inputFocus}
          }
        `}
  `
)

const MenuItemStyled = styled(MenuItem)(
  ({ theme }) => css`
    white-space: normal;
    line-height: ${theme.typography.pxToRem(26)};
    padding: ${theme.spacing(2)}px;
  `
)

const FormControlStyled = styled(FormControl)`
  max-width: 100%;
  label[hidden] {
    display: none;
  }
`

const menuProps: Partial<MenuProps> = {
  anchorOrigin: {
    vertical: 'bottom',
    horizontal: 'left',
  },
  transformOrigin: {
    vertical: 'top',
    horizontal: 'left',
  },
  getContentAnchorEl: null,
  PaperProps: {
    style: {
      maxHeight: 280,
      maxWidth: 240,
    },
  },
}

const AnswerDropdown: FC<Props> = ({
  question,
  values,
  valueOverride,
  index,
  size = 'normal',
  changeValueDropdown,
}) => {
  const normalSize = size === 'normal'

  return (
    <FormControlStyled fullWidth={normalSize}>
      <InputLabel id={`dropdown-${question.id}`} hidden>
        {question.label}
      </InputLabel>
      <SelectStyled
        labelId={`dropdown-${question.id}`}
        value={valueOverride || values[index] || ''}
        onChange={changeValueDropdown(index)}
        renderValue={(value) => (value as string) || question.label}
        MenuProps={menuProps}
        displayEmpty
        IconComponent={(props) =>
          normalSize ? (
            <ExpandMoreIcon {...props} />
          ) : (
            <DynamicIcon icon="arrowDown" {...props} />
          )
        }
        disableUnderline={normalSize}
        size={size}
      >
        {question.options &&
          question.options.map((option, iOption) => (
            <MenuItemStyled value={option} key={iOption}>
              {option}
            </MenuItemStyled>
          ))}
      </SelectStyled>
    </FormControlStyled>
  )
}

export default AnswerDropdown
