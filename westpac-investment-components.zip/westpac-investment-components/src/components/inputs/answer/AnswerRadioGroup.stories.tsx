import React from 'react'

import AnswerRadioGroup from './AnswerRadioGroup'
import { useState } from '@storybook/addons'
import { IQuestion } from '../../navigation/IQuestionnaire'

export default {
  title: '🔸 Internal/Inputs/Answer/AnswerRadioGroup',
  component: AnswerRadioGroup,
}

export const Basic = () => {
  const [values, setValues] = useState<string[]>(['Option 1'])
  const changeValueRadioGroup = (
    index: number,
    option: string | number
  ) => () => {
    const newValues = [...values.slice(0, index)]
    newValues[index] = option as string
    setValues(newValues)
  }

  const question: IQuestion = {
    id: 'Q1',
    type: 'radioGroup',
    title: 'Question',
    options: ['Option 1', 'Option 2', 'Option 3'],
    icons: ['calendar'],
  }

  return (
    <div>
      <AnswerRadioGroup
        changeValueRadioGroup={changeValueRadioGroup}
        values={values}
        index={0}
        question={question}
        size="normal"
      />
      <AnswerRadioGroup
        changeValueRadioGroup={changeValueRadioGroup}
        values={values}
        index={0}
        question={{ ...question, label: 'label' }}
        size="large"
      />
      <AnswerRadioGroup
        changeValueRadioGroup={changeValueRadioGroup}
        values={values}
        index={0}
        question={{ ...question, options: undefined }}
      />
    </div>
  )
}
