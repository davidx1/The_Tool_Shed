import React, { useState } from 'react'
import AnswerDropdown from './AnswerDropdown'
import { IQuestion } from '../../navigation/IQuestionnaire'
import { render, fireEvent, waitFor } from '@testing-library/react'
import { InvestToolsProvider } from '../../InvestToolsProvider'

const Sample = () => {
  const [values, setValues] = useState<string[]>([])
  const changeValueDropdown = () => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
  ) => {
    setValues([event.target.value as string])
  }

  const question: IQuestion = {
    id: 'Q1',
    type: 'dropdown',
    title: 'Question',
    options: ['Option 1', 'Option 2', 'Option 3'],
    label: 'Placeholder',
  }

  return (
    <InvestToolsProvider>
      <AnswerDropdown
        changeValueDropdown={changeValueDropdown}
        values={values}
        index={0}
        question={question}
        size="large"
      />
    </InvestToolsProvider>
  )
}

describe('<AnswerDropdown/>', () => {
  it('should show dropdown list and select option', async () => {
    const { getByText, getByRole } = render(<Sample />)

    const dropdownButton = getByRole('button')
    expect(dropdownButton).toHaveTextContent('Placeholder')

    fireEvent.mouseDown(dropdownButton)
    await waitFor(() => {
      expect(getByText('Option 1')).toBeInTheDocument()
    })

    fireEvent.click(getByText('Option 1'))

    await waitFor(() => {
      expect(dropdownButton).toHaveTextContent('Option 1')
    })
  })
})
