import React from 'react'

import AnswerNext from './AnswerNext'

export default {
  title: '🔸 Internal/Inputs/Answer/AnswerNext',
  component: AnswerNext,
}

export const Basic = () => {
  const nextHandler = () => {
    console.log('next')
  }
  return (
    <div>
      <AnswerNext index={0} disabled />
      <AnswerNext index={0} isLastStep nextHandler={nextHandler} />
    </div>
  )
}
