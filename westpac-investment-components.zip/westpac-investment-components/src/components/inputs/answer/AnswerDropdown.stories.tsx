import React from 'react'

import AnswerDropdown from './AnswerDropdown'
import { useState } from '@storybook/addons'
import { IQuestion } from '../../navigation/IQuestionnaire'

export default {
  title: '🔸 Internal/Inputs/Answer/AnswerDropdown',
  component: AnswerDropdown,
}

export const Basic = () => {
  const [values, setValues] = useState<string[]>([])
  const changeValueDropdown = (index: number) => (
    event: React.ChangeEvent<{ name?: string | undefined; value: unknown }>
  ) => {
    const newValues = [...values.slice(0, index)]
    newValues[index] = event.target.value as string
    setValues(newValues)
  }

  const question: IQuestion = {
    id: 'Q1',
    type: 'dropdown',
    title: 'Question',
    options: ['Option 1', 'Option 2', 'Option 3'],
    label: 'Placeholder',
  }

  return (
    <div>
      <AnswerDropdown
        changeValueDropdown={changeValueDropdown}
        values={values}
        index={0}
        question={question}
        size="normal"
      />
      <AnswerDropdown
        changeValueDropdown={changeValueDropdown}
        values={values}
        index={0}
        question={question}
        size="large"
      />
    </div>
  )
}
