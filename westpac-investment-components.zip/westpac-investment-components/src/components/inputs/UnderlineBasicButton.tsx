import styled, { css } from 'styled-components'
import BasicButton from './BasicButton'

const UnderlineBasicButton = styled(BasicButton)`
  ${({ theme }) => css`
    && {
      color: ${theme.palette.text.primary};
      text-decoration: underline;
      text-underline-position: under;
    }
    &:hover {
      background-color: transparent;
    }
    &:focus {
      background-color: transparent;
    }
  `}
`

export default UnderlineBasicButton
