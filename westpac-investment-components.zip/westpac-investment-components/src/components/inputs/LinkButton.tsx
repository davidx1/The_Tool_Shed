import styled, { css } from 'styled-components'
import React, { FC } from 'react'
import { ButtonProps, ButtonBase } from '@material-ui/core'

const StyledButton = styled(ButtonBase)(
  ({ theme }) => css`
    font-weight: ${theme.typography.fontWeightMedium};
    line-height: ${theme.typography.pxToRem(20)};
    color: ${theme.palette.text.primary};
    text-decoration: underline;
    text-align: inherit;
    vertical-align: baseline;
    font-size: inherit;
    &:hover {
      color: ${theme.palette.tertiary.main};
      background-color: transparent;
    }
    &:focus:not(:hover) {
      color: ${theme.palette.text.primary};
      background-color: transparent;
    }
  `
)

const LinkButton: FC<ButtonProps> = ({ children, ...props }) => {
  return (
    <StyledButton {...props} disableTouchRipple focusRipple>
      {children}
    </StyledButton>
  )
}

export default LinkButton
