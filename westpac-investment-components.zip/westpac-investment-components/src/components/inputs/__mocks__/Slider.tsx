import React from 'react'
import { SliderProps } from '@material-ui/core/Slider'

const Slider: React.FunctionComponent<SliderProps> = (props) => {
  const { onChangeCommitted, onChange, value } = props

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(e, Number(e.target.value))
    }
  }

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    if (onChangeCommitted) {
      onChangeCommitted(e, value || 0)
    }
  }

  return (
    <input
      data-testid="slider-input"
      onChange={handleChange}
      onBlur={handleBlur}
    />
  )
}

export default Slider
