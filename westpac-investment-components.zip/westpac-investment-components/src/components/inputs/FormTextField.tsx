import React, { FC } from 'react'
import styled from 'styled-components'

import {
  InputLabel,
  InputBase,
  FormHelperText,
  FormControl,
  InputBaseProps,
} from '@material-ui/core'

import { createStyles, fade, Theme, withStyles } from '@material-ui/core/styles'
import ErrorAdornment from './ErrorAdornment'

const StyledInput = withStyles((theme: Theme) =>
  createStyles({
    root: {
      'label + &': {
        marginTop: theme.spacing(4),
        fontWeight: theme.typography.fontWeightMedium,
        fontSize: theme.typography.pxToRem(18),
      },
    },
    input: {
      border: `1px solid ${theme.palette.text.secondary}`,
      fontSize: theme.typography.pxToRem(16),
      lineHeight: theme.typography.pxToRem(22),
      color: theme.palette.text.primary,
      padding: theme.spacing(2, 1),
      position: 'relative',
      borderRadius: 3,
      width: '100%',
      transition: theme.transitions.create(['border-color', 'box-shadow']),
      '&:focus': {
        boxShadow: `${fade(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
        borderColor: theme.palette.secondary.dark,
      },
    },
  })
)(InputBase)

const StyledInputLabel = styled(InputLabel)(
  ({ theme }) => `
  && {
    font-weight: ${theme.typography.fontWeightMedium};
    font-size: ${theme.typography.pxToRem(16)};
    color: ${theme.palette.text.primary};
    transform: none;
  }
  `
)

interface RequiredProps {
  name: string
  label: string
}

export type Props = InputBaseProps & RequiredProps

const FormTextField: FC<Props> = ({
  name,
  error,
  placeholder,
  label,
  ...props
}) => {
  // const [field, meta] = useField(name)
  const hasError = !!error
  const inputId = `input-${name}`

  return (
    <FormControl error={hasError} fullWidth>
      <StyledInputLabel shrink htmlFor={inputId}>
        {label}
      </StyledInputLabel>
      <StyledInput
        id={inputId}
        endAdornment={hasError ? <ErrorAdornment /> : undefined}
        fullWidth
        {...props}
      />
      {hasError && <FormHelperText>{placeholder}</FormHelperText>}
    </FormControl>
  )
}

export default FormTextField
