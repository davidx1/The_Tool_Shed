import React, { FC } from 'react'
import styled, { css, StyledProps } from 'styled-components'
import { Grid, Checkbox, CheckboxProps } from '@material-ui/core'

export interface Props {
  content?: React.ReactNode
  label: string | React.ReactNode
  description: string | React.ReactNode
  checkboxProps?: CheckboxProps
}

const StyledCheckbox = styled(Checkbox)(
  ({ theme }) => css`
    svg {
      width: ${theme.typography.pxToRem(32)};
      height: ${theme.typography.pxToRem(32)};
    }

    &.Mui-checked svg {
      fill: currentColor;
    }
  `
)

const LabelFund = styled((props) => <Grid component="label" {...props} />)(
  ({ theme, disabled }: StyledProps<{ disabled?: boolean }>) => `
    font-size: ${theme.typography.pxToRem(16)};
    padding: ${theme.spacing(1, 1, 0, 2)};
    position: relative;
    align-items: center;
    vertical-align: middle;
    cursor: ${disabled ? 'not-allowed' : 'pointer'};
  `
)

const LabelFundText = styled.span`
  font-weight: ${({ theme }) => theme.typography.fontWeightBold};
  order: -1;

  .Mui-disabled ~ & {
    opacity: 0.7;
  }
`

const BigCheckbox: FC<Props> = ({
  content,
  label,
  description,
  checkboxProps,
  children,
}) => {
  return (
    <Grid item container>
      <LabelFund item container disabled={checkboxProps?.disabled}>
        <Grid
          item
          container
          wrap="nowrap"
          alignItems="center"
          justify="space-between"
        >
          {children || <StyledCheckbox {...checkboxProps} color="primary" />}
          <LabelFundText>{label}</LabelFundText>
        </Grid>
        <Grid item xs={12}>
          {description}
        </Grid>
      </LabelFund>
      {content && (
        <Grid item container>
          {content}
        </Grid>
      )}
    </Grid>
  )
}

export default BigCheckbox
