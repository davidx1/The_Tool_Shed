import React from 'react'
import styled, { css } from 'styled-components'
import { IconButton, IconButtonProps } from '@material-ui/core'
import NavigateNextIcon from '@material-ui/icons/NavigateNext'
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore'

const baseButtonStyle = css`
  width: 28.5px;
  height: 46px;
  margin: auto;
  box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.3);
  z-index: 2;
  transition: transform 0.3s ease;
  border-radius: 50px;
  padding: 0px;
`

const StyledIconButtonLeft = styled(IconButton).attrs<IconButtonProps>({
  color: 'secondary',
})`
  ${baseButtonStyle}
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  padding-right: 8px;
`

const StyledIconButtonRight = styled(IconButton).attrs<IconButtonProps>({
  color: 'secondary',
})`
  ${baseButtonStyle}
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  padding-left: 8px;
`

export const ButtonSemicircleLeft = (props: IconButtonProps) => (
  <StyledIconButtonLeft {...props}>
    <NavigateBeforeIcon />
  </StyledIconButtonLeft>
)

export const ButtonSemicircleRight = (props: IconButtonProps) => (
  <StyledIconButtonRight {...props}>
    <NavigateNextIcon />
  </StyledIconButtonRight>
)
