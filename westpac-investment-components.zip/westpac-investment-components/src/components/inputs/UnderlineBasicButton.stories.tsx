import React from 'react'

import Underline from './UnderlineBasicButton'

export default {
  title: 'Inputs/Buttons/UnderlineBasicButton',
  component: Underline,
}

export const UnderlineBasicButton = () => {
  return <Underline>Button</Underline>
}
