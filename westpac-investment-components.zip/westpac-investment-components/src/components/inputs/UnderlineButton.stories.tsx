import React from 'react'

import UnderlineButton from './UnderlineButton'

export default {
  title: 'Inputs/Buttons/UnderlineButton',
  component: UnderlineButton,
}

export const Basic = () => {
  return (
    <>
      <UnderlineButton>Button</UnderlineButton>
      <span style={{ background: '#cacaca' }}>
        <UnderlineButton color="secondary">Secondary</UnderlineButton>
      </span>
    </>
  )
}
