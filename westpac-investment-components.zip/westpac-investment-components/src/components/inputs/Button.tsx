import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Button as ButtonBase, ButtonProps } from '@material-ui/core'

/**
 * Extends Material UI Button component
 * https://material-ui.com/api/button/
 */
const Button: FC<ButtonProps> = (props) => <ButtonBase {...props} />


export const SmallScreensButton = styled(Button)`
  ${({ theme }) => css`
    ${theme.breakpoints.down('xs')} {
      width: 100%;
      margin: 0 auto;
      display: block;
    }
  `}
`

export default Button
