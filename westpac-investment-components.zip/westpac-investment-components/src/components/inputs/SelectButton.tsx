import styled, { css, StyledProps } from 'styled-components'
import React, { FC } from 'react'
import { Button, ButtonProps, useMediaQuery, useTheme } from '@material-ui/core'
import DynamicIcon, { AllIconsType } from '../dataDisplay/DynamicIcon'
import { mobileLandscapeViewport } from '../../styles/theme'

interface SelectButtonStyleProps {
  selected?: boolean
}

export interface SelectButtonProps extends SelectButtonStyleProps, ButtonProps {
  label: string
  icon: AllIconsType | null
  customIconSize?: number
}

const hoverStyles = ({ theme }: StyledProps<SelectButtonStyleProps>) => css`
  border: 2px solid ${theme.palette.primary.main};
  background: transparent;
`

const StyledButton = styled(Button)(
  ({ theme }) => css`
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.15);
    border: 2px solid transparent;
    border-radius: 0;
    padding: ${theme.spacing(2)}px;
    font-size: ${theme.typography.pxToRem(16)};
    min-height: 165px;
    .MuiButton-label {
      flex-direction: column;
    }
    &:hover {
      ${hoverStyles}
    }
    &:focus {
      background-color: transparent
    }
    ${mobileLandscapeViewport} {
      min-height: 0;
    }
    ${({ selected }: StyledProps<SelectButtonStyleProps>) =>
      selected && hoverStyles}
  `
)

const StyledButtonText = styled.span`
  max-width: 100%;

  ${mobileLandscapeViewport} {
    margin-top: 0;
  }
`

const SelectButton: FC<SelectButtonProps> = ({
  label,
  icon,
  customIconSize,
  ...props
}) => {
  const theme = useTheme()
  const desktopDown = useMediaQuery(theme.breakpoints.down('md'))
  const defaultIconSize = desktopDown ? 60 : 80
  const iconSize = customIconSize || defaultIconSize
  return (
    <StyledButton {...props}>
      <DynamicIcon icon={icon} height={iconSize} width={iconSize} />
      <StyledButtonText>{label}</StyledButtonText>
    </StyledButton>
  )
}

export default SelectButton
