import React from 'react'

import ArrowButton from './ArrowButton'

export default {
  title: 'Inputs/Buttons/ArrowButton',
  component: ArrowButton,
}

export const Basic = () => {
  return <ArrowButton>Button</ArrowButton>
}
