import React from 'react'

import FormTextField from './FormTextField'

export default {
  title: 'Inputs/FormTextField',
  component: FormTextField,
}

export const Basic = () => (
  <FormTextField type="email" name="email" label="Email address" />
)

export const WithError = () => (
  <FormTextField
    name="anotherfield"
    label="Name"
    placeholder="Enter your name"
    error
  />
)
