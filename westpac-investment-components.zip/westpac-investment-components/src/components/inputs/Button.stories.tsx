import React from 'react'

import Button from './Button'

export default {
  title: 'Inputs/Buttons/Button',
  component: Button,
}

export const Basic = () => {
  return (
    <div>
      <h2>Contained</h2>
      <div>
        <Button variant="contained" color="primary">
          Primary
        </Button>
        <Button variant="contained" color="secondary">
          Secondary
        </Button>
      </div>
      <h2>Outlined</h2>
      <div>
        <Button variant="outlined" color="primary">
          Primary
        </Button>
      </div>
    </div>
  )
}
