import styled, { css } from 'styled-components'
import { Slider as MuiSlider } from '@material-ui/core'

const THUMB_RADIUS = 10
const TRACK_THICKNESS = 6

const StyledSlider = styled(MuiSlider)`
  ${({ theme }) => css`
    display: block;
    color: ${theme.palette.primary.main};
    height: 4px;
    padding: 10px 0;
    flex: 1;

    .MuiSlider-track {
      height: ${TRACK_THICKNESS}px;
      border-radius: ${TRACK_THICKNESS / 2}px;
    }
    .MuiSlider-rail {
      height: ${TRACK_THICKNESS}px;
      border-radius: ${TRACK_THICKNESS / 2}px;
      background-color: ${theme.palette.background.darkGrey};
    }
  `}
`

// Material UI Slider will pass a `style` object to the thumb component
// By default the thumb's anchor point is centered. Which means if the slider
// value is 0, the left half of the thumb would overflow from the track
// and if the value is 100, the right half of the thumb would over flow from the track
// SEE: https://material-ui.com/components/slider/#customized-sliders

// However, we don't want the thumb to over flow.
// So first we remove the margin-left that the thumb have by default
// Then we set the slider position to the current value, eg 50%, minutes the radius
// of the the thumb eg, 20px multiplied by the current percentage value.
// So when the value is 0, it's 0% - 0*10. So the thumb would be shown at position 0;
// When the value is 100, it's 100% - 1*20. So the thumb would be shown 20px short of 100%.
const StyledThumb = styled.span.attrs(({ style }) => {
  const left = typeof style?.left === 'string' ? style.left : '0%'
  return {
    style: {
      left: `calc(${left} - ${(parseFloat(left) * 2 * THUMB_RADIUS) / 100}px)`,
    },
  }
})`
  height: ${THUMB_RADIUS * 2}px;
  width: ${THUMB_RADIUS * 2}px;
  background-color: #fff;
  border: 2px solid ${({ theme }) => theme.palette.primary.main};
  margin-left: 0;
  margin-top: -${THUMB_RADIUS - TRACK_THICKNESS / 2}px;
  &:focus &:hover &:active {
    box-shadow: inherit;
  }
`

export default styled(StyledSlider).attrs({
  ThumbComponent: StyledThumb,
})``
