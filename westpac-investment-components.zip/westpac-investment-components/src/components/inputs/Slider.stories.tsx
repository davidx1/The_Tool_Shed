import React, { useState } from 'react'
import Slider from './Slider'

export default {
  title: 'Inputs/Slider',
  component: Slider,
}

export const Basic = () => {
  return <Slider />
}

export const SpecifyingSteps = () => {
  return <Slider min={0} max={30} step={2} />
}

export const ControlledSlider = () => {
  const [value, setValue] = useState(0)
  const handleChange = (_: unknown, newValue: number | number[]) => {
    const v = typeof newValue === 'number' ? newValue : 0
    setValue(v)
  }
  return (
    <div>
      <p>Controlled Value: {value}</p>
      <Slider
        defaultValue={0}
        value={value}
        onChange={handleChange}
        min={0}
        max={100}
        step={1}
      />
    </div>
  )
}

export const OnChangeVsOnChangeCommitted = () => {
  const [sliderValue, setSliderValue] = useState(0)
  const [committedValue, setCommitted] = useState(0)
  const handleChange = (_: unknown, newValue: number | number[]) => {
    const v = typeof newValue === 'number' ? newValue : 0
    setSliderValue(v)
  }
  const handleCommit = (_: unknown, newValue: number | number[]) => {
    const v = typeof newValue === 'number' ? newValue : 0
    setCommitted(v)
  }
  return (
    <div>
      <p>Slider Value: {sliderValue}</p>
      <p>Committed Value: {committedValue}</p>

      <Slider
        defaultValue={0}
        value={sliderValue}
        onChange={handleChange}
        onChangeCommitted={handleCommit}
        min={0}
        max={100}
        step={1}
      />
    </div>
  )
}
