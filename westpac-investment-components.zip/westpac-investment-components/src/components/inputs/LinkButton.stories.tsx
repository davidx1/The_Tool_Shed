import React from 'react'

import LinkButton from './LinkButton'

export default {
  title: 'Inputs/Buttons/LinkButton',
  component: LinkButton,
}

export const Basic = () => {
  return <LinkButton>Button</LinkButton>
}
