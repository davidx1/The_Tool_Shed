import React, { FC } from 'react'

import { ThemeProvider } from 'styled-components'

import ScopedCssBaseline from '@material-ui/core/ScopedCssBaseline'
import { StylesProvider, MuiThemeProvider } from '@material-ui/core/styles'
import theme from '../styles/theme'
import ErrorToastProvider from './error/ErrorToastProvider'

/**
 * Add InvestToolsProvider to the root of your component tree, or at the highest level
 * you wish to use the investment tools. This provider will enable the theme to be passed
 * to all components.
 */
export const InvestToolsProvider: FC = ({ children }) => {
  return (
    <MuiThemeProvider theme={theme}>
      <ThemeProvider theme={theme}>
        <StylesProvider injectFirst>
          <ErrorToastProvider>
            <ScopedCssBaseline>{children}</ScopedCssBaseline>
          </ErrorToastProvider>
        </StylesProvider>
      </ThemeProvider>
    </MuiThemeProvider>
  )
}
