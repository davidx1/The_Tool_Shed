import React from 'react'

export default React.memo((props: any) => (
  <svg
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    x="0px"
    y="0px"
    viewBox="0 0 1439 398"
    {...props}
  >
    <rect fill="#F7F7F7" width="1440" height="398" />
    <path
      fill="#F5F5F5"
      fillRule="evenodd"
      clipRule="evenodd"
      d="M1030.7,57.9l34.8,109.3l34.8-109.3c13.3-45.2,27.2-57.9,61.8-57.9L960.2,0C994.7,0,1017.4,12.8,1030.7,57.9z"
    />
    <path
      fill="#F7F7F7"
      fillRule="evenodd"
      clipRule="evenodd"
      d="M1031.1,58.1C1017.8,12.8,995.2,0,960.7,0H786l0.3,396.7l181.5,0.4c0,0,0.1,0,0.1,0h10.9
c13.3-2.4,27.8-42,27.8-42l59.3-187.3L1031.1,58.1z"
    />
    <path
      fill="#EEEEEE"
      fillRule="evenodd"
      clipRule="evenodd"
      d="M1100.6,58l-34.7,109.9l59.2,187.6c0,0,14.5,39.6,27.8,42h128.9V-0.2H1162C1127.6-0.2,1113.9,12.6,1100.6,58z"
    />
    <path
      fill="#F3F3F3"
      fillRule="evenodd"
      clipRule="evenodd"
      d="M1125.3,355.3l-59.4-188l-59.4,188c0,0-14.5,39.7-27.8,42.1h174.5C1139.9,395,1125.3,355.3,1125.3,355.3z"
    />
    <rect x="1272.7" fill="#EEEEEE" width="166.9" height="398" />
  </svg>
))
