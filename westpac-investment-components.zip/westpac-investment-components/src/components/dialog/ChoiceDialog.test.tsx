import React from 'react'
import ChoiceDialog from './ChoiceDialog'
import { render, fireEvent } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'

describe('ChoiceDialog', () => {
  it('should render without crashing', () => {
    const closeClickHandler = jest.fn()
    const leftButtonClickHandler = jest.fn()
    const rightButtonClickHandler = jest.fn()
    const { getByText, getByLabelText } = render(
      <InvestToolsProvider>
        <ChoiceDialog
          title="Dialog Title"
          open={true}
          onClose={closeClickHandler}
          leftButtonLabel="Left button"
          rightButtonLabel="Right button"
          leftButtonTitle="Left title"
          rightButtonTitle="Right title"
          onLeftButtonClick={leftButtonClickHandler}
          onRightButtonClick={rightButtonClickHandler}
        >
          Disclaimer Dialog
        </ChoiceDialog>
      </InvestToolsProvider>
    )
    expect(getByText('Dialog Title')).toBeInTheDocument()
    fireEvent.click(getByText('Left button'))
    expect(leftButtonClickHandler).toBeCalledTimes(1)
    fireEvent.click(getByText('Right button'))
    expect(rightButtonClickHandler).toBeCalledTimes(1)
    fireEvent.click(getByLabelText('Close'))
    expect(closeClickHandler).toBeCalledTimes(1)
  })
})
