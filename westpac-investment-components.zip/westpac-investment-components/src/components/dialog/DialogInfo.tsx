import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import Dialog from '@material-ui/core/Dialog'
import MuiDialogTitle from '@material-ui/core/DialogTitle'
import MuiDialogContent from '@material-ui/core/DialogContent'
import IconButton from '@material-ui/core/IconButton'
import CloseIcon from '@material-ui/icons/Close'
import Typography from '@material-ui/core/Typography'

export interface DialogInfoProps {
  children: React.ReactNode
  onClose: () => void
  open: boolean
  dialogOverline?: React.ReactNode
  dialogTitle?: string
  dialogUnderline?: React.ReactNode
  dialogClose?: string
  maxWidth?: false | 'md' | 'xs' | 'sm' | 'lg' | 'xl'
}

const DialogHeader = styled(MuiDialogTitle)(
  ({ theme }) => css`
    margin: 0;
    padding: ${theme.spacing(2)}px;
    display: flex;
    align-items: start;
    justify-content: space-between;
    background: #f7f7f7;
    ${theme.breakpoints.up('sm')} {
      padding: ${theme.spacing(3)}px ${theme.spacing(4)}px;
    }
  `
)

const DialogHeaderText = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: start;
  justify-content: space-between;
`

const TypographyTagline = styled((props) => (
  <Typography component="p" variant="h6" {...props} />
))`
  position: absolute;
  color: ${({ theme }) => theme.palette.secondary.light};
`

const TypographyTitle = styled((props) => (
  <Typography component="h1" variant="h2" {...props} />
))`
  width: 100%;
  margin-top: 28px;
`

const DialogContent = styled(MuiDialogContent)`
  padding: 0;
  &:first-child {
    padding-top: 0;
  }
`

const CloseButton = styled(IconButton)(
  ({ theme }) => css`
    && {
      border-radius: 50%;
      box-shadow: none;
      background: ${theme.palette.disabled.light};
      color: ${({ theme }) => theme.palette.text.primary};
    }
  `
)

const DialogInfo: FC<DialogInfoProps> = ({
  dialogOverline,
  dialogTitle,
  dialogUnderline,
  dialogClose = 'Close',
  maxWidth = 'md',
  onClose,
  open,
  children,
}) => {
  return (
    <Dialog
      maxWidth={maxWidth}
      fullWidth
      onClose={onClose}
      aria-labelledby={dialogTitle && 'dialog-title'}
      open={open}
    >
      {dialogTitle && (
        <DialogHeader disableTypography>
          <DialogHeaderText>
            {dialogOverline && (
              <TypographyTagline>{dialogOverline}</TypographyTagline>
            )}
            <TypographyTitle id="dialog-title" gutterBottom={!!dialogUnderline}>
              {dialogTitle}
            </TypographyTitle>
            {dialogUnderline}
          </DialogHeaderText>
          {onClose && (
            <CloseButton aria-label={dialogClose} onClick={onClose}>
              <CloseIcon />
            </CloseButton>
          )}
        </DialogHeader>
      )}
      <DialogContent>{children}</DialogContent>
    </Dialog>
  )
}

export default DialogInfo
