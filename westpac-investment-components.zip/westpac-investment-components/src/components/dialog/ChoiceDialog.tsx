import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Typography, Box, Button } from '@material-ui/core'
import DialogInfo from './DialogInfo'

export interface Props {
  open: boolean
  onClose: () => void
  title: string
  leftButtonTitle: string
  rightButtonTitle: string
  leftButtonLabel: string
  rightButtonLabel: string
  onLeftButtonClick: () => void
  onRightButtonClick: () => void
}

const TypographyInfo = styled((props) => (
  <Typography {...props} variant="body2" component="div" />
))`
  margin: 10px 0 20px;
`

const ButtonTitle = styled(Typography)(
  ({ theme }) => css`
    font-size: ${theme.typography.pxToRem(16)};
    line-height: ${theme.typography.pxToRem(22)};
    font-weight: ${theme.typography.fontWeightBold};
    margin-bottom: ${theme.spacing(2)}px;
  `
)

const ActionButtonsWrapper = styled.div(
  ({ theme }) => css`
    display: flex;
    align-items: center;
    justify-content: center;

    ${theme.breakpoints.down('xs')} {
      flex-direction: column;

      button {
        width: 100%;
      }
    }
  `
)

const ChoiceWrapper = styled.div`
  ${({ theme }) => css`
    width: 100%;
    text-align: center;
    display: flex;
    flex-direction: column;

    ${theme.breakpoints.up('sm')} {
      height: 115px;
    }
  `}
`

const HalfTallDiv = styled.div`
  height: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
`

const Divider = styled.div(
  ({ theme }) => css`
    height: 91px;
    width: 0px;
    margin: ${theme.spacing(0, 7)};
    border-left: 1px solid ${theme.palette.text.hint};

    ${theme.breakpoints.down('xs')} {
      width: 91px;
      height: 0px;
      margin: ${theme.spacing(3, 0)};
      border-left: none;
      border-top: 1px solid ${theme.palette.text.hint};
    }
  `
)

const ChoiceDialog: FC<Props> = ({
  open,
  title,
  onClose,
  children,
  leftButtonTitle,
  leftButtonLabel,
  onLeftButtonClick,
  onRightButtonClick,
  rightButtonLabel,
  rightButtonTitle,
}) => (
  <DialogInfo dialogTitle={title} onClose={onClose} open={open}>
    <Box bgcolor="background.paper" px={[2, 4]} pb={[4, 5]} pt={3}>
      {children && <TypographyInfo>{children}</TypographyInfo>}
      <Box mt={children ? [3, 5, 7] : [0]}>
        <ActionButtonsWrapper>
          <ChoiceWrapper>
            <HalfTallDiv>
              <ButtonTitle variant="h4">{leftButtonTitle}</ButtonTitle>
            </HalfTallDiv>
            <HalfTallDiv>
              <Button
                color="primary"
                variant="contained"
                onClick={onLeftButtonClick}
              >
                {leftButtonLabel}
              </Button>
            </HalfTallDiv>
          </ChoiceWrapper>
          <Divider />
          <ChoiceWrapper>
            <HalfTallDiv>
              <ButtonTitle variant="h4">{rightButtonTitle}</ButtonTitle>
            </HalfTallDiv>

            <HalfTallDiv>
              <Button
                color="primary"
                variant="contained"
                onClick={onRightButtonClick}
              >
                {rightButtonLabel}
              </Button>
            </HalfTallDiv>
          </ChoiceWrapper>
        </ActionButtonsWrapper>
      </Box>
    </Box>
  </DialogInfo>
)

export default ChoiceDialog
