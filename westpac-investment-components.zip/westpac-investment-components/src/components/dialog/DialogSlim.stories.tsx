import React, { useState } from 'react'

import DialogSlim from './DialogSlim'
import { Button } from '@material-ui/core'

export default {
  title: 'Dialog/DialogSlim',
  component: DialogSlim,
}

export const Basic = () => {
  const [openTool, setOpenTool] = useState(false)
  return (
    <React.Fragment>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setOpenTool(true)}
      >
        Open Dialog
      </Button>
      <DialogSlim
        dialogTitle="Title"
        dialogOverline="overline text"
        dialogUnderline="underline text"
        open={openTool}
        maxWidth="xs"
        onClose={() => setOpenTool(false)}
      >
        Add the content here
      </DialogSlim>
    </React.Fragment>
  )
}
