import React from 'react'
import DialogInfo from './DialogInfo'
import { render } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'

describe('DialogInfo', () => {
  it('should render without crashing', () => {
    const { getByText } = render(
      <InvestToolsProvider>
        <DialogInfo
          dialogTitle="Dialog Title"
          dialogOverline="Overline"
          open={true}
          onClose={() => {}}
        >
          Test
        </DialogInfo>
      </InvestToolsProvider>
    )
    expect(getByText('Dialog Title')).toBeInTheDocument()
  })
})
