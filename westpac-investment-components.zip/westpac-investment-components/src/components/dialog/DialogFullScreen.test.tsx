import React from 'react'
import DialogFullScreen from './DialogFullScreen'
import { render } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'

describe('DialogFullScreen', () => {
  it('should render without crashing', () => {
    const { getByText } = render(
      <InvestToolsProvider>
        <DialogFullScreen
          title="Long Title"
          shortTitle="Short Title"
          open={true}
          onClose={() => {}}
        />
      </InvestToolsProvider>
    )
    expect(getByText('Short Title')).toBeInTheDocument()
  })
})
