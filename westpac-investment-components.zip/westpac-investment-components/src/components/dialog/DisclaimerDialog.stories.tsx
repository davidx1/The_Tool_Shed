import React, { useState } from 'react'

import DisclaimerDialog from './DisclaimerDialog'
import { Button } from '@material-ui/core'

export default {
  title: 'Dialog/DisclaimerDialog',
  component: DisclaimerDialog,
}

export const Basic = () => {
  const [openTool, setOpenTool] = useState(false)
  return (
    <React.Fragment>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setOpenTool(true)}
      >
        Open Dialog
      </Button>
      <DisclaimerDialog
        title="Title"
        open={openTool}
        onClose={() => setOpenTool(false)}
        onContinue={() => setOpenTool(false)}
      >
        Add the content here
      </DisclaimerDialog>
    </React.Fragment>
  )
}
