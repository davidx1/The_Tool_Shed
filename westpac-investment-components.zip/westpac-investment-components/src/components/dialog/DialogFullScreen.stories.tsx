import React, { useState } from 'react'

import DialogFullScreen from './DialogFullScreen'
import { Button } from '@material-ui/core'

export default {
  title: 'Dialog/DialogFullScreen',
  component: DialogFullScreen,
}

export const Basic = () => {
  const [openTool, setOpenTool] = useState(false)
  return (
    <React.Fragment>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setOpenTool(true)}
      >
        Open Dialog
      </Button>
      <DialogFullScreen
        open={openTool}
        onClose={() => setOpenTool(false)}
        title="Title"
        closeLabel="Close"
      >
        Add the content here
      </DialogFullScreen>
    </React.Fragment>
  )
}
