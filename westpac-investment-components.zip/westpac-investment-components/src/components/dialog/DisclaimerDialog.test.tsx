import React from 'react'
import DisclaimerDialog from './DisclaimerDialog'
import { render } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'

describe('DisclaimerDialog', () => {
  it('should render without crashing', () => {
    const { getByText, queryByText } = render(
      <InvestToolsProvider>
        <DisclaimerDialog
          title="Dialog Title"
          open={true}
          onClose={() => {}}
          onContinue={() => {}}
        >
          Disclaimer Dialog
        </DisclaimerDialog>
      </InvestToolsProvider>
    )
    expect(getByText('Dialog Title')).toBeInTheDocument()
    expect(queryByText('I understand')).toBeInTheDocument()
  })

  it('should render without the continue button', () => {
    const { getByText, queryByText } = render(
      <InvestToolsProvider>
        <DisclaimerDialog title="Dialog Title" open={true} onClose={() => {}}>
          Disclaimer Dialog
        </DisclaimerDialog>
      </InvestToolsProvider>
    )
    expect(getByText('Dialog Title')).toBeInTheDocument()
    expect(queryByText('I understand')).not.toBeInTheDocument()
  })
})
