import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import Dialog from '@material-ui/core/Dialog'
import IconButton from '@material-ui/core/IconButton'
import CloseIcon from '@material-ui/icons/Close'
import { DialogInfoProps } from './DialogInfo'

const CloseButton = styled(IconButton)(
  ({ theme }) => css`
    position: fixed;
    top: ${theme.spacing(2.25)}px;
    right: ${theme.spacing(2.25)}px;
    border-radius: 50%;
    box-shadow: none;
    background: ${theme.palette.disabled.light};

    ${theme.breakpoints.up('sm')} {
      position: absolute;
      top: ${theme.spacing(-2)}px;
      right: ${theme.spacing(-2)}px;
    }

    ${theme.breakpoints.up('md')} {
      top: ${theme.spacing(-3)}px;
      right: ${theme.spacing(-3)}px;
    }
  `
)

const StyledDialog = styled(Dialog)(
  ({ theme }) => css`
    .MuiDialog-paper {
      margin: ${theme.spacing(4)}px;
    }
    .MuiPaper-root {
      overflow: visible;

      ${theme.breakpoints.down('xs')} {
        width: 100%;
        margin: ${theme.spacing(13, 0, 0)};
      }
    }
  `
)

const DialogInner = styled.div`
  overflow: hidden;
`

const DialogSlim: FC<DialogInfoProps> = ({
  dialogTitle,
  dialogClose = 'Close',
  maxWidth = 'lg',
  onClose,
  open,
  children,
}) => {
  return (
    <StyledDialog
      maxWidth={maxWidth}
      fullWidth
      onClose={onClose}
      aria-labelledby={dialogTitle && 'dialog-title'}
      open={open}
    >
      <DialogInner>{children}</DialogInner>
      {onClose && (
        <CloseButton
          aria-label={dialogClose}
          onClick={onClose}
          color="secondary"
        >
          <CloseIcon />
        </CloseButton>
      )}
    </StyledDialog>
  )
}

export default DialogSlim
