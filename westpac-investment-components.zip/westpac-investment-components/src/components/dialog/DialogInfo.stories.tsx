import React, { useState } from 'react'

import DialogInfo from './DialogInfo'
import { Button } from '@material-ui/core'

export default {
  title: 'Dialog/DialogInfo',
  component: DialogInfo,
}

export const Basic = () => {
  const [openTool, setOpenTool] = useState(false)
  return (
    <React.Fragment>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setOpenTool(true)}
      >
        Open Dialog
      </Button>
      <DialogInfo
        dialogTitle="Title"
        dialogOverline="overline text"
        dialogUnderline="underline text"
        open={openTool}
        maxWidth="xs"
        onClose={() => setOpenTool(false)}
      >
        Add the content here
      </DialogInfo>
    </React.Fragment>
  )
}
