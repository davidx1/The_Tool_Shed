import React from 'react'
import DialogSlim from './DialogSlim'
import { render } from '@testing-library/react'
import { InvestToolsProvider } from '../InvestToolsProvider'

describe('DialogInfo', () => {
  it('should render without crashing', () => {
    const { getByText } = render(
      <InvestToolsProvider>
        <DialogSlim dialogTitle="Dialog Title" open={true} onClose={() => {}}>
          Dialog content
        </DialogSlim>
      </InvestToolsProvider>
    )
    expect(getByText('Dialog content')).toBeInTheDocument()
  })
})
