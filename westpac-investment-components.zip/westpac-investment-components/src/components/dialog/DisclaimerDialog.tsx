import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { Typography, Box, Button } from '@material-ui/core'
import DialogInfo from './DialogInfo'
import UnderlineButton from '../inputs/UnderlineButton'

export interface DisclaimerDialogProps {
  open: boolean
  onClose: () => void
  onContinue?: () => void
  title?: string
  subtitle?: string
  continueButtonText?: string
  secondaryButtonLabel?: string
}

const TypographyInfo = styled((props) => (
  <Typography {...props} variant="body2" component="div" />
))`
  margin: 10px 0 20px;
`

const ActionButtons = styled.div`
  ${({ theme }) => css`
    display: flex;
    align-items: center;
    justify-items: flex-start;

    ${theme.breakpoints.down('xs')} {
      flex-direction: column;
    }
  `}
`

export const StyledButton = styled(Button)`
  ${({ theme }) => css`
    margin-top: 10px;
    ${theme.breakpoints.down('xs')} {
      width: 100%;
    }
  `}
`

const SecondaryButton = styled(UnderlineButton)`
  ${({ theme }) => css`
    margin: ${theme.spacing(0, 0, 0, 3)};
    ${theme.breakpoints.down('xs')} {
      margin: ${theme.spacing(2, 0)};
    }
  `}
`

const DisclaimerDialog: FC<DisclaimerDialogProps> = ({
  open,
  onClose,
  children,
  onContinue,
  subtitle,
  title = 'Before you get started.',
  continueButtonText = 'I understand',
  secondaryButtonLabel,
}) => (
  <DialogInfo dialogTitle={title} onClose={onClose} open={open}>
    <Box bgcolor="background.paper" px={[2, 4]} pb={[4, 5]} pt={3}>
      {subtitle && (
        <Typography variant="h4" gutterBottom>
          {subtitle}
        </Typography>
      )}
      <TypographyInfo>{children}</TypographyInfo>
      <ActionButtons>
        {onContinue && (
          <StyledButton
            color="primary"
            variant="contained"
            onClick={onContinue}
          >
            {continueButtonText}
          </StyledButton>
        )}
        {secondaryButtonLabel && (
          <SecondaryButton onClick={onClose}>
            {secondaryButtonLabel}
          </SecondaryButton>
        )}
      </ActionButtons>
    </Box>
  </DialogInfo>
)

export default DisclaimerDialog
