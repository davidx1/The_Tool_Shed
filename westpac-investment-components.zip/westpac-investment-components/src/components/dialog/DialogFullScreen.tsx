import React, { FC } from 'react'
import styled, { css } from 'styled-components'
import { srOnly } from '../../styles/sharedStyles'
import Dialog from '@material-ui/core/Dialog'
import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import Typography from '@material-ui/core/Typography'
import CloseIcon from '@material-ui/icons/Close'
import Slide from '@material-ui/core/Slide'
import Hidden from '@material-ui/core/Hidden'
import { TransitionProps } from '@material-ui/core/transitions'
import { Container, Button } from '@material-ui/core'
import WestpacLogo from '../../icons/westpac'

export const DIALOG_HEADER_HEIGHT = 80

const StyledDialog = styled(Dialog)`
  .MuiDialog-paper {
    margin-top: ${DIALOG_HEADER_HEIGHT}px;
    max-height: calc(100% - ${DIALOG_HEADER_HEIGHT}px);
  }
`

const StyledAppBar = styled(AppBar)`
  margin: 0;
  height: ${DIALOG_HEADER_HEIGHT}px;
  justify-content: center;
`

const StyledToolbar = styled(Toolbar)`
  height: 100%;
`

const Title = styled((props) => (
  <Typography variant="h4" component="p" {...props} />
))(
  ({ theme }) => css`
    flex-grow: 1;
    padding-left: 16px;
    ${theme.breakpoints.down('xs')} {
      font-size: ${theme.typography.pxToRem(18)};
      line-height: ${theme.typography.pxToRem(25)};
    }
  `
)

const CloseButton = styled(Button)`
  color: ${({ theme }) => theme.palette.text.primary};
  font-style: normal;
  font-weight: normal;
  font-size: ${({ theme }) => theme.typography.pxToRem(18)};
  min-width: 55px;
  padding-right: 0;

  :hover {
    color: ${({ theme }) => theme.palette.text.primary};
    background: none;
  }
`

const CloseLabel = styled.span`
  margin-right: 20px;

  ${({ theme }) => theme.breakpoints.down('xs')} {
    ${srOnly}
  }
`

const CloseAdornment = styled.span`
  && {
    background: ${({ theme }) => theme.palette.disabled.light};
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;

    svg {
      width: 20px;
      color: ${({ theme }) => theme.palette.text.primary};
    }
  }
`

const StyledContainer = styled.div`
  height: 100%;
  position: relative;
`

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement<any, any> },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />
})

const DialogFullScreen: FC<Props> = ({
  children,
  open,
  title,
  shortTitle,
  closeLabel = 'Close',
  onClose,
}) => {
  return (
    <StyledDialog
      fullScreen
      open={open}
      onClose={onClose}
      TransitionComponent={Transition}
      disableEscapeKeyDown
      hideBackdrop
    >
      <StyledAppBar position="fixed" color="inherit">
        <Container>
          <StyledToolbar disableGutters>
            <WestpacLogo />
            {shortTitle ? (
              <React.Fragment>
                <Hidden smUp>
                  <Title>{shortTitle}</Title>
                </Hidden>
                <Hidden xsDown>
                  <Title>{title}</Title>
                </Hidden>
              </React.Fragment>
            ) : (
              <Title>{title}</Title>
            )}
            <CloseButton onClick={onClose} disableTouchRipple>
              <CloseLabel>{closeLabel}</CloseLabel>
              <CloseAdornment>
                <CloseIcon />
              </CloseAdornment>
            </CloseButton>
          </StyledToolbar>
        </Container>
      </StyledAppBar>
      <StyledContainer>{children}</StyledContainer>
    </StyledDialog>
  )
}

export interface Props {
  open: boolean
  title: string
  closeLabel?: string
  onClose: () => void
  shortTitle?: string
}

export default DialogFullScreen
