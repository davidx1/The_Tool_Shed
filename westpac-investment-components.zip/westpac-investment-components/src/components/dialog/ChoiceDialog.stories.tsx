import React, { useState } from 'react'

import ChoiceDialog from './ChoiceDialog'
import { Button } from '@material-ui/core'

export default {
  title: 'Dialog/ChoiceDialog',
  component: ChoiceDialog,
}

export const Basic = () => {
  const [openTool, setOpenTool] = useState(false)
  return (
    <React.Fragment>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setOpenTool(true)}
      >
        Open Dialog
      </Button>
      <ChoiceDialog
        title="Change your KiwiSaver fund."
        open={openTool}
        onClose={() => setOpenTool(false)}
        leftButtonLabel="Login to Westpac One"
        rightButtonLabel="Join now"
        leftButtonTitle="Already a Westpac KiwiSaver Scheme customer?"
        rightButtonTitle="Join the Westpac KiwiSaver Scheme?"
        onLeftButtonClick={() => {}}
        onRightButtonClick={() => {}}
      >
        Your choice of fund will depend on your investment time frame and how
        you feel about risk. If you need help choosing a fund use the Fund
        Chooser.
      </ChoiceDialog>
    </React.Fragment>
  )
}
