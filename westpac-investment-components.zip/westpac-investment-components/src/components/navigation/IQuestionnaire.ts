import { IconType } from '../dataDisplay/DynamicIcon'
import { ILink } from './ILink'

export interface IValues {
  [key: string]: string | number
}

export type IQuestionTypes =
  | 'text'
  | 'radioGroup'
  | 'dropdown'
  | 'confirmationModal'
  | 'dropdownText'

export const ACTION_BUTTON_CLOSE_VALUE = 'CLOSE_ACTION'

export type IActionButton = {
  value: string
  description?: string
  label?: string
}

export type IQuestion =
  | IQuestionDropdownText
  | IQuestionRadio
  | IQuestionText
  | IQuestionDropdown
  | IQuestionConfirmationModal

export interface IQuestionBase {
  id: string
  title: string
  default?: string | number
  information?: {
    body: string[]
    icon?: IconType
    moreInfoUrl?: string
    callUs?: ILink
  }
}

export interface IQuestionDropdownText extends IQuestionBase {
  type: 'dropdownText'
  dropdown: {
    label: string
    options: (string | number)[]
  }
  text: {
    label: string
    suffix?: string
    inputOptions: {
      type: 'text' | 'number' | 'currency'
      min?: number
      max?: number
    }
  }
  confirmationModalOptions?: {
    body: string[]
    actionButtons?: IActionButton[]
  }
}

export interface IQuestionRadio extends IQuestionBase {
  type: 'radioGroup'
  icons?: IconType[]
  label?: string
  options?: (string | number)[]
}

export interface IQuestionText extends IQuestionBase {
  type: 'text'
  label: string
  suffix?: string
  inputOptions: {
    type: 'text' | 'number' | 'currency'
    min?: number
    max?: number
  }
}

export interface IQuestionDropdown extends IQuestionBase {
  type: 'dropdown'
  label: string
  options: (string | number)[]
}

export interface IQuestionConfirmationModal extends IQuestionBase {
  type: 'confirmationModal'
  confirmationModalOptions?: {
    body: string[]
    actionButtons?: IActionButton[]
  }
}

export interface ICustomerInteraction {
  subject: string
  whyProductSuitable: string
  additionalInfo: string
}

export interface IStep {
  type: 'question' | 'recommendation'
  question?: IQuestion
  isLastStep?: boolean
  estimatedProgress?: number
  getNextStep?: (
    values: IValues,
    customerInteraction: ICustomerInteraction
  ) => IStep | null
}

export interface IAnswerStep {
  answer: string | number
  question?: IQuestion
}
