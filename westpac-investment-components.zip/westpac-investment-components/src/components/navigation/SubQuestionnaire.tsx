import React, { FC } from 'react'
import { Box, Typography, BoxProps } from '@material-ui/core'
import Answer from '../inputs/answer/Answer'
import { IQuestionnaireBase } from '../../hooks/useQuestionnaire'
import { IStep } from './IQuestionnaire'
import LoadingProgress from '../feedback/LoadingProgress'
import styled, { css, StyledProps } from 'styled-components'

const StepContainerBase = styled(
  ({ key, forwardedRef, className, ...props }) => (
    <div key={key} ref={forwardedRef} tabIndex={-1} className={className}>
      <Box py={2} maxWidth={700} mx="auto" {...props} />
    </div>
  )
)(
  ({ theme }: StyledProps<HTMLDivElement>) => css`
    outline: none;
    padding: ${theme.spacing(0, 2, 2)};
    &:nth-child(even) {
      background: ${theme.palette.background.light};
    }

    ${theme.breakpoints.up('sm')} {
      padding: ${theme.spacing(0, 4)};
    }
  `
)

const StepContainer = React.forwardRef<unknown, BoxProps>((props, ref) => (
  <StepContainerBase {...props} forwardedRef={ref} />
))

export const LabelField = styled((props) => (
  <Typography variant="body1" component="h2" {...props} />
))(
  ({ theme }) => css`
    font-weight: ${theme.typography.fontWeightBold};
    min-width: 100%;
    width: 100%;
    padding: ${theme.spacing(2, 4, 2, 0)};
    ${theme.breakpoints.up('sm')} {
      min-width: 50%;
      width: 50%;
    }
  `
)

export const ValueField = styled.div(
  ({ theme }) => css`
    width: 100%;
    ${theme.breakpoints.up('sm')} {
      width: 50%;
      padding-top: ${theme.spacing(1)}px;
    }
  `
)

const Information = styled(Typography)(
  ({ theme }) => css`
    margin: ${theme.spacing(3, 0)};
  `
)

export interface Props {
  questionnaire: IQuestionnaireBase<IStep>
  resultContainerProps?: BoxProps
  recommendationRender: (recommendation: IStep) => JSX.Element
}

const SubQuestionnaire: FC<Props> = ({
  questionnaire: {
    steps,
    changeValue,
    setQuestionRef,
    values,
    isFetching,
    recommendation,
  },
  recommendationRender,
  resultContainerProps,
}) => {
  return (
    <React.Fragment>
      {steps.map((step, index) => {
        if (step.question) {
          return (
            <StepContainer key={step.question.id} ref={setQuestionRef(index)}>
              <Box flexDirection="row" display="flex" flexWrap="wrap">
                <LabelField id={`q-${step.question.id}`}>
                  {step.question.title}
                </LabelField>
                <ValueField>
                  <Answer
                    question={step.question}
                    isLastStep={!!step.isLastStep}
                    moveToNextStep={() => {}}
                    changeValue={changeValue}
                    values={values}
                    index={index}
                  />
                </ValueField>
              </Box>
              {step.question.information &&
                steps.length === index + 1 &&
                !isFetching &&
                step.question.information.body.map(
                  (bodyItem, bodyItemIndex) => (
                    <Information key={bodyItemIndex}>{bodyItem}</Information>
                  )
                )}
            </StepContainer>
          )
        }
        return (
          <StepContainer
            key="result"
            ref={setQuestionRef(index)}
            {...resultContainerProps}
          >
            {recommendationRender(steps[index])}
          </StepContainer>
        )
      })}
      {isFetching && (
        <StepContainer pb={1}>
          <LoadingProgress isActive fullWidth>
            Loading...
          </LoadingProgress>
        </StepContainer>
      )}
      {!isFetching && !recommendation && <StepContainer py={6} />}
    </React.Fragment>
  )
}

export default SubQuestionnaire
