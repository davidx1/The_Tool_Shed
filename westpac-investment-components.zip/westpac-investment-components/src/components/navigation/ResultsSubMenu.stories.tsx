import React from 'react'

import ResultsSubMenu from './ResultsSubMenu'

export default {
  title: 'Navigation/ResultsSubMenu',
  component: ResultsSubMenu,
}

export const Basic = () => {
  const emptyHandler = () => {}
  return (
    <ResultsSubMenu
      backToQuestions={emptyHandler}
      secondaryHandler={emptyHandler}
      secondaryLabel="Download PDF"
    />
  )
}
