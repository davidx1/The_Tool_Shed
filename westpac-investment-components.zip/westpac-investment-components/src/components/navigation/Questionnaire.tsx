import React, { FC, useState, useCallback, useRef } from 'react'
import styled, { css } from 'styled-components'
import { Container } from '@material-ui/core'
import { mobileLandscapeViewport } from '../../styles/theme'
import { Question } from './Question'
import InformativeBox from '../dataDisplay/InformativeBox'
import FormProgress from './FormProgress'
import { IQuestionnaireBase } from '../../hooks/useQuestionnaire'
import { IStep, IQuestion } from './IQuestionnaire'
import LoadingProgress from '../feedback/LoadingProgress'
import VisibilitySensor from 'react-visibility-sensor'
import TransitionResultContainer from '../layout/TransitionResultContainer'
import { useShortScreenState } from '../../hooks/useShortScreenState'

const ScrollableArea = styled.div(
  ({ isResultStep }: { isResultStep: boolean }) => css`
    width: 100%;
    height: 100%;
    -webkit-scroll-snap-type: y mandatory;
    -moz-scroll-snap-type: y mandatory;
    -ms-scroll-snap-type: y mandatory;
    scroll-snap-type: y mandatory;
    @supports (-webkit-hyphens: none) {
      scroll-snap-type: unset; //removed from safari temporarily till find a better solution
    }
    overflow-y: ${isResultStep ? 'hidden' : 'scroll'};
  `
)

const QuestionsContainer = styled.main`
  height: 100%;
`

const QuestionsInner = styled(Container)`
  outline: none;
  scroll-snap-align: start;
  scroll-snap-stop: always;
  height: 100%;
  display: flex;
  align-items: center;
`

const TopGradient = styled.div(
  ({ isScrolling }: { isScrolling: boolean }) => css`
    visibility: ${isScrolling ? 'visible' : 'hidden'};
    background: transparent;
    background: linear-gradient(
      0deg,
      rgba(255, 255, 255, 0) 0%,
      rgba(255, 255, 255, 1) 100%
    );
    position: absolute;
    height: 20%;
    width: calc(100% - 16px);
    pointer-events: none;
    z-index: 1;
    ${({ theme }) => theme.breakpoints.up('md')} {
      height: 30%;
    }
    ${mobileLandscapeViewport} {
      display: none;
    }
  `
)

const BottomGradient = styled.div(
  ({ isScrolling }: { isScrolling: boolean }) => css`
    visibility: ${isScrolling ? 'visible' : 'hidden'};
    background: transparent;
    background: linear-gradient(
      0deg,
      rgba(255, 255, 255, 1) 0%,
      rgba(255, 255, 255, 0) 100%
    );
    position: absolute;
    bottom: 0;
    height: 160px;
    width: calc(100% - 16px);
    pointer-events: none;
    z-index: 1;
    ${mobileLandscapeViewport} {
      display: none;
    }
  `
)

// Take scroll away from ScrollableArea and scroll within to avoid scroll snapping
const ResultContainer = styled.div(
  ({ isResultStep }: { isResultStep: boolean }) => css`
    outline: none;
    width: 100%;
    height: 75%;
    scroll-snap-align: start;
    scroll-snap-stop: always;
    position: relative;
    z-index: ${isResultStep ? '3' : '1'};
  `
)

const sensorOffset = { top: -100, bottom: -100 }
export interface Props {
  name: string
  paddingTop?: number
  questionnaire: IQuestionnaireBase<IStep>
  recommendationRender: (
    recommendation: IStep,
    backToQuestions: () => void,
    containerRef: React.RefObject<HTMLDivElement>
  ) => JSX.Element
  questionDetailRender?: (
    question: IQuestion,
    stepIndex: number
  ) => JSX.Element | null
}

const Questionnaire: FC<Props> = ({
  questionnaire: {
    steps,
    setScrollContainer,
    setQuestionRef,
    moveToPreviousStep,
    moveToNextStep,
    changeValue,
    values,
    isFetching,
    isScrolling,
    recommendation,
  },
  recommendationRender,
  name,
  paddingTop = 0,
  questionDetailRender,
}) => {
  const [selectedStep, setSelectedStep] = useState<number>(0)
  const [showRecommendation, setShowRecommendation] = useState(false)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const { isShortScreen } = useShortScreenState(500)

  const changeVisibleStepHandler = (index: number) => (isVisible: boolean) => {
    if (isVisible && selectedStep !== index && !showRecommendation) {
      setShowRecommendation(steps[index] === recommendation)
      setSelectedStep(index)
    }
  }

  const backToQuestions = useCallback(() => {
    setShowRecommendation(false)
    moveToPreviousStep(steps.length - 1, false)
  }, [moveToPreviousStep, steps.length])

  let questionNumber = 1

  const formatQuestionNumber = (n: number) => `00${n}`.slice(-2)

  return (
    <ScrollableArea ref={setScrollContainer} isResultStep={showRecommendation}>
      <QuestionsContainer>
        <TopGradient isScrolling={isScrolling} />
        <BottomGradient isScrolling={isScrolling} />

        {steps.map((step, index) => {
          if (!step.question || step.question?.type === 'confirmationModal') {
            return null
          }
          return (
            <VisibilitySensor
              key={step.question.id}
              onChange={changeVisibleStepHandler(index)}
              offset={sensorOffset}
            >
              <QuestionsInner ref={setQuestionRef(index)} tabIndex={-1}>
                <Question
                  isInert={showRecommendation}
                  changeValue={changeValue}
                  values={values}
                  questionDetailRender={questionDetailRender}
                  step={step}
                  questionNumberString={formatQuestionNumber(questionNumber++)}
                  moveToNextStep={moveToNextStep}
                  index={index}
                />
              </QuestionsInner>
            </VisibilitySensor>
          )
        })}
        {recommendation && (
          <VisibilitySensor
            onChange={changeVisibleStepHandler(steps.length - 1)}
            offset={sensorOffset}
          >
            <ResultContainer
              isResultStep={showRecommendation}
              ref={setQuestionRef(steps.length - 1)}
              tabIndex={-1}
            >
              <TransitionResultContainer
                isTransitioning={showRecommendation}
                ref={scrollContainerRef}
              >
                {selectedStep === steps.length - 1 &&
                  recommendationRender(
                    recommendation,
                    backToQuestions,
                    scrollContainerRef
                  )}
              </TransitionResultContainer>
            </ResultContainer>
          </VisibilitySensor>
        )}
      </QuestionsContainer>
      <InformativeBox step={steps[selectedStep]} paddingTop={paddingTop} />
      {!isShortScreen && (
        <FormProgress
          steps={steps}
          selectedStep={selectedStep}
          moveToNextStep={moveToNextStep}
          moveToPreviousStep={moveToPreviousStep}
          srDescription={`${name} Questionnaire completion percentage`}
          isInert={showRecommendation}
        />
      )}
      <LoadingProgress isActive={isFetching} isFixed>
        Loading next step...
      </LoadingProgress>
    </ScrollableArea>
  )
}

export default Questionnaire
