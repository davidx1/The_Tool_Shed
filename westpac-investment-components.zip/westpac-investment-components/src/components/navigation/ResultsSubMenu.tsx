import React, { FC } from 'react'
import styled from 'styled-components'
import { srOnly } from '../../styles/sharedStyles'
import { Grid, Button, Box } from '@material-ui/core'
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft'
import GetAppIcon from '@material-ui/icons/GetApp'
import UnderlineButton from '../inputs/UnderlineButton'

export interface Props {
  backToQuestions: () => void
  secondaryHandler?: () => void
  secondaryLabel?: string
}

const BackButton = styled(Button)(
  ({ theme }) => `
  color: ${theme.palette.text.primary};
  font-weight: ${theme.typography.fontWeightRegular};
  font-size: ${theme.typography.pxToRem(18)};
  padding: ${theme.spacing(1)}px 0;
  :hover {
    color: ${theme.palette.text.primary};
    background: none;
  }
`
)

const DownloadIcon = styled(GetAppIcon)(
  ({ theme }) => `
  margin-left: ${theme.spacing(0.5)}px;
`
)

const BackLabel = styled.span`
  ${({ theme }) => theme.breakpoints.down('xs')} {
    ${srOnly}
  }
`

const ResultsSubMenu: FC<Props> = ({
  backToQuestions,
  secondaryHandler,
  secondaryLabel,
}) => {
  return (
    <Box py={3}>
      <Grid container spacing={3} justify="space-between">
        <Grid item>
          <BackButton
            startIcon={<ChevronLeftIcon />}
            onClick={backToQuestions}
            disableTouchRipple
          >
            Back&nbsp;<BackLabel>to questions</BackLabel>
          </BackButton>
        </Grid>
        {secondaryLabel && secondaryHandler && (
          <Grid item>
            <UnderlineButton onClick={secondaryHandler}>
              {secondaryLabel}
              <DownloadIcon />
            </UnderlineButton>
          </Grid>
        )}
      </Grid>
    </Box>
  )
}

export default ResultsSubMenu
