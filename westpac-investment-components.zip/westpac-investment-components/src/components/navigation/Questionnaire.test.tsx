import React from 'react'
import Questionnaire from './Questionnaire'
import useQuestionnaire, {
  IQuestionnaireBase,
} from '../../hooks/useQuestionnaire'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { IStep } from './IQuestionnaire'
import { render, waitFor, fireEvent } from '@testing-library/react'

// mock react-visibility-sensor to simulate the scroll in the recommendation step
class MockSensor extends React.Component {
  componentDidMount() {
    this.props.onChange(true)
  }
  render() {
    var { children } = this.props

    return children
  }
}
jest.mock('react-visibility-sensor', () => (props) => <MockSensor {...props} />)

// mock API for displaying question and result
const getNextStep = jest
  .fn()
  .mockResolvedValueOnce({
    type: 'question',
    question: {
      id: 'Q1',
      type: 'radioGroup',
      title: 'Title Question',
      options: ['Option 1', 'Option 2', 'Option 3'],
      label: 'Label',
    },
  })
  .mockResolvedValue({
    type: 'recommendation',
  })

describe('<Questionnaire/>', () => {
  beforeAll(() => {
    // mock missing events in jsdom
    Object.defineProperty(window.HTMLElement.prototype, 'scrollBy', {
      writable: true,
      value: jest.fn(),
    })
    Object.defineProperty(window, 'matchMedia', {
      value: jest.fn(() => {
        return {
          matches: true,
          addListener: jest.fn(),
          removeListener: jest.fn(),
        }
      }),
    })
  })

  it('should navigate from question to result', async () => {
    const View = () => {
      const questionnaire: IQuestionnaireBase<IStep> = useQuestionnaire(
        getNextStep
      )
      return (
        <Questionnaire
          name="Questionnaire"
          questionnaire={questionnaire}
          recommendationRender={(recommendationStep, backToQuestions) => (
            <div>
              <strong>Recommendation</strong> {recommendationStep.type}
              <button onClick={backToQuestions}>Back to questions</button>
            </div>
          )}
        />
      )
    }
    const { getByText } = render(
      <InvestToolsProvider>
        <View />
      </InvestToolsProvider>
    )

    await waitFor(() => {
      expect(getByText('Title Question')).toBeVisible()
    })
    fireEvent.click(getByText('Option 1'))
    await waitFor(() => {
      expect(getByText('Recommendation')).toBeVisible()
    })
    fireEvent.click(getByText('Back to questions'))
    await waitFor(() => {
      expect(getByText('Title Question')).toBeVisible()
    })
  })
})
