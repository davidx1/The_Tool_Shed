import React from 'react'

import SubQuestionnaire from './SubQuestionnaire'
import { IStep } from './IQuestionnaire'
import useQuestionnaire, {
  IQuestionnaireBase,
} from '../../hooks/useQuestionnaire'
import { getNextStepPIRRate } from '../../utils/pir-rate-finder/PIRRateUtils'

export default {
  title: 'Navigation/SubQuestionnaire',
  component: SubQuestionnaire,
}

const getNextStep = async (userAnswers: (string | number)[]) =>
  getNextStepPIRRate(userAnswers)

export const Basic = () => {
  const questionnaire: IQuestionnaireBase<IStep> = useQuestionnaire(getNextStep)
  return (
    <SubQuestionnaire
      questionnaire={questionnaire}
      recommendationRender={(recommendationStep: IStep) => (
        <div>
          <h3>RecommendationStep type: {recommendationStep.type}</h3>
        </div>
      )}
    />
  )
}

Basic.parameters = {
  storyshots: false,
}
