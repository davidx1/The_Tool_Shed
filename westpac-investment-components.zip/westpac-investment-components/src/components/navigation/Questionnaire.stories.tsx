import React from 'react'

import Questionnaire from './Questionnaire'
import { IStep } from './IQuestionnaire'
import useQuestionnaire, {
  IQuestionnaireBase,
} from '../../hooks/useQuestionnaire'
import { getNextStepProductChooser } from '../../utils/product-chooser/productChooserUtils'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'
import ratesData from '../../utils/product-chooser/__mocks__/ProductChooserRatesData'

export default {
  title: 'Navigation/Questionnaire',
  component: Questionnaire,
}

const getNextStep = async (userAnswers: (string | number)[]) =>
  getNextStepProductChooser(userAnswers, config, ratesData)

export const Basic = () => {
  const questionnaire: IQuestionnaireBase<IStep> = useQuestionnaire(getNextStep)
  return (
    <div style={{ width: '100%', height: '600px', position: 'relative' }}>
      <Questionnaire
        name="Questionnaire Sample"
        questionnaire={questionnaire}
        recommendationRender={(recommendationStep: IStep, backToQuestions) => (
          <div>
            <h3>RecommendationStep type: {recommendationStep.type}</h3>
            <button onClick={backToQuestions}>Back</button>
          </div>
        )}
      />
    </div>
  )
}

Basic.parameters = {
  storyshots: false,
}
