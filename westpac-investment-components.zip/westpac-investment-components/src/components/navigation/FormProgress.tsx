import React from 'react'
import styled, { css } from 'styled-components'
import { spacing, mobileLandscapeViewport } from '../../styles/theme'
import {
  Typography,
  Grid,
  LinearProgress,
  Container,
  IconButton,
} from '@material-ui/core'
import KeyboardArrowDownRoundedIcon from '@material-ui/icons/KeyboardArrowDownRounded'
import KeyboardArrowUpRoundedIcon from '@material-ui/icons/KeyboardArrowUpRounded'
import { IStep } from './IQuestionnaire'
import Inert from '../layout/Inert'

interface Props {
  steps: IStep[]
  selectedStep: number
  isInert: boolean
  srDescription: string
  moveToNextStep: (index: number) => void
  moveToPreviousStep: (index: number) => void
}

const ProgressContainer = styled(Container)(
  ({ theme }) => css`
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    pointer-events: none;
    z-index: 2;
    margin-bottom: 60px;
    ${theme.breakpoints.up('md')} {
      margin-bottom: 0;
    }
    ${mobileLandscapeViewport} {
      display: none;
    }
    ${theme.breakpoints.down(360)} {
      display: none;
    }
  `
)

const ProgressInner = styled.div(
  ({ theme }) => css`
    padding: ${spacing(3)}px 0;
    width: 100%;
    max-width: 800px;
    color: ${theme.palette.primary.light};
    button {
      pointer-events: all;
    }
    button + button {
      padding-left: 20px;
    }
    ${theme.breakpoints.up('md')} {
      width: 60%;
      padding: ${spacing(4)}px 0;
    }
  `
)

const StyledIconButton = styled(IconButton)(
  ({ theme }) => css`
    background-color: ${theme.palette.background.paper};
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.15);
    &:hover {
      background-color: ${theme.palette.tertiary.main};
      color: ${theme.palette.tertiary.contrastText};
    }
  `
)

const FormProgress: React.FC<Props> = ({
  steps,
  selectedStep,
  moveToNextStep,
  moveToPreviousStep,
  isInert,
  srDescription,
}) => {
  const estimatedProgress = steps[selectedStep]?.estimatedProgress || 0

  const navigate = (moveFunction: (index: number) => void) => () => {
    moveFunction(selectedStep)
  }
  return (
    <ProgressContainer>
      <Inert isInert={isInert} delay={1}>
        <ProgressInner>
          <Grid container alignItems="center" spacing={2}>
            <Grid item>
              <Typography
                variant="h6"
                component="p"
                color="inherit"
                id="questionProgress"
              >
                <Typography variant="srOnly">{`${srDescription}: `}</Typography>
                {estimatedProgress}%
              </Typography>
            </Grid>
            <Grid item xs>
              <LinearProgress
                value={estimatedProgress || 2}
                aria-labelledby="questionProgress"
                variant="determinate"
                color="secondary"
              />
            </Grid>
            <Grid item sm={4}>
              <Grid container wrap="nowrap" spacing={2}>
                <Grid item sm={1} md />
                <Grid item>
                  <StyledIconButton
                    aria-label="Previous"
                    onClick={navigate(moveToPreviousStep)}
                    disabled={selectedStep === 0}
                    disableTouchRipple
                  >
                    <KeyboardArrowUpRoundedIcon fontSize="inherit" />
                  </StyledIconButton>
                </Grid>
                <Grid item>
                  <StyledIconButton
                    aria-label="Next"
                    onClick={navigate(moveToNextStep)}
                    disabled={
                      !steps.length || selectedStep === steps.length - 1
                    }
                    disableTouchRipple
                  >
                    <KeyboardArrowDownRoundedIcon fontSize="inherit" />
                  </StyledIconButton>
                </Grid>
                <Grid item sm={1} />
              </Grid>
            </Grid>
          </Grid>
        </ProgressInner>
      </Inert>
    </ProgressContainer>
  )
}

export default FormProgress
