import React from 'react'

import { Question } from './Question'
export default {
  title: 'Navigation/Question',
  component: Question,
}

export const Basic = () => {
  return (
    <Question
      isInert={false}
      questionNumberString={"01"}
      changeValue={() => {}}
      values={['perYear::']}
      moveToNextStep={() => {}}
      index={0}
      questionDetailRender={() => <span />}
      step={{
        type: 'question',
        question: {
          id: 'bob',
          type: 'dropdownText',
          title: 'My Question',
          dropdown: {
            label: 'Choose option',
            options: ['per week', 'per month', 'per year'],
          },
          text: {
            label: 'Enter income',
            inputOptions: {
              type: 'currency',
            },
          },
          information: {
            body: [
              `This will help us give you a detailed projection, if unsure you can ask your employer(s).`,
            ],
            icon: 'moneyCoin',
          },
        },
        isLastStep: false,
      }}
    />
  )
}

export const Complex = () => {
  return (
    <Question
      isInert={false}
      questionNumberString={"02"}
      changeValue={() => {}}
      values={['22']}
      moveToNextStep={() => {}}
      index={1}
      questionDetailRender={() => <span />}
      step={{
        type: 'question',
        question: {
          id: 'bob',
          type: 'text',
          title: 'My Question',
          label: 'Enter income',
          inputOptions: {
            type: 'currency',
          },
          information: {
            body: [
              `This will help us give you a detailed projection, if unsure you can ask your employer(s).`,
            ],
            icon: 'moneyCoin',
          },
        },
        isLastStep: false,
      }}
    />
  )
}

Basic.parameters = {
  storyshots: false,
}
