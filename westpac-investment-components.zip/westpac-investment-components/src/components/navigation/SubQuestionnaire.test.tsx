import React from 'react'
import SubQuestionnaire from './SubQuestionnaire'
import useQuestionnaire, {
  IQuestionnaireBase,
} from '../../hooks/useQuestionnaire'
import { InvestToolsProvider } from '../InvestToolsProvider'
import { IStep } from './IQuestionnaire'
import { render, waitFor } from '@testing-library/react'

const getNextStep = async () => {
  return {
    type: 'question',
    question: {
      id: 'Q1',
      type: 'dropdown',
      title: 'Title Question',
      options: ['Option 1', 'Option 2', 'Option 3'],
      label: 'Dropdown Label',
    },
  } as IStep
}

describe('<SubQuestionnaire/>', () => {
  beforeAll(() => {
    Object.defineProperty(window.HTMLElement.prototype, 'scrollBy', {
      writable: true,
      value: jest.fn(),
    })
    Object.defineProperty(window, 'matchMedia', {
      value: jest.fn(() => {
        return {
          matches: true,
          addListener: jest.fn(),
          removeListener: jest.fn(),
        }
      }),
    })
  })

  it('should create hook and get populate with first question', async () => {
    const View = () => {
      const questionnaire: IQuestionnaireBase<IStep> = useQuestionnaire(
        getNextStep
      )
      return (
        <SubQuestionnaire
          questionnaire={questionnaire}
          recommendationRender={() => <div />}
        />
      )
    }
    const { getByText } = render(
      <InvestToolsProvider>
        <View />
      </InvestToolsProvider>
    )

    await waitFor(() => {
      expect(getByText('Title Question')).toBeInTheDocument()
    })
  })
})
