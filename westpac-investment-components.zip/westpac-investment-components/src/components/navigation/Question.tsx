import React from 'react'
import Inert from '../layout/Inert'
import Answer from '../inputs/answer/Answer'
import { Typography } from '@material-ui/core'
import styled, { css } from 'styled-components'
import { mobileLandscapeViewport } from '../../styles/theme'
import { IStep, IQuestion } from './IQuestionnaire'

export interface Props {
  isInert: boolean
  questionNumberString: string
  changeValue: (
    index: number,
    value: React.ReactText,
    submitValue: boolean
  ) => void
  values: React.ReactText[]
  questionDetailRender:
    | ((question: IQuestion, stepIndex: number) => JSX.Element | null)
    | undefined
  step: IStep
  moveToNextStep: (index: number, animateScroll?: boolean | undefined) => void
  index: number
}

export const Question = ({
  isInert,
  questionNumberString,
  changeValue,
  values,
  step,
  moveToNextStep,
  index,
  questionDetailRender,
}: Props) => {
  if (!step.question || step.question?.type === 'confirmationModal') {
    return null
  }
  return (
    <QuestionContainer>
      <Inert isInert={isInert}>
        <Typography variant="caption" display="block">
          {questionNumberString}
        </Typography>

        <Title id={`q-${step?.question.id}`}>{step?.question.title}</Title>

        <Answer
          question={step.question}
          isLastStep={!!step.isLastStep}
          moveToNextStep={moveToNextStep}
          changeValue={changeValue}
          values={values}
          index={index}
          size="large"
        />

        {questionDetailRender?.(step.question, index)}
      </Inert>
    </QuestionContainer>
  )
}

const QuestionContainer = styled.div(
  ({ theme }) => css`
    padding-bottom: ${theme.spacing(12)}px;
    ${theme.breakpoints.up('md')} {
      max-width: 50%;
    }
    ${mobileLandscapeViewport} {
      padding-bottom: 0;
    }
  `
)

const Title = styled(Typography).attrs({
  variant: 'h2',
})`
  display: inline;
  margin-right: ${({ theme }) => theme.spacing(1)}px;
`
