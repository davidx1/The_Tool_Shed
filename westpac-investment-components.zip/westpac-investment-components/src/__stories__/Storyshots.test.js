import React from 'react'
import { StylesProvider, createGenerateClassName } from '@material-ui/core'
import initStoryshots from '@storybook/addon-storyshots'
import renderer from 'react-test-renderer'

const ignoreList = [
  './components/projectionsTool',
  './components/inputs/Slider',
]

const ignoreRegex = `(${ignoreList.join('|')}).*`

initStoryshots({
  asyncJest: true,
  test: async ({ story, context, done }) => {
    if (!story.fileName.match(ignoreRegex)) {
      // Add StyleProvider to snapshots to avoid MUI classNames changing aleatory
      const providerProps = { generateClassName: createGenerateClassName() }
      const tree = renderer.create(
        React.createElement(StylesProvider, providerProps, story.render())
      )
      setTimeout(() => {
        expect(tree.toJSON()).toMatchSnapshot()
        done()
      })
    } else {
      done()
    }
  },
})
