import { IQuestion, IStep } from '../../components/navigation/IQuestionnaire'
import { getNextStep } from '../questionnaireUtils'
import { IProductChooserProductType } from '../product-chooser/productChooserUtils'

export interface IInterestFrequencyStep extends IStep {
  recommendation?: IInterestFrequencyItem
}

export interface IInterestFrequencyItem {
  title: string
  description: string
}

/* -----------------------------------------------
                    Questions
 ----------------------------------------------- */

export const OPTION_UNDER_6_MONTHS = 'Under 6 months'
export const OPTION_6_MONTHS_OR_ABOVE = '6 months or above'

const getHowLongQuestion = (
  recommendationType?: IProductChooserProductType
): IQuestion => ({
  id: 'QUESTION_HOW_LONG',
  type: 'radioGroup',
  title: `How long do you want to fix your ${
    recommendationType === 'termPIE' ? 'Term PIE' : 'Term Deposit'
  }?`,
  options: [OPTION_UNDER_6_MONTHS, OPTION_6_MONTHS_OR_ABOVE],
})

/* ----------------------------------------------- */

export const OPTION_GOAL_GROW_INVESTMENT = 'To grow my investment'
export const OPTION_GOAL_SUPPLEMENT_INCOME = 'To supplement my income'
export const OPTION_GOAL_LUMP_SUM = 'Lump sum paid out'

const getGoalQuestion = (
  recommendationType?: IProductChooserProductType
): IQuestion => ({
  id: 'QUESTION_GOAL',
  type: 'dropdown',
  title: `What do you want your ${
    recommendationType === 'termPIE' ? 'rate of return' : 'interest'
  } to do for you?`,
  label: 'Select option',
  options: [
    OPTION_GOAL_GROW_INVESTMENT,
    OPTION_GOAL_SUPPLEMENT_INCOME,
    OPTION_GOAL_LUMP_SUM,
  ],
})

/* -----------------------------------------------
                      Recommendations
   ----------------------------------------------- */

const COMPOUNDED_TERM_DEPOSIT: IInterestFrequencyItem = {
  title: 'Interest compounded',
  description:
    'For terms six months or longer, interest can be compounded quarterly (added automatically to your original investment). This allows you to earn interest on interest, meaning your investment grows at a faster rate than if interest were paid out during the course of the investment or paid in full at maturity.',
}

const COMPOUNDED_TERM_PIE: IInterestFrequencyItem = {
  title: 'Returns compounded',
  description:
    'For terms six months or longer, returns can be compounded quarterly (added automatically to your original investment). This allows you to earn returns on returns, meaning your investment grows at a faster rate than returns were paid out during the course of the investment or paid in full at maturity.',
}

const PAID_TERM_DEPOSIT: IInterestFrequencyItem = {
  title: 'Interest paid periodically',
  description:
    'For terms six months or longer, you can choose to have your interest paid monthly or quarterly into your nominated New Zealand bank account. This regular income stream may work well if you need to supplement other income such as New Zealand Superannuation.',
}

const PAID_TERM_PIE: IInterestFrequencyItem = {
  title: 'Returns paid periodically',
  description:
    'For terms six months or longer, you can choose to have returns paid monthly or quarterly into your nominated New Zealand bank account. This regular income stream may work well if you need to supplement other income such as New Zealand Superannuation.',
}

const MATURITY_TERM_DEPOSIT_UNDER_6: IInterestFrequencyItem = {
  title: 'Interest at maturity',
  description:
    'For terms under six months, interest is paid at the end of the investment term.',
}

const MATURITY_TERM_PIE_UNDER_6: IInterestFrequencyItem = {
  title: 'Returns at maturity',
  description:
    'For terms under six months, returns are paid at the end of the investment term.',
}

const MATURITY_TERM_DEPOSIT_OVER_6: IInterestFrequencyItem = {
  title: 'Interest at maturity',
  description: `For all terms, interest is able to be paid at the end of the investment term.`,
}

const MATURITY_TERM_PIE_OVER_6: IInterestFrequencyItem = {
  title: 'Returns at maturity',
  description: `For all terms, returns are able to be paid at the end of the investment term.`,
}

/* -----------------------------------------------
                      Steps
   ----------------------------------------------- */

const getInitialQuestion = (
  recommendationType?: IProductChooserProductType
): IInterestFrequencyStep => {
  const question = getHowLongQuestion(recommendationType)
  return {
    type: 'question',
    question,
    getNextStep: (values) => {
      if (values[question.id] === OPTION_UNDER_6_MONTHS) {
        return recommendationType === 'termPIE'
          ? getRecommendation(MATURITY_TERM_PIE_UNDER_6)
          : getRecommendation(MATURITY_TERM_DEPOSIT_UNDER_6)
      }
      return getGoalStep(recommendationType)
    },
  }
}

const getGoalStep = (
  recommendationType?: IProductChooserProductType
): IInterestFrequencyStep => {
  const question = getGoalQuestion(recommendationType)
  return {
    type: 'question',
    question,
    getNextStep: (values) => {
      switch (values[question.id]) {
        case OPTION_GOAL_GROW_INVESTMENT:
          return recommendationType === 'termPIE'
            ? getRecommendation(COMPOUNDED_TERM_PIE)
            : getRecommendation(COMPOUNDED_TERM_DEPOSIT)
        case OPTION_GOAL_SUPPLEMENT_INCOME:
          return recommendationType === 'termPIE'
            ? getRecommendation(PAID_TERM_PIE)
            : getRecommendation(PAID_TERM_DEPOSIT)
        case OPTION_GOAL_LUMP_SUM:
          return recommendationType === 'termPIE'
            ? getRecommendation(MATURITY_TERM_PIE_OVER_6)
            : getRecommendation(MATURITY_TERM_DEPOSIT_OVER_6)
        default:
          return null
      }
    },
  }
}

const getRecommendation = (recommendation: IInterestFrequencyItem) =>
  ({
    type: 'recommendation',
    recommendation,
  } as IInterestFrequencyStep)

export const getNextStepInterestFrequency = (
  userAnswers: (string | number)[],
  recommendationType?: IProductChooserProductType
) =>
  getNextStep(
    userAnswers,
    getInitialQuestion(recommendationType)
  ) as IInterestFrequencyStep
