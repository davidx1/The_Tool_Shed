import { IProductChooserProductType } from '../product-chooser/productChooserUtils'
import {
  getNextStepInterestFrequency,
  OPTION_UNDER_6_MONTHS,
  OPTION_6_MONTHS_OR_ABOVE,
  OPTION_GOAL_GROW_INVESTMENT,
  OPTION_GOAL_SUPPLEMENT_INCOME,
  OPTION_GOAL_LUMP_SUM,
} from './InterestFrequencyFinderUtils'

const testInterestFrequencyRecommendation = (
  userAnswer: (string | number)[],
  recommendationType: IProductChooserProductType,
  interestTitle: string
) => {
  const step = getNextStepInterestFrequency(userAnswer, recommendationType)

  expect(step.type).toBe('recommendation')
  expect(step.recommendation?.title).toBe(interestTitle)
}

const testUnexpectedInterestFrequencyScenarios = (
  userAnswer: (string | number)[]
) => {
  const step = getNextStepInterestFrequency(userAnswer)
  expect(step).toBe(null)
}

const unexpectedValue = 'unexpected'

describe('Interest frequency finder', () => {
  it('As a user who want to fix his interest under 6 months I should receive a recommendation of Interest at Maturity', () => {
    testInterestFrequencyRecommendation(
      [OPTION_UNDER_6_MONTHS],
      'termDeposit',
      'Interest at maturity'
    )
    testInterestFrequencyRecommendation(
      [OPTION_UNDER_6_MONTHS],
      'termPIE',
      'Returns at maturity'
    )
  })
  it('As a user who want to fix his interest over 6 months and want to use for Lump sum paid out I should receive a recommendation of Interest at Maturity', () => {
    testInterestFrequencyRecommendation(
      [OPTION_6_MONTHS_OR_ABOVE, OPTION_GOAL_LUMP_SUM],
      'termDeposit',
      'Interest at maturity'
    )
    testInterestFrequencyRecommendation(
      [OPTION_6_MONTHS_OR_ABOVE, OPTION_GOAL_LUMP_SUM],
      'termPIE',
      'Returns at maturity'
    )
  })
  it('As a user who want to fix his interest over 6 months and want to use for Investisment I should receive a recommendation of Interest compounded', () => {
    testInterestFrequencyRecommendation(
      [OPTION_6_MONTHS_OR_ABOVE, OPTION_GOAL_GROW_INVESTMENT],
      'termDeposit',
      'Interest compounded'
    )
    testInterestFrequencyRecommendation(
      [OPTION_6_MONTHS_OR_ABOVE, OPTION_GOAL_GROW_INVESTMENT],
      'termPIE',
      'Returns compounded'
    )
  })
  it('As a user who want to fix his interest over 6 months and want to use for supplement incomes I should receive a recommendation of Interest paid', () => {
    testInterestFrequencyRecommendation(
      [OPTION_6_MONTHS_OR_ABOVE, OPTION_GOAL_SUPPLEMENT_INCOME],
      'termDeposit',
      'Interest paid periodically'
    )
    testInterestFrequencyRecommendation(
      [OPTION_6_MONTHS_OR_ABOVE, OPTION_GOAL_SUPPLEMENT_INCOME],
      'termPIE',
      'Returns paid periodically'
    )
  })
  it('should return null if an answer is unexpected', () => {
    testUnexpectedInterestFrequencyScenarios([
      OPTION_6_MONTHS_OR_ABOVE,
      'termDeposit',
      unexpectedValue,
    ])
  })
})
