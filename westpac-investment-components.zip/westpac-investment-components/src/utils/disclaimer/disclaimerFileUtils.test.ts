import { generateDisclaimerRecommendationFile } from './disclaimerFileUtils'
import config from '../product-chooser/__mocks__/ProductChooserConfigMockData'
import { pdfTextFn, saveFn } from '../../__mocks__/jspdf'

jest.mock('moment', () => () =>
  jest.requireActual('moment')('2020-01-01T00:00:00.000Z')
)

describe('disclaimerFileUtils', () => {
  const getPdfTextFnFormatted = () =>
    pdfTextFn.mock.calls.map((call) => call[0]).join('\n')

  it('generateDisclaimerRecommendationFile > Check PDF generation', () => {
    const { doc, save } = generateDisclaimerRecommendationFile(
      'Title',
      config.disclaimer
    )
    expect(doc.getNumberOfPages()).toBe(2)

    save()
    expect(saveFn).toHaveBeenCalledWith('disclaimer-2020-01-01.pdf')
  })

  it('generateDisclaimerRecommendationFile > PDF should render correctly', () => {
    generateDisclaimerRecommendationFile('Title', config.disclaimer)
    expect(getPdfTextFnFormatted()).toMatchSnapshot()
  })
})
