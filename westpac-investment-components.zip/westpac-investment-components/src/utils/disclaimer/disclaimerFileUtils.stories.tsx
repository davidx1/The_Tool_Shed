import React from 'react'

import { generateDisclaimerRecommendationFile } from './disclaimerFileUtils'
import config from '../product-chooser/__mocks__/ProductChooserConfigMockData'

export default {
  title: 'Disclaimer/generateDisclaimerRecommendationFile',
}

export const Basic = () => {
  const file = generateDisclaimerRecommendationFile('Savings & Investment Chooser Tool.', config.disclaimer)
  const uri = file.doc.output('datauristring')
  return (
    <div>
      <iframe src={uri} title="PDF Viewer" height="500" width="100%" />
      <button onClick={() => file.save()}>Download PDF</button>
    </div>
  )
}

Basic.parameters = {
  storyshots: false,
}
