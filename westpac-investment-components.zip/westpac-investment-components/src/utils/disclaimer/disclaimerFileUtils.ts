import moment from 'moment'

import { createPDF } from '../pdfUtils'

const createDisclaimerDoc = (title: string, text: string[]) => {
  const file = createPDF()

  const renderDisclaimer = () => {
    file.renderTitle(title)
    file.renderHTML(text)
  }

  const renderAll = () => {
    file.renderTopImage()
    file.renderSpace(0.2)
    renderDisclaimer()
  }

  function getFileName() {
    return `disclaimer-${moment().format('YYYY-MM-DD')}`
  }

  function save() {
    file.doc.save(`${getFileName()}.pdf`)
  }

  return {
    ...file,
    renderAll,
    getFileName,
    save,
  }
}

export const generateDisclaimerRecommendationFile = (
  title: string,
  text: string[]
) => {
  const disclaimerDoc = createDisclaimerDoc(title, text)
  disclaimerDoc.renderAll()
  return disclaimerDoc
}
