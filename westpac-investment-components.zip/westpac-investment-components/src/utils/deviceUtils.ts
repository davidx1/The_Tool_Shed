export const isExternalLink = function (url: string) {
  return url.indexOf('http://') > -1 || url.indexOf('https://') > -1
}

export const isNativeApp = function () {
  return !isExternalLink(window.document.URL)
}
