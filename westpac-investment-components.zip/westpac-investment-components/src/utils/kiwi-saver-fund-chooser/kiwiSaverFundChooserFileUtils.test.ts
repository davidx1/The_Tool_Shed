import { generateKiwisaverRecommendationFile } from './kiwiSaverFundChooserFileUtils'
import {
  GOAL_RETIREMENT,
  IKiwisaverFundType,
} from './kiwiSaverFundChooserUtils'
import { kiwisaverFundChooserConfig } from './__mocks__/kiwiSaverFundMockData'
import { pdfTextFn, saveFn } from '../../__mocks__/jspdf'

const CUSTOMER_AGE_33 = 33

jest.mock('moment', () => () =>
  jest.requireActual('moment')('2020-01-01T00:00:00.000Z')
)

describe('kiwiSaverFundChooserFileUtils', () => {
  const getPdfTextFnFormatted = () =>
    pdfTextFn.mock.calls.map((call) => call[0]).join('\n')

  it('generateKiwisaverRecommendationFile > Check PDF generation', () => {
    const userAnswers = [CUSTOMER_AGE_33, GOAL_RETIREMENT]
    const { doc, save } = generateKiwisaverRecommendationFile(
      userAnswers,
      kiwisaverFundChooserConfig
    )
    expect(doc.getNumberOfPages()).toBe(5)

    save()
    expect(saveFn).toHaveBeenCalledWith(
      'westpac-kiwisaver-recommendation-2020-01-01.pdf'
    )
  })

  it('generateKiwisaverRecommendationFile > Provide PDF for customer with single allocated fund', () => {
    const userAnswers = [CUSTOMER_AGE_33, GOAL_RETIREMENT]
    const allocatedFunds: IKiwisaverFundType[] = ['growth']
    generateKiwisaverRecommendationFile(
      userAnswers,
      kiwisaverFundChooserConfig,
      'John M.',
      allocatedFunds
    )
    expect(getPdfTextFnFormatted()).toMatchSnapshot()
  })

  it('generateKiwisaverRecommendationFile > Provide PDF for customer with multiple allocated fund', () => {
    const userAnswers = [CUSTOMER_AGE_33, GOAL_RETIREMENT]
    const allocatedFunds: IKiwisaverFundType[] = ['growth', 'conservative']
    generateKiwisaverRecommendationFile(
      userAnswers,
      kiwisaverFundChooserConfig,
      'Mark',
      allocatedFunds
    )
    expect(getPdfTextFnFormatted()).toMatchSnapshot()
  })

  it('generateKiwisaverRecommendationFile > Provide PDF for annonymous customer', () => {
    const userAnswers = [CUSTOMER_AGE_33, GOAL_RETIREMENT]
    generateKiwisaverRecommendationFile(userAnswers, kiwisaverFundChooserConfig)
    expect(getPdfTextFnFormatted()).toMatchSnapshot()
  })

  it('generateKiwisaverRecommendationFile > Provide PDF for default fund customer', () => {
    const userAnswers = [CUSTOMER_AGE_33, GOAL_RETIREMENT]
    generateKiwisaverRecommendationFile(
      userAnswers,
      kiwisaverFundChooserConfig,
      'Jenny',
      ['defensive', 'growth'],
      true
    )
    expect(getPdfTextFnFormatted()).toMatchSnapshot()
  })
})
