import moment from 'moment'
import autoTable from 'jspdf-autotable'

import { createPDF, interpolateValues } from '../pdfUtils'
import {
  IKiwisaverStep,
  IKiwisaverFundType,
  getFundChooserRecommendationSteps,
  IKiwisaverFundChooserConfig,
  IKiwisaverFundItem,
} from './kiwiSaverFundChooserUtils'
import { IAnswerStep } from '../../components/navigation/IQuestionnaire'

const createKiwisaverDoc = (
  answers: IAnswerStep[],
  recommendationStep: IKiwisaverStep | null,
  config: IKiwisaverFundChooserConfig,
  authenticated: boolean,
  compareDefaultFund?: boolean
) => {
  const file = createPDF({ pageNumberEnabled: false, btLogoVisible: true })
  const currentDate = moment().format('DD MMM YY')
  const { recommendation, recommendationDetails } = recommendationStep || {}

  const renderIntroduction = () => {
    file.renderTitle('Westpac KiwiSaver Scheme Fund Chooser.')
    file.renderHTML(
      interpolateValues(config.pdfContents.introduction, { currentDate })
    )
  }

  const renderRecommendationHeader = () => {
    if (!recommendation) return

    const { title, description } = recommendation
    file.renderTitle('Westpac recommends:')
    file.renderSubTitle(title)
    file.renderText(description.join('\n'))

    file.renderHTML(config.pdfContents.recommendationDetails)
  }

  const renderGraph = () => {
    file.renderSubTitle(
      `See how the ${recommendation?.shortname} Fund has performed`
    )
    file.renderText(recommendationDetails?.chartDescription || '', 0)
    file.renderGraphImage(
      recommendationDetails?.monthlyData,
      recommendation?.type,
      compareDefaultFund
    )
    file.renderDisclaimer(() => {
      file.renderHTML(config.pdfContents.graphDisclosures, 6)
    })
  }

  const renderQuestionAndAnswer = () => {
    file.renderTitle('Your questions and answers.')
    file.renderText(
      `The answers you provided on ${currentDate}`,
      undefined,
      undefined,
      'bold'
    )
    answers.forEach((answer) => {
      if (answer.question?.type !== 'confirmationModal') {
        const title = answer.question?.title || ''
        file.renderSubTitle(title, undefined, 0.05)
        const description = answer.answer.toString()
        file.renderText(description)
      }
    })

    file.renderMixedText(
      `Based on this we recommended the **${recommendation?.title}**`
    )

    file.renderText(recommendation?.description.join(' ') || '')

    file.renderSubTitle('More information')
    file.renderHTML(config.pdfContents.moreInformation)
    file.renderSpace(0.2)

    file.renderTitle('How to make a change.')
    file.renderHTML(config.pdfContents.howToChange)
    file.renderSpace(0.2)
  }

  const renderComparisonTable = () => {
    const comparisonColumns = [
      { title: '', dataField: 'shortname' },
      { title: 'Fund description', dataField: 'shortDescription' },
      { title: 'Average annual return*', dataField: 'averageAnnualReturn' },
      {
        title: 'Estimated annual fund charge^',
        dataField: 'annualFundChargePercent',
      },
      { title: 'Annual admin fee', dataField: 'adminFeePerYear' },
    ]

    const renderColumnValue = (item: IKiwisaverFundItem, column: string) => {
      switch (column) {
        case 'shortname':
          return `${item.shortname} Fund`
        case 'shortDescription':
          return item.shortDescription.map(file.cleanText).join('\n\n')
        case 'averageAnnualReturn':
        case 'annualFundChargePercent':
          return `${item[column]}%`
        case 'adminFeePerYear':
          return `$${item.adminFeePerYear}`
        default:
          return item[column]
      }
    }

    const head = [comparisonColumns.map((column) => column.title)]
    const body = recommendationDetails?.comparisonTable.map((fund) =>
      comparisonColumns.map((column) =>
        renderColumnValue(fund, column.dataField)
      )
    )

    file.renderSpace(-0.3)
    file.renderBackground('#F7F7F7')
    file.renderLogos()
    file.renderTitle('Fund comparison.', -0.05)
    file.renderTagImage()
    file.renderBackground('#FFFFFF')
    renderFundChooserTable(head, body, `${recommendation?.shortname} Fund`)
    file.renderDisclaimer(() => {
      const html = interpolateValues(config.pdfContents.comparisonDisclosures, {
        returnsUpdatedAt: config.returnsUpdatedAt,
      })
      file.renderHTML(html, 6)
    })
  }

  const renderDisclosures = () => {
    file.setCurrentY(8.3)
    file.renderDisclaimer(() => {
      file.renderHTML(config.pdfContents.disclosures, 8)
    })
  }

  const renderOtherInformation = () => {
    file.renderTitle('Other important information.', undefined, 22)
    file.renderHTML(config.pdfContents.otherInformation, 8, authenticated)
  }

  const renderAll = () => {
    renderIntroduction()
    file.renderBackground('#F7F7F7')
    renderRecommendationHeader()
    file.renderBackground('#FFFFFF')
    renderGraph()
    file.addPageBreak()
    file.enablePageNumber()
    renderQuestionAndAnswer()
    renderDisclosures()
    file.addPageBreak()
    renderComparisonTable()
    file.addPageBreak()
    renderOtherInformation()
    file.renderPageNumbers()
  }

  function renderFundChooserTable(
    head: any,
    body: any,
    recommendation?: string
  ) {
    let paintCell = false
    const {
      doc,
      margin,
      pageWidth,
      renderDotImage,
      setCurrentYBelowTable,
      getCurrentY,
    } = file

    autoTable(doc, {
      head,
      body,
      theme: 'plain',
      startY: getCurrentY() - 0.2,
      margin,
      tableWidth: pageWidth - margin * 2,
      bodyStyles: {
        fontStyle: 'bold',
        cellPadding: 0.16,
        fontSize: 7,
      },
      headStyles: {
        cellPadding: 0.16,
        fontSize: 7,
      },
      columnStyles: {
        0: { cellWidth: 1.2 },
      },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index === 1) {
          data.cell.styles.fontStyle = 'normal'
        }
        if (data.section === 'body' && data.column.index === 0) {
          paintCell = data.cell.text[0] === recommendation
        }
        if (paintCell) {
          data.cell.styles.fillColor = '#F4EDF2'
        }
      },
      didDrawCell: (data) => {
        doc.setFillColor(data.section === 'head' ? '#621A4B' : '#EBEBEB')
        const x = data.cell.x
        const y = data.cell.y + data.cell.height
        if (data.row.index !== body.length - 1) {
          // @ts-ignore-next-line -- library typings doesn't match this correct overload
          doc.line(x, y, x + data.cell.width, y, 'F')
        }
        if (
          data.section === 'body' &&
          data.column.index === 0 &&
          data.cell.text.join(' ') === recommendation
        ) {
          renderDotImage(x + 0.06, y - data.cell.height + 0.18)
        }
      },
      didDrawPage: setCurrentYBelowTable,
    })
  }

  function getFileName() {
    return `westpac-kiwisaver-recommendation-${moment().format('YYYY-MM-DD')}`
  }

  function save() {
    file.doc.save(`${getFileName()}.pdf`)
  }

  return {
    ...file,
    renderAll,
    getFileName,
    save,
  }
}

export const generateKiwisaverRecommendationFile = (
  userAnswers: (string | number)[],
  config: IKiwisaverFundChooserConfig,
  customerName?: string,
  _allocatedFunds?: IKiwisaverFundType[],
  compareDefaultFund?: boolean
) => {
  const { answerSteps, recommendation } = getFundChooserRecommendationSteps(
    userAnswers,
    config,
    compareDefaultFund
  )
  const kiwisaverDoc = createKiwisaverDoc(
    answerSteps,
    recommendation,
    config,
    !!customerName,
    compareDefaultFund
  )
  kiwisaverDoc.renderAll()
  return kiwisaverDoc
}
