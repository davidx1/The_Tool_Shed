import React from 'react'

import { GOAL_FIRST_HOME, USE_MORE_10_YEARS } from './kiwiSaverFundChooserUtils'

import { generateKiwisaverRecommendationFile } from './kiwiSaverFundChooserFileUtils'
import { kiwisaverFundChooserConfig } from './__mocks__/kiwiSaverFundMockData'

export default {
  title: 'KiwiSaver/generateKiwisaverRecommendationFile',
}

export const Basic = () => {
  const CUSTOMER_AGE_34 = 34
  const file = generateKiwisaverRecommendationFile(
    [CUSTOMER_AGE_34, GOAL_FIRST_HOME, USE_MORE_10_YEARS],
    kiwisaverFundChooserConfig,
    'John',
    ['conservative']
  )
  const uri = file.doc.output('datauristring')
  return (
    <div>
      <iframe src={uri} title="PDF Viewer" height="500" width="100%" />
      <button onClick={() => file.save()}>Download PDF</button>
    </div>
  )
}

Basic.parameters = {
  storyshots: false,
}
