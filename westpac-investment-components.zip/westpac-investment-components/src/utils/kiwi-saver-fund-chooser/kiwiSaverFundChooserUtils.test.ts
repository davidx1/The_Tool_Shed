import {
  getNextStepFundChooser,
  getMonthlyData,
  IKiwisaverStep,
  IKiwisaverMonthlyData,
  CONFIRMATION_AGE_BETWEEN_60_TO_64,
  GOAL_FIRST_HOME,
  GOAL_RETIREMENT,
  USE_WITHIN_1_YEAR,
  USE_1_2_YEARS,
  USE_3_4_YEARS,
  USE_5_6_YEARS,
  USE_7_9_YEARS,
  USE_MORE_10_YEARS,
  LOWER_RISK_OPTION,
  HIGHER_RISK_OPTION,
  KIWISAVER_EXPECTED_USAGE_65_YEARS,
  KIWISAVER_EXPECTED_USAGE_66_YEARS,
  KIWISAVER_EXPECTED_USAGE_67_YEARS,
  KIWISAVER_EXPECTED_USAGE_68_YEARS,
  KIWISAVER_EXPECTED_USAGE_70_YEARS,
  KIWISAVER_EXPECTED_USAGE_75_OR_OVER_YEARS,
  CONFIRMATION_UNDER_AGE,
  CONFIRMATION_AGE_FIRST_HOME_55_OR_OVER,
} from './kiwiSaverFundChooserUtils'
import { kiwisaverFundChooserConfig } from './__mocks__/kiwiSaverFundMockData'

import { threeMonthsRatesMockData } from './__mocks__/kiwiSaverFundMonthlyRatesMockData'

jest.mock('moment', () => () =>
  jest.requireActual('moment')('2020-01-01T00:00:00.000Z')
)

const CUSTOMER_AGE_17 = 17
const CUSTOMER_AGE_18 = 18
const CUSTOMER_AGE_20 = 20
const CUSTOMER_AGE_45 = 45
const CUSTOMER_AGE_54 = 54
const CUSTOMER_AGE_55 = 55
const CUSTOMER_AGE_60 = 60
const CUSTOMER_AGE_62 = 62
const CUSTOMER_AGE_63 = 63
const CUSTOMER_AGE_64 = 64

describe('getNextStepFundChooser > Saving for home tests', () => {
  it('As a customer aged 64 aiming to buy a home, the app should show a notification advising to call Westpac lending specialist for advice', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_64, CONFIRMATION_AGE_BETWEEN_60_TO_64, GOAL_FIRST_HOME],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('question')
    expect(step.question?.id).toBe(
      'QUESTION_CONFIRMATION_BUY_FIRST_HOME_AGE_55_OR_OVER'
    )
  })

  it('As a customer aged 54 aiming to buy a home in less that one year, after answering questions on the app, should be directed to CASH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_54, GOAL_FIRST_HOME, USE_WITHIN_1_YEAR],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('cash')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 54, has a goal of buying first home within a year.'
    )
  })

  it('As a customer aged 54 aiming to buy a home in 1-2 years with a small risk return on invested savings, after answering questions on the app, should be directed to CONSERVATIVE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_54, GOAL_FIRST_HOME, USE_1_2_YEARS, HIGHER_RISK_OPTION],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('conservative')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 54, has a goal of buying first home in 1 to 2 years selected higher risk preference.'
    )
  })

  it('As a customer aged 54 aiming to buy a home in 1-2 years with a lowest risk return on invested savings, after answering questions on the app, should be directed to CASH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_54, GOAL_FIRST_HOME, USE_1_2_YEARS, LOWER_RISK_OPTION],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('cash')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 54, has a goal of buying first home in 1 to 2 years selected lower risk preference.'
    )
  })

  it('As a customer aged 45 aiming to buy a home in 3-4 years, after answering questions on the app, should be directed to CONSERVATIVE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_45, GOAL_FIRST_HOME, USE_3_4_YEARS],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('conservative')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 45, has a goal of buying first home in 3 to 4 years.'
    )
  })

  it('As a customer aged 18 aiming to buy a home in 5-6 year, after answering questions on the app, should be directed to MODERATE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_18, GOAL_FIRST_HOME, USE_5_6_YEARS],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('moderate')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 18, has a goal of buying first home in 5 to 6 years.'
    )
  })

  it('As a customer aged 17 aiming to buy a home in 7-9 year, after answering questions on the app, should be directed to BALANCED FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_17, CONFIRMATION_UNDER_AGE, GOAL_FIRST_HOME, USE_7_9_YEARS],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('balanced')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 17, has a goal of buying first home in 7 to 9 years.'
    )
  })

  it('As a customer aged 20 aiming to buy a home in 10+ years, after answering questions on the app, should be directed to GROWTH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_20, GOAL_FIRST_HOME, USE_MORE_10_YEARS],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('growth')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 20, has a goal of buying first home in 10 years +.'
    )
  })
})

describe('getNextStepFundChooser > Saving for retirement tests', () => {
  it('As a customer aged 64 planning to start spending KiwiSaver fund by 65, then the app should direct to CASH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_64,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_65_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('cash')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 64, has a goal of retirement within a year.'
    )
  })

  it('As a customer aged 64 planning to start spending KiwiSaver fund by 66 with return on fund, then the app should direct to CONSERVATIVE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_64,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_66_YEARS,
        HIGHER_RISK_OPTION,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('conservative')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 64, has a goal of retirement in 2 years selected higher risk preference.'
    )
  })

  it('As a customer aged 63 planning to start spending KiwiSaver fund by 66, then the app should direct to CONSERVATIVE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_63,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_66_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('conservative')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 63, has a goal of retirement in 3 years.'
    )
  })

  it('As a customer aged 62 planning to start spending KiwiSaver fund by 67, then the app should direct to MODERATE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_62,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_67_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('moderate')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 62, has a goal of retirement in 5 years.'
    )
  })

  it('As a customer aged 64 planning to start spending KiwiSaver fund by 70, then the app should direct to MODERATE FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_64,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_70_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('moderate')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 64, has a goal of retirement in 6 years.'
    )
  })

  it('As a customer aged 63 planning to start spending KiwiSaver fund by 70, then the app should direct to BALANCED FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_63,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_70_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('balanced')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 63, has a goal of retirement in 7 years.'
    )
  })

  it('As a customer aged 60 planning to start spending KiwiSaver fund by 68, then the app should direct to BALANCED FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_60,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_68_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('balanced')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 60, has a goal of retirement in 8 years.'
    )
  })

  it('As a customer aged 55 planning to start spending KiwiSaver fund by 65, then the app should direct to GROWTH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_55, GOAL_RETIREMENT, KIWISAVER_EXPECTED_USAGE_65_YEARS],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('growth')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 55, has a goal of retirement in 10 years.'
    )
  })

  it('As a customer aged 64 planning to start spending KiwiSaver fund by >75, then the app should direct to GROWTH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_64,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_75_OR_OVER_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('growth')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 64, has a goal of retirement in 11 years.'
    )
  })

  it('As a customer aged 54 saving for retirement, then the app should direct to GROWTH FUND results page', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_54, GOAL_RETIREMENT],
      kiwisaverFundChooserConfig
    )

    expect(step.type).toBe('recommendation')
    expect(step.recommendation?.type).toBe('growth')
    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 54, has a goal of retirement.'
    )
  })
})

describe('getNextStepFundChooser > KiwiSaver for customer age >= 60 and <=64', () => {
  const closeToRetireAges = ['60', '62', '64']
  closeToRetireAges.forEach((customerAge) => {
    it(`As a customer aged ${customerAge}, the app should show a notification advising to call Westpac for advice but allow to continue using the app`, () => {
      const step: IKiwisaverStep = getNextStepFundChooser(
        [customerAge],
        kiwisaverFundChooserConfig
      )

      expect(step.type).toBe('question')
      expect(step.question?.id).toBe(
        'QUESTION_CONFIRMATION_AGE_BETWEEN_60_TO_64'
      )
    })
  })
})

describe('getNextStepFundChooser > Check for recommendation details', () => {
  it(`return correct chartDescription`, () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_45, GOAL_RETIREMENT],
      kiwisaverFundChooserConfig
    )
    expect(step.recommendationDetails?.chartDescription).toMatchSnapshot()
  })
})

describe('getNextStepFundChooser > KiwiSaver for customer age >= 65', () => {
  const retiredAges = ['65', '70']
  retiredAges.forEach((customerAge) => {
    it(`As a customer aged ${customerAge}, the app should show a notification advising to call Westpac for advice`, () => {
      const step: IKiwisaverStep = getNextStepFundChooser(
        [customerAge],
        kiwisaverFundChooserConfig
      )

      expect(step.type).toBe('question')
      expect(step.question?.id).toBe('QUESTION_CONFIRMATION_AGE_65_OR_OVER')
    })
  })
})

describe('getNextStepFundChooser > KiwiSaver for customer age >= 55 buying first home', () => {
  const over55Ages = ['55', '59']
  over55Ages.forEach((customerAge) => {
    it(`As a customer aged ${customerAge}, the app should show a notification advising to call Westpac lending specialist for advice`, () => {
      const step: IKiwisaverStep = getNextStepFundChooser(
        [customerAge, GOAL_FIRST_HOME, CONFIRMATION_AGE_FIRST_HOME_55_OR_OVER],
        kiwisaverFundChooserConfig
      )
      expect(step.type).toBe('question')
      expect(step.question?.id).toBe('QUESTION_YEARS_TO_BUY_FIRST_HOME')
    })
  })
})

describe('getNextStepFundChooser > KiwiSaver for customer under 18', () => {
  const under18Ages = ['0', '17']
  under18Ages.forEach((customerAge) => {
    it(`As a customer aged ${customerAge}, the app should show a notification advising to complete with parent or guardian`, () => {
      const step: IKiwisaverStep = getNextStepFundChooser(
        [customerAge],
        kiwisaverFundChooserConfig
      )

      expect(step.type).toBe('question')
      expect(step.question?.id).toBe('QUESTION_CONFIRMATION_UNDER_AGE')
    })
  })
})

describe('getNextStepFundChooser > Invalid values', () => {
  it(`Return null when passing a invalid combination`, () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [''],
      kiwisaverFundChooserConfig
    )

    expect(step).toBe(null)
  })
})

describe('getNextStepFundChooser > show defensive fund flag', () => {
  const ANSWERS_SAMPLE = [CUSTOMER_AGE_54, GOAL_RETIREMENT]
  it(`Return a recommendation that includes the defensive fund in the comparison table`, () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      ANSWERS_SAMPLE,
      kiwisaverFundChooserConfig,
      true
    )

    expect(step.recommendationDetails?.comparisonTable).toContainEqual(
      expect.objectContaining({ type: 'defensive' })
    )
  })

  it(`Return a recommendation that NOT includes the defensive fund in the comparison table`, () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      ANSWERS_SAMPLE,
      kiwisaverFundChooserConfig,
      false
    )

    expect(step.recommendationDetails?.comparisonTable).not.toContainEqual(
      expect.objectContaining({ type: 'defensive' })
    )
  })
})

describe('getMonthlyData > return correct monthly rates for each fund', () => {
  it(`calculates accurate monthly return for each fund`, () => {
    const monthlyData: IKiwisaverMonthlyData[] = getMonthlyData(
      100,
      threeMonthsRatesMockData
    )
    const lastMonthData = monthlyData.pop() as IKiwisaverMonthlyData

    expect(lastMonthData.cash.toFixed(2)).toBe('100.54')
    expect(lastMonthData.conservative.toFixed(2)).toBe('99.91')
    expect(lastMonthData.moderate.toFixed(2)).toBe('97.56')
    expect(lastMonthData.balanced.toFixed(2)).toBe('99.19')
    expect(lastMonthData.growth.toFixed(2)).toBe('99.69')
    expect(lastMonthData.defensive.toFixed(2)).toBe('99.07')
  })
})

describe('getNextStepFundChooser > human-readable format of the answers and recommendation + reporting data', () => {
  it('Conservative recommendation for first home goal', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [CUSTOMER_AGE_45, GOAL_FIRST_HOME, USE_1_2_YEARS, HIGHER_RISK_OPTION],
      kiwisaverFundChooserConfig
    )

    expect(step.customerInteraction?.subject).toBe(
      'KiwiSaver fund chooser tool recommends Conservative Fund 100%'
    )

    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 45, has a goal of buying first home in 1 to 2 years selected higher risk preference.'
    )

    expect(step.customerInteraction?.additionalInfo).toEqual(
      [
        '<data>',
        '<Age>45</Age>',
        '<Goal>First Home</Goal>',
        '<YearsToBuy>1 to 2 years</YearsToBuy>',
        '<ExpectedUsageDate>01/2022</ExpectedUsageDate>',
        '<WhatIsMoreImportant>The potential for somewhat higher investment returns, but with more risk of your savings going down between now and when you want them.</WhatIsMoreImportant>',
        '<Recommendation>conservative</Recommendation>',
        '</data>',
      ].join('')
    )
  })

  it('Moderate recommendation for retirement goal', () => {
    const step: IKiwisaverStep = getNextStepFundChooser(
      [
        CUSTOMER_AGE_60,
        CONFIRMATION_AGE_BETWEEN_60_TO_64,
        GOAL_RETIREMENT,
        KIWISAVER_EXPECTED_USAGE_65_YEARS,
      ],
      kiwisaverFundChooserConfig
    )

    expect(step.customerInteraction?.subject).toBe(
      'KiwiSaver fund chooser tool recommends Moderate Fund 100%'
    )

    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'Customer aged 60, has a goal of retirement in 5 years.'
    )

    expect(step.customerInteraction?.additionalInfo).toEqual(
      [
        '<data>',
        '<Age>60</Age>',
        '<Goal>Retirement</Goal>',
        '<ExpectedUsageAge>65</ExpectedUsageAge>',
        '<ExpectedUsageDate>01/2025</ExpectedUsageDate>',
        '<Recommendation>moderate</Recommendation>',
        '</data>',
      ].join('')
    )
  })
})
