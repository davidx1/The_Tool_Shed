import { format } from 'd3-format'
import {
  ICustomerInteraction,
  IQuestion,
} from '../../components/navigation/IQuestionnaire'
import { getNextStep, getRecommendationSteps } from '../questionnaireUtils'

import {
  IStep,
  ACTION_BUTTON_CLOSE_VALUE,
} from '../../components/navigation/IQuestionnaire'
import moment from 'moment'
import { ILink } from '../../components/navigation/ILink'

export interface IKiwisaverStep extends IStep {
  recommendation?: IKiwisaverFundItem
  recommendationDetails?: IKiwisaverRecommendationDetails
  customerInteraction?: ICustomerInteraction
}

export interface IKiwisaverRecommendationDetails {
  monthlyData: IKiwisaverMonthlyData[]
  initialYear: number
  initialDeposit: number
  comparisonTable: IKiwisaverFundItem[]
  chartDescription: string
}

export type IKiwisaverFundType =
  | 'cash'
  | 'conservative'
  | 'moderate'
  | 'balanced'
  | 'growth'
  | 'defensive'

export interface IKiwisaverFundItem {
  type: IKiwisaverFundType
  title: string
  shortname: string
  description: string[]
  shortDescription: string[]
  feeDetails: string[]
  adminFeePerYear: number
  averageAnnualReturn: number
  annualFundChargePercent: number
  annualFundChargeDescription: string
}

export type IKiwisaverFunds<T> = {
  [K in IKiwisaverFundType]: T
}

export interface IKiwisaverMonthlyData extends IKiwisaverFunds<number> {
  date: string
}

export interface ConfirmationModal {
  title: string
  body: string[]
  actionLabel?: string
}

export interface IKiwisaverFundChooserConfig {
  links: {
    kiwiSaverWealthOfficePhone: ILink
    kiwiSaverSpecialistsPhone: ILink
    kiwiSaverHomeLoansPhone: ILink
    kiwiSaverFAQs: string
    joinWestpac: string
    changeFund: string
    guardianForm: string
    infoKiwiSaver: string
    infoFirstHome: string
  }
  modals: {
    underAge: ConfirmationModal
    firstHomeAge55OrOver: ConfirmationModal
    ageBetween60to64: ConfirmationModal
    age65OrOver: ConfirmationModal
  }
  monthlyData: IKiwisaverMonthlyData[]
  fundItems: IKiwisaverFunds<IKiwisaverFundItem>
  beforeYouStart: string[]
  beforeYouStartSecondary: string[]
  beforeYouStartStaff: string[]
  disclaimers: string[]
  disclaimersLoggedUser: string[]
  recommendationDisclosures: string[]
  returnsUpdatedAt: string
  pdfContents: {
    introduction: string[]
    recommendationDetails: string[]
    graphDisclosures: string[]
    howToChange: string[]
    moreInformation: string[]
    disclosures: string[]
    comparisonDisclosures: string[]
    otherInformation: string[]
  }
}

export const CONFIRMATION_UNDER_AGE = 'Ok, I understand'
export const CONFIRMATION_AGE_FIRST_HOME_55_OR_OVER = 'I want to continue'
export const CONFIRMATION_AGE_BETWEEN_60_TO_64 = 'I want to continue'

export const GOAL_FIRST_HOME = 'First Home'
export const GOAL_RETIREMENT = 'Retirement'

export const USE_WITHIN_1_YEAR = 'Within a year'
export const USE_1_2_YEARS = '1 to 2 years'
export const USE_3_4_YEARS = '3 to 4 years'
export const USE_5_6_YEARS = '5 to 6 years'
export const USE_7_9_YEARS = '7 to 9 years'
export const USE_MORE_10_YEARS = '10 years +'

export const KIWISAVER_EXPECTED_USAGE_65_YEARS = 65
export const KIWISAVER_EXPECTED_USAGE_66_YEARS = 66
export const KIWISAVER_EXPECTED_USAGE_67_YEARS = 67
export const KIWISAVER_EXPECTED_USAGE_68_YEARS = 68
export const KIWISAVER_EXPECTED_USAGE_69_YEARS = 69
export const KIWISAVER_EXPECTED_USAGE_70_YEARS = 70
export const KIWISAVER_EXPECTED_USAGE_71_YEARS = 71
export const KIWISAVER_EXPECTED_USAGE_72_YEARS = 72
export const KIWISAVER_EXPECTED_USAGE_73_YEARS = 73
export const KIWISAVER_EXPECTED_USAGE_74_YEARS = 74
export const KIWISAVER_EXPECTED_USAGE_75_OR_OVER_YEARS = '75 or over'

export const LOWER_RISK_OPTION =
  'The lowest risk of your savings going down significantly between now and when you want them. This means you should expect very low investment returns.'
export const HIGHER_RISK_OPTION =
  'The potential for somewhat higher investment returns, but with more risk of your savings going down between now and when you want them.'

function createKiwiSaverFundChooserFlow(config: IKiwisaverFundChooserConfig) {
  /* -----------------------------------------------
                      Questions
   ----------------------------------------------- */

  const QUESTION_AGE: IQuestion = {
    id: 'QUESTION_AGE',
    type: 'text',
    title: 'First of all, what’s your current age?',
    label: 'Enter your age',
    inputOptions: {
      type: 'number',
      min: 0,
    },
    information: {
      body: [
        'By telling us your age, you help us work out how long it will be until you’re able to withdraw your savings. For many people, this is from now until you reach retirement.',
      ],
      icon: 'timeline',
      callUs: config.links.kiwiSaverSpecialistsPhone,
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_CONFIRMATION_UNDER_AGE: IQuestion = {
    id: 'QUESTION_CONFIRMATION_UNDER_AGE',
    type: 'confirmationModal',
    title: config.modals.underAge.title,
    confirmationModalOptions: {
      body: config.modals.underAge.body,
      actionButtons: [
        {
          value: CONFIRMATION_UNDER_AGE,
        },
      ],
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_CONFIRMATION_BUY_FIRST_HOME_AGE_55_OR_OVER: IQuestion = {
    id: 'QUESTION_CONFIRMATION_BUY_FIRST_HOME_AGE_55_OR_OVER',
    type: 'confirmationModal',
    title: config.modals.firstHomeAge55OrOver.title,
    confirmationModalOptions: {
      body: config.modals.firstHomeAge55OrOver.body,
      actionButtons: [
        {
          value: CONFIRMATION_AGE_FIRST_HOME_55_OR_OVER,
          description: config.modals.firstHomeAge55OrOver.actionLabel,
        },
      ],
    },
  }
  /* ----------------------------------------------- */

  const QUESTION_CONFIRMATION_AGE_BETWEEN_60_TO_64: IQuestion = {
    id: 'QUESTION_CONFIRMATION_AGE_BETWEEN_60_TO_64',
    type: 'confirmationModal',
    title: config.modals.ageBetween60to64.title,
    confirmationModalOptions: {
      body: config.modals.ageBetween60to64.body,
      actionButtons: [
        {
          value: CONFIRMATION_AGE_BETWEEN_60_TO_64,
          description: config.modals.ageBetween60to64.actionLabel,
        },
      ],
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_CONFIRMATION_AGE_65_OR_OVER: IQuestion = {
    id: 'QUESTION_CONFIRMATION_AGE_65_OR_OVER',
    type: 'confirmationModal',
    title: config.modals.age65OrOver.title,
    confirmationModalOptions: {
      body: config.modals.age65OrOver.body,
      actionButtons: [
        {
          label: 'Close Fund Chooser',
          value: ACTION_BUTTON_CLOSE_VALUE,
          description: config.modals.age65OrOver.actionLabel,
        },
      ],
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_KIWISAVER_GOAL: IQuestion = {
    id: 'QUESTION_KIWISAVER_GOAL',
    type: 'radioGroup',
    title: 'What will you be using your KiwiSaver savings for first?',
    options: [GOAL_FIRST_HOME, GOAL_RETIREMENT],
    icons: ['houseOnly', 'palmTree'],
    information: {
      body: [
        'Generally, you can’t withdraw your KiwiSaver savings until 65, or to buy your first home.',
      ],
      icon: 'kiwiSaver',
      callUs: config.links.kiwiSaverSpecialistsPhone,
      moreInfoUrl: config.links.infoKiwiSaver,
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_YEARS_TO_BUY_FIRST_HOME: IQuestion = {
    id: 'QUESTION_YEARS_TO_BUY_FIRST_HOME',
    type: 'dropdown',
    title: 'When do you think you will be buying your first home?',
    label: 'Pick a range',
    options: [
      USE_WITHIN_1_YEAR,
      USE_1_2_YEARS,
      USE_3_4_YEARS,
      USE_5_6_YEARS,
      USE_7_9_YEARS,
      USE_MORE_10_YEARS,
    ],
    information: {
      body: [
        'If you’re eligible you can use your KiwiSaver funds to help buy your first home but you must be planning to live in it and meet the other eligibility requirements.',
      ],
      icon: 'houseDollar',
      callUs: config.links.kiwiSaverSpecialistsPhone,
      moreInfoUrl: config.links.infoFirstHome,
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_EXPECTED_AGE_TO_USE_KIWISAVER: IQuestion = {
    id: 'QUESTION_EXPECTED_AGE_TO_USE_KIWISAVER',
    type: 'dropdown',
    title: 'At what age do you plan to start spending your KiwiSaver savings?',
    label: 'Pick an age',
    options: [
      KIWISAVER_EXPECTED_USAGE_65_YEARS,
      KIWISAVER_EXPECTED_USAGE_66_YEARS,
      KIWISAVER_EXPECTED_USAGE_67_YEARS,
      KIWISAVER_EXPECTED_USAGE_68_YEARS,
      KIWISAVER_EXPECTED_USAGE_69_YEARS,
      KIWISAVER_EXPECTED_USAGE_70_YEARS,
      KIWISAVER_EXPECTED_USAGE_71_YEARS,
      KIWISAVER_EXPECTED_USAGE_72_YEARS,
      KIWISAVER_EXPECTED_USAGE_73_YEARS,
      KIWISAVER_EXPECTED_USAGE_74_YEARS,
      KIWISAVER_EXPECTED_USAGE_75_OR_OVER_YEARS,
    ],
    information: {
      body: [
        'If you don’t intend to start spending your KiwiSaver savings until you’re a bit older than 65, we’ll recommend a fund that takes that into account.',
      ],
      icon: 'palmTree',
      callUs: config.links.kiwiSaverSpecialistsPhone,
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_WHAT_IS_MORE_IMPORTANT: IQuestion = {
    id: 'QUESTION_WHAT_IS_MORE_IMPORTANT',
    type: 'dropdown',
    title:
      'Given you’re planning to withdraw your KiwiSaver savings soon, what’s more important to you?',
    label: 'Pick an option',
    options: [LOWER_RISK_OPTION, HIGHER_RISK_OPTION],
    information: {
      body: [
        'It’s important to remember to check back on your fund choice as you get closer to using your KiwiSaver savings or if your plans change.',
      ],
      icon: 'plantGrowth',
      callUs: config.links.kiwiSaverSpecialistsPhone,
    },
  }

  /* -----------------------------------------------
                        Steps
     ----------------------------------------------- */

  const isBetween = (value: number, min: number, max: number) =>
    value >= min && value <= max

  const KIWISAVER_INITIAL_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_AGE,
    estimatedProgress: 0,
    getNextStep: (values, customerInteraction) => {
      const customerAge = values[QUESTION_AGE.id]
      customerInteraction.whyProductSuitable += `Customer aged ${customerAge}, `
      customerInteraction.additionalInfo += `<Age>${customerAge}</Age>`
      if (customerAge < 18) {
        return CONFIRM_UNDER_AGE_STEP
      } else if (customerAge >= 60 && customerAge <= 64) {
        return CONFIRM_AGE_BETWEEN_60_TO_64_STEP
      } else if (customerAge >= 65) {
        return CONFIRM_AGE_65_OR_OVER_STEP
      }
      return BUY_GOAL_FIRST_HOME_STEP
    },
  }

  const CONFIRM_UNDER_AGE_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_CONFIRMATION_UNDER_AGE,
    estimatedProgress: 10,
    getNextStep: (values) => {
      if (
        values[QUESTION_CONFIRMATION_UNDER_AGE.id] === CONFIRMATION_UNDER_AGE
      ) {
        return BUY_GOAL_FIRST_HOME_STEP
      }
      return null
    },
  }

  const CONFIRM_AGE_BETWEEN_60_TO_64_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_CONFIRMATION_AGE_BETWEEN_60_TO_64,
    estimatedProgress: 10,
    getNextStep: (values) => {
      if (
        values[QUESTION_CONFIRMATION_AGE_BETWEEN_60_TO_64.id] ===
        CONFIRMATION_AGE_BETWEEN_60_TO_64
      ) {
        return BUY_GOAL_FIRST_HOME_STEP
      }
      return null
    },
  }

  const CONFIRM_AGE_65_OR_OVER_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_CONFIRMATION_AGE_65_OR_OVER,
    estimatedProgress: 100,
    getNextStep: () => null,
  }

  const BUY_GOAL_FIRST_HOME_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_KIWISAVER_GOAL,
    estimatedProgress: 30,
    getNextStep: (values, customerInteraction) => {
      const customerAge = values[QUESTION_AGE.id] as number
      const goal = values[QUESTION_KIWISAVER_GOAL.id]
      customerInteraction.additionalInfo += `<Goal>${goal}</Goal>`
      if (goal === GOAL_FIRST_HOME) {
        customerInteraction.whyProductSuitable += `has a goal of buying first home `
        if (customerAge >= 55) {
          return CONFIRM_BUY_FIRST_HOME_AGE_55_OR_OVER_STEP
        }
        return YEARS_TO_BUY_FIRST_HOME_STEP
      } else {
        if (isBetween(customerAge, 55, 64)) {
          customerInteraction.whyProductSuitable += `has a goal of retirement `
          return EXPECTED_AGE_TO_USE_KIWISAVER_STEP
        }
        customerInteraction.whyProductSuitable += `has a goal of retirement.`
        return getRecommendation('growth', customerInteraction)
      }
    },
  }

  const CONFIRM_BUY_FIRST_HOME_AGE_55_OR_OVER_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_CONFIRMATION_BUY_FIRST_HOME_AGE_55_OR_OVER,
    estimatedProgress: 40,
    getNextStep: (values) => {
      if (
        values[QUESTION_CONFIRMATION_BUY_FIRST_HOME_AGE_55_OR_OVER.id] ===
        CONFIRMATION_AGE_FIRST_HOME_55_OR_OVER
      ) {
        return YEARS_TO_BUY_FIRST_HOME_STEP
      }
      return null
    },
  }

  const addExpectedUsageDate = (
    customerInteraction: ICustomerInteraction,
    investHorizon: number
  ) => {
    const formatted = moment().add(investHorizon, 'year').format('MM/YYYY')
    customerInteraction.additionalInfo += `<ExpectedUsageDate>${formatted}</ExpectedUsageDate>`
  }

  const YEARS_TO_BUY_FIRST_HOME_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_YEARS_TO_BUY_FIRST_HOME,
    estimatedProgress: 50,
    getNextStep: (values, customerInteraction) => {
      const yearsToBuy = values[QUESTION_YEARS_TO_BUY_FIRST_HOME.id]
      customerInteraction.additionalInfo += `<YearsToBuy>${yearsToBuy}</YearsToBuy>`

      switch (yearsToBuy) {
        case USE_WITHIN_1_YEAR:
          addExpectedUsageDate(customerInteraction, 1)
          customerInteraction.whyProductSuitable += `${USE_WITHIN_1_YEAR.toLowerCase()}.`

          return getRecommendation('cash', customerInteraction)
        case USE_1_2_YEARS:
          addExpectedUsageDate(customerInteraction, 2)
          customerInteraction.whyProductSuitable += `in ${USE_1_2_YEARS} `
          return WHAT_IS_MORE_IMPORTANT_STEP
        case USE_3_4_YEARS:
          addExpectedUsageDate(customerInteraction, 4)
          customerInteraction.whyProductSuitable += `in ${USE_3_4_YEARS}.`
          return getRecommendation('conservative', customerInteraction)
        case USE_5_6_YEARS:
          addExpectedUsageDate(customerInteraction, 6)
          customerInteraction.whyProductSuitable += `in ${USE_5_6_YEARS}.`
          return getRecommendation('moderate', customerInteraction)
        case USE_7_9_YEARS:
          addExpectedUsageDate(customerInteraction, 9)
          customerInteraction.whyProductSuitable += `in ${USE_7_9_YEARS}.`
          return getRecommendation('balanced', customerInteraction)
        case USE_MORE_10_YEARS:
          addExpectedUsageDate(customerInteraction, 10)
          customerInteraction.whyProductSuitable += `in ${USE_MORE_10_YEARS}.`
          return getRecommendation('growth', customerInteraction)
        default:
          return null
      }
    },
  }

  const EXPECTED_AGE_TO_USE_KIWISAVER_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_EXPECTED_AGE_TO_USE_KIWISAVER,
    isLastStep: false,
    estimatedProgress: 70,
    getNextStep: (values, customerInteraction) => {
      let expectedUsageAge = values[QUESTION_EXPECTED_AGE_TO_USE_KIWISAVER.id]
      if (expectedUsageAge === KIWISAVER_EXPECTED_USAGE_75_OR_OVER_YEARS) {
        expectedUsageAge = 75
      }
      const investHorizon =
        (expectedUsageAge as number) - (values[QUESTION_AGE.id] as number)
      customerInteraction.additionalInfo += `<ExpectedUsageAge>${expectedUsageAge}</ExpectedUsageAge>`

      addExpectedUsageDate(customerInteraction, investHorizon)
      if (investHorizon <= 1) {
        customerInteraction.whyProductSuitable += `${USE_WITHIN_1_YEAR.toLowerCase()}.`

        return getRecommendation('cash', customerInteraction)
      }
      if (investHorizon <= 2) {
        customerInteraction.whyProductSuitable += `in ${investHorizon} years `
        return WHAT_IS_MORE_IMPORTANT_STEP
      }
      customerInteraction.whyProductSuitable += `in ${investHorizon} years.`
      if (investHorizon <= 4) {
        return getRecommendation('conservative', customerInteraction)
      } else if (investHorizon <= 6) {
        return getRecommendation('moderate', customerInteraction)
      } else if (investHorizon <= 9) {
        return getRecommendation('balanced', customerInteraction)
      }
      return getRecommendation('growth', customerInteraction)
    },
  }

  const WHAT_IS_MORE_IMPORTANT_STEP: IKiwisaverStep = {
    type: 'question',
    question: QUESTION_WHAT_IS_MORE_IMPORTANT,
    estimatedProgress: 90,
    isLastStep: true,
    getNextStep: (values, customerInteraction) => {
      const whatIsMoreImportant = values[QUESTION_WHAT_IS_MORE_IMPORTANT.id]
      customerInteraction.additionalInfo += `<WhatIsMoreImportant>${whatIsMoreImportant}</WhatIsMoreImportant>`

      if (whatIsMoreImportant === LOWER_RISK_OPTION) {
        customerInteraction.whyProductSuitable += `selected lower risk preference.`

        return getRecommendation('cash', customerInteraction)
      } else {
        customerInteraction.whyProductSuitable += `selected higher risk preference.`

        return getRecommendation('conservative', customerInteraction)
      }
    },
  }

  const getChartDescription = (
    recommendation: IKiwisaverFundItem,
    initialDeposit: number,
    initialYear: number
  ) => {
    const initialDepositFormatted = format(',.0f')(initialDeposit)
    return `This graph shows you what would’ve happened if you had put $${initialDepositFormatted} 
      in the ${recommendation.shortname} Fund in ${initialYear}. Make sure you’re comfortable 
      with how much you may see your balance go up and down in the future if you choose to put your savings 
      in the ${recommendation.shortname} Fund. Keep in mind that the graph shows past performance and the funds 
      may perform differently in the future.`
  }

  const getFundDetails = (
    recommendation: IKiwisaverFundItem,
    initialDeposit: number = 10000
  ) => {
    const initialYear = 2008
    const monthlyData = getMonthlyData(initialDeposit, config.monthlyData)
    return {
      monthlyData,
      initialYear,
      initialDeposit,
      chartDescription: getChartDescription(
        recommendation,
        initialDeposit,
        initialYear
      ),
      comparisonTable: [
        config.fundItems.cash,
        config.fundItems.conservative,
        config.fundItems.moderate,
        config.fundItems.balanced,
        config.fundItems.growth,
      ],
    } as IKiwisaverRecommendationDetails
  }

  const getRecommendation = (
    type: IKiwisaverFundType,
    customerInteraction: ICustomerInteraction
  ) => {
    const recommendation = config.fundItems[type]
    customerInteraction.subject = `KiwiSaver fund chooser tool recommends ${recommendation.shortname} Fund 100%`
    customerInteraction.additionalInfo += `<Recommendation>${type}</Recommendation>`
    customerInteraction.additionalInfo = `<data>${customerInteraction.additionalInfo}</data>`
    const recommendationStep: IKiwisaverStep = {
      recommendation,
      type: 'recommendation',
      estimatedProgress: 100,
      recommendationDetails: getFundDetails(recommendation),
      customerInteraction,
    }
    return recommendationStep
  }

  return KIWISAVER_INITIAL_STEP
}

export const getMonthlyData = (
  initialDeposit: number = 10000,
  monthlyRates: IKiwisaverMonthlyData[] = []
) => {
  const monthlyData: IKiwisaverMonthlyData[] = []
  const currentValue = {
    cash: initialDeposit,
    conservative: initialDeposit,
    balanced: initialDeposit,
    moderate: initialDeposit,
    growth: initialDeposit,
    defensive: initialDeposit,
  }
  monthlyRates.forEach((item) => {
    currentValue.cash += (currentValue.cash * item.cash) / 100
    currentValue.conservative +=
      (currentValue.conservative * item.conservative) / 100
    currentValue.balanced += (currentValue.balanced * item.balanced) / 100
    currentValue.moderate += (currentValue.moderate * item.moderate) / 100
    currentValue.growth += (currentValue.growth * item.growth) / 100
    currentValue.defensive += (currentValue.defensive * item.defensive) / 100
    monthlyData.push({
      date: item.date,
      ...currentValue,
    })
  })

  return monthlyData
}

const addDefaultFundData = (
  step: IKiwisaverStep,
  config: IKiwisaverFundChooserConfig
) => {
  if (step?.type === 'recommendation') {
    const comparisonTable = step.recommendationDetails?.comparisonTable
    comparisonTable?.splice(1, 0, config.fundItems.defensive)
  }
}

export const getNextStepFundChooser = (
  userAnswers: (string | number)[],
  config: IKiwisaverFundChooserConfig,
  compareDefaultFund?: boolean
) => {
  const initialStep = createKiwiSaverFundChooserFlow(config)
  const step = getNextStep(userAnswers, initialStep)
  if (compareDefaultFund) {
    addDefaultFundData(step, config)
  }
  return step as IKiwisaverStep
}

export const getFundChooserRecommendationSteps = (
  userAnswers: (string | number)[],
  config: IKiwisaverFundChooserConfig,
  compareDefaultFund?: boolean
) => {
  const initialStep = createKiwiSaverFundChooserFlow(config)
  const steps = getRecommendationSteps(userAnswers, initialStep)
  const recommendationStep = steps.recommendation as IKiwisaverStep
  if (recommendationStep && compareDefaultFund) {
    addDefaultFundData(recommendationStep, config)
  }
  return steps
}
