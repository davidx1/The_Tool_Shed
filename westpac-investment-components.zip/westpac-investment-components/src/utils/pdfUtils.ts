import { jsPDF } from 'jspdf'
import {
  IKiwisaverMonthlyData,
  IKiwisaverFundType,
} from './kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
import getGraphImage from './pdfGraphUtils'

type TextAlign = 'left' | 'center' | 'right'

const assetsUrl = 'https://assets.westpac.co.nz/w1/investment-tools/pdf-images'

const WESTPAC_LOGO = `${assetsUrl}/westpac-logo.png`
const TOP_PAGE_IMAGE = `${assetsUrl}/top-bar.png`
const RECOMMENDED_TAG_IMAGE = `${assetsUrl}/recommended-tag.png`
const RECOMMENDED_DOT_IMAGE = `${assetsUrl}/recommended-dot.png`
const BT_LOGO = `${assetsUrl}/bt-logo.png`

const FontStyle = {
  bold: 'bold',
  normal: 'normal',
}

interface InitialConfig {
  btLogoVisible: boolean
  pageNumberEnabled: boolean
}

export function createPDF(initialConfig: Partial<InitialConfig> = {}) {
  const fontName = 'Helvetica'
  const pageWidth = 8.5
  const pageHeight = 11.9
  const lineHeight = 1.3
  const ptsPerInch = 72
  const boxHeight = 1.43

  const config = {
    btLogoVisible: false,
    pageNumberEnabled: true,
    ...initialConfig,
  }

  let pagesWithNumber: number[] = config.pageNumberEnabled ? [1] : []
  let currentY = 0
  let margin = 0.4

  const getMaxLineWidth = () => pageWidth - margin * 2
  const getBoxWidth = () => (pageWidth - margin * 5) / 3

  /* -----------------------------------------------
                      Setup
   ----------------------------------------------- */
  const doc = new jsPDF({
    unit: 'in',
    format: [pageWidth, pageHeight],
  })
  resetContentY()

  /* -----------------------------------------------
                      Render utils
   ----------------------------------------------- */
  function renderImage(
    image: string,
    imageName: string,
    width: number,
    height: number,
    x: number = margin,
    y: number = currentY
  ) {
    try {
      // @ts-ignore-next-line -- library typings doesn't match this correct overload
      doc.addImage(image, 'PNG', x, y, width, height, imageName, 'FAST')
    } catch (error) {
      console.info('Image not available\n', error)
    }
  }

  function renderLogos() {
    const logoHeight = 0.26
    const logoWidth = 0.62

    const xPosition = getXPosition('right') - logoWidth

    renderImage(WESTPAC_LOGO, 'logo', logoWidth, logoHeight, xPosition)

    if (config.btLogoVisible) {
      renderImage(
        BT_LOGO,
        'bt-logo',
        0.6,
        logoHeight,
        xPosition - logoWidth - 0.12
      )
    }
  }

  function renderTopImage() {
    const imageHeight = 0.14
    const imageWidth = pageWidth

    renderImage(TOP_PAGE_IMAGE, 'topImage', imageWidth, imageHeight, 0, 0)

    currentY = imageHeight
  }

  function renderTagImage() {
    const imageHeight = 0.44
    const imageWidth = 1.4

    renderImage(RECOMMENDED_TAG_IMAGE, 'tag', imageWidth, imageHeight, 0.3)

    currentY += imageHeight + margin / 2
  }

  function renderDotImage(x: number, y: number) {
    const imageHeight = 0.05
    const imageWidth = 0.05

    renderImage(RECOMMENDED_DOT_IMAGE, 'dot', imageWidth, imageHeight, x, y)
  }

  function renderPhotoImage(imageUrl: string) {
    const imageHeight = 1.875
    const imageWidth = 2.75

    renderImage(imageUrl, 'photo', imageWidth, imageHeight)
  }

  function renderIcon(imageUrl: string, index: number) {
    const imageHeight = 0.7
    const imageWidth = 0.7

    renderImage(imageUrl, `icon-${index}`, imageWidth, imageHeight)
  }

  function renderGraphImage(
    data?: IKiwisaverMonthlyData[],
    recommendedType: IKiwisaverFundType = 'growth',
    compareDefaultFund?: boolean
  ) {
    const imageHeight = 3.8
    const imageWidth = pageWidth - margin * 2
    renderSeparator()

    const dataUrl = getGraphImage(data, recommendedType, compareDefaultFund)
    if (dataUrl) {
      renderImage(dataUrl, 'graph', imageWidth, imageHeight)

      currentY += imageHeight - 0.2
    }
    renderSeparator()
  }

  function renderBackground(color: string) {
    doc.setFillColor(color)
    doc.rect(0, currentY, pageWidth, pageHeight - currentY, 'F')
    currentY += 0.2
  }

  function renderBox(startX: number) {
    const offset = startX + margin
    const boxWidth = getBoxWidth()
    doc.setLineWidth(2)
    doc.setFillColor('#949494')
    // @ts-ignore-next-line -- library typings doesn't match this correct overload
    doc.line(offset, currentY, offset + boxWidth, currentY, 'F')
    // @ts-ignore-next-line -- library typings doesn't match this correct overload
    doc.line(offset, currentY, offset, currentY + boxHeight, 'F')
    doc.line(
      offset,
      currentY + boxHeight,
      offset + boxWidth,
      currentY + boxHeight,
      // @ts-ignore-next-line -- library typings doesn't match this correct overload
      'F'
    )
    doc.line(
      offset + boxWidth,
      currentY,
      offset + boxWidth,
      currentY + boxHeight,
      // @ts-ignore-next-line -- library typings doesn't match this correct overload
      'F'
    )
  }

  function renderMixedText(
    textString: string,
    marginBottom: number = 0.2,
    fontSize: number = 10,
    separator: string = '**',
    offset: number = margin
  ) {
    let startX = offset
    let startY = currentY

    const endX = pageWidth - margin
    const text = cleanText(injectUrlsIntoText(textString))
    doc.setFont(fontName, FontStyle.bold)
    doc.setFontSize(fontSize)
    let textMap = doc.splitTextToSize(text, endX)

    const height = calculateLineHeight(fontSize)

    const isBoldOpen = (arrayLength: number, valueBefore: boolean = false) => {
      const isEven = arrayLength % 2 === 0
      return valueBefore !== isEven
    }

    const startXCached = startX
    let boldOpen = false
    textMap.forEach((text: string) => {
      if (text) {
        const arrayOfNormalAndBoldText = text.split(separator)

        arrayOfNormalAndBoldText.forEach((textItems, j) => {
          doc.setFont(fontName, boldOpen ? FontStyle.normal : FontStyle.bold)
          if (j % 2 === 0) {
            doc.setFont(fontName, boldOpen ? FontStyle.bold : FontStyle.normal)
          }
          doc.text(textItems, startX, startY, {
            baseline: 'top',
          })
          startX = startX + doc.getTextWidth(textItems) + 0.02
        })
        boldOpen = isBoldOpen(arrayOfNormalAndBoldText.length, boldOpen)
        startX = startXCached
        startY += height
      }
    })

    currentY = startY
    renderSpace(marginBottom)
  }

  function calculateLineHeight(fontSize: number) {
    return ((fontSize * lineHeight) / ptsPerInch) * 1.1
  }

  function renderText(
    text: string,
    marginBottom: number = 0.2,
    fontSize: number = 10,
    fontStyle: 'normal' | 'bold' | 'italic' = 'normal',
    align: TextAlign = 'left',
    keepSameLine?: boolean,
    startX?: number
  ) {
    const textLines = doc
      .setFont(fontName, fontStyle)
      .setFontSize(fontSize)
      .splitTextToSize(
        cleanText(injectUrlsIntoText(text)),
        getMaxLineWidth() - (startX || 0)
      )

    const height = calculateLineHeight(fontSize)

    let nextY = currentY
    textLines.forEach((line: string) => {
      if (nextY > getBoundaryBottom()) {
        addPageBreak(true)
        nextY = currentY
      }

      doc.text(line, startX || getXPosition(align), nextY, {
        baseline: 'top',
        align,
      })
      nextY += height
    })

    if (!keepSameLine) {
      currentY = nextY
      renderSpace(marginBottom)
    }
  }

  function renderTextWithLink(
    text: string,
    url: string,
    startX: number,
    fontSize: number = 10,
    fontStyle: 'normal' | 'bold' | 'italic' = 'bold'
  ) {
    doc.setFont(fontName, fontStyle)
    const height = (fontSize * lineHeight) / ptsPerInch

    doc.textWithLink(cleanText(text), startX, currentY, { url })
    currentY += height
  }

  function renderTitle(
    title: string,
    marginBottom: number = 0.12,
    fontSize: number = 18
  ) {
    renderText(title, marginBottom, fontSize, 'bold', undefined)
  }

  const renderSubTitle = (
    title: string,
    fontSize: number = 10,
    marginBottom: number = 0.08
  ) => renderText(title, marginBottom, fontSize, 'bold')

  function renderSpace(space: number) {
    if (!space) return

    if (currentY + space > getBoundaryBottom()) {
      addPageBreak(true)
    } else {
      currentY += space
    }
  }

  function renderDisclaimer(render: () => void) {
    doc.setTextColor('#636363')
    render()
    doc.setTextColor('#222222')
  }

  function renderDisclaimerText(text: string) {
    renderDisclaimer(() => {
      renderText(text, undefined, 8)
    })
  }

  function setCurrentYBelowTable(data: any) {
    const cursorY = data.cursor?.y
    if (cursorY) {
      currentY = cursorY + 0.2
    }
  }

  function renderSeparator() {
    renderSpace(margin / 2)
    doc.setFillColor('#EBEBEB')
    // @ts-ignore-next-line -- library typings doesn't match this correct overload
    doc.line(margin, currentY, pageWidth - margin, currentY, 'F')
    renderSpace(margin / 2)
  }

  function renderHTML(
    html: string[],
    fontSize: number = 10,
    authenticated?: boolean
  ) {
    html.forEach((line) => {
      if (!line.includes('<authenticated/>') || authenticated) {
        if (line === '<pageBreak/>') {
          addPageBreak()
          renderSpace(0.4)
        } else if (line.includes('<h6>')) {
          renderSubTitle(line, fontSize)
        } else {
          const isListItem = line.includes('<li>')
          if (isListItem) {
            doc.circle(margin + 0.02, currentY + 0.06, 0.02, 'F')
            margin += 0.1
          }
          const hasBottomMargin =
            line.includes('</p>') || line.includes('</ul>')
          renderMixedText(line, hasBottomMargin ? undefined : 0, fontSize)
          if (isListItem) {
            margin -= 0.1
          }
        }
      }
    })
  }

  function renderHeader(hideLogo?: boolean) {
    renderTopImage()
    resetContentY()
    !hideLogo && renderLogos()
  }

  /* -----------------------------------------------
                      Utilities
   ----------------------------------------------- */
  function getCurrentY() {
    return currentY
  }

  function setCurrentY(value: number) {
    currentY = value
  }

  function resetContentY() {
    currentY = margin
  }

  function addPageBreak(hideLogo?: boolean) {
    if (currentY > 1) {
      doc.addPage()
      if (config.pageNumberEnabled) {
        pagesWithNumber.push(doc.getCurrentPageInfo().pageNumber)
      }
      renderHeader(hideLogo)
    }
  }

  function enablePageNumber() {
    config.pageNumberEnabled = true
    pagesWithNumber.push(doc.getCurrentPageInfo().pageNumber)
  }

  function disablePageNumber() {
    config.pageNumberEnabled = false
    const currentPage = doc.getCurrentPageInfo().pageNumber
    pagesWithNumber = pagesWithNumber.filter((page) => page !== currentPage)
  }

  function showBTLogo() {
    config.btLogoVisible = true
  }

  function getBoundaryBottom() {
    const boundaryBottom = pageHeight - margin
    if (config.pageNumberEnabled) {
      return boundaryBottom - 0.3
    }
    return boundaryBottom
  }

  function renderPageNumbers() {
    const numberOfPages = doc.getNumberOfPages()
    for (let index = 0; index < numberOfPages; index++) {
      if (pagesWithNumber.includes(index + 1)) {
        doc.setFont(fontName, FontStyle.normal)
        doc.setFontSize(8)
        doc.setTextColor('#222222')
        const pageString = `Page ${index + 1}`
        const pageStringWidth = doc.getTextWidth(pageString)
        doc.setPage(index + 1)
        doc.text('Westpac New Zealand Limited.', margin, pageHeight - margin)
        doc.text(
          pageString,
          pageWidth - pageStringWidth - margin,
          pageHeight - margin
        )
      }
    }
  }

  function injectUrlsIntoText(text: string) {
    const parser = new DOMParser()
    const html = parser.parseFromString(text, 'text/html')
    const links = html.getElementsByTagName('a')
    if (links.length > 0) {
      const linksTyped: HTMLAnchorElement[] = Array.from(links)
      linksTyped.forEach((link: HTMLAnchorElement) => {
        if (link.getAttribute('href')?.indexOf('#') !== 0) {
          link.innerHTML = `${link.innerHTML} (${link.href})`
        }
      })
    }

    return new XMLSerializer().serializeToString(html)
  }

  function cleanText(text: string) {
    return text
      ? text
          .replace(/&amp;/gi, '&') // replace ’ to valid character
          .replace(/’/gi, "'") // replace ’ to valid character
          .replace(/•/gi, '-') // replace • to valid character
          .replace(/–/gi, '-') // replace – to valid character
          .replace(/“/gi, '"') // replace “ to valid character
          .replace(/”/gi, '"') // replace ” to valid character
          .replace(/‘/gi, "'") // replace ‘ to valid character
          .replace(/’/gi, "'") // replace ’ to valid character
          .replace(/\s+/g, ' ') // trim between words
          .replace(/>\s+</g, '><') // trim between tags
          .replace(/<\/p>/gi, '</p>\n\n') // add line break
          .replace(/(<([^>]+)>)/gi, '') // strip html tags
          .trim() // trim start and end of string
      : ''
  }

  function getXPosition(align: TextAlign) {
    switch (align) {
      case 'right':
        return pageWidth - margin
      case 'center':
        return pageWidth / 2
      case 'left':
      default:
        return margin
    }
  }

  renderHeader()

  /* -----------------------------------------------
                      Public props
   ----------------------------------------------- */

  return {
    renderLogos,
    renderTopImage,
    renderPhotoImage,
    renderText,
    renderTitle,
    renderSubTitle,
    renderDisclaimerText,
    renderDisclaimer,
    renderTextWithLink,
    renderSpace,
    renderDotImage,
    renderHTML,
    setCurrentYBelowTable,
    addPageBreak,
    renderBackground,
    cleanText,
    renderTagImage,
    renderIcon,
    renderGraphImage,
    renderSeparator,
    renderMixedText,
    renderPageNumbers,
    getCurrentY,
    setCurrentY,
    renderBox,
    enablePageNumber,
    disablePageNumber,
    showBTLogo,
    getBoxWidth,
    injectUrlsIntoText,
    pageWidth,
    boxHeight,
    margin,
    doc,
  }
}

export function interpolateValues(values: string[], props: Object) {
  return values.map((item) => {
    let line = item
    Object.keys(props).forEach((prop) => {
      line = line.replace(new RegExp(`{{${prop}}}`, 'g'), props[prop])
    })
    return line
  })
}
