import { scrollElBy, scrollToAndFocusEl } from './elementUtils'

describe('elementUtils', () => {
  beforeAll(() => {
    Object.defineProperty(window, 'matchMedia', {
      value: jest.fn(() => {
        return {
          matches: true,
          addListener: jest.fn(),
          removeListener: jest.fn(),
        }
      }),
    })
  })

  it('should call scrollElBy with null', () => {
    scrollElBy(null)
  })

  it('should call scrollElBy without crash', () => {
    const wrapper = document.createElement('div')
    const scrollBy = jest.fn()
    Object.defineProperty(wrapper, 'scrollBy', {
      writable: true,
      value: scrollBy,
    })
    scrollElBy(wrapper, 10, 20)
    expect(wrapper.scrollBy).toBeCalledWith({
      behavior: 'auto',
      left: 10,
      top: 20,
    })
  })

  it('should call scrollToAndFocusEl without crash', () => {
    const wrapper = document.createElement('div')
    const element = document.createElement('div')
    const scrollBy = jest.fn()
    Object.defineProperty(wrapper, 'scrollBy', {
      writable: true,
      value: scrollBy,
    })
    scrollToAndFocusEl(wrapper, element)
    expect(wrapper.scrollBy).toBeCalled()
  })
})
