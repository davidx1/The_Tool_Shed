import { scaleLinear, scaleTime } from 'd3-scale'
import { line } from 'd3-shape'
import { extent } from 'd3-array'
import {
  IKiwisaverMonthlyData,
  IKiwisaverFundType,
} from './kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

interface FundArrayItem {
  name: string
  type: IKiwisaverFundType
  color: string
}

const getGraphImage = (
  data?: IKiwisaverMonthlyData[],
  recommendedType: IKiwisaverFundType = 'growth',
  compareDefaultFund?: boolean
): string => {
  if (!data) return ''

  const fundsArray: FundArrayItem[] = [
    {
      name: 'Cash',
      type: 'cash',
      color: '#636363',
    },
    {
      name: 'Default',
      type: 'defensive',
      color: '#E94E1B',
    },
    {
      name: 'Conservative',
      type: 'conservative',
      color: '#007A1C',
    },
    {
      name: 'Moderate',
      type: 'moderate',
      color: '#40BBC4',
    },
    {
      name: 'Balanced',
      type: 'balanced',
      color: '#222222',
    },
    {
      name: 'Growth',
      type: 'growth',
      color: '#2A8289',
    },
  ]
  const canvas = document.createElement('canvas') as HTMLCanvasElement
  canvas.setAttribute('width', '2310px')
  canvas.setAttribute('height', '1168px')
  const context = canvas.getContext('2d') as CanvasRenderingContext2D
  const multiplier = 3.12
  const legendHeight = 25 * multiplier
  var margin = {
      top: 20 * multiplier,
      right: 20 * multiplier,
      bottom: 30 * multiplier,
      left: 50 * multiplier,
    },
    width = canvas.width - margin.left - margin.right,
    height = canvas.height - margin.top - margin.bottom - legendHeight
  var parseTime = (d: string) => new Date(d)
  var x = scaleTime()
    .range([0, width])
    .domain(
      extent(data, function (d) {
        return parseTime(d.date)
      }) as [Date, Date]
    )
  var y = scaleLinear().range([height, 0]).domain([0, 25000])
  let currentX = 0
  let currentY = 0
  var fundLine = (lineType: IKiwisaverFundType) =>
    line<IKiwisaverMonthlyData>()
      .x((d) => {
        currentX = x(parseTime(d.date))
        return currentX
      })
      .y((d) => {
        currentY = y(d[lineType])
        return currentY
      })
      .context(context)
  drawLegend()
  context.translate(margin.left, margin.top + legendHeight)
  xAxis()
  yAxis()

  const fundIndex = fundsArray.findIndex(
    (item) => item.type === recommendedType
  )
  if (fundIndex !== undefined) {
    const [recommendedItem] = fundsArray.splice(fundIndex, 1)
    fundsArray.push(recommendedItem)
  }
  fundsArray.forEach((fund) => {
    if (
      compareDefaultFund ||
      (!compareDefaultFund && fund.type !== 'defensive')
    ) {
      drawGraphLine(fund.type, fund.color)
    }
  })

  function drawLegend() {
    const gap = (compareDefaultFund ? 60 : 90) * multiplier
    let legendX = 10 * multiplier
    let legendY = 15 * multiplier

    context.font = 'bold 32px Arial'
    context.fillStyle = '#222222'
    context.fillText('Funds:', legendX, legendY)
    legendX += 80 * multiplier
    fundsArray.forEach((fund) => {
      if (
        compareDefaultFund ||
        (!compareDefaultFund && fund.type !== 'defensive')
      ) {
        legendX =
          drawLegendItem(legendX, legendY, fund.name, fund.color, fund.type) +
          gap
      }
    })
  }
  function drawLegendItem(
    startX: number,
    startY: number,
    text: string,
    color: string,
    type: IKiwisaverFundType
  ): number {
    context.beginPath()
    drawCircle(startX, startY - 2.5 * multiplier, color)

    context.beginPath()
    context.moveTo(startX + 11 * multiplier, startY)
    context.font = 'normal 32px Arial'
    context.fillStyle = '#222222'
    context.fillText(text, startX + 11 * multiplier, startY)
    const textWidth = text.length * multiplier * 5

    if (type === recommendedType) {
      context.beginPath()
      context.font = 'bold 25px Arial'
      context.fillStyle = color
      context.fillText(
        'Recommended',
        startX + 11 * multiplier,
        startY + 10 * multiplier
      )
    }

    return startX + 11 * multiplier + textWidth
  }
  function drawGraphLine(type: IKiwisaverFundType, color: string) {
    context.beginPath()
    fundLine(type)(data!)
    context.lineWidth = 2 * multiplier
    context.strokeStyle = color
    setDashedLine(type)
    context.stroke()
    context.beginPath()
    drawCircle(currentX, currentY, color)
  }
  function drawCircle(x: number, y: number, color: string) {
    context.arc(x, y, 5 * multiplier, 0, 2 * Math.PI)
    context.shadowBlur = 5 * multiplier
    context.shadowColor = color
    context.shadowOffsetX = 0
    context.shadowOffsetY = 0
    context.strokeStyle = '#FFFFFF'
    context.fillStyle = color
    context.lineWidth = 2 * multiplier
    context.fill()
    context.setLineDash([])
    context.stroke()
    context.shadowColor = 'transparent'
  }
  function xAxis() {
    var tickCount = 4,
      tickSize = 6 * multiplier,
      ticks = x.ticks(tickCount)
    context.beginPath()
    context.strokeStyle = '#DADADA'
    context.stroke()
    context.textAlign = 'center'
    context.textBaseline = 'top'
    context.font = 'bold 25px Arial'
    context.fillStyle = '#949494'
    ticks.forEach(function (d) {
      context.fillText(d.getFullYear().toString(), x(d), height + tickSize)
    })
  }
  function yAxis() {
    var tickCount = 6,
      tickSize = 6 * multiplier,
      tickPadding = 3 * multiplier,
      ticks = y.ticks(tickCount),
      tickFormat = y.tickFormat(tickCount)
    context.beginPath()
    context.lineWidth = 0.5 * multiplier
    ticks.forEach(function (d) {
      context.moveTo(0, y(d))
      context.lineTo(width, y(d))
    })
    context.strokeStyle = '#DADADA'
    context.stroke()
    context.textAlign = 'right'
    context.textBaseline = 'middle'
    context.font = 'bold 25px'
    context.fillStyle = '#949494'
    ticks.forEach(function (d) {
      context.fillText(`$${tickFormat(d)}`, -tickSize - tickPadding, y(d))
    })
  }
  function setDashedLine(type: IKiwisaverFundType) {
    context.setLineDash(
      recommendedType === type ? [] : [3 * multiplier, 1 * multiplier]
    )
  }
  return canvas.toDataURL()
}
export default getGraphImage
