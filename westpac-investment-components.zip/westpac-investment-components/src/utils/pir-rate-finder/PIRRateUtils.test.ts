import {
  getNextStepPIRRate,
  OPTION_HELD_BY_INDIVIDUAL,
  OPTION_HELD_BY_SOME_JOINTLY,
  OPTION_HELD_BY_TRUSTEE,
  OPTION_HELD_BY_OTHERS,
  OPTION_YES,
  OPTION_NO,
} from './PIRRateUtils'

const testPIRRateRecommendation = (
  userAnswers: (string | number)[],
  PIRRate: string | null
) => {
  const step = getNextStepPIRRate(userAnswers)

  expect(step.type).toBe('recommendation')
  expect(step.recommendation?.PIRRate).toBe(PIRRate)
}

const testUnexpectedPIRRateScenario = (userAnswers: (string | number)[]) => {
  const step = getNextStepPIRRate(userAnswers)
  expect(step).toBe(null)
}

const unexpectedValue = 'unexpected'

describe('PIR Rate finder', () => {
  it('As a trustee holder should have a recommandation of 0%, 17,5% or 28%', () => {
    testPIRRateRecommendation([OPTION_HELD_BY_TRUSTEE], '0%, 17.5% or 28%')
  })
  it('As an other holder should have a recommandation of 0%', () => {
    testPIRRateRecommendation([OPTION_HELD_BY_OTHERS], '0%')
  })
  it('As an individual or jointly holder, with less than 14k taxable should have a recommandation of 10.5%', () => {
    testPIRRateRecommendation([OPTION_HELD_BY_INDIVIDUAL, OPTION_YES], '10.5%')
    testPIRRateRecommendation(
      [OPTION_HELD_BY_SOME_JOINTLY, OPTION_YES],
      '10.5%'
    )
  })
  it('As an individual or jointly holder, with less than 48k taxable should have a recommandation of 17.5%', () => {
    testPIRRateRecommendation(
      [OPTION_HELD_BY_INDIVIDUAL, OPTION_NO, OPTION_YES],
      '17.5%'
    )
    testPIRRateRecommendation(
      [OPTION_HELD_BY_SOME_JOINTLY, OPTION_NO, OPTION_YES],
      '17.5%'
    )
  })
  it('As an individual or jointly holder, with more than 48k taxable should have a recommandation of 28%', () => {
    testPIRRateRecommendation(
      [OPTION_HELD_BY_INDIVIDUAL, OPTION_NO, OPTION_NO],
      '28%'
    )
    testPIRRateRecommendation(
      [OPTION_HELD_BY_SOME_JOINTLY, OPTION_NO, OPTION_NO],
      '28%'
    )
  })
  it('Should return null if answer is unexpected', () => {
    testUnexpectedPIRRateScenario([unexpectedValue])
    testUnexpectedPIRRateScenario([OPTION_HELD_BY_INDIVIDUAL, unexpectedValue])
    testUnexpectedPIRRateScenario([
      OPTION_HELD_BY_INDIVIDUAL,
      OPTION_NO,
      unexpectedValue,
    ])
  })
})
