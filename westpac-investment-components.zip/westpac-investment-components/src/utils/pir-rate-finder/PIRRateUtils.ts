import { IQuestion, IStep } from '../../components/navigation/IQuestionnaire'
import { getNextStep } from '../questionnaireUtils'

export interface IPIRRateItem {
  PIRRate: string
  description?: string
}

export interface IPIRRateStep extends IStep {
  recommendation?: IPIRRateItem
}

/* -----------------------------------------------
                    Questions
 ----------------------------------------------- */

export const OPTION_YES = 'Yes'
export const OPTION_NO = 'No'

/* ----------------------------------------------- */

export const OPTION_HELD_BY_INDIVIDUAL = 'By me, as an individual'
export const OPTION_HELD_BY_SOME_JOINTLY = 'Some (or all) are jointly held'
export const OPTION_HELD_BY_TRUSTEE = 'A trust'
export const OPTION_HELD_BY_OTHERS =
  'A company, charity, unit trust, or non-profit'

const QUESTION_INVESTMENT_HELD_BY: IQuestion = {
  id: 'QUESTION_INVESTMENT_HELD_BY',
  type: 'dropdown',
  title: 'Who are your investments held by:',
  label: 'Select option',
  options: [
    OPTION_HELD_BY_INDIVIDUAL,
    OPTION_HELD_BY_SOME_JOINTLY,
    OPTION_HELD_BY_TRUSTEE,
    OPTION_HELD_BY_OTHERS,
  ],
}

/* ----------------------------------------------- */

const QUESTION_INCOME_RANGE_LOW: IQuestion = {
  id: 'QUESTION_INCOME_RANGE_LOW',
  type: 'radioGroup',
  title:
    'In one of the last two tax years to 31 March, was your taxable income* $14,000 or less and your taxable income plus your PIE income $48,000 or less?',
  label: 'Select option',
  information: {
    body: [
      '* Examples of taxable income include salary, wages, commission, NZ Super, rent, interest and dividends, student allowances, parental leave, tips and gratuities. Taxable income does not include income from PIE compliant KiwiSaver schemes and managed funds, including the Westpac Term PIE Fund.',
    ],
  },
  options: [OPTION_YES, OPTION_NO],
}

/* ----------------------------------------------- */

const QUESTION_INCOME_RANGE_HIGH: IQuestion = {
  id: 'QUESTION_INCOME_RANGE_HIGH',
  type: 'radioGroup',
  title:
    'In one of the last two tax years to 31 March, was your taxable income*  $48,000 or less and your taxable income plus your PIE income $70,000 or less?',
  label: 'Select option',
  information: {
    body: [
      '* Examples of taxable income include salary, wages, commission, NZ Super, rent, interest and dividends, student allowances, parental leave, tips and gratuities. Taxable income does not include income from PIE compliant KiwiSaver schemes and managed funds, including the Westpac Term PIE Fund.',
    ],
  },
  options: [OPTION_YES, OPTION_NO],
}

/* -----------------------------------------------
                      Steps
   ----------------------------------------------- */

const PIR_RATE_INITIAL_STEP: IPIRRateStep = {
  type: 'question',
  question: QUESTION_INVESTMENT_HELD_BY,
  getNextStep: (values) => {
    switch (values[QUESTION_INVESTMENT_HELD_BY.id]) {
      case OPTION_HELD_BY_INDIVIDUAL:
      case OPTION_HELD_BY_SOME_JOINTLY:
        return INCOME_RANGE_LOW_STEP
      case OPTION_HELD_BY_TRUSTEE:
        return getRecommendation(
          '0%, 17.5% or 28%',
          'Some testamentary trusts may be eligible for a PIR of 10.5% in certain circumstances. If you are unsure which PIR to use, we recommend you speak with a tax advisor.'
        )
      case OPTION_HELD_BY_OTHERS:
        return getRecommendation('0%')
      default:
        return null
    }
  },
}

const INCOME_RANGE_LOW_STEP: IPIRRateStep = {
  type: 'question',
  question: QUESTION_INCOME_RANGE_LOW,
  getNextStep: (values) => {
    switch (values[QUESTION_INCOME_RANGE_LOW.id]) {
      case OPTION_YES:
        return getRecommendation('10.5%')
      case OPTION_NO:
        return INCOME_RANGE_HIGH_STEP
      default:
        return null
    }
  },
}

const INCOME_RANGE_HIGH_STEP: IPIRRateStep = {
  type: 'question',
  question: QUESTION_INCOME_RANGE_HIGH,
  getNextStep: (values) => {
    switch (values[QUESTION_INCOME_RANGE_HIGH.id]) {
      case OPTION_YES:
        return getRecommendation('17.5%')
      case OPTION_NO:
        return getRecommendation('28%')
      default:
        return null
    }
  },
}

const getRecommendation = (PIRRate: string, description?: string) =>
  ({
    type: 'recommendation',
    recommendation: { PIRRate, description },
  } as IPIRRateStep)

export const getNextStepPIRRate = (userAnswers: (string | number)[]) =>
  getNextStep(userAnswers, PIR_RATE_INITIAL_STEP) as IPIRRateStep
