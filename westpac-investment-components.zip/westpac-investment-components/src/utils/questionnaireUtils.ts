import {
  ICustomerInteraction,
  IStep,
  IValues,
} from '../components/navigation/IQuestionnaire'

export const getNextStep = (
  userAnswers: (string | number)[],
  initialStep: IStep
) => {
  const values: IValues = {}
  let step: IStep | null = initialStep

  const customerInteraction: ICustomerInteraction = {
    subject: '',
    additionalInfo: '',
    whyProductSuitable: '',
  }

  if (Array.isArray(userAnswers)) {
    userAnswers.forEach((answer) => {
      if (answer && step?.getNextStep) {
        if (step.question) {
          values[step.question.id] = answer
        }
        step = step.getNextStep(values, customerInteraction)
      } else {
        step = null
      }
    })
  }

  return step
}

export const getRecommendationSteps = (
  userAnswers: (string | number)[],
  initialStep: IStep
) => {
  const answerSteps = userAnswers.map((answer, i) => ({
    answer,
    question: getNextStep(userAnswers.slice(0, i), initialStep).question,
  }))
  const lastStep = getNextStep(userAnswers, initialStep)
  return {
    answerSteps,
    recommendation: lastStep?.type === 'recommendation' ? lastStep : null,
  }
}
