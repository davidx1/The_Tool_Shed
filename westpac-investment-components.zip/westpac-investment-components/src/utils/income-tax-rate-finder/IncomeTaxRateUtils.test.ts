import {
  getNextStepIncomeTaxRate,
  OPTION_HELD_BY_INDIVIDUAL,
  OPTION_HELD_BY_SOME_JOINTLY,
  OPTION_HELD_BY_TRUSTEE,
  OPTION_HELD_BY_OTHERS,
  OPTION_INCOME_0_TO_14K,
  OPTION_INCOME_14K_TO_48K,
  OPTION_INCOME_48K_TO_70K,
  OPTION_INCOME_70K_OR_MORE,
  OPTION_ENTITY_CHARITY,
  OPTION_ENTITY_COMPANY,
} from './IncomeTaxRateUtils'

const testIncomeTaxRateRecommendation = (
  userAnswers: (string | number)[],
  taxRate: string | undefined
) => {
  const step = getNextStepIncomeTaxRate(userAnswers)

  expect(step.type).toBe('recommendation')
  expect(step.recommendation?.taxRate).toBe(taxRate)
}

const testUnexpectedIncomeTaxRateScenarios = (
  userAnswers: (string | number)[]
) => {
  const step = getNextStepIncomeTaxRate(userAnswers)
  expect(step).toBe(null)
}

const unexpectedValue = 'unexpected'

describe('Income tax rate finder', () => {
  describe('Trustee hold', () => {
    it('As a trustee holden investment I expect the recommendation to have a tax rate at 33%', () => {
      testIncomeTaxRateRecommendation([OPTION_HELD_BY_TRUSTEE], '33%')
    })
  })
  describe('Other hold', () => {
    it('As a charity holden investment I expect the recommendation to have a tax rate at 0%', () => {
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_OTHERS, OPTION_ENTITY_CHARITY],
        '0%'
      )
    })
    it('As a charity holden investment I expect the recommendation to have a tax rate at 28%', () => {
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_OTHERS, OPTION_ENTITY_COMPANY],
        '28%'
      )
    })
  })
  describe('Individual and jointly', () => {
    it('As a individual or jointly holden investment and have income under 14k I expect the recommendation to have a tax rate at 10.5%', () => {
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_INDIVIDUAL, OPTION_INCOME_0_TO_14K],
        '10.5%'
      )
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_SOME_JOINTLY, OPTION_INCOME_0_TO_14K],
        '10.5%'
      )
    })
    it('As a individual or jointly holden investment and have income from 14k to 48k I expect the recommendation to have a tax rate at 17.5%', () => {
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_INDIVIDUAL, OPTION_INCOME_14K_TO_48K],
        '17.5%'
      )
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_SOME_JOINTLY, OPTION_INCOME_14K_TO_48K],
        '17.5%'
      )
    })
    it('As a individual or jointly holden investment and have income from 48k to 70k I expect the recommendation to have a tax rate at 30%', () => {
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_INDIVIDUAL, OPTION_INCOME_48K_TO_70K],
        '30%'
      )
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_SOME_JOINTLY, OPTION_INCOME_48K_TO_70K],
        '30%'
      )
    })
    it('As a individual or jointly holden investment and have income from 70k I expect the recommendation to have a tax rate at 33%', () => {
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_INDIVIDUAL, OPTION_INCOME_70K_OR_MORE],
        '33%'
      )
      testIncomeTaxRateRecommendation(
        [OPTION_HELD_BY_SOME_JOINTLY, OPTION_INCOME_70K_OR_MORE],
        '33%'
      )
    })
  })
  describe('Unexpected', () => {
    it('should return null if the answer is unexpected', () => {
      testUnexpectedIncomeTaxRateScenarios([unexpectedValue])
      testUnexpectedIncomeTaxRateScenarios([
        OPTION_HELD_BY_OTHERS,
        unexpectedValue,
      ])
      testUnexpectedIncomeTaxRateScenarios([
        OPTION_HELD_BY_INDIVIDUAL,
        unexpectedValue,
      ])
    })
  })
})
