import { IQuestion, IStep } from '../../components/navigation/IQuestionnaire'
import { getNextStep } from '../questionnaireUtils'

export interface IIncomeTaxRateStep extends IStep {
  recommendation?: IIncomeTaxRateItem
}

export interface IIncomeTaxRateItem {
  taxRate: string
}

/* -----------------------------------------------
                    Questions
 ----------------------------------------------- */

export const OPTION_HELD_BY_INDIVIDUAL = 'By me, as an individual'
export const OPTION_HELD_BY_SOME_JOINTLY = 'Some (or all) are jointly held'
export const OPTION_HELD_BY_TRUSTEE = 'A trust'
export const OPTION_HELD_BY_OTHERS =
  'A company, charity, unit trust, or non-profit'

const QUESTION_INVESTMENT_HELD_BY: IQuestion = {
  id: 'QUESTION_INVESTMENT_HELD_BY',
  type: 'dropdown',
  title: 'Who are your investments held by:',
  label: 'Select option',
  options: [
    OPTION_HELD_BY_INDIVIDUAL,
    OPTION_HELD_BY_SOME_JOINTLY,
    OPTION_HELD_BY_TRUSTEE,
    OPTION_HELD_BY_OTHERS,
  ],
}

/* ----------------------------------------------- */

export const OPTION_INCOME_0_TO_14K = '$0 – $14,000'
export const OPTION_INCOME_14K_TO_48K = '$14,001 – $48,000'
export const OPTION_INCOME_48K_TO_70K = '$48,001 – $70,000'
export const OPTION_INCOME_70K_OR_MORE = '$70,001 or more'

const QUESTION_EXPECTED_TAXABLE_INCOME: IQuestion = {
  id: 'QUESTION_EXPECTED_TAXABLE_INCOME',
  type: 'dropdown',
  title:
    'My expected annual taxable income (or that of the trust’s beneficiary) is:',
  label: 'Select option',
  options: [
    OPTION_INCOME_0_TO_14K,
    OPTION_INCOME_14K_TO_48K,
    OPTION_INCOME_48K_TO_70K,
    OPTION_INCOME_70K_OR_MORE,
  ],
}

/* ----------------------------------------------- */

export const OPTION_ENTITY_CHARITY = 'Charity'
export const OPTION_ENTITY_COMPANY = 'Company'

const QUESTION_ENTITY_TYPE: IQuestion = {
  id: 'QUESTION_ENTITY_TYPE',
  type: 'radioGroup',
  title: 'What is your entity type?',
  label: 'Select option',
  options: [OPTION_ENTITY_CHARITY, OPTION_ENTITY_COMPANY],
}

/* -----------------------------------------------
                      Steps
   ----------------------------------------------- */

const INCOME_TAX_RATE_INITIAL_STEP: IIncomeTaxRateStep = {
  type: 'question',
  question: QUESTION_INVESTMENT_HELD_BY,
  getNextStep: (values) => {
    switch (values[QUESTION_INVESTMENT_HELD_BY.id]) {
      case OPTION_HELD_BY_INDIVIDUAL:
      case OPTION_HELD_BY_SOME_JOINTLY:
        return EXPECTED_TAXABLE_INCOME_STEP
      case OPTION_HELD_BY_TRUSTEE:
        return getRecommendation(33)
      case OPTION_HELD_BY_OTHERS:
        return ENTITY_TYPE_STEP
      default:
        return null
    }
  },
}

const EXPECTED_TAXABLE_INCOME_STEP: IIncomeTaxRateStep = {
  type: 'question',
  question: QUESTION_EXPECTED_TAXABLE_INCOME,
  getNextStep: (values) => {
    switch (values[QUESTION_EXPECTED_TAXABLE_INCOME.id]) {
      case OPTION_INCOME_0_TO_14K:
        return getRecommendation(10.5)
      case OPTION_INCOME_14K_TO_48K:
        return getRecommendation(17.5)
      case OPTION_INCOME_48K_TO_70K:
        return getRecommendation(30)
      case OPTION_INCOME_70K_OR_MORE:
        return getRecommendation(33)
      default:
        return null
    }
  },
}

const ENTITY_TYPE_STEP: IIncomeTaxRateStep = {
  type: 'question',
  question: QUESTION_ENTITY_TYPE,
  getNextStep: (values) => {
    switch (values[QUESTION_ENTITY_TYPE.id]) {
      case OPTION_ENTITY_CHARITY:
        return getRecommendation(0)
      case OPTION_ENTITY_COMPANY:
        return getRecommendation(28)
      default:
        return null
    }
  },
}

const getRecommendation = (taxRate: number) =>
  ({
    type: 'recommendation',
    recommendation: {
      taxRate: `${taxRate}%`,
    },
  } as IIncomeTaxRateStep)

export const getNextStepIncomeTaxRate = (userAnswers: (string | number)[]) =>
  getNextStep(userAnswers, INCOME_TAX_RATE_INITIAL_STEP) as IIncomeTaxRateStep
