const getScrollBehavior = () => {
  const prefersReducedMotion = window.matchMedia(
    '(prefers-reduced-motion: reduce)'
  )
  return prefersReducedMotion.matches ? 'auto' : 'smooth'
}

// Scroll to and set focus on a specific element
export const scrollToAndFocusEl = (
  scrollAreaElement: HTMLDivElement | null,
  element: HTMLDivElement | null,
  animateScroll: boolean = true
) => {
  if (!element || !scrollAreaElement) return

  if (document.activeElement instanceof HTMLElement) {
    document.activeElement.blur()
  }

  const behavior = animateScroll ? getScrollBehavior() : undefined

  element.focus({ preventScroll: true })
  scrollAreaElement.scrollBy({
    behavior,
    top: element.getBoundingClientRect().top,
  })
}

// Scrolls inside an element by the amount passed in
export const scrollElBy = (
  element: HTMLDivElement | null,
  left: number = 0,
  top: number = 0
) => {
  if (!element) return

  const behavior = getScrollBehavior()

  element.scrollBy({
    top,
    left,
    behavior,
  })
}
