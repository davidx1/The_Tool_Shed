import React from 'react'

import {
  OPTION_ACCESS_I_CAN_WAIT,
  OPTION_INTERVAL_NO_MORE,
  OPTION_OVER_5K,
  OPTION_NZ_TAX_RESIDENT_NO,
} from './productChooserUtils'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'
import ratesData from './__mocks__/ProductChooserRatesData'

import { generateProductRecommendationFile } from './productChooserFileUtils'

export default {
  title: 'ProductChooser/generateProductRecommendationFile',
}

export const Basic = () => {
  const file = generateProductRecommendationFile(
    [
      OPTION_ACCESS_I_CAN_WAIT,
      OPTION_INTERVAL_NO_MORE,
      OPTION_OVER_5K,
      OPTION_NZ_TAX_RESIDENT_NO
    ],
    config,
    ratesData
  )
  const uri = file.doc.output('datauristring')
  return (
    <div>
      <iframe src={uri} title="PDF Viewer" height="500" width="100%" />
      <button onClick={() => file.save()}>Download PDF</button>
    </div>
  )
}

Basic.parameters = {
  storyshots: false,
}

// this is to easily swap config to check other recommendation
// as it looks like Storybook doesn't support two pdf renderers at a time
// export const Basic = () => {
//   const file = generateProductRecommendationFile(
//     [
//       OPTION_ACCESS_ANYTIME,
//       OPTION_NZ_TAX_RESIDENT_NO
//     ],
//     config,
//     ratesData
//   )
//   const uri = file.doc.output('datauristring')
//   return (
//     <div>
//       <iframe src={uri} title="PDF Viewer" height="500" width="100%" />
//       <button onClick={() => file.save()}>Download PDF</button>
//     </div>
//   )
// }

// Basic.parameters = {
//   storyshots: false,
// }
