import { ILink } from '../../components/navigation/ILink'
import {
  IQuestion,
  IValues,
  IStep,
  ICustomerInteraction,
} from '../../components/navigation/IQuestionnaire'
import { getNextStep, getRecommendationSteps } from '../questionnaireUtils'

export type IProductChooserProductType =
  | 'noticeSaver'
  | 'bonusSaverAccount'
  | 'bonusSaverPIE'
  | 'termDeposit'
  | 'termPIE'
  | 'simpleSaver'

export interface IProductChooserInterestEffectiveReturn {
  thirty: string
  thirtyThree: string
}

export interface IProductChooserInterestRateBase {
  annualRatePercent: string
  durationInMonths?: string
  description?: string
  disclosure?: string
  effectiveReturn?: IProductChooserInterestEffectiveReturn
}

export interface IProductChooserInterestRate
  extends IProductChooserInterestRateBase {
  breakdown?: IProductChooserInterestRateBase[]
}

export interface IProductChooserFee {
  type: string
  amount: string
}

export interface IProductChooserFees {
  accountFees: IProductChooserFee[]
  serviceFees: IProductChooserFee[]
  accountFeesDisclaimer?: string
  serviceFeesDisclaimer?: string
  accountFeesEmptyState?: string
  serviceFeesEmptyState?: string
}

export interface IProductChooserVideo {
  title: string
  description: string
  url: string
  posterImageUrl?: string
}
export interface IDetail {
  title: string
  details: string[]
  disclosures: string[]
}

export interface IProductChooserProductItem {
  type: IProductChooserProductType
  title: string
  description: string | string[]
  shortDescription: string
  interestRatesTitle?: string
  interestRatesDescription?: string | string[]
  interestRates: IProductChooserInterestRate[]
  interestRatesDisclaimer?: string
  video?: IProductChooserVideo
  benefits?: string[]
  details?: IDetail[]
  fees: IProductChooserFees
  disclosures: string[]
  disclosuresPDF: string[]
  applyUrl: string
  applyTitle: string
  benefitsComparison: string
  feesComparison: string
  ratesComparison: string
  thingsToKnowComparison: string
  icon: string
}

export interface IProductChooserStep extends IStep {
  recommendation?: IProductChooserProductItem
  recommendationDetails?: IProductChooserRecommendationDetails
  customerInteraction?: ICustomerInteraction
}

export interface IProductChooserRecommendationDetails {
  secondaryRecommendation: IProductChooserProductType
  tertiaryRecommendation?: IProductChooserProductType
  comparisonTable: IProductChooserProductItem[]
  comparisonDisclaimer: string
  updateAt: string
}

export interface IProductChooserConfigItem {
  icon: string
  applyUrl: string
  disclosures: string[]
  termSheetUrl?: string
  ratesImageUrl?: string
  earlyWithdrawalUrl?: string
  westpacDocumentsUrl?: string
  trustDeedUrl?: string
}

export interface IProductChooserConfig {
  links: {
    contactUsPhone: ILink
    contactUs: string
    glossary: string
    branchLocator: string
    termsAndConditions: string
    hardshipWithdrawal: string
    interestRates: string
    toolDisclosure: string
    fees: string
  }
  pieVideo: {
    url: string
    shortUrl: string
    posterImageUrl: string
  }
  productItems: {
    [P in IProductChooserProductType]: IProductChooserConfigItem
  }
  disclaimer: string[]
  disclaimerSecondary: string[]
  disclaimerStaff: string[]
}

export interface IProductChooserSingleRate {
  annualRate: string
  baseRate?: string
  bonusRate?: string
  termLength?: string
  returnRate?: {
    thirty: string
    thirtyThree: string
  }
}
export interface IProductChooserMultipleRate {
  term1: IProductChooserSingleRate
  term2: IProductChooserSingleRate
  term3: IProductChooserSingleRate
}

export interface IProductChooserFeeItem {
  value: string
  frequency?: string
}

export interface IProductChooserRatesAndFees<T> {
  rateBreakdown: T
  accountFees: {
    maintenanceFee?: IProductChooserFeeItem
    electronicStatementsFee?: IProductChooserFeeItem
    paperStatementsFee?: IProductChooserFeeItem
    electronicWithdrawals?: IProductChooserFeeItem
    firstWithdrawal?: IProductChooserFeeItem
    manualWithdrawals?: IProductChooserFeeItem
    chequeWithdrawals?: IProductChooserFeeItem
    depositFee?: IProductChooserFeeItem
  }
  serviceFees: {
    callFee?: IProductChooserFeeItem
    emailAlertFee?: IProductChooserFeeItem
    onlinePaymentSetupFee?: IProductChooserFeeItem
    branchPaymentSetupFee?: IProductChooserFeeItem
  }
}

export type IProductChooserRatesData = {
  noticeSaver: IProductChooserRatesAndFees<IProductChooserSingleRate>
  bonusSaverAccount: IProductChooserRatesAndFees<IProductChooserSingleRate>
  bonusSaverPIE: IProductChooserRatesAndFees<IProductChooserSingleRate>
  simpleSaver: IProductChooserRatesAndFees<IProductChooserSingleRate>
  termDeposit: IProductChooserRatesAndFees<IProductChooserMultipleRate>
  termPIE: IProductChooserRatesAndFees<IProductChooserMultipleRate>
  updatedAt: string
}

export const OPTION_ACCESS_I_CAN_WAIT =
  'I can lock my money away for a fixed period. Or I can give 32 days’ notice when I need access to my money.'
export const OPTION_ACCESS_ANYTIME = 'I need access anytime.'

export const OPTION_INTERVAL_ONCE_A_MONTH = 'At least once a month.'
export const OPTION_INTERVAL_SOMETIMES = 'Sometimes, but not every month.'
export const OPTION_INTERVAL_NO_MORE =
  'I have a lump sum now and don’t want to add more.'

export const OPTION_NZ_TAX_RESIDENT_YES = 'Yes'
export const OPTION_NZ_TAX_RESIDENT_NO = 'No'

export const OPTIONS_TAX_RATE_LOW = ['0%', '10.5%', '17.5%', '28%']
export const OPTIONS_TAX_RATE_HIGH = ['30%', '33%']

export const OPTION_UNDER_5K = 'Under $5,000'
export const OPTION_OVER_5K = 'Over $5,000'

function createProductChooserFlow(
  config: IProductChooserConfig,
  ratesData: IProductChooserRatesData
) {
  const {
    bonusSaverAccount,
    bonusSaverPIE,
    noticeSaver,
    simpleSaver,
    termDeposit,
    termPIE,
    updatedAt,
  } = ratesData
  /* -----------------------------------------------
                    Questions
 ----------------------------------------------- */

  const QUESTION_ACCESS_MONEY: IQuestion = {
    id: 'QUESTION_ACCESS_MONEY',
    type: 'dropdown',
    title: 'When will you need to access your money?',
    label: 'Choose an option',
    options: [OPTION_ACCESS_ANYTIME, OPTION_ACCESS_I_CAN_WAIT],
    information: {
      body: [
        'Think about how easily you want to be able to access your savings. Do you want to be able to access your money any time? Accounts and investments where your money is always available tend to pay less interest.',
        'If you’re prepared to lock your money away for a fixed period (or with a rolling 32-day notice period), you can often benefit from a higher interest rate or rate of return. But if you need your money in a hurry, you may need to wait.',
      ],
      icon: 'timeline',
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_DEPOSIT_INTERVAL: IQuestion = {
    id: 'QUESTION_DEPOSIT_INTERVAL',
    type: 'dropdown',
    title: 'How often will you deposit money into your savings?',
    label: 'Choose an option',
    options: [
      OPTION_INTERVAL_ONCE_A_MONTH,
      OPTION_INTERVAL_SOMETIMES,
      OPTION_INTERVAL_NO_MORE,
    ],
    information: {
      body: [
        'Some savings accounts allow or encourage you to contribute regularly to your savings.',
        'If your money is in a term investment, it’s a one-off deposit of a fixed amount from the start.',
      ],
      icon: 'plantGrowth',
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_NZ_TAX_RESIDENT: IQuestion = {
    id: 'QUESTION_NZ_TAX_RESIDENT',
    type: 'radioGroup',
    title: 'Are you a New Zealand tax resident?',
    options: [OPTION_NZ_TAX_RESIDENT_YES, OPTION_NZ_TAX_RESIDENT_NO],
    icons: ['handUp', 'handDown'],
    information: {
      body: [
        'PIE investments have tax benefits which are only available for NZ tax residents. So, if you’re not a NZ tax resident we won’t recommend them to you.',
        "You're a New Zealand tax resident (as an individual) if you have a 'permanent place of abode' in New Zealand; or you have been in New Zealand for more than 183 days in total in any 12-month period and haven't become a non-resident (absent from New Zealand for more than 325 days in total in a 12-month period).",
        'If you are unsure of your tax residency, you may wish to seek professional advice.',
      ],
      icon: 'piggyTax',
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_WHAT_IS_YOUR_TAX_RATE: IQuestion = {
    id: 'QUESTION_WHAT_IS_YOUR_TAX_RATE',
    type: 'dropdown',
    title: 'What is your tax rate?',
    label: 'Choose a tax rate',
    options: [...OPTIONS_TAX_RATE_LOW, ...OPTIONS_TAX_RATE_HIGH],
    information: {
      body: [
        'For personal customers, New Zealand has progressive or graduated tax rates: Tax rates increase as your income increases.',
        'Tax rates are based on your total income for the tax year. Higher tax rates only apply to each dollar over the tax threshold.',
      ],
      icon: 'taxPayment',
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_INITIAL_DEPOSIT: IQuestion = {
    id: 'QUESTION_INITIAL_DEPOSIT',
    type: 'radioGroup',
    title: 'How much is your initial deposit?',
    options: [OPTION_UNDER_5K, OPTION_OVER_5K],
    icons: ['dollarLess', 'dollarMore'],
    information: {
      body: [
        'Our term investments need a minimum investment of $5,000.',
        'Other types of savings and investment options are available for any amount of money.',
      ],
      icon: 'handCoin',
    },
  }

  /* -----------------------------------------------
                      Recommendations
   ----------------------------------------------- */

  const PIE_VIDEO_BLOCK: IProductChooserVideo = {
    ...config.pieVideo,
    title: 'What is PIE?',
    description:
      'PIEs are an investment where you buy units in a fund and you pay tax at a special rate. The special tax rate is called the Prescribed Investor Rate or PIR. Watch this short video to learn more.',
  }

  const PRODUCT_NOTICE_SAVER: IProductChooserProductItem = {
    ...config.productItems.noticeSaver,
    applyTitle: 'Opening a Notice Saver.',
    type: 'noticeSaver',
    title: 'Notice Saver',
    description: [
      "As you don’t need to access your money instantly, Notice Saver can help you focus on saving towards a particular goal, giving us 32 days' notice before making a withdrawal. It earns our highest savings return for an account that you can add money to anytime. Notice Saver is a PIE option, so if you’re a New Zealand tax resident paying 30% or 33% income tax, you could benefit from the tax rate of 28%.",
      'Notice Saver is suitable for saving for a long-term goal like a holiday or to start saving for a house deposit. It also works if you’re adding funds to grow an investment over time, provided you’re happy to have the money locked away with a notice period.',
    ],
    shortDescription:
      'Dipping into your savings too often? With Notice Saver you can focus on saving towards a particular goal, with 32 days’ notice required before you can make a withdrawal. As a PIE option, there is a potential tax benefit which means that your balance could earn more after tax.',
    interestRatesTitle: 'Return rate.',
    interestRates: [
      {
        annualRatePercent: noticeSaver.rateBreakdown.annualRate,
        description:
          'Rates of return are variable and are subject to change without notice.',
        effectiveReturn: {
          thirty: noticeSaver.rateBreakdown.returnRate!.thirty,
          thirtyThree: noticeSaver.rateBreakdown.returnRate!.thirtyThree,
        },
      },
    ],
    interestRatesDisclaimer: `<p>^The effective return incorporates the Notice Saver tax benefits, so you can compare it with the interest rate on a standard savings account. The effective return is the rate you would need to receive from a regular savings account to match the returns from a Notice Saver (after tax is paid). This is based on a PIR (Prescribed Investor Rate) of 28% and an income tax rate of 30% or 33%. Rates subject to change without notice. ^^Individuals with taxable income of $48,001 to $70,000. ^^^Individuals with taxable income of $70,001 and over.</p>`,
    video: PIE_VIDEO_BLOCK,
    benefits: [
      'Earn a higher return compared to our accounts where your money is available immediately.',
      'Potentially enjoy the tax benefits of paying less tax which means your after-tax return is higher.',
      'No monthly account maintenance fees.',
    ],
    details: [
      {
        title: 'How you earn returns',
        details: [
          'Based on the tax residency and tax rate you have provided, you may benefit from paying tax on returns at a PIR instead of income tax rate.',
          'Returns are calculated daily on the full credit balance and paid (less PIE tax) into your Notice Saver on the last business day of each month.',
          `The rates of return are current as at ${updatedAt}, are variable and can change without notice.`,
        ],
        disclosures: [],
      },
      {
        title: 'Accessibility',
        details: [
          'Apply in branch or via the Contact Centre',
          'Access in Westpac One® online banking to view balances and transfer funds in.',
          'Make deposits in Westpac One® online banking, the branch, via the Contact Centre or by direct debit or automatic payment.',
          'Withdrawals must be requested via branch or Contact Centre and (outside of the 7 day cooling off period) will be subject to the 32 day notice period (see more in Important things to know).',
        ],
        disclosures: [],
      },
      {
        title: 'Important things to know',
        details: [
          `Please read the <a href="${config.productItems.noticeSaver.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Notice Saver PIE Fund Term Sheet</a>, which contains the full terms and conditions for Notice Saver.`,
          `You have seven working days as a cooling off period after you open your account, in case you change your mind. Once you are invested, you must give us 32 days’ notice to make a withdrawal.  If we agree you are suffering financial hardship, you can withdraw all or part of your investment without giving 32 days’ notice - our <a href="${config.productItems.noticeSaver.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> for Notice Saver will apply.`,
        ],
        disclosures: [],
      },
    ],
    fees: {
      accountFees: [
        {
          type: 'Monthly account maintenance fee',
          amount: noticeSaver.accountFees.maintenanceFee?.value!,
        },
        {
          type: 'Paper statements',
          amount: noticeSaver.accountFees.paperStatementsFee?.value!,
        },
        {
          type: 'Staff assisted withdrawals',
          amount: noticeSaver.accountFees.manualWithdrawals?.value!,
        },
        {
          type: 'Deposits / fund transfers',
          amount: noticeSaver.accountFees.depositFee?.value!,
        },
      ],
      serviceFees: [
        {
          type: 'Phone Banking - each call',
          amount: noticeSaver.serviceFees.callFee?.value!,
        },
      ],
      serviceFeesDisclaimer: `
      <p>Service fees may apply for additional transactions or services you request. Find out more <a href="${config.links.fees}" target="_blank" rel="noopener noreferrer">here.</a>.</p>
      <p>The fees are current as at ${updatedAt}.</p>
      `,
    },
    benefitsComparison: `
    <p>Our highest-earning savings investment account (outside term investments), requiring 32 days’ notice before making a withdrawal.</p>
    <p>Higher after-tax returns for some investors due to PIE tax benefits.</p>
    <p>Delay for withdrawals to minimise impulse purchases.</p>
  `,
    feesComparison: `
    <p><b>No fees.</b></p>
  `,
    ratesComparison: `
    <p><b>${noticeSaver.rateBreakdown.annualRate}% p.a.</b></p>
  `,
    thingsToKnowComparison: `
    <p>Please read the <a href="${config.productItems.noticeSaver.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Notice Saver Fund Term Sheet</a>, which contains the full terms and conditions for Notice Saver.</p>
    <p>A different type of tax rate is used for PIE accounts – Prescribed Investor Rate (PIR). If your income tax rate is higher than the PIR, you will pay a lower tax rate in a PIE than in a comparable non-PIE account.</p>
    <p>You have seven working days as a cooling off period after you open your account, in case you change your mind. Once you are invested, you need to give 32 days’ notice to make a withdrawal. If we agree you are suffering financial hardship, you can withdraw all or part of your investment without giving 32 days’ notice. Our <a href="${config.productItems.noticeSaver.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> for Notice Saver will apply.</p>
  `,
    disclosures: [
      `
      Notice Saver is offered under the Westpac Notice Saver PIE Fund (the “Fund”). Investments made in the Fund do not represent bank deposits or other liabilities of Westpac Banking Corporation ABN 33 007 457 141, Westpac New Zealand Limited (“Westpac NZ”) or other members of the Westpac group of companies.  They are subject to investment and other risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested. 
      None of BT Funds Management (NZ) Limited (as manager), any member of the Westpac group of companies, Trustees Executors Limited (as trustee),  or any director or nominee of any of those entities guarantees the Fund’s performance, returns or repayment of capital.  Westpac NZ's General Terms and Conditions (including online banking terms) apply to the account and any investments in the fund. 
      You can get more information and free copies of the Disclosure Statement for Westpac NZ, Westpac NZ's General Terms and Conditions and the term sheet for the Fund from any Westpac branch or online <a href="${config.productItems.noticeSaver.westpacDocumentsUrl}" target="_blank" rel="noopener noreferrer">here</a>. A copy of the Trust Deed for the Fund can be accessed <a href="${config.productItems.noticeSaver.trustDeedUrl}" target="_blank" rel="noopener noreferrer">here</a>.
      `,
    ],
    disclosuresPDF: [
      '<p>Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.</p>',
      '<p>Notice Saver is offered under the Westpac Notice Saver PIE Fund ("the Fund”).  Investments made in the Fund do not represent bank deposits or other liabilities of Westpac Banking Corporation ABN 33 007 457 141, Westpac New Zealand Limited (“Westpac NZ”) or other members of the Westpac group of companies.',
      '<br/>Investments are subject to risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.</p>',
    ],
  }

  const PRODUCT_BONUS_SAVER_ACCOUNT: IProductChooserProductItem = {
    ...config.productItems.bonusSaverAccount,
    applyTitle: 'Opening an account.',
    type: 'bonusSaverAccount',
    title: 'Westpac Bonus Saver',
    description: [
      'This is a savings account which rewards you with bonus interest for growing your balance.',
      'This account is often used for saving for a goal like a holiday or a house deposit. It also works well if you’re regularly putting money aside for a rainy day.',
    ],
    shortDescription:
      'Our Westpac Bonus Saver account rewards you with bonus interest if you increase your balance by $20 each month (must be $20 more than  the balance on the last business day of the month prior, and excludes interest earned and fees charged to the account). Interest is compounded and you have immediate access to your money.',
    interestRatesTitle: 'Interest rate.',
    interestRates: [
      {
        annualRatePercent: bonusSaverAccount.rateBreakdown.annualRate,
        description: `
          <p>Potential rate of ${bonusSaverAccount.rateBreakdown.annualRate}% p.a. (base rate of ${bonusSaverAccount.rateBreakdown.baseRate}% p.a. + bonus rate of ${bonusSaverAccount.rateBreakdown.bonusRate}% p.a.).</p>
          <p>You’ll get bonus interest if the account balance on the last business day of the month is at least $20 higher than it was on the last business day of the month prior.*</p>
        `,
        disclosure: `Interest rates are current as at ${updatedAt} - rates are variable and are subject to change without notice.`,
        breakdown: [
          {
            annualRatePercent: bonusSaverAccount.rateBreakdown.baseRate!,
            description: '(base interest)',
          },
          {
            annualRatePercent: bonusSaverAccount.rateBreakdown.bonusRate!,
            description: '(bonus interest)',
          },
        ],
      },
    ],
    benefits: [
      `Potential interest rate of ${bonusSaverAccount.rateBreakdown.annualRate}% p.a. if your balance is $20 greater than on the last business day of the prior month.* Interest is compounded and paid monthly.`,
      'Get immediate access to your money with unlimited withdrawals.',
      'No monthly account maintenance fees.',
    ],
    details: [
      {
        title: 'How you earn interest',
        details: [
          'The potential to earn bonus interest if the account balance on the last business day of the month is $20 greater than on the last business day of the month prior.*',
          'Interest is calculated daily on the full credit balance and paid (less tax) into your Westpac Bonus Saver account on the last business day of each month.',
          `Interest rates are current as at ${updatedAt}, are variable and are subject to change without notice.`,
        ],
        disclosures: [
          '*The $20 excludes interest earned on the account and/or Westpac fees charged to the account.',
        ],
      },
      {
        title: 'Accessibility',
        details: [
          'Apply in Westpac One® online banking, the branch, and via the Contact Centre.',
          'Access in Westpac One® online banking, Phone Banking, via the Contact Centre^ or in branch^',
        ],
        disclosures: ['^Refer to the Fees section.'],
      },
      {
        title: 'Important things to know',
        details: [
          'The above rates are not available to financial institutions.',
          `Full details of the Westpac General Terms and Conditions are available <a href="${config.links.termsAndConditions}" target="_blank" rel="noopener noreferrer">here</a> or from any Westpac branch in New Zealand.`,
          'Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.',
        ],
        disclosures: [],
      },
    ],
    fees: {
      accountFees: [
        {
          type: 'Monthly account maintenance fee',
          amount: bonusSaverAccount.accountFees.maintenanceFee?.value!,
        },
        {
          type: 'Electronic statements',
          amount: bonusSaverAccount.accountFees.electronicStatementsFee?.value!,
        },
        {
          type: 'Paper statements*',
          amount: bonusSaverAccount.accountFees.paperStatementsFee?.value!,
        },
        {
          type: 'Electronic withdrawals',
          amount: bonusSaverAccount.accountFees.electronicWithdrawals?.value!,
        },
        {
          type: 'Staff assisted withdrawals*',
          amount: `${
            bonusSaverAccount.accountFees.manualWithdrawals?.value
          } (${bonusSaverAccount.accountFees.manualWithdrawals?.frequency?.toLowerCase()})`,
        },
        {
          type: 'Cheque withdrawals*',
          amount: `${
            bonusSaverAccount.accountFees.chequeWithdrawals?.value
          } (${bonusSaverAccount.accountFees.chequeWithdrawals?.frequency?.toLowerCase()})`,
        },
        {
          type: 'Deposits / funds transfers',
          amount: bonusSaverAccount.accountFees.depositFee?.value!,
        },
      ],
      accountFeesDisclaimer: `
      <p>*Fees relate to Westpac Bonus Saver only. Standard fees will apply to the account which money is being transferred to or from.</p>
      <p>Fee exemptions available for customers aged under 19, customers over 65 and superannuitants.</p>
    `,
      serviceFees: [
        {
          type: 'Phone Banking - each call',
          amount: bonusSaverAccount.serviceFees.callFee?.value!,
        },
        {
          type: 'Email alerts',
          amount: bonusSaverAccount.serviceFees.emailAlertFee?.value!,
        },
        {
          type: 'Online automatic payments set up and amend',
          amount: bonusSaverAccount.serviceFees.onlinePaymentSetupFee?.value!,
        },
        {
          type: 'Branch and phone payments set up and amend',
          amount: bonusSaverAccount.serviceFees.branchPaymentSetupFee?.value!,
        },
      ],
      serviceFeesDisclaimer: `
      <p>*Service fees may apply for additional transactions or services you request. Find out more <a href="${config.links.fees}" target="_blank" rel="noopener noreferrer">here</a>.</p>
      <p>The fees are current as at ${updatedAt}.</p>
    `,
    },
    benefitsComparison: `
    <p>The potential to earn bonus interest if the account balance is $20 greater on the last business day of the month than the balance on the last business day of the month prior. The $20 excludes interest earned on the account and/or Westpac fees charged to the account.</p>
    <p>Payments can be made directly in and out of your Westpac Bonus Saver account via Westpac One® online banking.</p>
  `,
    feesComparison: `
    <p>Monthly account fee: <b>${
      bonusSaverAccount.accountFees.maintenanceFee?.value
    }</b></p>
    <p>Electronic transactions: <b>${
      bonusSaverAccount.accountFees.electronicStatementsFee?.value
    }</b></p>
    <p>Manual transactions: deposits <b>${
      bonusSaverAccount.accountFees.depositFee?.value
    }</b>, withdrawals <b>${
      bonusSaverAccount.accountFees.manualWithdrawals?.value
    }</b> (${bonusSaverAccount.accountFees.manualWithdrawals?.frequency?.toLowerCase()})</p>
    <p>Statements: electronic <b>${
      bonusSaverAccount.accountFees.electronicStatementsFee?.value
    }</b> or paper <b>${
      bonusSaverAccount.accountFees.paperStatementsFee?.value
    }</b> per statement.</p>
  `,
    ratesComparison: `
    <p><b>Up to ${bonusSaverAccount.rateBreakdown.annualRate}% p.a.</b></p>
    (${bonusSaverAccount.rateBreakdown.baseRate}% p.a. base rate + ${bonusSaverAccount.rateBreakdown.bonusRate}% p.a. potential monthly bonus).</p>
  `,
    thingsToKnowComparison:
      'You will need to fulfil the bonus rate criteria to receive the bonus interest rate.',
    disclosuresPDF: [
      '<p>Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.</p>',
    ],
  }

  const PRODUCT_BONUS_SAVER_PIE: IProductChooserProductItem = {
    ...config.productItems.bonusSaverPIE,
    applyTitle: 'Opening an account.',
    type: 'bonusSaverPIE',
    title: 'Westpac Bonus Saver PIE',
    description: [
      'As you have a higher tax rate, we recommend Westpac Bonus Saver PIE. This is an investment option rather than a traditional savings account. It rewards you for regular saving and there can be added tax benefits.',
      'This investment option works if you’re saving for a goal, like a holiday or to start saving for a house deposit. It’s also suitable for putting money regularly aside for a rainy day or growing your savings a little faster than a regular savings account - with potentially less tax to pay each month.',
    ],
    shortDescription:
      'A savings account for serious savers. Enjoy the same benefits of the Westpac Bonus Saver account with the added advantage of potentially paying less tax so you can save more. The potential of bonus monthly returns when you increase your balance by $20 each month (must be $20 more than  the balance on last business day of the month prior and excludes interest earned and fees charged to the account).',
    interestRatesTitle: 'Rate of return.',
    interestRates: [
      {
        annualRatePercent: bonusSaverPIE.rateBreakdown.annualRate,
        description: `
          <p><b>Potential rate of ${bonusSaverPIE.rateBreakdown.annualRate}% p.a. (base rate of ${bonusSaverPIE.rateBreakdown.baseRate}% p.a. + bonus rate of ${bonusSaverPIE.rateBreakdown.bonusRate}% p.a.)</b></p>
          <p>The potential to earn bonus returns if your balance on the last business day of the month is $20 greater than on the last business day of the month prior.*</p>
        `,
        effectiveReturn: {
          thirty: bonusSaverPIE.rateBreakdown.returnRate?.thirty!,
          thirtyThree: bonusSaverPIE.rateBreakdown.returnRate?.thirtyThree!,
        },
        breakdown: [
          {
            annualRatePercent: bonusSaverPIE.rateBreakdown.baseRate!,
            description: '(base interest)',
          },
          {
            annualRatePercent: bonusSaverPIE.rateBreakdown.bonusRate!,
            description: '(bonus interest)',
          },
        ],
      },
    ],
    interestRatesDisclaimer: `
      <p>*The rates of return are current as at ${updatedAt}. Rates are variable and are subject to change without notice.</p>
      <p>^ The effective return is the rate you would need to receive from a regular savings account to achieve the same after-tax return as your Westpac Bonus Saver PIE account, based on a PIR of 28% and an income tax rate of either 30% or 33%.^^ Individuals with taxable income of $48,001 to $70,000.^^^ Individuals with taxable income of $70,001 and over.</p>
    `,
    video: PIE_VIDEO_BLOCK,
    benefits: [
      'The potential to earn bonus returns when you save regularly*.',
      'Immediate access to your money with unlimited withdrawals.',
      'Westpac Bonus Saver PIE has an added tax benefit: your balance could earn more after tax when compared to a traditional savings account earning the same interest rate.',
      'Tax on your earnings in a Westpac Bonus Saver PIE is paid by Westpac on your behalf, so you don’t need to do it (provided we hold your correct PIR for the whole tax year).',
      'No monthly account maintenance fees.',
    ],
    details: [
      {
        title: 'How you earn returns',
        details: [
          'The potential to earn bonus returns if the account balance on the last business day of the month is $20 greater than on the last business day of the month prior.*',
          'Based on the tax residency and tax rate you have provided, you will benefit from paying tax on returns at a PIR instead of at income tax rate.',
          'Returns are calculated daily on the full credit balance and paid (less PIE tax) into your Westpac Bonus Saver PIE on the last business day of each month.',
          `The rates of return are current as at ${updatedAt}, are variable in nature and are subject to change without notice.`,
        ],
        disclosures: [
          '*The $20 excludes returns earned on the account and/or Westpac fees charged to the account.',
        ],
      },
      {
        title: 'Accessibility',
        details: [
          'Apply via the Contact Centre or in branch.',
          'Access in Westpac One® online banking, via the Contact Centre^, Phone Banking or in the branch^.',
        ],
        disclosures: ['^Refer to Fees.'],
      },
      {
        title: 'Important things to know',
        details: [
          `Please read the <a href="${config.productItems.bonusSaverPIE.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Cash PIE Fund Term Sheet</a>, which contains the full terms and conditions for Westpac Bonus Saver PIE.`,
          'Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.',
        ],
        disclosures: [],
      },
    ],
    fees: {
      accountFees: [
        {
          type: 'Monthly account maintenance fee',
          amount: bonusSaverPIE.accountFees.maintenanceFee?.value!,
        },
        {
          type: 'Electronic statements',
          amount: bonusSaverPIE.accountFees.electronicStatementsFee?.value!,
        },
        {
          type: 'Paper statements*',
          amount: bonusSaverPIE.accountFees.paperStatementsFee?.value!,
        },
        {
          type: 'Electronic withdrawals',
          amount: bonusSaverPIE.accountFees.electronicWithdrawals?.value!,
        },
        {
          type: 'Staff assisted withdrawals*',
          amount: `${
            bonusSaverPIE.accountFees.manualWithdrawals?.value
          } (${bonusSaverPIE.accountFees.manualWithdrawals?.frequency?.toLowerCase()})`,
        },
        {
          type: 'Cheque withdrawals*',
          amount: `${
            bonusSaverPIE.accountFees.chequeWithdrawals?.value
          } (${bonusSaverPIE.accountFees.chequeWithdrawals?.frequency?.toLowerCase()})`,
        },
        {
          type: 'Deposits / fund transfers',
          amount: bonusSaverPIE.accountFees.depositFee?.value!,
        },
      ],
      serviceFees: [
        {
          type: 'Phone Banking - each call',
          amount: bonusSaverPIE.serviceFees.callFee?.value!,
        },
        {
          type: 'Email alerts',
          amount: bonusSaverPIE.serviceFees.emailAlertFee?.value!,
        },
        {
          type: 'Online automatic payments set up and amend',
          amount: bonusSaverPIE.serviceFees.onlinePaymentSetupFee?.value!,
        },
        {
          type: 'Branch and phone payments set up and amend',
          amount: bonusSaverPIE.serviceFees.branchPaymentSetupFee?.value!,
        },
      ],
      accountFeesDisclaimer: `
      <p>Fee exemptions available for customers aged under 19, customers over 65 and superannuitants.</p>
      <p>*Manual withdrawal fees and paper statement fees are charged by BT Funds Management (NZ) Limited as manager and issuer of the Westpac Cash PIE Fund.</p>
    `,
      serviceFeesDisclaimer: `
      <p>Service fees may apply for additional transactions or services you request. Find out more <a href="${config.links.fees}" target="_blank" rel="noopener noreferrer">here</a>.</p>
      <p>The fees are current as at ${updatedAt}.</p>
    `,
    },
    benefitsComparison: `
    <p>The potential to earn bonus returns if the account balance is $20 greater on the last business day of the month than the balance on the last business day of the month prior. The $20 excludes returns earned on the account and/or Westpac fees charged to the account.</p>
    <p>Higher after-tax returns for some investors.</p>
    <p>No minimum balance required.</p>
  `,
    feesComparison: `
    <p>Monthly account fee: <b>${bonusSaverPIE.accountFees.maintenanceFee?.value}</b></p>
    <p>Electronic transactions: <b>${bonusSaverPIE.accountFees.electronicStatementsFee?.value}</b></p>
    <p>Manual transactions: deposits <b>${bonusSaverPIE.accountFees.depositFee?.value}</b>, withdrawals <b>${bonusSaverPIE.accountFees.manualWithdrawals?.value}</b></p>
    <p>Statements: electronic <b>${bonusSaverPIE.accountFees.electronicStatementsFee?.value}</b> or paper <b>${bonusSaverPIE.accountFees.paperStatementsFee?.value}</b> per statement.</p>
  `,
    ratesComparison: `
    <p><b>Up to ${bonusSaverPIE.rateBreakdown.annualRate}% p.a.</b></p>
    (${bonusSaverPIE.rateBreakdown.baseRate}% p.a. base rate + ${bonusSaverPIE.rateBreakdown.bonusRate}% p.a. potential monthly bonus).</p>
  `,
    thingsToKnowComparison: `
    <p>Please read the <a href="${config.productItems.bonusSaverPIE.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Cash PIE Fund Term Sheet</a>, which contains the full terms and conditions for Westpac Bonus Saver PIE.</p>
    <p>You will need to fulfil the bonus rate criteria to receive the bonus return rate.</p>
    <p>A different type of tax rate is used for PIE accounts - Prescribed Investor Rate (PIR).  If your income tax rate is higher than the PIR, you will pay a lower tax rate in a PIE than in a comparable non-PIE account.</p>
    <p>Tax on your earnings in a Westpac Term PIE is paid by Westpac on your behalf, so you don’t need to do it (provided we hold your correct PIR for the whole tax year).</p>
  `,
    disclosuresPDF: [
      '<p>Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.</p>',
      '<p>Westpac Bonus Saver PIE is offered under the Westpac Cash PIE Fund. Investments made in the Fund do not represent bank deposits or liabilities of Westpac New Zealand Limited (“Westpac NZ”), Westpac Banking Corporation ABN 33 007 457 141 or any other member of the Westpac group of companies.',
      '<br/>Investments are subject to risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.',
      '<br/>None of: BT Funds Management (NZ) Limited (as manager); Trustees Executors Limited (as trustee); any member of the Westpac group of companies; nor any other person guarantees the Fund’s performance, returns, or repayment of capital.</p>',
    ],
  }

  const PRODUCT_TERM_DEPOSIT: IProductChooserProductItem = {
    ...config.productItems.termDeposit,
    applyTitle: 'Opening a Term Deposit.',
    type: 'termDeposit',
    title: 'Term Deposit',
    description: [
      'As you don’t need your money available immediately, and you’re not looking to add more to your initial investment, we recommend a Term Deposit. ',
      'Put away as little as $5,000 for a fixed term and earn a fixed interest rate.',
      'Term Deposits are useful because they provide an agreed rate over a fixed time period, so you know what your returns will be and when you’ll receive them. This makes them suitable for growing your money, and potentially for providing an income, depending on the payment options and terms you choose.',
    ],
    shortDescription:
      'A Term Deposit can help you grow your savings - invest $5,000 or more for a fixed term and earn a fixed interest rate. A simple way to invest for a fixed timeframe. Terms available from 30 days to 5 years. You can choose to earn income regularly or compound it for faster growth, depending on your term.',
    interestRatesTitle: 'Interest Rates.',
    interestRatesDescription:
      'Our Term Deposits are a simple fee-free way to invest $5,000 or more. They earn a fixed interest rate for a fixed period of time. If you can lock your money away, you are generally rewarded with a higher rate.',
    interestRates: [
      {
        annualRatePercent: termDeposit.rateBreakdown.term1.annualRate,
        durationInMonths: termDeposit.rateBreakdown.term1.termLength,
        description: 'Interest at maturity, periodically or compounding',
      },
      {
        annualRatePercent: termDeposit.rateBreakdown.term2.annualRate,
        durationInMonths: termDeposit.rateBreakdown.term2.termLength,
        description: 'Interest at maturity, periodically or compounding',
      },
      {
        annualRatePercent: termDeposit.rateBreakdown.term3.annualRate,
        durationInMonths: termDeposit.rateBreakdown.term3.termLength,
        description: 'Interest at maturity, periodically or compounding',
      },
    ],
    interestRatesDisclaimer: `
    <p>Rates are subject to change without notice.^ Once you’ve locked in a rate, it will not change during the term (unless you make an early withdrawal - see <a href="#more-details">Important things to know</a>).</p>
    <p>Terms available from 30 days to 5 years.</p>
  `,
    benefits: [
      'A simple, straightforward way to invest for a fixed timeframe - with everything agreed upfront.',
      'A fixed interest rate to lock in your savings.',
      'Depending on your term, the option to receive regular income from your investment or compound it for faster growth.',
      'Easy to set up and refix in Westpac One® online banking.',
    ],
    details: [
      {
        title: 'Accessibility',
        details: [
          'Apply in Westpac One® online banking, the branch, or via Contact Centre.',
          `<b>Withdrawals</b>: Choosing to invest in a Term Deposit means you’re willing to keep your money invested for a fixed time frame.`,
          `You have seven working days as a cooling off period after you open your Term Deposit, in case you change your mind. Once you are invested your savings will be locked in, and you can only make an early withdrawal if we agree and you have given us 32 days’ notice. If we agree you are suffering financial hardship, you can withdraw all or part of your investment without giving 32 days’ notice. Our <a href="${config.productItems.termDeposit.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> for Term Deposits will apply.`,
        ],
        disclosures: [],
      },
      {
        title: 'Important things to know',
        details: [
          `Please read the <a href="${config.productItems.termDeposit.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Term Deposits Term Sheet</a> which contains the full terms and conditions for our Term Deposits.`,
          `In deciding whether to agree to an early withdrawal, we will apply our <a href="${config.productItems.termDeposit.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> which may change from time to time. A reduced interest rate will apply, unless determined otherwise under our Early Withdrawal Policy.`,
          'Rates are available for Retail and Business Banking customers and apply up to the first $5,000,000 of deposits held either solely or jointly with Westpac. For rates applicable to amounts in excess of $5,000,000, please contact us.',
          'Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.',
        ],
        disclosures: [],
      },
    ],
    fees: {
      accountFees: [
        {
          type: 'Monthly account maintenance fee',
          amount: termDeposit.accountFees.maintenanceFee?.value!,
        },
        {
          type: 'Paper statement',
          amount: termDeposit.accountFees.paperStatementsFee?.value!,
        },
      ],
      serviceFees: [],
      serviceFeesEmptyState: `
          <p>Service fees may apply for additional transactions or services you request. Find out more <a href="${config.links.fees}" target="_blank" rel="noopener noreferrer">here</a>.</p> 
          <p>The fees are current as at ${updatedAt}</p>
        `,
    },
    benefitsComparison: `
    <p>Invest $5,000 or more for a fixed term and earn a fixed interest rate.</p>
    <p>Choose to earn income regularly or compound it for faster growth, depending on your term.</p>
    <p>No monthly fees.</p>
  `,
    feesComparison: `
    <p><b>No fees.</b></p>
  `,
    ratesComparison: `
    <p><b>${termDeposit.rateBreakdown.term1.annualRate}%</b> p.a.: ${termDeposit.rateBreakdown.term1.termLength} term</p>
    <p><b>${termDeposit.rateBreakdown.term2.annualRate}%</b> p.a.: ${termDeposit.rateBreakdown.term2.termLength} term</p>
    <p><b>${termDeposit.rateBreakdown.term3.annualRate}%</b> p.a.: ${termDeposit.rateBreakdown.term3.termLength} term</p>
    <p>Terms available from 30 days to 5 years.</p>
  `,
    thingsToKnowComparison: `
    <p>Please read the <a href="${config.productItems.termDeposit.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Term Deposit Term Sheet</a>, which contains the full terms and conditions for Term Deposit.</p>
    <p>Withdrawals: Choosing to invest in a Term Deposit means you’re willing to keep your money invested for a fixed time frame.</p>
    <p>You have seven working days as a cooling off period after you open your Term Deposit, in case you change your mind. Once you are invested, you can only make an early withdrawal if we agree and you have given us 32 days’ notice. If we agree you are suffering financial hardship, you can withdraw all or part of your investment without giving 32 days’ notice. Our <a href="${config.productItems.termDeposit.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> for Term Investments, and generally a reduced interest rate, will apply.</p>
  `,
    disclosuresPDF: [
      '<p>Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.</p>',
    ],
  }

  const PRODUCT_TERM_PIE: IProductChooserProductItem = {
    ...config.productItems.termPIE,
    applyTitle: 'Opening a Westpac Term PIE Fund.',
    type: 'termPIE',
    title: 'Westpac Term PIE Fund',
    description: [
      'As you don’t need your money immediately and you’re not looking to add to your investment, we recommend the Westpac Term PIE Fund. Put away as little as $5,000 for a fixed term and earn a fixed rate of return.',
      'As you are a New Zealand tax resident and have a personal income tax rate of 30% or 33%, there could be added tax benefits.',
      'Term PIEs have a fixed rate of return agreed upfront for a set amount of time and offer a range of pay out options.',
    ],
    shortDescription:
      'With a Term PIE you invest a fixed amount for a set period of time at an agreed rate of return. Term PIEs are governed by special tax rules and could have a tax benefit meaning more returns after tax. Terms available from 7 days to 5 years. You can choose to earn income regularly or compound it for faster growth, depending on your term.',
    interestRatesTitle: 'Our Term PIE rates.',
    interestRatesDescription: [
      'Our Term PIEs are a simple fee-free way to invest $5,000 or more. They earn a fixed rate of return for a fixed period of time. If you can lock your money away, you are generally rewarded with a higher rate, and certainty on your returns.',
      'As a PIE, this investment could provide you with a higher effective return. Because you may potentially pay less tax, your savings could grow a little faster in a Term PIE than in a regular Term Deposit with the same term and rate.',
    ],
    interestRates: [
      {
        annualRatePercent: termPIE.rateBreakdown.term1.annualRate,
        durationInMonths: termPIE.rateBreakdown.term1.termLength,
        effectiveReturn: {
          thirty: termPIE.rateBreakdown.term1.returnRate?.thirty!,
          thirtyThree: termPIE.rateBreakdown.term1.returnRate?.thirtyThree!,
        },
      },
      {
        annualRatePercent: termPIE.rateBreakdown.term2.annualRate,
        durationInMonths: termPIE.rateBreakdown.term2.termLength,
        effectiveReturn: {
          thirty: termPIE.rateBreakdown.term2.returnRate?.thirty!,
          thirtyThree: termPIE.rateBreakdown.term2.returnRate?.thirtyThree!,
        },
      },
      {
        annualRatePercent: termPIE.rateBreakdown.term3.annualRate,
        durationInMonths: termPIE.rateBreakdown.term3.termLength,
        effectiveReturn: {
          thirty: termPIE.rateBreakdown.term3.returnRate?.thirty!,
          thirtyThree: termPIE.rateBreakdown.term3.returnRate?.thirtyThree!,
        },
      },
    ],
    interestRatesDisclaimer: `
    <p>Rates of return and effective rates are current as at ${updatedAt} and are subject to change without notice. Once you’ve locked in a rate, it will not change during the term (unless you make an early withdrawal). Terms available from 30 days to 5 years.</p>
    <p>^The effective return is the rate you would need to receive from a regular savings account to achieve the same after-tax return from your Term PIE account, based on a PIR of 28% and an income tax rate of either 30% or 33%. 
    ^^Individuals with taxable income of $48,001 to $70,000. ^^^Individuals with taxable income of $70,001 and over.</p>
  `,
    video: PIE_VIDEO_BLOCK,
    benefits: [
      'A simple way to invest from 30 days to 5 years.',
      'Tax on returns is capped at 28% - so if your income tax rate is 30% or 33%, a Term PIE provides higher after-tax returns when compared to a Term Deposit for the same rate and term. This means your investment could grow a little faster.',
      'If you can lock your money away, you are generally rewarded with a higher rate.',
    ],
    details: [
      {
        title: 'Accessibility',
        details: [
          'Apply in branch, or via Contact Centre.',
          `<b>Withdrawals</b>: Choosing to invest in a Term PIE means you’re willing to keep your money invested for a fixed time frame.`,
          `You have seven working days as a cooling off period after you open your Term PIE, in case you change your mind. Once you are invested your savings will be locked in, and you can only make an early withdrawal if we agree and you have given us 32 days’ notice. If we agree you are suffering financial hardship, you can withdraw all or part of your investment without giving 32 days’ notice. Our <a href="${config.productItems.termDeposit.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> for Term Investments will apply.`,
        ],
        disclosures: [],
      },
      {
        title: 'Important things to know',
        details: [
          `Please read the <a href="${config.productItems.termPIE.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Term PIE Fund Term Sheet</a> which contains the full terms and conditions for our Term PIEs.`,
          `In deciding whether to agree to an early withdrawal, we will apply our <a href="${config.productItems.termPIE.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> which may change from time to time. A reduced interest rate will apply, unless determined otherwise under our Early Withdrawal Policy.`,
          'Rates are available for Retail and Business Banking customers and apply up to the first $5,000,000 of deposits held either solely or jointly with Westpac. For rates applicable to amounts in excess of $5,000,000, please contact us.',
          'Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.',
        ],
        disclosures: [],
      },
    ],
    fees: {
      accountFees: [
        {
          type: 'Monthly account maintenance fee',
          amount: termPIE.accountFees.maintenanceFee?.value!,
        },
        {
          type: 'Paper statements',
          amount: termPIE.accountFees.paperStatementsFee?.value!,
        },
      ],
      serviceFees: [],
      serviceFeesEmptyState: `
          <p>Service fees may apply for additional transactions or services you request. Find out more <a href="${config.links.fees}" target="_blank" rel="noopener noreferrer">here</a>.</p> 
          <p>The fees are current as at ${updatedAt}</p>
        `,
    },
    benefitsComparison: `
    <p>A better after-tax return for some investors, so it may grow your money faster.</p>
    <p>Returns can be paid monthly, quarterly or compounded, depending on your term.</p>
    <p>Fixed rate of return locked in to maximise your savings.</p>
    <p>No monthly fees.</p>
  `,
    feesComparison: `
    <p>Monthly account fee: <b>${termPIE.accountFees.maintenanceFee?.value}</b></p>
    <p>Paper statements: <b>${termPIE.accountFees.paperStatementsFee?.value}</b></p>
  `,
    ratesComparison: `
    <p><b>${termPIE.rateBreakdown.term1.annualRate}% p.a.</b> (${termPIE.rateBreakdown.term1.termLength} months)\nEffective return\nIf your income tax rate is 30%^: ${termPIE.rateBreakdown.term1.returnRate?.thirty}\nIf your income tax rate is 33%^: ${termPIE.rateBreakdown.term1.returnRate?.thirtyThree}^^</p>
    <p><b>${termPIE.rateBreakdown.term2.annualRate}% p.a.</b> (${termPIE.rateBreakdown.term2.termLength} months)\nEffective return\nIf your income tax rate is 30%^: ${termPIE.rateBreakdown.term2.returnRate?.thirty}\nIf your income tax rate is 33%^: ${termPIE.rateBreakdown.term2.returnRate?.thirtyThree}^^</p>
    <p><b>${termPIE.rateBreakdown.term3.annualRate}% p.a.</b> (${termPIE.rateBreakdown.term3.termLength} months)\nEffective return\nIf your income tax rate is 30%^: ${termPIE.rateBreakdown.term3.returnRate?.thirty}\nIf your income tax rate is 33%^: ${termPIE.rateBreakdown.term3.returnRate?.thirtyThree}^^</p>
    <p>Terms available from 30 days to 5 years</p>
  `,
    thingsToKnowComparison: `
    <p>Please read the <a href="${config.productItems.termPIE.termSheetUrl}" target="_blank" rel="noopener noreferrer">Westpac Term Deposit Term Sheet</a>, which contains the full terms and conditions for the Term PIE Fund.</p>
    <p>A different type of tax rate is used for PIE - Prescribed Investor Rate (PIR). If your income tax rate is higher than the PIR, you will pay a lower tax rate in a PIE than in a comparable non-PIE investment.</p>
    <p>Withdrawals: Choosing to invest in a Term PIE means you’re willing to keep your money invested for a fixed time frame.</p>
    <p>You have seven working days as a cooling off period after you open your Term PIE, in case you change your mind. Once you are invested, you can only make an early withdrawal if we agree and you have given us 32 days’ notice. If we agree you are suffering financial hardship, you can withdraw all or part of your investment without giving 32 days’ notice. Our <a href="${config.productItems.termPIE.earlyWithdrawalUrl}" target="_blank" rel="noopener noreferrer">Early Withdrawal Policy</a> for Term Investments, and generally a reduced rate of return, will apply.</p>
  `,
    disclosuresPDF: [
      '<p>Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.</p>',
      '<p>Term PIE is offered under the Westpac Term PIE Fund (“the Fund”).  Investments made in the Fund do not represent bank deposits or other liabilities of Westpac Banking Corporation (ABN 33 007 457 141), Westpac New Zealand Limited or other members of the Westpac group of companies.',
      '<br/>Investments are subject risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.',
      '<br/>None of BT Funds Management (NZ) Limited (as manager); any member of the Westpac group of companies; Trustees Executors Limited (as trustee); or any director or nominee of any of those entities guarantees the Fund’s performance, returns or repayment of capital.</p>',
    ],
  }

  const PRODUCT_SIMPLE_SAVER: IProductChooserProductItem = {
    ...config.productItems.simpleSaver,
    applyTitle: 'Opening an account.',
    type: 'simpleSaver',
    title: 'Simple Saver',
    description:
      'The name says it all. This no-fuss savings account gives you the same competitive interest rate, whatever your balance. And your first manual or electronic withdrawal each month is free.',
    shortDescription:
      'Our Simple Saver account gives you the same interest rate, whatever your balance. Earn the same set interest rate on every dollar you save, with no monthly account maintenance fee to pay and no minimum balance required. Other account fees apply.',
    interestRates: [
      { annualRatePercent: simpleSaver.rateBreakdown.annualRate },
    ],
    fees: {
      accountFees: [],
      serviceFees: [],
    },
    benefits: [
      'Earn the same interest rate on every dollar you save.',
      'No minimum balance required.',
    ],
    benefitsComparison: `
    <p>Earn the same interest rate on every dollar you save.</p>
    <p>No minimum balance required.</p>
  `,
    feesComparison: `
    <p>Monthly account fee: <b>${simpleSaver.accountFees.maintenanceFee?.value}</b></p>
    <p>Electronic transactions: deposits <b>${simpleSaver.accountFees.depositFee?.value}</b>, first manual or electronic withdrawal each month is <b>${simpleSaver.accountFees.firstWithdrawal?.value}</b> then <b>${simpleSaver.accountFees.electronicWithdrawals?.value}</b> per withdrawal</p>
    <p>Manual transactions: deposit <b>${simpleSaver.accountFees.depositFee?.value}</b>, withdrawals <b>${simpleSaver.accountFees.manualWithdrawals?.value}</b> each</p>
    <p>Statements: electronic <b>${simpleSaver.accountFees.electronicStatementsFee?.value}</b>, paper <b>${simpleSaver.accountFees.paperStatementsFee?.value}</b> per statement.</p>
  `,
    ratesComparison: `
    <p><b>${simpleSaver.rateBreakdown.annualRate}% p.a.</b></p>
  `,
    thingsToKnowComparison:
      'If you are under 19, you may qualify for no monthly account or transaction fees.',
    disclosuresPDF: [
      '<p>Our recommendation is based on your responses. If your circumstances change, please complete the Savings & Investment Chooser tool again to update the recommendation.',
    ],
  }

  const PRODUCT_BONUS_SAVER_ACCOUNT_NON_RESIDENT: IProductChooserProductItem = {
    ...PRODUCT_BONUS_SAVER_ACCOUNT,
    description: [
      'As you’re not a New Zealand tax resident, this is a savings account that will work for you, rewarding you with a bonus interest for growing your balance.',
      'This account is often used for saving for a goal like a holiday or a house deposit. It also works well if you’re regularly putting money aside for a rainy day.',
    ],
  }

  /* -----------------------------------------------
                      Steps
   ----------------------------------------------- */

  const PRODUCT_CHOOSER_INITIAL_STEP: IProductChooserStep = {
    type: 'question',
    question: QUESTION_ACCESS_MONEY,
    estimatedProgress: 0,
    getNextStep: (values, customerInteraction) => {
      const accessMoney = values[QUESTION_ACCESS_MONEY.id]
      customerInteraction.whyProductSuitable = `${QUESTION_ACCESS_MONEY.title} - ${accessMoney}; `
      return accessMoney === OPTION_ACCESS_I_CAN_WAIT
        ? DEPOSIT_INTERVAL_STEP
        : NZ_TAX_RESIDENT_STEP
    },
  }

  const DEPOSIT_INTERVAL_STEP: IProductChooserStep = {
    type: 'question',
    question: QUESTION_DEPOSIT_INTERVAL,
    estimatedProgress: 20,
    getNextStep: (values, customerInteraction) => {
      const depositInterval = values[QUESTION_DEPOSIT_INTERVAL.id]
      customerInteraction.whyProductSuitable += `${QUESTION_DEPOSIT_INTERVAL.title} - ${depositInterval}; `
      return depositInterval === OPTION_INTERVAL_NO_MORE
        ? INITIAL_DEPOSIT_STEP
        : NZ_TAX_RESIDENT_STEP
    },
  }

  const INITIAL_DEPOSIT_STEP: IProductChooserStep = {
    type: 'question',
    question: QUESTION_INITIAL_DEPOSIT,
    estimatedProgress: 40,
    getNextStep: (values, customerInteraction) => {
      customerInteraction.whyProductSuitable += `${
        QUESTION_INITIAL_DEPOSIT.title
      } - ${values[QUESTION_INITIAL_DEPOSIT.id]}; `
      return NZ_TAX_RESIDENT_STEP
    },
  }

  const NZ_TAX_RESIDENT_STEP: IProductChooserStep = {
    type: 'question',
    question: QUESTION_NZ_TAX_RESIDENT,
    estimatedProgress: 60,
    getNextStep: (values, customerInteraction) => {
      const taxResident = values[QUESTION_NZ_TAX_RESIDENT.id]
      customerInteraction.whyProductSuitable += `${QUESTION_NZ_TAX_RESIDENT.title} - ${taxResident}; `
      if (values[QUESTION_NZ_TAX_RESIDENT.id] === OPTION_NZ_TAX_RESIDENT_YES) {
        return WHAT_IS_YOUR_TAX_RATE_STEP
      }
      return getRecommendation(values, customerInteraction)
    },
  }

  const WHAT_IS_YOUR_TAX_RATE_STEP: IProductChooserStep = {
    type: 'question',
    question: QUESTION_WHAT_IS_YOUR_TAX_RATE,
    estimatedProgress: 80,
    getNextStep: (values, customerInteraction) => {
      customerInteraction.whyProductSuitable += `${
        QUESTION_WHAT_IS_YOUR_TAX_RATE.title
      } - ${values[QUESTION_WHAT_IS_YOUR_TAX_RATE.id]}; `
      return getRecommendation(values, customerInteraction)
    },
  }

  const isAfterTaxProduct = (type: IProductChooserProductType) => {
    return (
      type === 'noticeSaver' || type === 'termPIE' || type === 'bonusSaverPIE'
    )
  }

  const getComparisonDisclaimer = (
    recommendation: IProductChooserProductItem,
    secondary: IProductChooserProductItem,
    tertiary?: IProductChooserProductItem | undefined
  ) => {
    const { type, title } = recommendation
    const comparison: string[] = []
    comparison.push(`<p>*Rates and fees are current as at ${updatedAt}.</p>`)
    comparison.push(
      `<p>Rates are variable in nature and is subject to change without notice, including after the account has been opened.</p>`
    )
    if (type === 'termDeposit' || type === 'termPIE') {
      comparison.push(
        `<p>Special rates cannot be used in conjunction with any other Westpac promotion, offer or package benefits.</p>`
      )
    }

    if (isAfterTaxProduct(type)) {
      const afterTaxProducts = [title]
      if (isAfterTaxProduct(secondary.type)) {
        afterTaxProducts.push(secondary.title)
      }
      if (tertiary && isAfterTaxProduct(tertiary?.type)) {
        afterTaxProducts.push(tertiary.title)
      }
      const afterTaxProductsText = afterTaxProducts.join(' or ')
      comparison.push(
        `<p>The effective return is the rate you would need to receive from a regular savings account in order to achieve the same after-tax return from your ${afterTaxProductsText} account, based on a PIR of 28% and an income tax rate of either 30% or 33%.
        <br />^Individuals with taxable income of $48,001 to $70,000.
        <br />^^Individuals with taxable income of $70,001 and over.
        </p>
        `
      )
    }
    comparison.push(
      '<p>Service fees may apply for additional services you request.</p>'
    )
    comparison.push(
      `<p>View our <a href="${config.links.interestRates}" target="_blank" rel="noopener noreferrer">full list of rates</a> and <a href="${config.links.fees}" target="_blank" rel="noopener noreferrer">full list of fees</a>.</p>`
    )
    return comparison.join('\n')
  }

  const getRecommendation = (
    values: IValues,
    customerInteraction: ICustomerInteraction
  ) => {
    // default recommendation for most common advice (1, 4, 7, 13 and 14)
    let recommendation: IProductChooserProductItem = PRODUCT_BONUS_SAVER_ACCOUNT_NON_RESIDENT
    let secondary: IProductChooserProductItem = PRODUCT_SIMPLE_SAVER
    let tertiary: IProductChooserProductItem | undefined

    const matchValues = (
      combinations: { [key: string]: string | string[] }[]
    ) => {
      const matches = combinations.map((combination) => {
        let match = true
        Object.keys(combination).forEach((key) => {
          if (Array.isArray(combination[key])) {
            if (combination[key].indexOf(values[key] as string) === -1) {
              match = false
            }
          } else if (values[key] !== combination[key]) {
            match = false
          }
        })
        return match
      })
      return matches.includes(true)
    }

    if (
      matchValues([
        {
          // matches for recommendation 2
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_ONCE_A_MONTH,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_LOW,
        },
        // matches for recommendation 5
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_SOMETIMES,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_LOW,
        },
        // matches for recommendation 8
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_NO_MORE,
          [QUESTION_INITIAL_DEPOSIT.id]: OPTION_UNDER_5K,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_LOW,
        },
      ])
    ) {
      recommendation = PRODUCT_NOTICE_SAVER
      secondary = PRODUCT_BONUS_SAVER_ACCOUNT
      tertiary = PRODUCT_SIMPLE_SAVER
    } else if (
      matchValues([
        // matches for recommendation 3
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_ONCE_A_MONTH,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_HIGH,
        },
        // matches for recommendation 6
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_SOMETIMES,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_HIGH,
        },
        // matches for recommendation 9
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_NO_MORE,
          [QUESTION_INITIAL_DEPOSIT.id]: OPTION_UNDER_5K,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_HIGH,
        },
      ])
    ) {
      recommendation = PRODUCT_NOTICE_SAVER
      secondary = PRODUCT_BONUS_SAVER_PIE
      tertiary = PRODUCT_BONUS_SAVER_ACCOUNT
    } else if (
      matchValues([
        // matches for recommendation 10
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_NO_MORE,
          [QUESTION_INITIAL_DEPOSIT.id]: OPTION_OVER_5K,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_NO,
        },
      ])
    ) {
      recommendation = PRODUCT_TERM_DEPOSIT
      secondary = PRODUCT_BONUS_SAVER_ACCOUNT
      tertiary = PRODUCT_SIMPLE_SAVER
    } else if (
      matchValues([
        // matches for recommendation 11
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_NO_MORE,
          [QUESTION_INITIAL_DEPOSIT.id]: OPTION_OVER_5K,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_LOW,
        },
      ])
    ) {
      recommendation = PRODUCT_TERM_DEPOSIT
      secondary = PRODUCT_NOTICE_SAVER
      tertiary = PRODUCT_BONUS_SAVER_ACCOUNT
    } else if (
      matchValues([
        // matches for recommendation 12
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_I_CAN_WAIT,
          [QUESTION_DEPOSIT_INTERVAL.id]: OPTION_INTERVAL_NO_MORE,
          [QUESTION_INITIAL_DEPOSIT.id]: OPTION_OVER_5K,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_HIGH,
        },
      ])
    ) {
      recommendation = PRODUCT_TERM_PIE
      secondary = PRODUCT_TERM_DEPOSIT
      tertiary = PRODUCT_NOTICE_SAVER
    } else if (
      matchValues([
        // matches for recommendation 14
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_ANYTIME,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_LOW,
        },
      ])
    ) {
      recommendation = PRODUCT_BONUS_SAVER_ACCOUNT
      secondary = PRODUCT_SIMPLE_SAVER
    } else if (
      matchValues([
        // matches for recommendation 15
        {
          [QUESTION_ACCESS_MONEY.id]: OPTION_ACCESS_ANYTIME,
          [QUESTION_NZ_TAX_RESIDENT.id]: OPTION_NZ_TAX_RESIDENT_YES,
          [QUESTION_WHAT_IS_YOUR_TAX_RATE.id]: OPTIONS_TAX_RATE_HIGH,
        },
      ])
    ) {
      recommendation = PRODUCT_BONUS_SAVER_PIE
      secondary = PRODUCT_BONUS_SAVER_ACCOUNT
      tertiary = PRODUCT_SIMPLE_SAVER
    }

    customerInteraction.subject = `Savings and Investment Chooser tool recommends ${recommendation.title}`
    customerInteraction.additionalInfo += `<Recommendation>${recommendation.title}</Recommendation>`
    const description = Array.isArray(recommendation.description)
      ? recommendation.description.join('')
      : recommendation.description
    customerInteraction.additionalInfo += `<RecommendationDescription>${description}</RecommendationDescription>`
    customerInteraction.additionalInfo += `<RecommendationSecondary>${secondary.title}</RecommendationSecondary>`
    if (tertiary?.type) {
      customerInteraction.additionalInfo += `<RecommendationTertiary>${tertiary.title}</RecommendationTertiary>`
    }
    customerInteraction.additionalInfo = `<data>${customerInteraction.additionalInfo}</data>`

    return {
      estimatedProgress: 100,
      type: 'recommendation',
      recommendation,
      recommendationDetails: {
        secondaryRecommendation: secondary.type,
        tertiaryRecommendation: tertiary?.type,
        comparisonDisclaimer: getComparisonDisclaimer(
          recommendation,
          secondary,
          tertiary
        ),
        comparisonTable: [
          PRODUCT_BONUS_SAVER_ACCOUNT,
          PRODUCT_BONUS_SAVER_PIE,
          PRODUCT_NOTICE_SAVER,
          PRODUCT_SIMPLE_SAVER,
          PRODUCT_TERM_DEPOSIT,
          PRODUCT_TERM_PIE,
        ],
      },
      customerInteraction,
    } as IProductChooserStep
  }
  return PRODUCT_CHOOSER_INITIAL_STEP
}

export const getNextStepProductChooser = (
  userAnswers: (string | number)[],
  config: IProductChooserConfig,
  ratesData: IProductChooserRatesData
): IProductChooserStep =>
  getNextStep(userAnswers, createProductChooserFlow(config, ratesData))

/**
 * Gets the primary, secondary, and tertiary (if present) product recommendation items
 * @param recommendationDetails: ProductChooserRecommendationDetails
 * @returns ProductChooserProductItem[]
 */
export const getCurrentRecommendationItems = (
  {
    comparisonTable,
    secondaryRecommendation,
    tertiaryRecommendation,
  }: IProductChooserRecommendationDetails,
  recommendation: IProductChooserProductItem
) => {
  const otherRecommendations = comparisonTable
    .filter(
      ({ type }) =>
        type === secondaryRecommendation || type === tertiaryRecommendation
    )
    .sort(({ type }) => (type === secondaryRecommendation ? -1 : 0))

  return [recommendation, ...otherRecommendations]
}

export const getProductChooserRecommendationSteps = (
  userAnswers: (string | number)[],
  config: IProductChooserConfig,
  ratesData: IProductChooserRatesData
) => {
  const steps = getRecommendationSteps(
    userAnswers,
    createProductChooserFlow(config, ratesData)
  )
  return steps
}
