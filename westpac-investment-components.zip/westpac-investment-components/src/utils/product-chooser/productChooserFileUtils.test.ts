import { generateProductRecommendationFile } from './productChooserFileUtils'
import {
  OPTION_ACCESS_ANYTIME,
  OPTION_ACCESS_I_CAN_WAIT,
  OPTION_INTERVAL_ONCE_A_MONTH,
  OPTION_INTERVAL_NO_MORE,
  OPTION_OVER_5K,
  OPTION_NZ_TAX_RESIDENT_NO,
  OPTION_NZ_TAX_RESIDENT_YES,
  OPTIONS_TAX_RATE_HIGH,
} from './productChooserUtils'
import { pdfTextFn, saveFn } from '../../__mocks__/jspdf'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'
import ratesData from './__mocks__/ProductChooserRatesData'

jest.mock('moment', () => () =>
  jest.requireActual('moment')('2020-01-01T00:00:00.000Z')
)

describe('productChooserFileUtils', () => {
  const getPdfTextFnFormatted = () =>
    pdfTextFn.mock.calls.map((call) => call[0]).join('\n')

  beforeEach(() => {
    jest.clearAllMocks()
  })

  it('generateProductRecommendationFile > Check PDF generation', () => {
    const userAnswers = [OPTION_ACCESS_ANYTIME, OPTION_NZ_TAX_RESIDENT_NO]
    const { doc, save } = generateProductRecommendationFile(
      userAnswers,
      config,
      ratesData
    )
    expect(doc.getNumberOfPages()).toBe(5)

    save()
    expect(saveFn).toHaveBeenCalledWith(
      'westpac-product-recommendation-2020-01-01.pdf'
    )
  })

  it('generateProductRecommendationFile > Provide PDF with Bonus Saver recommendation', () => {
    const userAnswers = [
      OPTION_ACCESS_I_CAN_WAIT,
      OPTION_INTERVAL_ONCE_A_MONTH,
      OPTION_NZ_TAX_RESIDENT_NO,
    ]
    generateProductRecommendationFile(userAnswers, config, ratesData)
    const pdfText = getPdfTextFnFormatted()
    expect(pdfText).toContain('We recommend.\nWestpac Bonus Saver')
    expect(pdfText).toMatchSnapshot()
  })

  it('generateProductRecommendationFile > Provide PDF with Notice Saver recommendation', () => {
    const userAnswers = [
      OPTION_ACCESS_I_CAN_WAIT,
      OPTION_INTERVAL_ONCE_A_MONTH,
      OPTION_NZ_TAX_RESIDENT_YES,
      OPTIONS_TAX_RATE_HIGH[0],
    ]
    generateProductRecommendationFile(userAnswers, config, ratesData)
    const pdfText = getPdfTextFnFormatted()
    expect(pdfText).toContain('We recommend.\nNotice Saver')
    expect(pdfText).toMatchSnapshot()
  })

  it('generateProductRecommendationFile > Provide PDF with Term Deposit recommendation', () => {
    const userAnswers = [
      OPTION_ACCESS_I_CAN_WAIT,
      OPTION_INTERVAL_NO_MORE,
      OPTION_OVER_5K,
      OPTION_NZ_TAX_RESIDENT_NO,
    ]
    generateProductRecommendationFile(userAnswers, config, ratesData)
    const pdfText = getPdfTextFnFormatted()
    expect(pdfText).toContain('We recommend.\nTerm Deposit')
    expect(pdfText).toMatchSnapshot()
  })

  it('generateProductRecommendationFile > Provide PDF with Term PIE recommendation', () => {
    const userAnswers = [
      OPTION_ACCESS_I_CAN_WAIT,
      OPTION_INTERVAL_NO_MORE,
      OPTION_OVER_5K,
      OPTION_NZ_TAX_RESIDENT_YES,
      OPTIONS_TAX_RATE_HIGH[0],
    ]
    generateProductRecommendationFile(userAnswers, config, ratesData)
    const pdfText = getPdfTextFnFormatted()
    expect(pdfText).toContain('We recommend.\nWestpac Term PIE')
    expect(pdfText).toMatchSnapshot()
  })

  it('generateProductRecommendationFile > Provide PDF with Bonus Saver PIE recommendation', () => {
    const userAnswers = [
      OPTION_ACCESS_ANYTIME,
      OPTION_NZ_TAX_RESIDENT_YES,
      OPTIONS_TAX_RATE_HIGH[0],
    ]
    generateProductRecommendationFile(userAnswers, config, ratesData)
    const pdfText = getPdfTextFnFormatted()
    expect(pdfText).toContain('We recommend.\nWestpac Bonus Saver PIE')
    expect(pdfText).toMatchSnapshot()
  })
})
