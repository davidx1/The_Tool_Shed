import moment from 'moment'
import autoTable from 'jspdf-autotable'

import { createPDF } from '../pdfUtils'
import {
  IProductChooserStep,
  getProductChooserRecommendationSteps,
  getCurrentRecommendationItems,
  IProductChooserProductItem,
  IProductChooserConfig,
  IProductChooserRatesData,
} from './productChooserUtils'
import { IAnswerStep } from '../../components/navigation/IQuestionnaire'

const createProductChooserDoc = (
  answers: IAnswerStep[],
  recommendationStep: IProductChooserStep | null,
  otherProducts: IProductChooserProductItem[],
  config: IProductChooserConfig
) => {
  const file = createPDF()
  const currentDate = moment().format('DD MMM YYYY')
  const { recommendation, recommendationDetails } = recommendationStep || {}

  const renderIntroduction = () => {
    file.renderTitle(`Savings & Investment Chooser tool.`)
    file.renderText(
      'Thank you for using the Savings & Investment Chooser tool.'
    )
    file.renderText(
      `Based on the information that you provided on ${currentDate}.`
    )
  }

  const renderRecommendationHeader = () => {
    if (!recommendation) return

    const { title, description, shortDescription } = recommendation
    file.renderTitle('We recommend.')
    file.renderSubTitle(title, 14)
    if (typeof description === 'object') {
      description.forEach((item: string) => file.renderText(item))
    } else {
      file.renderText(description || shortDescription)
    }
  }

  const getInterestTitle = () => {
    switch (recommendation?.type) {
      case 'termPIE':
        return 'Our Term PIE rates.'
      case 'bonusSaverPIE':
      case 'noticeSaver':
        return 'Rate of return.'
      default:
        return 'Interest rate.'
    }
  }

  const renderInterestRate = () => {
    if (recommendation && recommendation.interestRates.length) {
      const {
        interestRates,
        interestRatesDescription,
        interestRatesDisclaimer,
      } = recommendation

      if (interestRates.length === 1) {
        const {
          annualRatePercent,
          description,
          disclosure,
          effectiveReturn,
        } = interestRates[0]
        file.renderPhotoImage(
          config.productItems[recommendation.type].ratesImageUrl!
        )
        const startX = 4
        file.renderText(
          getInterestTitle(),
          0.1,
          18,
          'bold',
          'left',
          false,
          startX
        )
        renderRatePA(
          `${annualRatePercent}`,
          startX,
          recommendation.type === 'bonusSaverAccount' ||
            recommendation.type === 'bonusSaverPIE'
        )
        description &&
          file.renderText(
            description,
            undefined,
            10,
            'normal',
            'left',
            false,
            startX
          )
        if (effectiveReturn) {
          file.renderText(
            'Effective return^',
            0.01,
            10,
            'bold',
            'left',
            false,
            startX
          )
          file.renderMixedText(
            `If your income tax rate is 30%^^: **${effectiveReturn.thirty}% p.a.**`,
            0.01,
            10,
            undefined,
            startX
          )
          file.renderMixedText(
            `If your income tax rate is 33%^^^: **${effectiveReturn.thirtyThree}% p.a.**`,
            0.01,
            10,
            undefined,
            startX
          )
        }

        file.doc.setTextColor('#636363')
        disclosure &&
          file.renderText(
            disclosure,
            undefined,
            8,
            'normal',
            'left',
            false,
            startX
          )
        file.doc.setTextColor('#000000')
      }

      if (interestRates.length === 3) {
        file.renderTitle('Interest rate.')
        if (typeof interestRatesDescription === 'string') {
          file.renderText(interestRatesDescription)
        }
        if (typeof interestRatesDescription === 'object') {
          interestRatesDescription.forEach((item) => file.renderText(item))
        }

        const gap = 0.4
        const padding = 0.1
        interestRates.forEach((rate, index) => {
          const {
            durationInMonths,
            annualRatePercent,
            description,
            effectiveReturn,
          } = rate
          const offset = index * (file.getBoxWidth() + gap)
          file.renderBox(offset)
          file.renderSpace(padding)

          file.renderText(
            durationInMonths!
              .split(' ')
              .map((word) => `${word.charAt(0).toUpperCase()}${word.substr(1)}`) // to capitalise words
              .join(' '),
            undefined,
            11,
            'bold',
            undefined,
            false,
            offset + 1.2
          )
          renderRatePA(`${annualRatePercent}`, offset + 1.1)
          if (description) {
            file.renderText(
              description,
              undefined,
              7,
              'normal',
              undefined,
              false,
              offset + 0.45
            )
            file.renderSpace(-padding)
          } else if (effectiveReturn) {
            const { thirty, thirtyThree } = effectiveReturn
            file.renderSpace(-0.1)
            file.renderText(
              `If your Income Tax Rate is 30%: ${thirty}%`,
              undefined,
              7,
              'normal',
              undefined,
              false,
              offset + 0.7
            )
            file.renderSpace(-0.2)
            file.renderText(
              `If your Income Tax Rate is 33%: ${thirtyThree}%`,
              0.01,
              7,
              'normal',
              undefined,
              false,
              offset + 0.7
            )
            file.renderSpace(padding / 2)
          }

          file.renderSpace(-file.boxHeight)
        })
        file.renderSpace(file.boxHeight)
      }

      if (interestRatesDisclaimer) {
        file.renderSpace(0.2)
        file.renderDisclaimerText(interestRatesDisclaimer)
      }
      file.renderSpace(0.2)
    }
  }

  const renderBenefits = () => {
    if (!recommendation || !recommendation.benefits) return
    const { title, benefits } = recommendation

    file.renderText('Benefits.', undefined, 18, 'bold', 'left', true)

    const startX = 2.5
    file.renderText(
      `Highlights of a ${title} account`,
      0.2,
      12,
      'bold',
      'left',
      false,
      startX
    )
    benefits.forEach((item) =>
      file.renderText(`- ${item}`, 0.2, 10, 'normal', 'left', false, startX)
    )
  }

  const renderPIE = () => {
    // don't show What's PIE section for Term Deposit and Bonus Saver accounts
    if (
      !recommendation ||
      recommendation.type === 'termDeposit' ||
      recommendation.type === 'bonusSaverAccount'
    )
      return
    const {
      pieVideo: { shortUrl },
    } = config
    const { video } = recommendation

    file.renderTitle(video?.title || '')
    file.renderText(video?.description || '', 0.3)

    file.renderTextWithLink(shortUrl, shortUrl, file.margin)
    file.renderSpace(0.1)
    file.renderSeparator()
    file.renderSpace(0.1)
  }

  const renderFeesTables = () => {
    if (!recommendation) return
    const {
      serviceFees,
      serviceFeesDisclaimer,
      serviceFeesEmptyState,
      accountFees,
      accountFeesDisclaimer,
      accountFeesEmptyState,
    } = recommendation.fees
    const feesColumns = [
      {
        title: 'Fee type',
        dataField: 'type',
      },
      {
        title: 'Fee amount',
        dataField: 'amount',
      },
    ]
    const head = [feesColumns.map((column) => column.title)]
    const bodyService = serviceFees.map((product) =>
      feesColumns.map((column) => product[column.dataField])
    )
    const bodyAccount = accountFees.map((product) =>
      feesColumns.map((column) => product[column.dataField])
    )

    file.renderTitle(`${recommendation.title} fees.`)
    file.renderText('Account fees.', undefined, 12, 'bold')
    renderFeesTable(head, bodyAccount)
    if (!accountFees.length && accountFeesEmptyState) {
      file.renderDisclaimerText(accountFeesEmptyState)
    }
    if (accountFeesDisclaimer) {
      file.renderDisclaimerText(accountFeesDisclaimer)
    }

    file.renderText('Service fees.', undefined, 12, 'bold')
    if (serviceFees.length) {
      renderFeesTable(head, bodyService)
    } else if (serviceFeesEmptyState) {
      file.renderDisclaimerText(serviceFeesEmptyState)
    }
    if (serviceFeesDisclaimer) {
      file.renderDisclaimerText(serviceFeesDisclaimer)
    }
  }

  const renderDetails = () => {
    if (!recommendation || !recommendation.details) return
    const { details } = recommendation

    file.renderTitle('More details.')
    details.forEach((detail) => {
      file.renderSubTitle(`${detail.title}.`, 12)
      detail.details.forEach((item) => {
        file.renderText(item)
      })
      detail.disclosures.forEach((item) => file.renderDisclaimerText(item))
      file.renderSpace(-0.2)
      file.renderSeparator()
    })
  }

  const renderOtherOptions = () => {
    file.renderTitle('Other options.')
    file.renderText(
      'You can also consider some other accounts and investment options that may suit you.'
    )

    const startX = 1.5
    otherProducts.forEach((product, index) => {
      file.renderIcon(product.icon, index)
      file.renderText(product.title, 0.1, 10, 'bold', 'left', false, startX)
      file.renderText(
        product.shortDescription,
        undefined,
        10,
        'normal',
        'left',
        false,
        startX
      )
      file.renderTextWithLink(
        `Find out more (${product.applyUrl})`,
        product.applyUrl || '',
        startX
      )
      if (index < otherProducts.length - 1) {
        file.renderSpace(0.1)
      }
    })
  }

  const renderComparisonTable = () => {
    const comparisonColumns = [
      {
        title: '',
        dataField: 'title',
      },
      {
        title: 'Benefits',
        dataField: 'benefitsComparison',
      },
      {
        title: 'Fees',
        dataField: 'feesComparison',
      },
      {
        title: 'Rates*',
        dataField: 'ratesComparison',
      },
      {
        title: 'Things to know',
        dataField: 'thingsToKnowComparison',
      },
    ]
    const { type } = recommendation || {}
    const {
      secondaryRecommendation,
      tertiaryRecommendation,
      comparisonTable = [],
    } = recommendationDetails || {}
    const firstRecommendation = comparisonTable.find(
      (item) => item.type === type
    )
    const secondRecommendation = comparisonTable.find(
      (item) => item.type === secondaryRecommendation
    )
    const thirdRecommendation = comparisonTable.find(
      (item) => item.type === tertiaryRecommendation
    )

    const head = [comparisonColumns.map((column) => column.title)]
    const body = [
      firstRecommendation,
      secondRecommendation,
      thirdRecommendation,
    ]
      .filter(Boolean)
      .map((product) =>
        comparisonColumns.map((column) =>
          file.cleanText(file.injectUrlsIntoText(product![column.dataField]))
        )
      )

    file.renderTitle('Compare.')
    file.renderText('A quick comparison of the recommendations.')
    file.renderTagImage()
    // @ts-ignore-next-line -- library typings doesn't match this correct overload
    renderProductChooserTable(head, body, recommendation?.title)
    recommendationDetails &&
      file.renderDisclaimer(() =>
        file.renderHTML(
          recommendationDetails?.comparisonDisclaimer.split('\n'),
          8
        )
      )
  }

  const renderContactUs = () => {
    if (!recommendation) return
    const { applyTitle } = recommendation
    const {
      links: {
        branchLocator,
        contactUsPhone: { label },
        contactUs,
      },
    } = config

    file.renderTitle(applyTitle)
    file.renderSubTitle('New to Westpac?', 12)
    file.renderText(
      'Please make an appointment at your local branch. Please bring some ID and proof of address.'
    )
    branchLocator &&
      file.renderTextWithLink(branchLocator, branchLocator, file.margin)
    file.renderSpace(0.1)

    file.renderSubTitle('Already a Westpac customer?', 12)
    file.renderMixedText(
      `To save time apply online or if you haven't registered for Westpac One® online banking, call us on **  ${label}.**`
    )
    file.renderTextWithLink(contactUs, contactUs, file.margin)
    file.renderSpace(0.1)

    file.renderSubTitle('Contact us', 12)
    file.renderText('Call us to discuss your savings and investment needs.')
    file.renderMixedText(`Call us on **${label}** `)
  }

  const renderQuestionAndAnswer = () => {
    file.renderSubTitle(`Your questions and answers as at ${currentDate}:`, 14)
    answers.forEach((answer) => {
      if (answer.question?.type !== 'confirmationModal') {
        const title = answer.question?.title || ''
        file.renderSubTitle(title, undefined, 0.05)
        const description = answer.answer.toString()
        file.renderText(
          description.substr(description.length - 1, 1) !== '.'
            ? `${description}.` // to add full stop if it's not present
            : description
        )
      }
    })

    file.renderSpace(0.2)
    if (recommendation && recommendation.disclosuresPDF) {
      file.renderHTML(recommendation.disclosuresPDF)
    }
  }

  const renderAll = () => {
    renderIntroduction()
    file.renderBackground('#F7F7F7')
    renderRecommendationHeader()
    file.renderBackground('#FFFFFF')
    renderInterestRate()
    file.renderBackground('#F7F7F7')
    renderBenefits()
    file.renderBackground('#FFFFFF')
    file.addPageBreak()
    renderPIE()
    renderFeesTables()
    file.addPageBreak()
    renderDetails()
    renderOtherOptions()
    file.addPageBreak()
    renderComparisonTable()
    file.addPageBreak()
    renderContactUs()
    renderQuestionAndAnswer()
    file.renderPageNumbers()
  }

  function renderRatePA(
    text: string,
    startX: number,
    isVariableRate?: boolean
  ) {
    const { doc, renderText, renderSpace } = file
    doc.setTextColor('#621A4B')
    if (isVariableRate) {
      renderText('Up to', undefined, 10, 'normal', 'left', true, startX)
      renderSpace(0.15)
    }
    doc.setFontSize(32)
    const percentStringWidth = doc.getTextWidth(text)
    const percentOffset = startX + percentStringWidth + 0.05
    renderText(text, undefined, 32, 'bold', 'left', true, startX)
    doc.setTextColor('#000000')
    renderSpace(0.05)
    renderText('%', 0, 14, 'bold', 'left', false, percentOffset)
    renderSpace(-0.05)
    renderText('p.a.', undefined, 10, 'bold', 'left', false, percentOffset)
  }

  function renderProductChooserTable(
    head: any,
    body: any,
    recommendation?: string
  ) {
    let paintCell = false
    const {
      doc,
      margin,
      pageWidth,
      renderDotImage,
      setCurrentYBelowTable,
      getCurrentY,
    } = file

    autoTable(doc, {
      head,
      body,
      theme: 'plain',
      startY: getCurrentY(),
      margin,
      tableWidth: pageWidth - margin * 2,
      styles: {
        cellPadding: 0.1,
      },
      columnStyles: {
        0: { cellWidth: 1 },
        2: { cellWidth: 1.9 },
        3: { cellWidth: 1.4 },
        4: { cellWidth: 1.8 },
      },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index === 0) {
          data.cell.styles.fontStyle = 'bold'
          paintCell = data.cell.text[0] === recommendation
        }
        if (paintCell) {
          data.cell.styles.fillColor = '#F4EDF2'
        }
      },
      didDrawCell: (data) => {
        doc.setFillColor('#EBEBEB')
        const x = data.cell.x
        const top = data.cell.y
        const bottom = data.cell.y + data.cell.height
        if (data.section === 'head') {
          // @ts-ignore-next-line -- library typings doesn't match this correct overload
          doc.line(x, top, x + data.cell.width, top, 'F')
          doc.setFillColor('#621A4B')
          // @ts-ignore-next-line -- library typings doesn't match this correct overload
          doc.line(x, bottom, x + data.cell.width, bottom, 'F')
        }
        // @ts-ignore-next-line -- library typings doesn't match this correct overload
        doc.line(x, bottom, x + data.cell.width, bottom, 'F')
        if (
          data.section === 'body' &&
          data.column.index === 0 &&
          data.cell.text.join(' ') === recommendation
        ) {
          renderDotImage(x + 0.02, top + 0.15)
        }
      },
      didDrawPage: setCurrentYBelowTable,
    })
  }

  function renderFeesTable(head: any, body: any) {
    const { doc, margin, pageWidth, setCurrentYBelowTable, getCurrentY } = file

    autoTable(doc, {
      head,
      body,
      theme: 'plain',
      startY: getCurrentY(),
      margin,
      tableWidth: pageWidth - margin * 2,
      styles: {
        cellPadding: 0.15,
      },
      headStyles: {
        fillColor: 'white',
        textColor: '#621A4B',
      },
      columnStyles: {
        0: { cellWidth: 5 },
        1: { cellWidth: 2.7 },
      },
      didParseCell: (data) => {
        if (data.section === 'body') {
          if (data.column.index === 1) {
            data.cell.styles.fontStyle = 'bold'
          }
          if (data.row.index % 2 === 0) {
            data.cell.styles.fillColor = '#EBEBEB'
          }
        }
      },
      didDrawCell: (data) => {
        doc.setFillColor('#949494')
        const x = data.cell.x
        const top = data.cell.y
        const bottom = data.cell.y + data.cell.height
        if (data.section === 'head') {
          // @ts-ignore-next-line -- library typings doesn't match this correct overload
          doc.line(x, top, x + data.cell.width, top, 'F')
          // @ts-ignore-next-line -- library typings doesn't match this correct overload
          doc.line(x, bottom, x + data.cell.width, bottom, 'F')
        }
        if (data.section === 'body' && data.row.index === body.length - 1) {
          // @ts-ignore-next-line -- library typings doesn't match this correct overload
          doc.line(x, bottom, x + data.cell.width, bottom, 'F')
        }
      },
      didDrawPage: setCurrentYBelowTable,
    })
  }

  function getFileName() {
    return `westpac-product-recommendation-${moment().format('YYYY-MM-DD')}`
  }

  function save() {
    file.doc.save(`${getFileName()}.pdf`)
  }

  return {
    ...file,
    renderAll,
    getFileName,
    save,
  }
}

export const generateProductRecommendationFile = (
  userAnswers: (string | number)[],
  config: IProductChooserConfig,
  ratesData: IProductChooserRatesData
) => {
  const { answerSteps, recommendation } = getProductChooserRecommendationSteps(
    userAnswers,
    config,
    ratesData
  )
  const {
    recommendationDetails,
    recommendation: recommendationItem,
  } = recommendation as IProductChooserStep
  let otherProducts: IProductChooserProductItem[] = []
  if (recommendationDetails && recommendationItem) {
    otherProducts = getCurrentRecommendationItems(
      recommendationDetails!,
      recommendationItem!
    )
    otherProducts.splice(0, 1)
  }
  const productChooserDoc = createProductChooserDoc(
    answerSteps,
    recommendation,
    otherProducts,
    config
  )
  productChooserDoc.renderAll()
  return productChooserDoc
}
