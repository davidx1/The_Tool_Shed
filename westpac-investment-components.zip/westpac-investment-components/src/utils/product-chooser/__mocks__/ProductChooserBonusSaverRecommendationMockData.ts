import { IProductChooserProductItem } from '../productChooserUtils'

const recommendation: IProductChooserProductItem = {
  type: 'bonusSaverAccount',
  icon: 'https://',
  title: 'Westpac Bonus Saver',
  description: [
    'For people like you who need to access their money any time, we generally recommend our Westpac Bonus Saver account. This is a savings account that rewards you with bonus interest for growing your balance.',
    'This account is often used for saving for a goal like a holiday or a house deposit, or putting money regularly aside for a rainy day.',
  ],
  interestRatesTitle: 'Interest rate.',
  interestRates: [
    {
      annualRatePercent: '0.05',
      description:
        'Potential rate of 0.50% p.a. (base rate of 0.05% p.a. + bonus rate of 0.45% p.a.)',
      disclosure:
        'Get bonus interest if the account balance on the last business day of the month is $20 greater than on the last business day of the month prior.*',
      breakdown: [
        {
          annualRatePercent: '0.05',
          description: '(base interest)',
        },
        {
          annualRatePercent: '0.45',
          description: '(bonus interest)',
        },
      ],
    },
  ],
  benefits: [
    'Be rewarded for growing your balance',
    'Immediate access to your money with unlimited withdrawals.',
    'No monthly account maintenance fee.',
  ],
  details: [
    {
      title: 'How you earn returns',
      details: [
        'Get bonus interest if the account balance on the last business day of the month is $20 greater than on the last business day of the month prior. *',
        'Interest is calculated daily on the full credit balance and paid (less resident withholding tax) into your Westpac Bonus Saver account on the last business day of each month.',
        'Interest rates are current as at <date>, are variable in nature and can change without notice.',
      ],
      disclosures: [
        '*The $20 excludes interest earned on the account and/or Westpac fees charged to the account.',
      ],
    },
    {
      title: 'Accessibility',
      details: [
        'Apply in Westpac One® online banking, via the Contact Centre or in branch.',
        'Access in Westpac One® online banking, phone banking, via the Contact Centre* or in branch*',
      ],
      disclosures: ['*Branch withdrawals fees of $2.50 apply'],
    },
    {
      title: 'Important things to know',
      details: [],
      disclosures: [],
    },
  ],
  fees: {
    accountFees: [
      {
        type: 'Monthly account maintence fee',
        amount: 'Free',
      },
      {
        type: 'Electronic statements',
        amount: 'Free',
      },
      {
        type: 'Paper statement',
        amount: 'Free',
      },
      {
        type: 'Branch withdrawals',
        amount: '$2.50 (per transaction)',
      },
      {
        type: 'Cheque withdrawals',
        amount: '$2.50 (per transaction)',
      },
      {
        type: 'Electronic deposits / fund transfers',
        amount: 'Free',
      },
    ],
    serviceFees: [
      {
        type: 'Phone Banking call',
        amount: 'Free',
      },
      {
        type: 'Email alerts',
        amount: 'Free',
      },
      {
        type: 'Online automatic payments set up and amend',
        amount: 'Free',
      },
      {
        type: 'Branch and phone payments set up and amend',
        amount: '$5',
      },
    ],
  },
  disclosures: [
    '<p>*Monthly bonus returns are available for Westpac Bonus Saver as long as on the last business day of the month the balance is $20 greater than on the last business day of the month prior. The $20 excludes interest earned on the account and/or Westpac fees charged to the account.</p>',
    '<p>Fees relate to Westpac Bonus Saver only. Standard fees will apply to the account which money is being transferred to or from.</p>',
    '<p>Interest rates and fees are current as at 11 August 2020 and are subject to change without notice.</p>',
    '<p>The above rates are not available to financial institutions. Full details of the Westpac General Terms and Conditions are available <a href="https://" target="_blank" rel="noopener noreferrer">here</a> or from any Westpac branch in New Zealand.</p>',
  ],
  disclosuresPDF: [],
  shortDescription: '<shortDescription>',
  applyUrl: '<applyUrl>',
  applyTitle: 'Open an account',
  benefitsComparison: '<benefitsComparison>',
  feesComparison: '<feesComparison>',
  ratesComparison: '<ratesComparison>',
  thingsToKnowComparison: '<thingsToKnowComparison>',
}

export default recommendation
