import { IProductChooserProductItem } from '../productChooserUtils'

const recommendation: IProductChooserProductItem = {
  icon: 'https://',
  type: 'simpleSaver',
  title: 'Simple Saver',
  description:
    'The name says it all. This no-fuss savings account gives you the same competitive interest rate, whatever your balance. And your first manual or electronic withdrawal each month is free.',
  interestRates: [
    {
      annualRatePercent: '0.05',
    },
  ],
  fees: {
    accountFees: [],
    serviceFees: [],
  },
  benefits: [
    'Earn the same interest rate on every dollar you save.',
    'No minimum balance required.',
  ],
  disclosures: [],
  disclosuresPDF: [],
  shortDescription: '<shortDescription>',
  applyUrl: '<applyUrl>',
  applyTitle: '<applyTitle>',
  benefitsComparison: '<benefitsComparison>',
  feesComparison: '<feesComparison>',
  ratesComparison: '<ratesComparison>',
  thingsToKnowComparison: '<thingsToKnowComparison>',
}

export default recommendation
