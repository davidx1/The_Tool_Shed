import { IProductChooserConfig } from '../productChooserUtils'

const config: IProductChooserConfig = {
  links: {
    contactUsPhone: {
      url: 'tel:0800400600',
      label: '0800 400 600',
    },
    contactUs: 'https://www.westpac.co.nz/contact-us/',
    glossary:
      '/w1/savings-investment-chooser/Savings-Investment-Tool-Glossary.pdf',
    branchLocator: 'https://www.westpac.co.nz/branch-finder',
    termsAndConditions:
      'https://www.westpac.co.nz/General-Terms-and-Conditions-Westpac-NZ',
    hardshipWithdrawal:
      'https://www.westpac.co.nz/managing-your-money/kiwisaver-hardship/',
    interestRates: 'https://www.westpac.co.nz/product-terms-fees-rates',
    toolDisclosure: 'https://www.westpac.co.nz/investor-documents',
    fees: 'https://www.westpac.co.nz/personal-bank-account-fees',
  },
  pieVideo: {
    url: 'https://www.youtube.com/embed/12a5-LmJNY8?enablejsapi=1&origin=*',
    shortUrl: 'https://youtu.be/12a5-LmJNY8',
    posterImageUrl:
      '/w1/savings-investment-chooser/images/pie-video-poster.png',
  },
  productItems: {
    noticeSaver: {
      applyUrl: 'https://www.westpac.co.nz/notice-saver',
      ratesImageUrl:
        '/w1/savings-investment-chooser/images/notice-saver-poster.png',
      termSheetUrl:
        'https://www.westpac.co.nz/Westpac-Notice-Saver-PIE-Fund-Term-Sheet',
      icon: '/w1/savings-investment-chooser/icons/notice-saver.png',
      earlyWithdrawalUrl:
        'https://www.westpac.co.nz/assets/Personal/investments/documents/Policy-Documents/Early-Withdrawal-Policy-for-Notice-Saver-PIE-Westpac-NZ.pdf',
      disclosures: [
        'Notice Saver is offered under the Westpac Notice Saver PIE Fund (the “Fund”).',
        'Investments made in the Fund do not represent bank deposits or other liabilities of Westpac Banking Corporation ABN 33 007 457 141, ',
        'Westpac New Zealand Limited (“Westpac NZ”) or other members of the Westpac group of companies.  They are subject to investment and other risks, ',
        'including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.  ',
        'None of BT Funds Management (NZ) Limited (as manager), any member of the Westpac group of companies, Trustees Executors Limited (as trustee), ',
        "or any director or nominee of any of those entities guarantees the Fund’s performance, returns or repayment of capital.  Westpac NZ's General Terms and Conditions ",
        '(including online banking terms) apply to the account and any investments in the fund.You can get more information and free copies of the Disclosure Statement for Westpac NZ, ',
        "Westpac NZ's General Terms and Conditions and the term sheet for the Fund from any Westpac branch or online here. A copy of the Trust Deed for the Fund can be accessed here.",
      ],
    },
    bonusSaverAccount: {
      applyUrl: 'https://www.westpac.co.nz/westpac-bonus-saver',
      ratesImageUrl:
        '/w1/savings-investment-chooser/images/westpac-bonus-saver-poster.png',
      icon: '/w1/savings-investment-chooser/icons/westpac-bonus-saver.png',
      disclosures: [],
    },
    bonusSaverPIE: {
      applyUrl: 'https://www.westpac.co.nz/westpac-bonus-saver-pie',
      icon: '/w1/savings-investment-chooser/icons/bonus-saver-pie.png',
      ratesImageUrl:
        '/w1/savings-investment-chooser/images/westpac-bonus-saver-pie-poster.png',
      termSheetUrl:
        'https://www.westpac.co.nz/Westpac-Cash-PIE-Fund-Term-Sheet',
      disclosures: [
        'Westpac Bonus Saver PIE is offered under the Westpac Cash PIE Fund. Investments made in the Fund do not represent bank deposits ',
        'or liabilities of Westpac New Zealand Limited (“Westpac NZ”), Westpac Banking Corporation ABN 33 007 457 141 or any other member of ',
        'the Westpac group of companies. They are subject to investment and other risks, including possible delays in payment of withdrawal amounts ',
        'in some circumstances, and loss of investment value, including principal invested. None of BT Funds Management (NZ) Limited (as manager), ',
        "Trustees Executors Limited (as trustee), any member of the Westpac group of companies nor any other person guarantees the Fund's performance, ",
        'returns, or repayment of capital. Any rates of return are subject to change without notice. You can get more information and free copies of the ',
        'Disclosure Statement for Westpac NZ, the term sheet for the Fund and Westpac NZ’s General Terms and Conditions from any Westpac branch.',
      ],
    },
    termDeposit: {
      applyUrl: 'https://www.westpac.co.nz/term-deposit',
      earlyWithdrawalUrl:
        'https://www.westpac.co.nz/Early-Withdrawal-Term-Investment-Policy',
      icon: '/w1/savings-investment-chooser/icons/term-deposit.png',
      termSheetUrl: 'https://www.westpac.co.nz/Westpac-Term-Deposit-Term-Sheet',
      disclosures: [],
    },
    termPIE: {
      applyUrl: 'https://www.westpac.co.nz/term-pie',
      termSheetUrl:
        'https://www.westpac.co.nz/assets/Personal/investments/documents/Term-Sheet/Westpac-Term-PIE-Fund-Term-Sheet-Westpac-NZ.pdf',
      earlyWithdrawalUrl:
        'https://www.westpac.co.nz/Early-Withdrawal-Term-Investment-Policy',
      icon: '/w1/savings-investment-chooser/icons/term-pie.png',
      disclosures: [
        'Term PIE is offered under the Westpac Term PIE Fund (“the Fund”). Investments made in the Fund do not represent bank deposits or other liabilities of Westpac Banking Corporation (ABN 33 007 457 141), Westpac New Zealand Limited or other members of the Westpac group of companies.',
        'Investments are subject risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.',
        'None of BT Funds Management (NZ) Limited (as manager); any member of the Westpac group of companies; Trustees Executors Limited (as trustee); or any director or nominee of any of those entities guarantees the Fund’s performance, returns or repayment of capital.',
      ],
    },
    simpleSaver: {
      applyUrl: 'https://www.westpac.co.nz/simple-saver',
      icon: '/w1/savings-investment-chooser/icons/simple-saver.png',
      disclosures: [],
    },
  },
  disclaimer: [
    '<p>This Savings & Investment Chooser tool gives you advice from Westpac New Zealand Limited (Westpac or “we”) on savings and investment options. The advice is based on the answers you provide to 5 questions, which take less than 5 minutes to answer.</p>',
    '<p>You’ll get a recommendation for one or more of these 6 products:',
    '<ul><li>Savings options – Simple Saver, Westpac Bonus Saver, Term Deposit</li>',
    '<li>Investment options – Westpac Bonus Saver PIE, Notice Saver, Term PIE</li></ul>',
    '<p>These savings and investment options are provided by Westpac, other than the PIE products, which are provided by BT Funds Management NZ (BTNZ), which is part of the Westpac group of companies.',
    '<br>Our Savings and Investment Chooser tool advice is free of charge. Details of any fees or other costs for the recommended savings and investment products are provided once the tool has made a recommendation.</p>',
    '<h6>What are the limitations of this advice?</h6>',
    "<p>This tool will provide a recommendation based only on the answers you provide today.  It doesn't take into consideration your current financial or personal circumstances, or any savings accounts or investments that you currently have with Westpac or other financial institutions. If circumstances change, we recommend that you complete the tool again or call us for help.</p>",
    "<p>Also, this tool does not consider products offered by other providers, or other types of investments such as KiwiSaver or other managed investment schemes. To find out more about the Westpac KiwiSaver Scheme, <a href='https://www.westpac.co.nz/kiwisaver/' target='_blank' rel='noopener noreferrer'>click here</a>.</p>",
    '<h6>I am under 18, can I use the tool?</h6>',
    '<p>If you’re under 18, you may need to have a parent or guardian help you through the tool to find the recommendation that best suits your needs.</p>',
    '<h6>Get in touch</h6>',
    "<p>If you’d like to talk with someone about your savings and investment requirements or require assistance, please call us on <a href='tel:0800400600'>0800 400 600</a> or <a href='tel:+6499148026'>+64 9 914 8026</a> between 7am – 8pm Monday to Friday, and 7am – 5pm Saturday and Sunday.</p>",
    '<h6>Conflict of interests and incentives</h6>',
    '<p>Because this tool advises on products offered by Westpac group companies only, Westpac benefits financially if you choose one of the recommended products.</p>',
    '<p>To manage conflicts, we have a conflict of interest policy and framework in place and we take all reasonable steps to ensure our advice is not materially influenced by our own or our affiliates’ interests, if we know that we or they have a conflict of interest with you. We regularly monitor and review financial advice given by this tool to ensure that recommendations are appropriate for our customers.</p>',
    '<p>Westpac does not receive any commissions in relation to advice given by this Savings & Investment Chooser tool.</p>',
    '<pageBreak/>',
    '<h6>Our duties providing financial advice</h6>',
    '<p>When providing financial advice through this tool,we are bound by a number of duties under the Financial Markets Conduct Act, including:</p>',
    '<ul><li>Meeting the standards of competence, knowledge and skill set out in the Code of Professional Conduct for Financial Advice Services (Code);</li>',
    '<li>Giving priority to your interests;</li>',
    '<li>Exercising care, diligence and skill; and </li>',
    '<li>Meeting the standards of ethical behaviour, conduct and client care set out in the Code.</li></ul>',
    '<h6>Reliability history</h6>',
    '<p>We need to let you know that an event, known as a ‘reliability event’ occurred involving Westpac.</p>',
    '<p>In August 2019, Westpac identified and self-disclosed an issue to the Financial Markets Authority and Commerce Commission. The issue related to the discounting of fees for some customers and a potential contravention of the fair dealing provisions of the Financial Markets Conduct Act. Steps were agreed in relation to the refund of fees to some 93,000 customers who had been overcharged.</p>',
    '<h6>Complaints</h6>',
    "<p>If you’re ever unhappy about something we’ve done – or perhaps not done – please give us the opportunity to put things right. You can use our complaints process, as outlined on our <a href='https://www.westpac.co.nz/who-we-are/find-contact-us/feedback/' target='_blank' rel='noopener noreferrer'>website</a>.</p>",
    "<p>If you’re not satisfied with our response after we have investigated your complaint, we are a member of the <a href='https://bankomb.org.nz/' target='_blank' rel='noopener noreferrer'>Banking Ombudsman Scheme</a>, a free and independent service to help you resolve the issue with us. Further information regarding the Banking Ombudsman Scheme is available on our <a href='https://www.westpac.co.nz/who-we-are/find-contact-us/feedback/' target='_blank' rel='noopener noreferrer'>website</a>.</p>",
    '<h6>Would you like this information in writing?</h6>',
    "<p><a href='/w1/savings-investment-chooser/Savings-Investment-Tool-Landing.pdf' target='_blank' rel='noopener noreferrer'>Click here</a> to download this information.</p>",
  ],
  disclaimerSecondary: [
    '<p>Westpac Bonus Saver PIE is offered under the Westpac Cash PIE Fund, Term PIE is offered under the Westpac Term PIE Fund, and Notice Saver is offered under the Westpac Notice Saver PIE Fund (together, the “Funds”).</p>',
    '<p>Investments made in the Funds do not represent bank deposits or other liabilities of Westpac Banking Corporation ABN 33 007 457 141, Westpac New Zealand Limited (“Westpac NZ”) or other members of the Westpac group of companies.  They are subject to investment and other risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.  None of BT Funds Management (NZ) Limited (as manager), any member of the Westpac group of companies, Trustees Executors Limited (as trustee), or any director or nominee of any of those entities guarantees the Funds’ performance, returns or repayment of capital.</p>',
    "<p>You can get more information and free copies of the Disclosure Statement for Westpac NZ or the term sheet for any of the Funds from any Westpac branch or online <a href='https://www.westpac.co.nz/investor-documents' target='_blank' rel='noopener noreferrer'>here</a>.</p>",
    "<p>A copy of the Trust Deed for the Funds can be accessed <a href='https://www.westpac.co.nz/assets/Personal/investments/documents/Trust-Deeds/Funds-Consolidated-Trust-Deed-Westpac-NZ.pdf' target='_blank' rel='noopener noreferrer'>here</a>.</p>",
    "<p>To view the latest Annual Report for Funds for the year ended 31 March 2020, please click <a href='https://www.westpac.co.nz/assets/Personal/investments/documents/Financial-Statements/Westpac-PIE-Funds-March-2020-Financial-Statements-Signed-Westpac-NZ.pdf' target='_blank' rel='noopener noreferrer'>here</a>.</p>",
  ],
  disclaimerStaff: [
    '<h6>Information Only Roles</h6>',
    '<p>We have a Westpac advice tool that can give you a recommendation from one of our Savings &amp;',
    'Term Investment products. I will be passing this advice on to you on behalf of Westpac. I need to',
    'get answers to a few short questions, and the tool will provide a recommendation based on those',
    'answers. Are you happy to proceed?</p>',
    '<h6>Nominated Representatives</h6>',
    '<p>We have a Westpac advice tool that can give you a recommendation from one of our Savings &amp;',
    'Term Investment products. I need to get answers to a few short questions, and the tool will',
    'provide a recommendation based on those answers. Are you happy to proceed?</p>',
    '<h6>Would you like to download the disclosure?</h6>',
    "<p><a href='/w1/savings-investment-chooser/Savings-Investment-Tool-Landing.pdf' target='_blank' rel='noopener noreferrer'>Click here</a> to download the disclosure.</p>",
  ],
}

export default config
