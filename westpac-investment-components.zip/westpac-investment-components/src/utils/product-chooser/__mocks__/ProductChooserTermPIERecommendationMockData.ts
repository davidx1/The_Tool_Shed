import { IProductChooserProductItem } from '../productChooserUtils'

const recommendation: IProductChooserProductItem = {
  icon: 'https://',
  type: 'termPIE',
  title: 'Westpac Term PIE Fund',
  description: [
    'For people who say they can lock their money away, and are not looking to add any more to their initial investment, we’d recommend the Westpac Term PIE Fund. Put away as little as $5,000 for a fixed term and earn a fixed return rate. For people who are a New Zealand tax resident and have a tax rate of 30% or 33%, there can be added tax benefits.',
    'Term PIEs are often used for: having a fixed interest rate agreed upfront for a set amount of time; growing the investment by compounding interest (for terms 6 months and more); providing an income by having the interest paid out to an everyday account (for terms of 6 months and more); or taking advantage of the special tax rules to get higher after-tax returns when compared to a Term Deposit with the same term.',
  ],
  interestRatesTitle: 'Our Term PIE rates.',
  interestRatesDescription: [
    'Our Term PIEs are a simple fee-free way to invest $5,000 or more. They earn a fixed rate of return for a fixed period of time. If you can lock your money away, you are generally rewarded with a higher rate, and certainty that the rate won’t change.',
    'As a PIE, this investment could be a smart way for you to save. Because you may potentially pay less tax, your savings could grow a little faster in a Term PIE than in a regular Term Deposit with the same term and rate.',
  ],
  interestRates: [
    {
      annualRatePercent: '1.50',
      durationInMonths: '6 months',
      effectiveReturn: {
        thirty: '1.54',
        thirtyThree: '1.61',
      },
    },
    {
      annualRatePercent: '1.55',
      durationInMonths: '8 months',
      effectiveReturn: {
        thirty: '1.59',
        thirtyThree: '1.67',
      },
    },
    {
      annualRatePercent: '1.50',
      durationInMonths: '12 months',
      effectiveReturn: {
        thirty: '1.54',
        thirtyThree: '1.61',
      },
    },
  ],
  video: {
    title: 'What is PIE?',
    description:
      'PIE products are treated as an investment where you buy units in a fund and you pay tax at a special tax rate. This is call the Prescribed Investor Rate or PIR. Watch this short video to find out more.',
    url: 'https://www.youtube.com/embed/12a5-LmJNY8?enablejsapi=1&origin=*',
    posterImageUrl: 'https://',
  },
  benefits: [
    'A simple way to invest from 7 days to 5 years and could offer you greater  after tax returns than a Term Deposit for the same term for investors taxed at 30% or 33%, as tax on returns is capped at 28% PIR.',
    'If you can lock your money away, you are generally rewarded with a higher rate.',
    'Potentially less tax to pay, your investment could grow a little faster in a Term PIE than in a regular Term Deposit with the same term and rate.',
  ],
  details: [
    {
      title: 'How you earn returns',
      details: [],
      disclosures: [],
    },
    {
      title: 'Accessibility',
      details: [
        'Apply in branch, or via Contact Centre.',
        'Withdrawals: Choosing to invest in a Term PIE means you’re willing to keep your money invested for a fixed time frame.',
        'There’s a 7 business day “cooling off” period starting on the date you take out your Term PIE. Outside this initial “cooling off” period, you can only withdraw all or part of your Term Investment early if we agree. In deciding whether to agree, we will apply our early withdrawal policy (please see below).',
        'We can only agree to an early withdrawal from a Term Investment if you have given us 32 days’ prior notice or you are suffering from hardship.',
      ],
      disclosures: [],
    },
    {
      title: 'Important things to know',
      details: [
        'Please read the Westpac Term PIE Fund Term Sheet which contains the full terms and conditions for our Term PIEs.',
        'Early Withdraw policy. In deciding whether to agree to an early withdrawal, we will apply our early withdrawal policy which may change from time to time. A reduced interest rate will apply if we agree, unless determined otherwise under our Early Withdrawal Policy.',
        'Rates are available for Retail and Business Banking customers and apply up to the first $5,000,000 of deposits held either solely or jointly with Westpac. For rates applicable to amounts in excess of $5,000,000, please contact us.',
        'Term PIE is offered under the Westpac Term PIE Fund (the “Fund”).  Investments made in the Fund do not represent bank deposits or other liabilities of Westpac Banking Corporation ABN 33 007 457 141, Westpac New Zealand Limited (“Westpac NZ”) or other members of the Westpac group of companies.',
        'They are subject to investment and other risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested.',
        'None of BT Funds Management (NZ) Limited (as manager), any member of the Westpac group of companies, Trustees Executors Limited (as trustee), or any director or nominee of any of those entities guarantees the Fund’s performance, returns or repayment of capital.',
      ],
      disclosures: [],
    },
  ],
  fees: {
    accountFees: [
      {
        type: 'Monthly account maintenance fee',
        amount: 'Free',
      },
      {
        type: 'Paper statement',
        amount: 'Free',
      },
    ],
    serviceFees: [],
  },
  disclosures: [
    'Interest rates and fees are current as at 11 August 2020 and are subject to change without notice.',
    'ˆThe Effective Return is the rate you would need to receive from a regular savings account in order to achieve the same after tax return from your Term PIE account, based on a PIR of 28% and an income tax rate of either 30% or 33%.\n¹Individuals with taxable income of $48,001 to $70,000.\n²Individuals with taxable income of $70,001 and over.',
  ],
  disclosuresPDF: [],
  shortDescription: '<shortDescription>',
  applyUrl: '<applyUrl>',
  applyTitle: '<applyTitle>',
  benefitsComparison: '<benefitsComparison>',
  feesComparison: '<feesComparison>',
  ratesComparison: '<ratesComparison>',
  thingsToKnowComparison: '<thingsToKnowComparison>',
}

export default recommendation
