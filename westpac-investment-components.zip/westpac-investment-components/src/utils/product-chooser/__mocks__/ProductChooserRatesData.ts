import { IProductChooserRatesData } from '../productChooserUtils'

const ratesData: IProductChooserRatesData = {
  bonusSaverAccount: {
    rateBreakdown: {
      annualRate: '0.50',
      baseRate: '0.05',
      bonusRate: '0.45',
    },
    accountFees: {
      maintenanceFee: {
        value: 'Free',
      },
      electronicStatementsFee: {
        value: 'Free',
      },
      paperStatementsFee: {
        value: '$1.50',
      },
      electronicWithdrawals: {
        value: 'Free',
      },
      manualWithdrawals: {
        value: '$2.50',
        frequency: 'per transaction',
      },
      chequeWithdrawals: {
        value: '$2.50',
        frequency: 'per transaction',
      },
      depositFee: {
        value: 'Free',
      },
    },
    serviceFees: {
      callFee: {
        value: 'Free',
      },
      emailAlertFee: {
        value: 'Free',
      },
      onlinePaymentSetupFee: {
        value: 'Free',
      },
      branchPaymentSetupFee: {
        value: '$5',
      },
    },
  },
  bonusSaverPIE: {
    rateBreakdown: {
      annualRate: '0.50',
      baseRate: '0.05',
      bonusRate: '0.45',
      returnRate: {
        thirty: '0.82',
        thirtyThree: '0.86',
      },
    },
    accountFees: {
      maintenanceFee: {
        value: 'Free',
      },
      electronicStatementsFee: {
        value: 'Free',
      },
      paperStatementsFee: {
        value: '$1.50',
      },
      electronicWithdrawals: {
        value: 'Free',
      },
      manualWithdrawals: {
        value: '$2.50',
        frequency: 'per transaction',
      },
      chequeWithdrawals: {
        value: '$2.50',
        frequency: 'per transaction',
      },
      depositFee: {
        value: 'Free',
      },
    },
    serviceFees: {
      callFee: {
        value: 'Free',
      },
      emailAlertFee: {
        value: 'Free',
      },
      onlinePaymentSetupFee: {
        value: 'Free',
      },
      branchPaymentSetupFee: {
        value: '$5',
      },
    },
  },
  noticeSaver: {
    rateBreakdown: {
      annualRate: '0.80',
      returnRate: {
        thirty: '0.82',
        thirtyThree: '0.86',
      },
    },
    accountFees: {
      maintenanceFee: {
        value: 'Free',
      },
      paperStatementsFee: {
        value: 'Free',
      },
      manualWithdrawals: {
        value: 'Free',
      },
      depositFee: {
        value: 'Free',
      },
    },
    serviceFees: {
      callFee: {
        value: 'Free',
      },
    },
  },
  simpleSaver: {
    rateBreakdown: {
      annualRate: '0.05',
    },
    accountFees: {
      maintenanceFee: {
        value: 'Free',
      },
      paperStatementsFee: {
        value: 'Free',
      },
      depositFee: {
        value: 'Free',
      },
      firstWithdrawal: {
        value: 'Free',
      },
      electronicWithdrawals: {
        value: '$1',
      },
      manualWithdrawals: {
        value: '$3',
      },
      electronicStatementsFee: {
        value: 'Free',
      },
    },
    serviceFees: {},
  },
  termDeposit: {
    rateBreakdown: {
      term1: {
        annualRate: '2.40',
        termLength: '6 months',
      },
      term2: {
        annualRate: '2.40',
        termLength: '9 months',
      },
      term3: {
        annualRate: '2.40',
        termLength: '12 months',
      },
    },
    accountFees: {
      maintenanceFee: {
        value: 'Free',
      },
      paperStatementsFee: {
        value: 'Free',
      },
    },
    serviceFees: {},
  },
  termPIE: {
    rateBreakdown: {
      term1: {
        annualRate: '1.50',
        returnRate: {
          thirty: '1.54',
          thirtyThree: '1.61',
        },
        termLength: '6 months',
      },
      term2: {
        annualRate: '1.55',
        returnRate: {
          thirty: '1.59',
          thirtyThree: '1.67',
        },
        termLength: '8 months',
      },
      term3: {
        annualRate: '1.50',
        returnRate: {
          thirty: '1.54',
          thirtyThree: '1.61',
        },
        termLength: '12 months',
      },
    },
    accountFees: {
      maintenanceFee: {
        value: 'Free',
      },
      paperStatementsFee: {
        value: 'Free',
      },
      electronicWithdrawals: {
        value: 'Free',
      },
      electronicStatementsFee: {
        value: 'Free',
      },
      manualWithdrawals: {
        value: 'Free',
      },
      depositFee: {
        value: 'Free',
      },
    },
    serviceFees: {},
  },
  updatedAt: '15 April 2020',
}

export default ratesData
