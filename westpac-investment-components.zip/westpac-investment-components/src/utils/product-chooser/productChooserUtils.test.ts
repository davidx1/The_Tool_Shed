import {
  getNextStepProductChooser,
  IProductChooserStep,
  IProductChooserProductType,
  OPTION_ACCESS_I_CAN_WAIT,
  OPTION_ACCESS_ANYTIME,
  OPTION_INTERVAL_ONCE_A_MONTH,
  OPTION_INTERVAL_SOMETIMES,
  OPTION_INTERVAL_NO_MORE,
  OPTION_UNDER_5K,
  OPTION_OVER_5K,
  OPTION_NZ_TAX_RESIDENT_YES,
  OPTION_NZ_TAX_RESIDENT_NO,
  OPTIONS_TAX_RATE_LOW,
  OPTIONS_TAX_RATE_HIGH,
} from './productChooserUtils'
import config from '../../utils/product-chooser/__mocks__/ProductChooserConfigMockData'
import ratesData from './__mocks__/ProductChooserRatesData'

const testProductChooserRecommendation = (
  options: (string | number)[],
  primaryRecommendation: IProductChooserProductType,
  secondaryRecommendation: IProductChooserProductType | undefined,
  tertiaryRecommendation: IProductChooserProductType | undefined
): void => {
  const step: IProductChooserStep = getNextStepProductChooser(
    options,
    config,
    ratesData
  )

  expect(step.type).toBe('recommendation')
  expect(step.recommendation?.type).toBe(primaryRecommendation)
  expect(step.recommendationDetails?.secondaryRecommendation).toBe(
    secondaryRecommendation
  )
  expect(step.recommendationDetails?.tertiaryRecommendation).toBe(
    tertiaryRecommendation
  )
}

describe('Withdraw after giving notice', () => {
  describe('Deposit at least once a month', () => {
    it('As a customer who is not an NZ tax resident, after answering questions on the app, should be directed to Westpac Bonus Saver results page', () => {
      testProductChooserRecommendation(
        [
          OPTION_ACCESS_I_CAN_WAIT,
          OPTION_INTERVAL_ONCE_A_MONTH,
          OPTION_NZ_TAX_RESIDENT_NO,
        ],
        'bonusSaverAccount',
        'simpleSaver',
        undefined
      )
    })
    OPTIONS_TAX_RATE_LOW.forEach((rate) => {
      it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Westpac Bonus Saver results page`, () => {
        testProductChooserRecommendation(
          [
            OPTION_ACCESS_I_CAN_WAIT,
            OPTION_INTERVAL_ONCE_A_MONTH,
            OPTION_NZ_TAX_RESIDENT_YES,
            rate,
          ],
          'noticeSaver',
          'bonusSaverAccount',
          'simpleSaver'
        )
      })
    })
    OPTIONS_TAX_RATE_HIGH.forEach((rate) => {
      it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Westpac Bonus Saver results page`, () => {
        testProductChooserRecommendation(
          [
            OPTION_ACCESS_I_CAN_WAIT,
            OPTION_INTERVAL_ONCE_A_MONTH,
            OPTION_NZ_TAX_RESIDENT_YES,
            rate,
          ],
          'noticeSaver',
          'bonusSaverPIE',
          'bonusSaverAccount'
        )
      })
    })
  })
  describe('Deposit sometimes but not every month', () => {
    it('As a customer who is not an NZ tax resident, after answering questions on the app, should be directed to Westpac Bonus Saver results page', () => {
      testProductChooserRecommendation(
        [
          OPTION_ACCESS_I_CAN_WAIT,
          OPTION_INTERVAL_SOMETIMES,
          OPTION_NZ_TAX_RESIDENT_NO,
        ],
        'bonusSaverAccount',
        'simpleSaver',
        undefined
      )
    })
    OPTIONS_TAX_RATE_LOW.forEach((rate) => {
      it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Notice Saver results page`, () => {
        testProductChooserRecommendation(
          [
            OPTION_ACCESS_I_CAN_WAIT,
            OPTION_INTERVAL_SOMETIMES,
            OPTION_NZ_TAX_RESIDENT_YES,
            rate,
          ],
          'noticeSaver',
          'bonusSaverAccount',
          'simpleSaver'
        )
      })
    })
    OPTIONS_TAX_RATE_HIGH.forEach((rate) => {
      it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Notice Saver results page`, () => {
        testProductChooserRecommendation(
          [
            OPTION_ACCESS_I_CAN_WAIT,
            OPTION_INTERVAL_SOMETIMES,
            OPTION_NZ_TAX_RESIDENT_YES,
            rate,
          ],
          'noticeSaver',
          'bonusSaverPIE',
          'bonusSaverAccount'
        )
      })
    })
  })
  describe('One time deposit', () => {
    describe('Deposit under $5,000', () => {
      it('As a customer who is not an NZ tax resident, after answering questions on the app, should be directed to Westpac Bonus Saver results page', () => {
        testProductChooserRecommendation(
          [
            OPTION_ACCESS_I_CAN_WAIT,
            OPTION_INTERVAL_NO_MORE,
            OPTION_UNDER_5K,
            OPTION_NZ_TAX_RESIDENT_NO,
          ],
          'bonusSaverAccount',
          'simpleSaver',
          undefined
        )
      })

      OPTIONS_TAX_RATE_LOW.forEach((rate) => {
        it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Notice Saver results page`, () => {
          testProductChooserRecommendation(
            [
              OPTION_ACCESS_I_CAN_WAIT,
              OPTION_INTERVAL_NO_MORE,
              OPTION_UNDER_5K,
              OPTION_NZ_TAX_RESIDENT_YES,
              rate,
            ],
            'noticeSaver',
            'bonusSaverAccount',
            'simpleSaver'
          )
        })
      })
      OPTIONS_TAX_RATE_HIGH.forEach((rate) => {
        it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Notice Saver results page`, () => {
          testProductChooserRecommendation(
            [
              OPTION_ACCESS_I_CAN_WAIT,
              OPTION_INTERVAL_NO_MORE,
              OPTION_UNDER_5K,
              OPTION_NZ_TAX_RESIDENT_YES,
              rate,
            ],
            'noticeSaver',
            'bonusSaverPIE',
            'bonusSaverAccount'
          )
        })
      })
    })
    describe('Deposit over $5,000', () => {
      it('As a customer who is not an NZ tax resident, after answering questions on the app, should be directed to Westpac Bonus Saver results page', () => {
        testProductChooserRecommendation(
          [
            OPTION_ACCESS_I_CAN_WAIT,
            OPTION_INTERVAL_NO_MORE,
            OPTION_OVER_5K,
            OPTION_NZ_TAX_RESIDENT_NO,
          ],
          'termDeposit',
          'bonusSaverAccount',
          'simpleSaver'
        )
      })
      OPTIONS_TAX_RATE_LOW.forEach((rate) => {
        it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Notice Saver results page`, () => {
          testProductChooserRecommendation(
            [
              OPTION_ACCESS_I_CAN_WAIT,
              OPTION_INTERVAL_NO_MORE,
              OPTION_OVER_5K,
              OPTION_NZ_TAX_RESIDENT_YES,
              rate,
            ],
            'termDeposit',
            'noticeSaver',
            'bonusSaverAccount'
          )
        })
      })
      OPTIONS_TAX_RATE_HIGH.forEach((rate) => {
        it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Notice Saver results page`, () => {
          testProductChooserRecommendation(
            [
              OPTION_ACCESS_I_CAN_WAIT,
              OPTION_INTERVAL_NO_MORE,
              OPTION_OVER_5K,
              OPTION_NZ_TAX_RESIDENT_YES,
              rate,
            ],
            'termPIE',
            'termDeposit',
            'noticeSaver'
          )
        })
      })
    })
  })
})

describe('Withdraw anytime', () => {
  it('As a customer who is not an NZ tax resident, after answering questions on the app, should be directed to Westpac Bonus Saver results page', () => {
    testProductChooserRecommendation(
      [OPTION_ACCESS_ANYTIME, OPTION_NZ_TAX_RESIDENT_NO],
      'bonusSaverAccount',
      'simpleSaver',
      undefined
    )
  })
  OPTIONS_TAX_RATE_LOW.forEach((rate) => {
    it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Westpac Bonus Saver results page`, () => {
      testProductChooserRecommendation(
        [OPTION_ACCESS_ANYTIME, OPTION_NZ_TAX_RESIDENT_YES, rate],
        'bonusSaverAccount',
        'simpleSaver',
        undefined
      )
    })
  })
  OPTIONS_TAX_RATE_HIGH.forEach((rate) => {
    it(`As a customer who is an NZ tax resident of ${rate}, after answering questions on the app, should be directed to Westpac Bonus Saver PIE results page`, () => {
      testProductChooserRecommendation(
        [OPTION_ACCESS_ANYTIME, OPTION_NZ_TAX_RESIDENT_YES, rate],
        'bonusSaverPIE',
        'bonusSaverAccount',
        'simpleSaver'
      )
    })
  })
})

describe('getNextStepProductChooser > human-readable format of the answers and recommendation + reporting data', () => {
  it('Conservative recommendation for first home goal', () => {
    const step: IProductChooserStep = getNextStepProductChooser(
      [
        OPTION_ACCESS_I_CAN_WAIT,
        OPTION_INTERVAL_NO_MORE,
        OPTION_UNDER_5K,
        OPTION_NZ_TAX_RESIDENT_YES,
        OPTIONS_TAX_RATE_HIGH[0],
      ],
      config,
      ratesData
    )

    expect(step.customerInteraction?.subject).toBe(
      'Savings and Investment Chooser tool recommends Notice Saver'
    )

    expect(step.customerInteraction?.whyProductSuitable).toBe(
      'When will you need to access your money? - I can lock my money away for a fixed period. Or I can give 32 days’ notice when I need access to my money.; How often will you deposit money into your savings? - I have a lump sum now and don’t want to add more.; How much is your initial deposit? - Under $5,000; Are you a New Zealand tax resident? - Yes; What is your tax rate? - 30%; '
    )

    expect(step.customerInteraction?.additionalInfo).toEqual(
      [
        '<data>',
        '<Recommendation>Notice Saver</Recommendation>',
        "<RecommendationDescription>As you don’t need to access your money instantly, Notice Saver can help you focus on saving towards a particular goal, giving us 32 days' notice before making a withdrawal. It earns our highest savings return for an account that you can add money to anytime. Notice Saver is a PIE option, so if you’re a New Zealand tax resident paying 30% or 33% income tax, you could benefit from the tax rate of 28%.Notice Saver is suitable for saving for a long-term goal like a holiday or to start saving for a house deposit. It also works if you’re adding funds to grow an investment over time, provided you’re happy to have the money locked away with a notice period.</RecommendationDescription>",
        '<RecommendationSecondary>Westpac Bonus Saver PIE</RecommendationSecondary>',
        '<RecommendationTertiary>Westpac Bonus Saver</RecommendationTertiary>',
        '</data>',
      ].join('')
    )
  })
})
