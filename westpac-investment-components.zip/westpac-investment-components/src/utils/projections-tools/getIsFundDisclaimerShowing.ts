import { checkIsWithdrawing } from './checkIsWithdrawing'
import { IProjectionsFundType } from './projectionsToolUtils'

export function getIsFundDisclaimerShowing(
  currentAge: number,
  retirementAge: number,
  homeWithdrawalAge: number,
  selectedFund: IProjectionsFundType
) {
  const moneyUsageAge = checkIsWithdrawing(
    currentAge,
    retirementAge,
    homeWithdrawalAge
  )
    ? homeWithdrawalAge
    : retirementAge

  const investmentHorizon = moneyUsageAge - currentAge;

  return (
    (selectedFund === 'conservative' && investmentHorizon <= 4) ||
    (selectedFund === 'moderate' && investmentHorizon <= 6) ||
    (selectedFund === 'balanced' && investmentHorizon <= 9) ||
    (selectedFund === 'growth' && investmentHorizon <= 10)
  )
}
