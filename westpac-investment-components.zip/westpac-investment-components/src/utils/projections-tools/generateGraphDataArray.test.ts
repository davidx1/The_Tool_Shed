import { generateGraphDataArray } from './generateGraphDataArray'
import { projectionsCalculation } from './projectionsCalculation'
import config from './__mocks__/ProjectionsConfigMockData'

it('The generated plot array is correct when there is a first home', () => {
  const currentAge = 18
  const retireAge = 22
  const firstHomeWithdrawalAge = 20

  const curriedNewY = (age: number) =>
    projectionsCalculation({
      currentAge,
      calculationEndAge: age,
      initialBalance: 800,
      investmentRate: 0.045,
      voluntaryContributionRate: 0,
      voluntaryContributionFrequency: 'annually',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      firstHomeWithdrawalAge,
      config,
    }).finalAmount

  const curriedOldY = (age: number) =>
    projectionsCalculation({
      currentAge,
      calculationEndAge: age,
      initialBalance: 800,
      investmentRate: 0.015,
      voluntaryContributionRate: 0,
      voluntaryContributionFrequency: 'annually',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      firstHomeWithdrawalAge,
      config,
    }).finalAmount

  const ageDiff = retireAge - currentAge + 1

  const newBalanceBeforeFirstHomeWithdrawal = curriedNewY(
    firstHomeWithdrawalAge
  )

  const oldBalanceBeforeFirstHomeWithdrawal = curriedOldY(
    firstHomeWithdrawalAge
  )

  expect(
    generateGraphDataArray({
      currentAge,
      firstHomeWithdrawalAge,
      retireAge,
      ageDiff,
      newBalanceBeforeFirstHomeWithdrawal,
      oldBalanceBeforeFirstHomeWithdrawal,
      curriedNewY,
      curriedOldY,
    })
  ).toMatchSnapshot()
})

it('The generated plot array is correct when there is NO first home withdrawal', () => {
  const currentAge = 18
  const retireAge = 22

  const curriedNewY = (age: number) =>
    projectionsCalculation({
      currentAge,
      calculationEndAge: age,
      initialBalance: 800,
      investmentRate: 0.045,
      voluntaryContributionRate: 0,
      voluntaryContributionFrequency: 'annually',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      config,
    }).finalAmount

  const curriedOldY = (age: number) =>
    projectionsCalculation({
      currentAge,
      calculationEndAge: age,
      initialBalance: 800,
      investmentRate: 0.015,
      voluntaryContributionRate: 0,
      voluntaryContributionFrequency: 'annually',
      salary: 50000,
      salaryContributionRate: 0.03,
      isIncludingSuperannuation: false,
      relationshipStatus: 'single',
      config,
    }).finalAmount

  const ageDiff = retireAge - currentAge + 1

  expect(
    generateGraphDataArray({
      currentAge,
      firstHomeWithdrawalAge: 0,
      retireAge,
      ageDiff,
      newBalanceBeforeFirstHomeWithdrawal: 0,
      oldBalanceBeforeFirstHomeWithdrawal: 0,
      curriedNewY,
      curriedOldY,
    })
  ).toMatchSnapshot()
})
