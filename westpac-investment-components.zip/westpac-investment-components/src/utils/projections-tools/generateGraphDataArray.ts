import { checkIsWithdrawing } from './checkIsWithdrawing'

// Data contain an array of coordinates.
// The reason we check if a firstHomeWithdrawal happens is because if
// there is a first home withdrawal then we need an extra point on the graph
// for the age when the withdrawal happens. For example normally there is one
// point per year, but if a withdrawal happens at 35 years old, there needs
// to be two points on x = 35, one for before the withdrawal, one of after
// and a straight vertical line would be plotted between the two points.
//
// The first point on the age of the withdrawal shows how much money is available
// at the time. The second point will usually be at $1000 because we are
// assuming the user withdrawals as much as possible. A min balance of $1000
// in kiwisaver can't be violated.
//
// If the person have less than $1000 at the time then the second point
// will be plotted at the same place as the first dot; whatever balance he/she
// has available, since he/she can't make a withdrawal.
export const generateGraphDataArray = ({
  currentAge,
  firstHomeWithdrawalAge,
  retireAge,
  ageDiff,
  newBalanceBeforeFirstHomeWithdrawal,
  oldBalanceBeforeFirstHomeWithdrawal,
  curriedNewY,
  curriedOldY,
}: Prop): GraphDataType[] => {
  const isWithdrawing = checkIsWithdrawing(
    currentAge,
    retireAge,
    firstHomeWithdrawalAge
  )

  return Array.from(
    {
      //If we are withdrawing for first home, we need to plot 1 extra data point,
      // because there are two points plotted at the age of withdrawal;
      // one before and one after the withdrawal
      length: isWithdrawing ? ageDiff + 1 : ageDiff,
    },
    (_, i) => {
      // For all points before the first home withdrawal, or if there are no first home withdrawal
      // the age each dot represent corresponds to its position in the array + current age
      // for all points post first home withdrawal, the age it represent is
      // equal to its position in the array + current age - 1 because 2 points were
      // plotted at the age of the withdrawal
      const x =
        !isWithdrawing || i + currentAge <= firstHomeWithdrawalAge
          ? i + currentAge
          : i + currentAge - 1

      let tempNewYBalance = curriedNewY(x)
      let tempOldYBalance = curriedOldY(x)
      if (i + currentAge - 1 === firstHomeWithdrawalAge) {
        tempNewYBalance = Math.min(newBalanceBeforeFirstHomeWithdrawal, 1000)
        tempOldYBalance = Math.min(oldBalanceBeforeFirstHomeWithdrawal, 1000)
      }
      return {
        x,
        newY: tempNewYBalance,
        oldY: tempOldYBalance,
      }
    }
  )
}

export interface GraphDataType {
  x: number
  newY: number
  oldY: number
}

interface Prop {
  currentAge: number
  firstHomeWithdrawalAge: number
  retireAge: number
  ageDiff: number
  newBalanceBeforeFirstHomeWithdrawal: number
  oldBalanceBeforeFirstHomeWithdrawal: number
  curriedNewY: (n: number) => number
  curriedOldY: (n: number) => number
}
