export function checkIsWithdrawing(
  currentAge: number,
  retireAge: number,
  withdrawalAge: number,
  rangeInclusive: boolean = true
) {
  return rangeInclusive
    ? withdrawalAge && withdrawalAge <= retireAge && withdrawalAge >= currentAge
    : withdrawalAge && withdrawalAge < retireAge && withdrawalAge > currentAge
}
