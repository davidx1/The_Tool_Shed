import { checkIsWithdrawing } from './checkIsWithdrawing'

describe('Function that checks if withdrawal age is between current age and retirement age', () => {
  it('should calculate all the inclusive values correctly', () => {
    //Get true when withdrawal age is between current and retire
    expect(checkIsWithdrawing(10, 30, 20)).toBeTruthy()
    expect(checkIsWithdrawing(10, 30, 11)).toBeTruthy()
    expect(checkIsWithdrawing(10, 30, 29)).toBeTruthy()

    expect(checkIsWithdrawing(2, 27, 3)).toBeTruthy()
    expect(checkIsWithdrawing(2, 27, 15)).toBeTruthy()
    expect(checkIsWithdrawing(2, 27, 26)).toBeTruthy()

    expect(checkIsWithdrawing(60, 70, 61)).toBeTruthy()
    expect(checkIsWithdrawing(60, 70, 65)).toBeTruthy()
    expect(checkIsWithdrawing(60, 70, 69)).toBeTruthy()

    //Get false when withdrawal age is current and retire or outside of them
    expect(checkIsWithdrawing(10, 30, 10)).toBeTruthy()
    expect(checkIsWithdrawing(10, 30, 30)).toBeTruthy()
    expect(checkIsWithdrawing(10, 30, 31)).toBeFalsy()
    expect(checkIsWithdrawing(10, 30, 9)).toBeFalsy()

    expect(checkIsWithdrawing(2, 27, 2)).toBeTruthy()
    expect(checkIsWithdrawing(2, 27, 27)).toBeTruthy()
    expect(checkIsWithdrawing(2, 27, 1)).toBeFalsy()
    expect(checkIsWithdrawing(2, 27, 28)).toBeFalsy()

    expect(checkIsWithdrawing(60, 70, 60)).toBeTruthy()
    expect(checkIsWithdrawing(60, 70, 70)).toBeTruthy()
    expect(checkIsWithdrawing(60, 70, 59)).toBeFalsy()
    expect(checkIsWithdrawing(60, 70, 71)).toBeFalsy()
  })

  it('should calculate all the exclusive values correctly', () => {
    //Get true when withdrawal age is between current and retire
    expect(checkIsWithdrawing(10, 30, 20, false)).toBeTruthy()
    expect(checkIsWithdrawing(10, 30, 11, false)).toBeTruthy()
    expect(checkIsWithdrawing(10, 30, 29, false)).toBeTruthy()

    expect(checkIsWithdrawing(2, 27, 3, false)).toBeTruthy()
    expect(checkIsWithdrawing(2, 27, 15, false)).toBeTruthy()
    expect(checkIsWithdrawing(2, 27, 26, false)).toBeTruthy()

    expect(checkIsWithdrawing(60, 70, 61, false)).toBeTruthy()
    expect(checkIsWithdrawing(60, 70, 65, false)).toBeTruthy()
    expect(checkIsWithdrawing(60, 70, 69, false)).toBeTruthy()

    //Get false when withdrawal age is current and retire or outside of them
    expect(checkIsWithdrawing(10, 30, 10, false)).toBeFalsy()
    expect(checkIsWithdrawing(10, 30, 30, false)).toBeFalsy()
    expect(checkIsWithdrawing(10, 30, 31, false)).toBeFalsy()
    expect(checkIsWithdrawing(10, 30, 9, false)).toBeFalsy()

    expect(checkIsWithdrawing(2, 27, 2, false)).toBeFalsy()
    expect(checkIsWithdrawing(2, 27, 27, false)).toBeFalsy()
    expect(checkIsWithdrawing(2, 27, 1, false)).toBeFalsy()
    expect(checkIsWithdrawing(2, 27, 28, false)).toBeFalsy()

    expect(checkIsWithdrawing(60, 70, 60, false)).toBeFalsy()
    expect(checkIsWithdrawing(60, 70, 70, false)).toBeFalsy()
    expect(checkIsWithdrawing(60, 70, 59, false)).toBeFalsy()
    expect(checkIsWithdrawing(60, 70, 71, false)).toBeFalsy()
  })
})
