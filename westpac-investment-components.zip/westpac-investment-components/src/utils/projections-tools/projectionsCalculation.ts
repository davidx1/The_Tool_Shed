import {
  IKiwisaverContributionFrequencyType,
  IKiwisaverProjectionsConfig,
  IRelationshipStatusType,
} from './projectionsToolUtils'

import { checkIsWithdrawing } from './checkIsWithdrawing'

interface CalculateBaseProps {
  currentAge: number
  calculationEndAge: number
  initialBalance: number
  investmentRate: number
  voluntaryContributionRate: number
  voluntaryContributionFrequency: IKiwisaverContributionFrequencyType
  salary: number
  salaryContributionRate: number
  isIncludingSuperannuation: boolean
  relationshipStatus: IRelationshipStatusType
  //Normally we want to calculate the projection between current age and some future age
  //However, there are scenarios, where we want to calculate the time between
  //a future age to another future age
  //Specifically between the withdrawal age and the retirement age
  //This is when calculationStartAge and calculationStartSalary comes in.
  calculationStartAge?: number
  calculationStartSalary?: number
  config: IKiwisaverProjectionsConfig
}

export interface CalculateReturn {
  finalAmount: number
  nominalAmount: number
  withdrawableAmount: number
  payments: {
    [key in IKiwisaverContributionFrequencyType]: number
  }
}

export interface CalculateProps extends CalculateBaseProps {
  firstHomeWithdrawalAge?: number
}

function calculateBase({
  currentAge,
  calculationStartAge = currentAge,
  calculationEndAge,
  initialBalance,
  investmentRate,
  voluntaryContributionRate,
  voluntaryContributionFrequency,
  salary,
  calculationStartSalary = salary,
  salaryContributionRate,
  isIncludingSuperannuation,
  relationshipStatus,
  config,
}: CalculateBaseProps): CalculateReturn {
  const MAX_GOVERNMENT_CONTRIBUTION = config.maxGovernmentContribution
  const EMPLOYER_CONTRIBUTION_RATE = config.employerContributionRate
  const ASSUMED_SALARY_INFLATION = config.assumedSalaryInflation
  const WEEKLY_SUPERANNUATION_SINGLE = config.weeklySuperannuationSingle
  const WEEKLY_SUPERANNUATION_COUPLE = config.weeklySuperannuationCouple
  const LIFE_EXPECTANCY = config.lifeExpectancy
  const VOLUNTARY_CONTRIBUTION_FREQUENCY_RATES = config.voluntaryContributionFrequencyRates

  // While post retirement investment rate and inflation rate won't change during execution, they may change due to law.
  // Our calculation need handle the possibility that h === inflationRate
  // But when we do `if(h === inflationRate)` and they are both declared
  // as const, typescript will complain. So declaring them as `let` instead.
  let POST_RETIREMENT_INVESTMENT_RATE = config.postRetirementInvestmentRate
  let INFLATION_RATE = config.inflationRate

  //The ESCT rate is calculated based on the current salary:
  //https://www.ird.govt.nz/employing-staff/deductions-from-income/employer-superannuation-contribution-tax/find-the-esct-rate-for-each-employee
  const employerSuperannuationContributionRate = config.esctRates.reduce(
    (acc, item) =>
      salary >= item.start && (item.end === null || salary <= item.end)
        ? item.rate
        : acc,
    config.esctRates[0].rate
  )

  const underAgeDuration = Math.max(18 - calculationStartAge, 0)
  const ofAgeDuration = calculationEndAge - Math.max(calculationStartAge, 18)
  const getSalaryInflation = (years: number) =>
    Math.pow(1 + ASSUMED_SALARY_INFLATION, years)

  const memberContribution = salaryContributionRate * calculationStartSalary

  //A person does not receive employer contribution or government contribution
  //until they are of age, aka, 18 years old. And due to inflation, the salary of a person
  //when they turn 18 will be different to their initial salary.
  //Initial employer contribution and government contribution is calculated based on the
  //person's salary at 18 years old.
  const memberContributionAtEighteen =
    memberContribution * getSalaryInflation(underAgeDuration)
  const salaryAtEighteen =
    calculationStartSalary * getSalaryInflation(underAgeDuration)
  const employerContribution =
    EMPLOYER_CONTRIBUTION_RATE *
    salaryAtEighteen *
    (1 - employerSuperannuationContributionRate)
  const voluntaryContribution =
    voluntaryContributionRate *
    VOLUNTARY_CONTRIBUTION_FREQUENCY_RATES[voluntaryContributionFrequency]
  const totalContribution =
    memberContributionAtEighteen + employerContribution + voluntaryContribution
  const governmentContribution = Math.min(
    (memberContributionAtEighteen + voluntaryContribution) / 2,
    MAX_GOVERNMENT_CONTRIBUTION
  )

  let temp = 0
  if (investmentRate === ASSUMED_SALARY_INFLATION) {
    //This is the projected amount of money a person will have when they turn 18.
    const preOffAgeBalance =
      memberContribution *
        underAgeDuration *
        Math.pow(1 + investmentRate, underAgeDuration - 1) +
      initialBalance * Math.pow(1 + investmentRate, underAgeDuration)

    temp =
      totalContribution *
        ofAgeDuration *
        Math.pow(1 + investmentRate, ofAgeDuration - 1) +
      governmentContribution *
        ((Math.pow(1 + investmentRate, ofAgeDuration) - 1) / investmentRate) +
      preOffAgeBalance * Math.pow(1 + investmentRate, ofAgeDuration)
  } else {
    const contributionOverTime = (years: number) =>
      (Math.pow(1 + investmentRate, years) -
        Math.pow(1 + ASSUMED_SALARY_INFLATION, years)) /
      (investmentRate - ASSUMED_SALARY_INFLATION)

    //This is the projected amount of money a person will have when they turn 18.
    const preOffAgeBalance =
      memberContribution * contributionOverTime(underAgeDuration) +
      initialBalance * Math.pow(1 + investmentRate, underAgeDuration)

    temp =
      totalContribution * contributionOverTime(ofAgeDuration) +
      governmentContribution *
        ((Math.pow(1 + investmentRate, ofAgeDuration) - 1) / investmentRate) +
      preOffAgeBalance * Math.pow(1 + investmentRate, ofAgeDuration)
  }

  const nominalAmount = temp
  const inflationElapsedTime = calculationEndAge - currentAge
  //User must leave $1000 in their amount before withdrawal.
  //So subtract 1000 from the nominal amount to get the withdrawable Amount
  //If a person have less than $1000 in their account then they can't withdrawal anything.
  //We are suppose to show the user inflation adjusted amount.
  //So adjust for inflation after subtracting the $1000
  const withdrawableAmount = adjustForInflation(
    Math.max(nominalAmount - 1000, 0),
    inflationElapsedTime,
    INFLATION_RATE
  )

  //We are suppose to show the user inflation adjusted amount.
  //So adjust for inflation after subtracting the $1000
  const finalAmount = adjustForInflation(nominalAmount, inflationElapsedTime, INFLATION_RATE)

  let tempWeeklyPayment = 0
  const yearsInRetirement = LIFE_EXPECTANCY - calculationEndAge

  if (POST_RETIREMENT_INVESTMENT_RATE !== INFLATION_RATE) {
    tempWeeklyPayment =
      finalAmount *
      (1 / VOLUNTARY_CONTRIBUTION_FREQUENCY_RATES.weekly) *
      (((POST_RETIREMENT_INVESTMENT_RATE - INFLATION_RATE) *
        Math.pow(
          1 + POST_RETIREMENT_INVESTMENT_RATE,
          yearsInRetirement - 0.5
        )) /
        (Math.pow(1 + INFLATION_RATE, 0.5) *
          (Math.pow(1 + POST_RETIREMENT_INVESTMENT_RATE, yearsInRetirement) -
            Math.pow(1 + INFLATION_RATE, yearsInRetirement))))
  }

  if (POST_RETIREMENT_INVESTMENT_RATE === INFLATION_RATE) {
    tempWeeklyPayment =
      (finalAmount / yearsInRetirement) *
      (1 / VOLUNTARY_CONTRIBUTION_FREQUENCY_RATES.weekly)
  }

  const superannuationWeeklyAddition =
    relationshipStatus === 'single'
      ? WEEKLY_SUPERANNUATION_SINGLE
      : WEEKLY_SUPERANNUATION_COUPLE

  const weeklyPayment = isIncludingSuperannuation
    ? tempWeeklyPayment + superannuationWeeklyAddition
    : tempWeeklyPayment
  const fortnightlyPayment = weeklyPayment * 2
  const annualPayment =
  VOLUNTARY_CONTRIBUTION_FREQUENCY_RATES.weekly * weeklyPayment
  const monthlyPayment = annualPayment / 12

  return {
    nominalAmount: nominalAmount,
    finalAmount: Math.round(finalAmount),
    withdrawableAmount: Math.round(withdrawableAmount),
    payments: {
      weekly: Math.round(weeklyPayment),
      fortnightly: Math.round(fortnightlyPayment),
      monthly: Math.round(monthlyPayment),
      annually: Math.round(annualPayment),
    },
  }
}

export function projectionsCalculation({
  firstHomeWithdrawalAge = Number.MAX_VALUE,
  ...props
}: CalculateProps): CalculateReturn {
  const { calculationEndAge, currentAge } = props

  // If the first home withdrawal is NOT between current age and retirement age
  // then effectively, the withdrawal didn't happen so we can ignore it.
  if (
    !checkIsWithdrawing(
      currentAge,
      calculationEndAge,
      firstHomeWithdrawalAge,
      false
    )
  ) {
    return calculateBase(props)
  }

  // If the withdrawal did happen, final projection for retirement age.
  // is basically a calculation that starts from the withdrawal age,
  // with whatever was left behind after the withdrawal as the 'initial balance',

  // The user must leave at least $1000 in kiwisaver at all times.
  // To see how much they left behind, we first check to see what they had
  // at the time of the withdrawal.
  //
  // If they had more than $1000 then they will withdraw until there's only $1000
  // If they don't $1000 already then whatever they had at the time is the initial balance.
  // For the new calculation
  const nominalSavingAtWithdrawalAge = calculateBase({
    ...props,
    calculationEndAge: firstHomeWithdrawalAge,
  }).nominalAmount

  const newInitialBalance = Math.min(nominalSavingAtWithdrawalAge, 1000)
  const newSalaryStart =
    props.salary * Math.pow(1.035, firstHomeWithdrawalAge - currentAge)

  return {
    ...calculateBase({
      ...props,
      calculationStartAge: firstHomeWithdrawalAge,
      calculationStartSalary: newSalaryStart,
      initialBalance: newInitialBalance,
    }),
  }
}

export function adjustForInflation(amount: number, elapsedTime: number, inflationRate: number) {
  return amount * (1 / Math.pow(1 + inflationRate, elapsedTime))
}
