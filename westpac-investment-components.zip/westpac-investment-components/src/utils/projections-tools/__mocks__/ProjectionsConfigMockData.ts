import { IKiwisaverProjectionsConfig } from '../projectionsToolUtils'

const config: IKiwisaverProjectionsConfig = {
  links: {
    kiwiSaverWealthOfficePhone: {
      url: 'tel:0800942822',
      label: '0800 942 822',
    },
    kiwiSaverSpecialistsPhone: {
      url: 'tel:0508972254',
      label: '0508 972 254',
    },
    westpacOneLogin: 'https://bank.westpac.co.nz/wone/app.html#login',
    kiwisaverMoreInfo: 'https://www.westpac.co.nz/help/kiwisaver-faqs',
    kiwisaverNextStep:
      'https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/#next-steps',
    firstHomeEligibility:
      'https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/using-kiwisaver-for-your-first-home/#first-home-basics',
    productChooserLandingPage:
      'https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/kiwisaver-calculators/new-kiwisaver-fund-chooser/',
    manageContribution:
      'https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/contributions/#manage-contributions',
  },
  dialog: {
    choiceDialog: {
      changeFundDialog: {
        title: 'Changing funds.',
        leftButtonTitle: 'I know what fund I want',
        rightButtonTitle: 'I need help choosing',
        leftButtonLabel: 'Change fund',
        rightButtonLabel: 'Go to Fund Chooser',
        body: [
          'Your choice of fund will depend on your investment timeframe and how you feel about risk. ',
          'If you need help choosing a fund for your savings, use the Fund Chooser.',
        ],
      },
      changeFundLoginDialog: {
        title: 'Changing your KiwiSaver fund.',
        leftButtonTitle: 'Already a Westpac KiwiSaver Scheme customer?',
        rightButtonTitle: 'Join the Westpac KiwiSaver Scheme?',
        leftButtonLabel: 'Login to Westpac One',
        rightButtonLabel: 'Find out more',
      },
      makeContributionDialog: {
        title: 'Making contributions.',
        leftButtonTitle: 'Already a Westpac KiwiSaver Scheme customer?',
        rightButtonTitle: 'Join the Westpac KiwiSaver Scheme?',
        leftButtonLabel: 'Login to Westpac One',
        rightButtonLabel: 'Find out more',
        body: [
          'Making regular additional contributions to a KiwiSaver scheme can help you reach your goals for retirement.',
        ],
      },
    },
    infoDialog: {
      assumptionDialog: {
        title: 'Calculations and assumptions.',
        body: [
          '<p>The projections are estimates only. They are calculated based on your responses about your current balance, employment status, income, contribution rate, and fund choice.</p>',
          '<p>This calculator uses a number of assumptions, including some about future events such as what investment returns and inflation are likely to be. The assumptions are aligned with those set by the government and are important because they affect the result of the calculation.</p>',
          '<span>The assumed (net of fees and tax) investment return for each fund type is:</span>',
          '<ul>',
          '<li>Defensive / Cash 1.5%</li>',
          '<li>Conservative / Default 2.5%</li>',
          '<li>Moderate / Balanced 3.5%</li>',
          '<li>Growth 4.5%</li>',
          '</ul>',
          '<span>The calculator assumes:</span>',
          '<ul>',
          '<li>Income increases at 3.5% each year.</li>',
          '<li>Inflation of 2% each year.</li>',
          '<li>‘Employed’ users receive employer contributions of 3% of before-tax income.</li>',
          '<li>Users who make a first home withdrawal take (and are able to take) their full balance, less $1,000.</li>',
          '<li>After the age of 65 users invest conservatively and don’t make any further contributions.</li>',
          '</ul>',
          '<p>The projections assume continuous eligibility for and availability of government contributions (calculated at 50 cents for every $1 each member contributes, up to a maximum government contributions of $521.43 per year). ',
          "Eligibility conditions apply and Government policy may change in the future. Details are available <a href='https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/contributions/#how-savings-grow' target='_blank' rel='noopener noreferrer'>here</a>.</p>",
          '<p>The projections relate only to KiwiSaver and do not take into account any other retirement savings or income, other than NZ Superannuation if you request this. NZ Superannuation is also subject to change.</p>',
          '<p>The projections assume no savings suspensions are taken, and that no other withdrawals are made.</p>',
          '<p>The projections are estimates only and are shown on an after-tax basis. Tax legislation, its interpretation and the levels and basis of taxation may change.</p>',
          '<p>Where users respond to the salary contribution rate question as “not sure” the projection assumes a rate of 3%.</p>',
          '<p>Where users respond to the “What type of fund are you currently in?” question as “I’m not sure which fund” or “it’s a mix of funds” the projection assumes balanced fund pre-retirement investment returns.</p>',
          '<p>The retirement savings lump sum amount is rounded to the nearest $1,000.</p>',
          '<p>The first home withdrawal amount is rounded to the nearest $1,000.</p>',
          '<p>The retirement savings income amount is rounded to the nearest $10.</p>',
          '<p>Where the calculator requires users to enter data, if information is entered incorrectly the output produced may not be appropriate.</p>',
          '<p>The projection results generated by the calculator are provided for information purposes only and are not a recommendation or opinion in relation to a specific financial product.</p>',
        ],
        closeLinkText: 'Go back to results',
      },
      inflationDialog: {
        title: 'How the calculator deals with inflation.',
        body: [
          '<p>All amounts are stated in real terms as a current dollar amount, using an assumed inflation rate of 2%p.a., including:</p>',
          '<ul>',
          '<li>the retirement lump sum,</li>',
          '<li>the retirement income, and</li>',
          '<li>the first home withdrawal amount.</li>',
          '</ul>',
          '<p>For example, if the calculator is showing your projected retirement income as $100 per week, then you are expected to be able to withdraw enough money from your KiwiSaver savings each week from age 65 to 90 to buy what $100 buys today.</p>',
        ],
        closeLinkText: 'Go back to results',
      },
    },
  },
  disclaimer: [
    '<p>The calculator helps you understand how your choices now affect how much you will have, either to help you purchase your first home, or when you turn 65.</p>',
    '<p>The calculator shows you how you are tracking now, and what happens if you change settings like your fund or contribution amount. Over time your choices can make a big difference.</p>',
    '<p>You make your choices today and we’ll put them to work for your tomorrow.</p>',
  ],
  disclosures: [
    '<p>The calculator contains information of a general nature intended to help you determine what your KiwiSaver balance might be at retirement. It is not intended as, and should not be taken as, a financial advice service, or a recommendation or opinion in relation to any particular financial product or action.</p>',
    '<p>The calculator uses assumptions about future events, such as what investment returns may be. The calculator does not reflect actual returns or predict future returns (which are subject to investment and other risks, including possible loss of income and principal invested). Returns are not guaranteed, and will vary over different periods depending on investment performance. When returns change, your KiwiSaver balance will go up and down.</p>',
    '<p>The amounts (first home withdrawal, retirement lump sum, and retirement income) projected by this calculator should be treated as a guide only. The projected KiwiSaver first home withdrawal amount in particular is an estimate only. Any withdrawal will be subject to eligibility criteria - find out more <a href="https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/using-kiwisaver-for-your-first-home/#first-home-basics" target="_blank" rel="noopener noreferrer">here</a>.</p>',
    '<p>For more information about how the projections are calculated, see <a id="kiwisaver-projection-calculations-and-assumptions-disclaimer-link">Calculations and Assumptions</a>.</p>',
    '<p>Where the calculator requires users to enter data, the information is used only to produce and display projection results for the user. The user’s personal information is not otherwise collected, stored, used or shared.</p>',
    'BT Funds Management (NZ) Limited is the scheme provider and Westpac New Zealand Limited is the distributor, of the Westpac KiwiSaver Scheme (Scheme). Investments made in the Scheme do not represent bank deposits or other liabilities of Westpac Banking Corporation ABN 33 007 457 141, Westpac New Zealand Limited or other members of the Westpac group of companies. ',
    'They are subject to investment and other risks, including possible delays in payment of withdrawal amounts in some circumstances, and loss of investment value, including principal invested. None of BT Funds Management (NZ) Limited (as manager), any member of the Westpac group of companies, The New Zealand Guardian Trust Company Limited (as supervisor), ',
    'or any director or nominee of any of those entities, or any other person guarantees the Scheme’s performance, returns or repayment of capital.</p>',
    '<p>The information above is subject to changes to government policy and law, and changes to the Scheme from time to time.</p>',
    "<p>For a copy of the Product Disclosure Statement or more information about the Scheme, contact any Westpac branch or call <a href=\"tel:0508972254\">0508 972 254</a> or from overseas <a href=\"tel:+6493759978\">+64 9 375 9978</a> (international toll charges apply). You can also download the <a href='https://www.westpac.co.nz/assets/Personal/kiwisaver/documents/Product-disclosure-statements/Westpac-KiwiSaver-Scheme-Product-Disclosure-Statement-2020.pdf' target='_blank' rel='noopener noreferrer'>Product Disclosure Statement</a>.</p>",
  ],
  projectedAmountDisclaimer: [
    "*The projected KiwiSaver first home withdrawal amount is a guide only. The actual amount you can withdraw will depend on several factors including investment market movements. <a href='https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/using-kiwisaver-for-your-first-home/#first-home-basics' target='_blank' rel='noopener noreferrer'>Eligibility criteria</a> apply.",
  ],
  controlPanelDescription: [
    'Retiring later than 65 can make a big impact. You can check out other scenarios by changing the inputs below.',
  ],
  fundSelectionTooAggressiveDisclaimer: [
    "As you’re wanting to withdraw funds soon use our <a target='_blank' rel='noopener noreferrer' href='https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/kiwisaver-calculators/new-kiwi-saver-fund-chooser/'>Fund Chooser</a> to find the right fund for you.",
  ],
  summaryInflationDisclaimer: [
    'All amounts are stated in real terms as a current dollar amount, using an assumed inflation rate of 2% p.a. ',
    "For an explanation see <a id='kiwisaver-projection-calculator-inflation-disclaimer-link'>How the Calculator Deals with Inflation</a>.",
  ],
  makeChangeSectionContent: {
    title: 'How to make changes.',
    description: [
      "To change your contribution percentage you need to contact your employer <a target='_blank' rel='noopener noreferrer' href='https://www.westpac.co.nz/kiwisaver-investments/kiwisaver/contributions/#manage-contributions'>find out more here</a>.",
    ],
    leftButtonText: 'Making contributions',
    rightButtonText: 'Changing funds',
  },
  moreQuestionSectionContent: {
    title: 'Have more questions?',
    faqSubSection: {
      title: 'FAQs',
      description: [
        'Need more info? Have a read through our FAQs about KiwiSaver.',
      ],
      arrowLinkText: 'Read our FAQs',
    },
    contactUsSubSection: {
      title: 'Contact Us',
      description: [
        'Call one of our Westpac KiwiSaver Scheme Specialists on our free 0508 number.',
      ],
    },
  },
  investmentRates: {
    cash: 0.015,
    conservative: 0.025,
    moderate: 0.035,
    balanced: 0.035,
    growth: 0.045,
  },
  voluntaryContributionFrequencyRates: {
    weekly: 52.1785714286,
    fortnightly: 26.0892857143,
    monthly: 12,
    annually: 1,
  },
  esctRates: [
    { start: 0, end: 16800, rate: 0.105 },
    { start: 16801, end: 57600, rate: 0.175 },
    { start: 57601, end: 84000, rate: 0.3 },
    { start: 84001, end: null, rate: 0.33 },
  ],
  lifeExpectancy: 90,
  defaultRetirementAge: 65,
  maxGovernmentContribution: 521.43,
  employerContributionRate: 0.03,
  assumedSalaryInflation: 0.035,
  weeklySuperannuationSingle: 391.22,
  weeklySuperannuationCouple: 326.02,
  postRetirementInvestmentRate: 0.025,
  inflationRate: 0.02,
}

export default config
