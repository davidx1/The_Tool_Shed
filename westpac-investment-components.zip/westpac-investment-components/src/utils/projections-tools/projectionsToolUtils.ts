import {
  IQuestion,
  IValues,
  IStep,
} from '../../components/navigation/IQuestionnaire'
import { getNextStep } from '../questionnaireUtils'
import { ILink } from '../../components/navigation/ILink'

/* -----------------------------------------------
                    Constants
 ----------------------------------------------- */

export const PROJECTION_MOBILE_TABLET_BREAKPOINT = 768

export const KIWISAVER_CONTRIBUTION_RATES = [
  0.03,
  0.04,
  0.06,
  0.08,
  0.1,
] as const

export const CONTRIBUTION_FREQUENCY_SUFFIX = {
  weekly: 'p.w',
  fortnightly: 'p.f',
  monthly: 'p.m',
  annually: 'p.a',
}

/* -----------------------------------------------
                Types and Interfaces
   ----------------------------------------------- */

export interface IEsctRate {
  start: number
  end: number | null
  rate: number
}

export interface IKiwisaverChoiceDialogContent {
  title: string
  leftButtonTitle: string
  rightButtonTitle: string
  leftButtonLabel: string
  rightButtonLabel: string
  body?: string[]
}

export interface IKiwisaverInfoDialogContent {
  title: string
  body?: string[]
  closeLinkText?: string
}

export type IChoiceDialog =
  | 'changeFundDialog'
  | 'changeFundLoginDialog'
  | 'makeContributionDialog'

export type IInfoDialog = 'assumptionDialog' | 'inflationDialog'

export interface IKiwisaverProjectionsDialogContent {
  choiceDialog: {
    [parameter in IChoiceDialog]: IKiwisaverChoiceDialogContent
  }
  infoDialog: {
    [parameter in IInfoDialog]: IKiwisaverInfoDialogContent
  }
}

export interface IKiwisaverProjectionLinksContent {
  kiwiSaverWealthOfficePhone: ILink
  kiwiSaverSpecialistsPhone: ILink
  westpacOneLogin: string
  kiwisaverMoreInfo: string
  kiwisaverNextStep: string
  firstHomeEligibility: string
  productChooserLandingPage: string
  manageContribution: string
}
export interface IKiwisaverProjectionsConfig {
  links: IKiwisaverProjectionLinksContent
  dialog: IKiwisaverProjectionsDialogContent
  disclaimer: string[]
  disclosures: string[]
  projectedAmountDisclaimer: string[]
  controlPanelDescription: string[]
  fundSelectionTooAggressiveDisclaimer: string[]
  summaryInflationDisclaimer: string[]
  makeChangeSectionContent: {
    title: string
    description: string[]
    leftButtonText: string
    rightButtonText: string
  }
  moreQuestionSectionContent: {
    title: string
    faqSubSection: {
      title: string
      description: string[]
      arrowLinkText: string
    }
    contactUsSubSection: {
      title: string
      description: string[]
    }
  }
  investmentRates: {
    cash: number
    conservative: number
    moderate: number
    balanced: number
    growth: number
  }
  voluntaryContributionFrequencyRates: {
    [key in IKiwisaverContributionFrequencyType]: number
  }
  esctRates: IEsctRate[]
  lifeExpectancy: number
  defaultRetirementAge: number
  maxGovernmentContribution: number
  employerContributionRate: number
  assumedSalaryInflation: number
  weeklySuperannuationSingle: number
  weeklySuperannuationCouple: number
  postRetirementInvestmentRate: number
  inflationRate: number
}

export type IProjectionsFundType =
  | 'cash'
  | 'conservative'
  | 'moderate'
  | 'balanced'
  | 'growth'

export type IKiwisaverSalaryContributionRateType = typeof KIWISAVER_CONTRIBUTION_RATES[number]

export type IRelationshipStatusType = 'single' | 'couple'

export type IKiwisaverContributionFrequencyType =
  | 'weekly'
  | 'fortnightly'
  | 'monthly'
  | 'annually'

export interface IProjectionsToolRecommendationStep extends IStep {
  userAnswers: {
    salaryContributionRate: IKiwisaverSalaryContributionRateType
    voluntaryContributionFrequency: IKiwisaverContributionFrequencyType
    voluntaryContributionRate: number
    firstHomeWithdrawalAge: number
    currentAge: number
    salary: number
    initialBalance: number
    fundType: IProjectionsFundType
  }
}

function createKiwiSaverProjectionsFlow(config: IKiwisaverProjectionsConfig) {
  /* -----------------------------------------------
                    Questions
 ----------------------------------------------- */

  const QUESTION_AGE: IQuestion = {
    id: 'QUESTION_AGE',
    type: 'text',
    title: 'First of all, what’s your current age?',
    label: 'Enter here',
    inputOptions: {
      type: 'number',
      min: 0,
    },
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        'Your current age lets us work out how many years you have to invest before you turn 65.',
      ],
      icon: 'timeline',
    },
  }

  /* ----------------------------------------------- */

  const CONFIRMATION_UNDER_AGE_I_UNDERSTAND = 'Ok, I understand'

  const QUESTION_CONFIRMATION_UNDER_AGE: IQuestion = {
    id: 'QUESTION_CONFIRMATION_UNDER_AGE',
    type: 'confirmationModal',
    title: 'We’re here to help.',
    confirmationModalOptions: {
      body: [
        `As you haven’t turned 18 yet, you should complete
        this tool with a parent or guardian. If you want to
        make any changes afterwards your parent or guardian
        will need to call us on <a href="${config.links.kiwiSaverSpecialistsPhone.url}">${config.links.kiwiSaverSpecialistsPhone.label}</a>.`,
      ],
      actionButtons: [
        {
          value: CONFIRMATION_UNDER_AGE_I_UNDERSTAND,
        },
      ],
    },
  }

  /* ----------------------------------------------- */

  const CONFIRMATION_OLDER_THAN_64_CLOSE = 'Close'

  const QUESTION_CONFIRMATION_OLDER_THAN_64: IQuestion = {
    id: 'QUESTION_CONFIRMATION_OLDER_THAN_64',
    type: 'confirmationModal',
    title: 'We’re here to help.',
    confirmationModalOptions: {
      body: [
        `As you’re nearing or at an age where you can withdraw your funds for retirement, we recommend talking to one of our financial advisers. They can talk to you about your plans and help you manage your KiwiSaver savings in the way that’s best for you.`,
        `Would you like to talk with one of our financial advisers? It’s easy just call us on
        <a href="${config.links.kiwiSaverWealthOfficePhone.url}">${config.links.kiwiSaverWealthOfficePhone.label}</a>.`,
        `Disclosure statements under the Financial Advisers Act 2008 are available free of charge on
        request from Westpac or your Westpac financial adviser.`,
      ],
      actionButtons: [
        {
          value: CONFIRMATION_OLDER_THAN_64_CLOSE,
        },
      ],
    },
  }

  /* ----------------------------------------------- */

  const GOAL_FIRST_HOME = 'First Home'
  const GOAL_RETIREMENT = 'Retirement'

  const QUESTION_KIWISAVER_GOAL: IQuestion = {
    id: 'QUESTION_KIWISAVER_GOAL',
    type: 'radioGroup',
    title: 'What will you be using your KiwiSaver savings for first?',
    options: [GOAL_FIRST_HOME, GOAL_RETIREMENT],
    icons: ['houseOnly', 'palmTree'],
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        'Remember to check the eligibility criteria if you want to use your KiwiSaver savings to buy your first home.',
      ],
      icon: 'kiwiSaver',
    },
  }

  /* ----------------------------------------------- */

  const EMPLOYMENT_STATUS_EMPLOYED = 'Employed'
  const EMPLOYMENT_STATUS_SELF_EMPLOYED = 'Self Employed'
  const EMPLOYMENT_STATUS_NOT_EMPLOYED = 'Not Employed'

  const QUESTION_EMPLOYMENT_STATUS: IQuestion = {
    id: 'QUESTION_EMPLOYMENT_STATUS',
    type: 'dropdown',
    title: 'What’s your employment status?',
    label: 'Choose option',
    options: [
      EMPLOYMENT_STATUS_EMPLOYED,
      EMPLOYMENT_STATUS_SELF_EMPLOYED,
      EMPLOYMENT_STATUS_NOT_EMPLOYED,
    ],
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `While you’re employed your employer contributions will usually be calculated at a rate of 3% of your before-tax salary or wages. `,
      ],
      icon: 'briefCase',
    },
  }

  /* ----------------------------------------------- */

  const BUY_HOME_IN_LESS_THAN_ONE_YEAR = 'Less than 1 year'
  const BUY_HOME_IN_ONE_YEAR = 'In 1 year'
  const BUY_HOME_IN_TWO_YEAR = 'In 2 years'
  const BUY_HOME_IN_THREE_YEAR = 'In 3 years'
  const BUY_HOME_IN_FOUR_YEAR = 'In 4 years'
  const BUY_HOME_IN_FIVE_YEAR = 'In 5 years or more'

  const getWhenToBuyHomeQuestion = (ageString: string): IQuestion => {
    const age = Number(ageString)

    // Making sure a user could only select a 'first home withdrawal age' that's less
    // than the default retirement age
    const options = [
      BUY_HOME_IN_LESS_THAN_ONE_YEAR,
      BUY_HOME_IN_ONE_YEAR,
      BUY_HOME_IN_TWO_YEAR,
      BUY_HOME_IN_THREE_YEAR,
      BUY_HOME_IN_FOUR_YEAR,
      BUY_HOME_IN_FIVE_YEAR,
    ].slice(0, config.defaultRetirementAge - age)
    return {
      id: 'QUESTION_WHEN_TO_BUY_HOME',
      type: 'dropdown',
      title: 'How many years until you expect to purchase your first home?',
      label: 'Choose option',
      options,
      information: {
        callUs: config.links.kiwiSaverSpecialistsPhone,
        body: [
          `This will help us estimate the total balance at time of withdrawal for your first home.`,
        ],
        icon: 'houseOnly',
      },
    }
  }

  const QUESTION_WHEN_TO_BUY_HOME: IQuestion = {
    id: 'QUESTION_WHEN_TO_BUY_HOME',
    type: 'dropdown',
    title: 'How many years until you expect to purchase your first home?',
    label: 'Choose option',
    options: [
      BUY_HOME_IN_LESS_THAN_ONE_YEAR,
      BUY_HOME_IN_ONE_YEAR,
      BUY_HOME_IN_TWO_YEAR,
      BUY_HOME_IN_THREE_YEAR,
      BUY_HOME_IN_FOUR_YEAR,
      BUY_HOME_IN_FIVE_YEAR,
    ],
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `This will help us estimate the total balance at time of withdrawal for your first home.`,
      ],
      icon: 'kiwiSaver',
    },
  }

  /* ----------------------------------------------- */

  const INCOME_FREQUENCY_WEEKLY = 'per week'
  const INCOME_FREQUENCY_FORTNIGHTLY = 'per fortnight'
  const INCOME_FREQUENCY_MONTHLY = 'per month'
  const INCOME_FREQUENCY_ANNUALLY = 'per year'

  const QUESTION_INCOME: IQuestion = {
    id: 'QUESTION_INCOME',
    type: 'dropdownText',
    title: 'What’s your income',
    dropdown: {
      label: 'Choose option',
      options: [
        INCOME_FREQUENCY_WEEKLY,
        INCOME_FREQUENCY_FORTNIGHTLY,
        INCOME_FREQUENCY_MONTHLY,
        INCOME_FREQUENCY_ANNUALLY,
      ],
    },
    text: {
      label: 'Enter income',
      suffix: '(before tax)',
      inputOptions: {
        type: 'currency',
      },
    },
    default: `${INCOME_FREQUENCY_ANNUALLY}::`,
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `We need an idea of your income to estimate your projection. If unsure you can ask your employer(s).`,
      ],
      icon: 'moneyCoin',
    },
  }

  /* ----------------------------------------------- */

  const QUESTION_KIWISAVER_BALANCE: IQuestion = {
    id: 'QUESTION_KIWISAVER_BALANCE',
    type: 'text',
    title: 'What’s your current KiwiSaver balance?',
    label: 'Enter balance',
    inputOptions: {
      type: 'currency',
    },
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `If you're unsure you can contact your provider or check your latest annual member statement.`,
      ],
      icon: 'kiwiSaver',
    },
  }

  /* ----------------------------------------------- */

  const CONTRIBUTION_PERCENTAGE_UNSURE = 'Not sure'
  const CONTRIBUTION_PERCENTAGE_3 = '3%'
  const CONTRIBUTION_PERCENTAGE_4 = '4%'
  const CONTRIBUTION_PERCENTAGE_6 = '6%'
  const CONTRIBUTION_PERCENTAGE_8 = '8%'
  const CONTRIBUTION_PERCENTAGE_10 = '10%'

  const QUESTION_CONTRIBUTION_PERCENTAGE: IQuestion = {
    id: 'QUESTION_CONTRIBUTION_PERCENTAGE',
    type: 'dropdown',
    title: 'What is your contribution rate?',
    label: 'Choose option',
    options: [
      CONTRIBUTION_PERCENTAGE_UNSURE,
      CONTRIBUTION_PERCENTAGE_3,
      CONTRIBUTION_PERCENTAGE_4,
      CONTRIBUTION_PERCENTAGE_6,
      CONTRIBUTION_PERCENTAGE_8,
      CONTRIBUTION_PERCENTAGE_10,
    ],
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `You can choose to contribute a regular amount equal to 3%, 4%, 6%, 8% or 10% of your before-tax salary or wage. The default rate is 3%, so we'll use this rate if you’re not sure.`,
      ],
      icon: 'money',
    },
  }

  /* ----------------------------------------------- */

  const VOLUNTARY_CONTRIBUTION_NONE = 'Not currently'
  const VOLUNTARY_CONTRIBUTION_WEEKLY = 'Weekly'
  const VOLUNTARY_CONTRIBUTION_FORTNIGHTLY = 'Fortnightly'
  const VOLUNTARY_CONTRIBUTION_MONTHLY = 'Monthly'
  const VOLUNTARY_CONTRIBUTION_ANNUALLY = 'Annually'

  const QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY: IQuestion = {
    id: 'QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY',
    type: 'dropdown',
    title: 'Do you make any contributions?',
    label: 'Choose option',
    options: [
      VOLUNTARY_CONTRIBUTION_NONE,
      VOLUNTARY_CONTRIBUTION_WEEKLY,
      VOLUNTARY_CONTRIBUTION_FORTNIGHTLY,
      VOLUNTARY_CONTRIBUTION_MONTHLY,
      VOLUNTARY_CONTRIBUTION_ANNUALLY,
    ],
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `If you’re eligible, the government’s current policy is to contribute 50 cents for every $1 you contribute, up to a maximum government contribution of $521.43 per year.`,
      ],
      icon: 'money',
    },
  }

  /* ----------------------------------------------- */

  const getVoluntaryContributionsAmountQuestion: (
    frequency: string
  ) => IQuestion = (frequency) => ({
    id: 'QUESTION_VOLUNTARY_CONTRIBUTION_AMOUNT',
    type: 'text',
    title: `How much are your ${frequency.toLocaleLowerCase()} contributions?`,
    label: 'Enter amount',
    inputOptions: {
      type: 'currency',
    },
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `These are any direct debits or other top ups you make towards your KiwiSaver savings.`,
      ],
      icon: 'kiwiSaver',
    },
  })

  /* ----------------------------------------------- */

  const CURRENT_FUND_UNSURE = 'I’m not sure which fund'
  const CURRENT_FUND_MIXED = 'It’s a mix of funds'
  const CURRENT_FUND_CASH = 'Defensive / Cash'
  const CURRENT_FUND_CONSERVATIVE = 'Conservative / Default'
  const CURRENT_FUND_MODERATE = 'Moderate'
  const CURRENT_FUND_BALANCED = 'Balanced'
  const CURRENT_FUND_GROWTH = 'Growth'

  const QUESTION_CURRENT_FUND: IQuestion = {
    id: 'QUESTION_CURRENT_FUND',
    type: 'dropdown',
    title: 'What type of fund are you currently in?',
    label: 'Choose fund',
    options: [
      CURRENT_FUND_UNSURE,
      CURRENT_FUND_MIXED,
      CURRENT_FUND_CASH,
      CURRENT_FUND_CONSERVATIVE,
      CURRENT_FUND_MODERATE,
      CURRENT_FUND_BALANCED,
      CURRENT_FUND_GROWTH,
    ],
    information: {
      callUs: config.links.kiwiSaverSpecialistsPhone,
      body: [
        `Knowing the type of fund you’re invested in is important and will affect what you are on track to receive at age 65. We use this to work out the assumed rate of return for your savings. If you say you’re not sure or are in a mix of funds, we’ll use the balanced fund assumed returns.`,
      ],
      icon: 'handGrowth',
    },
  }

  /* -----------------------------------------------
                      Steps
   ----------------------------------------------- */

  const PROJECTIONS_INITIAL_STEP: IStep = {
    type: 'question',
    question: QUESTION_AGE,
    estimatedProgress: 0,
    getNextStep: (values) => {
      if (values[QUESTION_AGE.id] < 18) {
        return CONFIRM_UNDER_AGE_STEP
      } else if (values[QUESTION_AGE.id] >= 64) {
        return CONFIRM_OLDER_THAN_64_STEP
      }
      return KIWISAVER_GOAL_STEP
    },
  }

  const CONFIRM_UNDER_AGE_STEP: IStep = {
    type: 'question',
    question: QUESTION_CONFIRMATION_UNDER_AGE,
    estimatedProgress: 10,
    getNextStep: (values) => {
      if (
        values[QUESTION_CONFIRMATION_UNDER_AGE.id] ===
        CONFIRMATION_UNDER_AGE_I_UNDERSTAND
      ) {
        return KIWISAVER_GOAL_STEP
      }
      return null
    },
  }

  const CONFIRM_OLDER_THAN_64_STEP: IStep = {
    type: 'question',
    question: QUESTION_CONFIRMATION_OLDER_THAN_64,
    estimatedProgress: 10,
    getNextStep: () => {
      return null
    },
  }

  const KIWISAVER_GOAL_STEP: IStep = {
    type: 'question',
    question: QUESTION_KIWISAVER_GOAL,
    estimatedProgress: 10,
    getNextStep: (values) => {
      if (values[QUESTION_KIWISAVER_GOAL.id] === GOAL_FIRST_HOME) {
        return getWhenToBuyHomeStep(values)
      }
      return EMPLOYMENT_STATUS_STEP
    },
  }

  const getWhenToBuyHomeStep: (values: IValues) => IStep = (values) => ({
    type: 'question',
    question: getWhenToBuyHomeQuestion(values[QUESTION_AGE.id] as string),
    estimatedProgress: 20,
    getNextStep: () => EMPLOYMENT_STATUS_STEP,
  })

  const EMPLOYMENT_STATUS_STEP: IStep = {
    type: 'question',
    question: QUESTION_EMPLOYMENT_STATUS,
    estimatedProgress: 30,
    getNextStep: (values: IValues) =>
      values[QUESTION_EMPLOYMENT_STATUS.id] === EMPLOYMENT_STATUS_EMPLOYED
        ? INCOME_STEP
        : KIWISAVER_BALANCE_STEP,
  }

  const INCOME_STEP: IStep = {
    type: 'question',
    question: QUESTION_INCOME,
    estimatedProgress: 40,
    getNextStep: () => KIWISAVER_BALANCE_STEP,
  }

  const KIWISAVER_BALANCE_STEP: IStep = {
    type: 'question',
    question: QUESTION_KIWISAVER_BALANCE,
    estimatedProgress: 50,
    getNextStep: (values) => {
      if (
        values[QUESTION_EMPLOYMENT_STATUS.id] === EMPLOYMENT_STATUS_EMPLOYED
      ) {
        return CONTRIBUTION_PERCENTAGE_STEP
      }
      return VOLUNTARY_CONTRIBUTIONS_FREQUENCY_STEP
    },
  }

  const CONTRIBUTION_PERCENTAGE_STEP: IStep = {
    type: 'question',
    question: QUESTION_CONTRIBUTION_PERCENTAGE,
    estimatedProgress: 60,
    getNextStep: () => CURRENT_FUND_STEP,
  }

  const VOLUNTARY_CONTRIBUTIONS_FREQUENCY_STEP: IStep = {
    type: 'question',
    question: QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY,
    estimatedProgress: 70,
    getNextStep: (values) => {
      if (
        values[QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY.id] ===
        VOLUNTARY_CONTRIBUTION_NONE
      ) {
        return CURRENT_FUND_STEP
      }
      return getVoluntaryContributionsAmountStep(values)
    },
  }

  const getVoluntaryContributionsAmountStep: (values: IValues) => IStep = (
    values
  ) => ({
    type: 'question',
    question: getVoluntaryContributionsAmountQuestion(
      values[QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY.id] as string
    ),
    estimatedProgress: 80,
    getNextStep: () => CURRENT_FUND_STEP,
  })

  const CURRENT_FUND_STEP: IStep = {
    type: 'question',
    question: QUESTION_CURRENT_FUND,
    estimatedProgress: 90,
    getNextStep: (values) => getRecommendationStep(values), //Go to recommendation page
  }

  const BUY_HOME_IN_YEAR_MAP: {
    [k: string]: number
  } = {
    [BUY_HOME_IN_LESS_THAN_ONE_YEAR]: 1,
    [BUY_HOME_IN_ONE_YEAR]: 1,
    [BUY_HOME_IN_TWO_YEAR]: 2,
    [BUY_HOME_IN_THREE_YEAR]: 3,
    [BUY_HOME_IN_FOUR_YEAR]: 4,
    [BUY_HOME_IN_FIVE_YEAR]: 5,
  }

  const CURRENT_FUND_MAP: {
    [k: string]: IProjectionsFundType
  } = {
    [CURRENT_FUND_UNSURE]: 'balanced',
    [CURRENT_FUND_MIXED]: 'balanced',
    [CURRENT_FUND_CASH]: 'cash',
    [CURRENT_FUND_CONSERVATIVE]: 'conservative',
    [CURRENT_FUND_MODERATE]: 'moderate',
    [CURRENT_FUND_BALANCED]: 'balanced',
    [CURRENT_FUND_GROWTH]: 'growth',
  }

  const CONTRIBUTION_FREQUENCY_MAP: {
    [k: string]: IKiwisaverContributionFrequencyType
  } = {
    [VOLUNTARY_CONTRIBUTION_NONE]: 'weekly',
    [VOLUNTARY_CONTRIBUTION_WEEKLY]: 'weekly',
    [VOLUNTARY_CONTRIBUTION_FORTNIGHTLY]: 'fortnightly',
    [VOLUNTARY_CONTRIBUTION_MONTHLY]: 'monthly',
    [VOLUNTARY_CONTRIBUTION_ANNUALLY]: 'annually',
  }

  const CONTRIBUTION_PERCENTAGE_MAP: {
    [k: string]: IKiwisaverSalaryContributionRateType
  } = {
    [CONTRIBUTION_PERCENTAGE_UNSURE]: 0.03,
    [CONTRIBUTION_PERCENTAGE_3]: 0.03,
    [CONTRIBUTION_PERCENTAGE_4]: 0.04,
    [CONTRIBUTION_PERCENTAGE_6]: 0.06,
    [CONTRIBUTION_PERCENTAGE_8]: 0.08,
    [CONTRIBUTION_PERCENTAGE_10]: 0.1,
  }

  const getSalary = (salaryString: string) => {
    const [freq, amountString] = salaryString.split('::')
    const amount = Number(amountString)
    const daysInYear = 365.25
    const numOfPayment =
      freq === INCOME_FREQUENCY_WEEKLY
        ? daysInYear / 7
        : freq === INCOME_FREQUENCY_FORTNIGHTLY
        ? daysInYear / 14
        : freq === INCOME_FREQUENCY_MONTHLY
        ? 12
        : 1
    return amount * numOfPayment
  }

  const getRecommendationStep: (
    values: IValues
  ) => IProjectionsToolRecommendationStep = (values: IValues) => {
    // Depending on the question flow design, some questions may be skipped
    // In those cases, we need to initialize those unanswered questions
    // with some reasonable values
    const currentAge = values[QUESTION_AGE.id] || 0
    const buyHomeYears = values[QUESTION_WHEN_TO_BUY_HOME.id] || ''
    const initialBalance = values[QUESTION_KIWISAVER_BALANCE.id] || 0
    const salary = values[QUESTION_INCOME.id]
      ? getSalary(values[QUESTION_INCOME.id] as string)
      : 0
    const salaryContributionRate =
      values[QUESTION_CONTRIBUTION_PERCENTAGE.id] || CONTRIBUTION_PERCENTAGE_3
    const voluntaryContributionFrequency =
      values[QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY.id] ||
      VOLUNTARY_CONTRIBUTION_WEEKLY
    const voluntaryContributionRate =
      values['QUESTION_VOLUNTARY_CONTRIBUTION_AMOUNT'] || 0
    const currentFund = values[QUESTION_CURRENT_FUND.id] || 0

    return {
      type: 'recommendation',
      estimatedProgress: 100,
      userAnswers: {
        currentAge: Number(currentAge),
        firstHomeWithdrawalAge:
          BUY_HOME_IN_YEAR_MAP[buyHomeYears] + Number(currentAge),
        initialBalance: Number(initialBalance),
        salary: Number(salary),
        salaryContributionRate:
          CONTRIBUTION_PERCENTAGE_MAP[salaryContributionRate],
        voluntaryContributionFrequency:
          CONTRIBUTION_FREQUENCY_MAP[voluntaryContributionFrequency],
        voluntaryContributionRate: Number(voluntaryContributionRate),
        fundType: CURRENT_FUND_MAP[currentFund],
      },
    }
  }

  return PROJECTIONS_INITIAL_STEP
}

export const getNextStepProjectionsTool = (
  userAnswers: (string | number)[],
  config: IKiwisaverProjectionsConfig
) => {
  const initialStep = createKiwiSaverProjectionsFlow(config)
  return getNextStep(
    userAnswers,
    initialStep
  ) as IProjectionsToolRecommendationStep
}
