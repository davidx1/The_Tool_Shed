import { getCurrencyString, getMoneyAbbreviated } from './getCurrencyString'

it('should be able to handle really weird inputs and make a guess of the correct answer', () => {
  const tests = [
    {
      input: 0.23,
      expected:'$0.23'
    },
    {
      input: -0.56,
      expected:'-$0.56'
    },
    {
      input: '',
      expected: '',
    },
    {
      input: '-',
      expected: '-',
    },
    {
      input: '-2',
      expected: '-$2',
    },
    {
      input: '%',
      expected: '',
    },
    {
      input: '$',
      expected: '$',
    },
    {
      input: 'A',
      expected: '',
    },
    {
      input: 'T',
      expected: '',
    },
    {
      input: '1',
      expected: '$1',
    },
    {
      input: '-$1',
      expected: '-$1',
    },
    {
      input: '$1-',
      expected: '$1',
    },
    {
      input: '$1.',
      expected: '$1.',
    },
    {
      input: '$1.2',
      expected: '$1.2',
    },
    {
      input: '$1.2-',
      expected: '$1.2',
    },
    {
      input: '$-1.2',
      expected: '-$1.2',
    },
    {
      input: '-$1234',
      expected: '-$1,234',
    },
    {
      input: '-$1,234.',
      expected: '-$1,234.',
    },
    {
      input: '-$1,2-34.',
      expected: '-$1,234.',
    },
    {
      input: '-$1,234..',
      expected: '-$1,234.',
    },
    {
      input: '-$1,2345.',
      expected: '-$12,345.',
    },
    {
      input: '-$12,3%45.',
      expected: '-$12,345.',
    },
    {
      input: '-$12,345.4',
      expected: '-$12,345.4',
    },
    {
      input: '-$12,35.4',
      expected: '-$1,235.4',
    },
    {
      input: '-$1,235.4.',
      expected: '-$1,235.4',
    },
    {
      input: '$1,235.4.',
      expected: '$1,235.4',
    },
    {
      input: '$1,.235.4',
      expected: '$1.23',
    },
    {
      input: '$1,235.474',
      expected: '$1,235.47',
    },
    {
      input: '-$1-245-2.3.45.1',
      expected: '-$12,452.34',
    },
    {
      input: '-$1-24%5-2$3.4/5.1',
      expected: '-$124,523.45',
    },
    {
      input: '-17283912029',
      expected: '-$17,283,912,029',
    },
    {
      input: '-45678',
      expected: '-$45,678',
    },
    {
      input: '-296',
      expected: '-$296',
    },
    {
      input: '-1.761',
      expected: '-$1.76',
    },
    {
      input: '-1',
      expected: '-$1',
    },
    {
      input: '-0.3579',
      expected: '-$0.35',
    },
    {
      input: '0',
      expected: '$0',
    },
    {
      input: '0.456',
      expected: '$0.45',
    },
    {
      input: '1',
      expected: '$1',
    },
    {
      input: '1.9688',
      expected: '$1.96',
    },
    {
      input: '246',
      expected: '$246',
    },
    {
      input: '45789',
      expected: '$45,789',
    },
    {
      input: '6699999',
      expected: '$6,699,999',
    },
    {
      input: '1203948810',
      expected: '$1,203,948,810',
    },
    {
      input: '1360182901839',
      expected: '$1,360,182,901,839',
    },
    {
      input: '999919293919392',
      expected: '$999,919,293,919,392',
    },
    {
      input: -17283912029,
      expected: '-$17,283,912,029',
    },
    {
      input: -45678,
      expected: '-$45,678',
    },
    {
      input: -296,
      expected: '-$296',
    },
    {
      input: -1.768,
      expected: '-$1.76',
    },
    {
      input: -1,
      expected: '-$1',
    },
    {
      input: -0.3579,
      expected: '-$0.35',
    },
    {
      input: 0,
      expected: '$0',
    },
    {
      input: 0.456,
      expected: '$0.45',
    },
    {
      input: 1,
      expected: '$1',
    },
    {
      input: 1.9688,
      expected: '$1.96',
    },
    {
      input: 246,
      expected: '$246',
    },
    {
      input: 45789,
      expected: '$45,789',
    },
    {
      input: 6699999,
      expected: '$6,699,999',
    },
    {
      input: 1203948810,
      expected: '$1,203,948,810',
    },
    {
      input: 1360182901839,
      expected: '$1,360,182,901,839',
    },
    {
      input: 999919293919392,
      expected: '$999,919,293,919,392',
    },
  ]
  tests.forEach((t) => {
    expect(getCurrencyString(t.input)).toEqual(t.expected)
  })
})

it('should abbreviate numbers correctly', () => {
  const tests=[
    {
      input: 1,
      expected: '$1'
    },
    {
      input: 0.1,
      expected: '$0.1'
    },
    {
      input: 0.246,
      expected: '$0.2'
    },
    {
      input: 0.578,
      expected: '$0.6'
    },
    {
      input: 1000,
      expected: '$1k'
    },
    {
      input: 2222222,
      expected: '$2.2m'
    },
    {
      input: 1234567890,
      expected: '$1.2b'
    },
    {
      input: 1234567890123,
      expected: '$1.2t'
    },
    {
      input: 1234567890123456,
      expected: '$1.2qa'
    }
  ]
  tests.forEach((t) => {
    expect(getMoneyAbbreviated(t.input)).toEqual(t.expected)
  })
})