import { projectionsCalculation } from './projectionsCalculation'
import config from './__mocks__/ProjectionsConfigMockData'

describe('Kiwisaver Calculator', () => {
  it('should return zero for everything if no input', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 0,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      })
    ).toEqual({
      finalAmount: 0,
      nominalAmount: 0,
      withdrawableAmount: 0,
      payments: {
        fortnightly: 0,
        monthly: 0,
        weekly: 0,
        annually: 0,
      },
    })
  })

  it('compound interest of initial balance calculated correctly', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 1000,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      })
    ).toEqual({
      finalAmount: 1986,
      nominalAmount: 5037.284039154978,
      withdrawableAmount: 1592,
      payments: {
        weekly: 2,
        fortnightly: 3,
        monthly: 7,
        annually: 84,
      },
    })

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 2345,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      })
    ).toEqual({
      finalAmount: 4657,
      nominalAmount: 11812.431071818424,
      withdrawableAmount: 4263,
      payments: {
        weekly: 4,
        fortnightly: 8,
        monthly: 16,
        annually: 198,
      },
    })
  })

  it('weekly return should be calculated correctly when superannuation is included', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 2345,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: true,
        relationshipStatus: 'single',
        config,
      }).payments.weekly
    ).toEqual(395)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 2345,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: true,
        relationshipStatus: 'couple',
        config,
      }).payments.weekly
    ).toEqual(330)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 1000,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: true,
        relationshipStatus: 'single',
        config,
      }).payments.weekly
    ).toEqual(393)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 1000,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: true,
        relationshipStatus: 'couple',
        config,
      }).payments.weekly
    ).toEqual(328)
  })

  it('salary should be calculated correctly', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 0,
        investmentRate: 0.025,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 52_000,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(225_187)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 0,
        investmentRate: 0.025,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 52_000,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(414_378)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 0,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 52_000,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(280_478)

    expect(
      projectionsCalculation({
        currentAge: 23,
        calculationEndAge: 65,
        initialBalance: 0,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 52_000,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(429_108)
  })

  it('different investment percentage gives correct results', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 5000,
        investmentRate: 0.015,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(3969)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 5000,
        investmentRate: 0.025,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(6292)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 5000,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(9930)

    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 65,
        initialBalance: 5000,
        investmentRate: 0.045,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'annually',
        salary: 0,
        salaryContributionRate: 0.03,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(15_604)
  })

  it('Random scenarios should all work', () => {
    expect(
      projectionsCalculation({
        currentAge: 23,
        calculationEndAge: 65,
        initialBalance: 12000,
        investmentRate: 0.045,
        voluntaryContributionRate: 100,
        voluntaryContributionFrequency: 'fortnightly',
        salary: 52000,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(800228)

    expect(
      projectionsCalculation({
        currentAge: 55,
        calculationEndAge: 65,
        initialBalance: 15_000,
        investmentRate: 0.025,
        voluntaryContributionRate: 450,
        voluntaryContributionFrequency: 'monthly',
        salary: 102000,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(143_995)

    expect(
      projectionsCalculation({
        currentAge: 38,
        calculationEndAge: 65,
        initialBalance: 10_000,
        investmentRate: 0.015,
        voluntaryContributionRate: 3450,
        voluntaryContributionFrequency: 'annually',
        salary: 252_000,
        salaryContributionRate: 0.1,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(1_042_769)

    expect(
      projectionsCalculation({
        currentAge: 42,
        calculationEndAge: 65,
        initialBalance: 17_520,
        investmentRate: 0.015,
        voluntaryContributionRate: 3450,
        voluntaryContributionFrequency: 'weekly',
        salary: 252_000,
        salaryContributionRate: 0.1,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(5_343_608)

    expect(
      projectionsCalculation({
        currentAge: 45,
        calculationEndAge: 65,
        initialBalance: 1000,
        investmentRate: 0.015,
        voluntaryContributionRate: 5,
        voluntaryContributionFrequency: 'weekly',
        salary: 24_000,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(48_284)

    expect(
      projectionsCalculation({
        currentAge: 29,
        calculationEndAge: 65,
        initialBalance: 40_000,
        investmentRate: 0.045,
        voluntaryContributionRate: 20,
        voluntaryContributionFrequency: 'monthly',
        salary: 124_000,
        salaryContributionRate: 0.06,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(829_330)
  })

  it('Should calculate first home withdrawal amount correctly', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        calculationEndAge: 23,
        initialBalance: 10_000,
        investmentRate: 0.045,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 80_000,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).withdrawableAmount
    ).toEqual(38_820)

    expect(
      projectionsCalculation({
        currentAge: 59,
        calculationEndAge: 60,
        initialBalance: 24_680,
        investmentRate: 0.025,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 145_670,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).withdrawableAmount
    ).toEqual(38_627)

    expect(
      projectionsCalculation({
        currentAge: 17,
        calculationEndAge: 21,
        initialBalance: 981,
        investmentRate: 0.025,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 65_432,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).withdrawableAmount
    ).toEqual(16_309)

    expect(
      projectionsCalculation({
        currentAge: 17,
        calculationEndAge: 21,
        initialBalance: 981,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 65_432,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).withdrawableAmount
    ).toEqual(16_558)

    expect(
      projectionsCalculation({
        currentAge: 26,
        calculationEndAge: 29,
        initialBalance: 54_367,
        investmentRate: 0.015,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 567_890,
        salaryContributionRate: 0.1,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).withdrawableAmount
    ).toEqual(256_702)

    expect(
      projectionsCalculation({
        currentAge: 60,
        calculationEndAge: 62,
        initialBalance: 98_765,
        investmentRate: 0.015,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 0,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).withdrawableAmount
    ).toEqual(96_838)
  })

  it('Should calculate retirement amount correctly after first home withdrawal', () => {
    expect(
      projectionsCalculation({
        currentAge: 18,
        firstHomeWithdrawalAge: 23,
        calculationEndAge: 65,
        initialBalance: 10_000,
        investmentRate: 0.045,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 80_000,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(509_200)

    expect(
      projectionsCalculation({
        currentAge: 59,
        firstHomeWithdrawalAge: 60,
        calculationEndAge: 65,
        initialBalance: 24_680,
        investmentRate: 0.025,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 145_670,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(78_858)

    expect(
      projectionsCalculation({
        currentAge: 17,
        firstHomeWithdrawalAge: 21,
        calculationEndAge: 65,
        initialBalance: 981,
        investmentRate: 0.035,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 65_432,
        salaryContributionRate: 0.04,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(364_110)

    expect(
      projectionsCalculation({
        currentAge: 26,
        firstHomeWithdrawalAge: 29,
        calculationEndAge: 65,
        initialBalance: 54_367,
        investmentRate: 0.015,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 567_890,
        salaryContributionRate: 0.1,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(3_053_216)

    expect(
      projectionsCalculation({
        currentAge: 60,
        firstHomeWithdrawalAge: 62,
        calculationEndAge: 65,
        initialBalance: 98_765,
        investmentRate: 0.015,
        voluntaryContributionRate: 0,
        voluntaryContributionFrequency: 'monthly',
        salary: 0,
        salaryContributionRate: 0.08,
        isIncludingSuperannuation: false,
        relationshipStatus: 'single',
        config,
      }).finalAmount
    ).toEqual(947)
  })
})
