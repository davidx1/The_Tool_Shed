export const getCurrencyString = (s: string | number): string => {
  if (s === '0' || 0) {
    return '$0'
  }

  if (s === '$' || s === '-$') {
    return s
  }

  if (typeof s !== 'string' && typeof s !== 'number') {
    return ''
  }

  const input = s.toString()
  //Remove all character that's NOT number, dash, or dot.
  const sanitized = input.replace(/[^0-9-.]/g, '')

  if (sanitized === '') {
    return ''
  }

  //Decide if the number should be negative depending on first character
  const isNegative = sanitized[0] === '-'

  //Then remove all '-'
  const absoluteInput = sanitized.replace(/[-]/g, '')
  if (sanitized === '') {
    return isNegative ? '-$' : ''
  }

  //Split the remaining string
  const decimalIndex = absoluteInput.indexOf('.')

  const integers =
    decimalIndex === -1 ? absoluteInput : absoluteInput.slice(0, decimalIndex)

  const decimals =
    decimalIndex === -1 || decimalIndex === absoluteInput.length - 1
      ? ''
      : absoluteInput.replace(/[.]/g, '').slice(decimalIndex, decimalIndex + 2)
  const isShowingDot = decimalIndex > -1 || !!decimals
  const isShowingDollar = !!integers.length

  // We want to add a comma for every 3rd digit from the right
  // So this reverses the string, and use regex to add a comma
  // to every three digits, then flips it back.
  const backwards = integers.split('').reverse().join('')
  const withComma = backwards.replace(/(\d{3})/g, '$1,')
  const tempResult = withComma.split('').reverse().join('')

  const resultInteger = tempResult[0] === ',' ? tempResult.slice(1) : tempResult

  return `${isNegative ? '-' : ''}${
    isShowingDollar ? '$' : ''
  }${resultInteger}${isShowingDot ? '.' : ''}${decimals}`
}

export function getMoneyAbbreviated(amount: number) {
  const moneyUnits = ['', 'k', 'm', 'b', 't', 'qa']
  const tempPower = Math.floor(Math.log(amount) / Math.log(1000))
  const power = tempPower > 0 ? tempPower : 0;
  const amountToDisplay = amount >= 1 || amount <= -1 ? amount / Math.pow(1000, power) : amount
  const formatted = amountToDisplay.toFixed(1).replace('.0', '')
  const finalString = `$${formatted}${moneyUnits[power]}`
  return finalString
}
