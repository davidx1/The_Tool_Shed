import { getNextStepProjectionsTool } from './projectionsToolUtils'
import ProjectionsConfigMockData from './__mocks__/ProjectionsConfigMockData'

function getSimpleNextStep(answers: (string | number)[]) {
  const step = getNextStepProjectionsTool(answers, ProjectionsConfigMockData)
  const {
    question: { id, title } = {
      id: '',
      title: '',
    },
  } = step

  return {
    id,
    title,
  }
}

function getAllSteps(answers: (string | number)[]) {
  const stepsSeen = []
  for (let i = 0; i <= answers.length; i++) {
    stepsSeen.push({
      ...getSimpleNextStep(answers.slice(0, i)),
      answer: answers[i],
    })
  }
  return stepsSeen
}

describe('Everyone sees the right questions', () => {
  it('young kid', () => {
    const kidAnswers = [
      '12',
      'Ok, I understand',
      'Retirement',
      'Not Employed',
      '1000',
      'Not currently',
      'Growth',
    ]
    expect(getAllSteps(kidAnswers)).toMatchInlineSnapshot(`
      Array [
        Object {
          "answer": "12",
          "id": "QUESTION_AGE",
          "title": "First of all, what’s your current age?",
        },
        Object {
          "answer": "Ok, I understand",
          "id": "QUESTION_CONFIRMATION_UNDER_AGE",
          "title": "We’re here to help.",
        },
        Object {
          "answer": "Retirement",
          "id": "QUESTION_KIWISAVER_GOAL",
          "title": "What will you be using your KiwiSaver savings for first?",
        },
        Object {
          "answer": "Not Employed",
          "id": "QUESTION_EMPLOYMENT_STATUS",
          "title": "What’s your employment status?",
        },
        Object {
          "answer": "1000",
          "id": "QUESTION_KIWISAVER_BALANCE",
          "title": "What’s your current KiwiSaver balance?",
        },
        Object {
          "answer": "Not currently",
          "id": "QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY",
          "title": "Do you make any contributions?",
        },
        Object {
          "answer": "Growth",
          "id": "QUESTION_CURRENT_FUND",
          "title": "What type of fund are you currently in?",
        },
        Object {
          "answer": undefined,
          "id": "",
          "title": "",
        },
      ]
    `)
  })

  it('office worker', () => {
    const workerAnswers = [
      '30',
      'First Home',
      'In 3 years',
      'Employed',
      '100000',
      '2000',
      '6%',
      'Conservative / Default',
    ]
    expect(getAllSteps(workerAnswers)).toMatchInlineSnapshot(`
      Array [
        Object {
          "answer": "30",
          "id": "QUESTION_AGE",
          "title": "First of all, what’s your current age?",
        },
        Object {
          "answer": "First Home",
          "id": "QUESTION_KIWISAVER_GOAL",
          "title": "What will you be using your KiwiSaver savings for first?",
        },
        Object {
          "answer": "In 3 years",
          "id": "QUESTION_WHEN_TO_BUY_HOME",
          "title": "How many years until you expect to purchase your first home?",
        },
        Object {
          "answer": "Employed",
          "id": "QUESTION_EMPLOYMENT_STATUS",
          "title": "What’s your employment status?",
        },
        Object {
          "answer": "100000",
          "id": "QUESTION_INCOME",
          "title": "What’s your income",
        },
        Object {
          "answer": "2000",
          "id": "QUESTION_KIWISAVER_BALANCE",
          "title": "What’s your current KiwiSaver balance?",
        },
        Object {
          "answer": "6%",
          "id": "QUESTION_CONTRIBUTION_PERCENTAGE",
          "title": "What is your contribution rate?",
        },
        Object {
          "answer": "Conservative / Default",
          "id": "QUESTION_CURRENT_FUND",
          "title": "What type of fund are you currently in?",
        },
        Object {
          "answer": undefined,
          "id": "",
          "title": "",
        },
      ]
    `)
  })

  it('self employed', () => {
    const selfEmployedAnswers = [
      '24',
      'First Home',
      'In 3 years',
      'Self Employed',
      '1000',
      'Weekly',
      '100',
      'It’s a mix of funds',
    ]
    expect(getAllSteps(selfEmployedAnswers)).toMatchInlineSnapshot(`
      Array [
        Object {
          "answer": "24",
          "id": "QUESTION_AGE",
          "title": "First of all, what’s your current age?",
        },
        Object {
          "answer": "First Home",
          "id": "QUESTION_KIWISAVER_GOAL",
          "title": "What will you be using your KiwiSaver savings for first?",
        },
        Object {
          "answer": "In 3 years",
          "id": "QUESTION_WHEN_TO_BUY_HOME",
          "title": "How many years until you expect to purchase your first home?",
        },
        Object {
          "answer": "Self Employed",
          "id": "QUESTION_EMPLOYMENT_STATUS",
          "title": "What’s your employment status?",
        },
        Object {
          "answer": "1000",
          "id": "QUESTION_KIWISAVER_BALANCE",
          "title": "What’s your current KiwiSaver balance?",
        },
        Object {
          "answer": "Weekly",
          "id": "QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY",
          "title": "Do you make any contributions?",
        },
        Object {
          "answer": "100",
          "id": "QUESTION_VOLUNTARY_CONTRIBUTION_AMOUNT",
          "title": "How much are your weekly contributions?",
        },
        Object {
          "answer": "It’s a mix of funds",
          "id": "QUESTION_CURRENT_FUND",
          "title": "What type of fund are you currently in?",
        },
        Object {
          "answer": undefined,
          "id": "",
          "title": "",
        },
      ]
    `)
  })

  it('unemployed', () => {
    const unemployedAnswers = [
      '34',
      'Retirement',
      'Not Employed',
      '3000',
      'Monthly',
      '100',
      'Moderate',
    ]
    expect(getAllSteps(unemployedAnswers)).toMatchInlineSnapshot(`
      Array [
        Object {
          "answer": "34",
          "id": "QUESTION_AGE",
          "title": "First of all, what’s your current age?",
        },
        Object {
          "answer": "Retirement",
          "id": "QUESTION_KIWISAVER_GOAL",
          "title": "What will you be using your KiwiSaver savings for first?",
        },
        Object {
          "answer": "Not Employed",
          "id": "QUESTION_EMPLOYMENT_STATUS",
          "title": "What’s your employment status?",
        },
        Object {
          "answer": "3000",
          "id": "QUESTION_KIWISAVER_BALANCE",
          "title": "What’s your current KiwiSaver balance?",
        },
        Object {
          "answer": "Monthly",
          "id": "QUESTION_VOLUNTARY_CONTRIBUTION_FREQUENCY",
          "title": "Do you make any contributions?",
        },
        Object {
          "answer": "100",
          "id": "QUESTION_VOLUNTARY_CONTRIBUTION_AMOUNT",
          "title": "How much are your monthly contributions?",
        },
        Object {
          "answer": "Moderate",
          "id": "QUESTION_CURRENT_FUND",
          "title": "What type of fund are you currently in?",
        },
        Object {
          "answer": undefined,
          "id": "",
          "title": "",
        },
      ]
    `)
  })

  it('oldest person', () => {
    const oldestAnswers = ['78']

    expect(getAllSteps(oldestAnswers)).toMatchInlineSnapshot(`
      Array [
        Object {
          "answer": "78",
          "id": "QUESTION_AGE",
          "title": "First of all, what’s your current age?",
        },
        Object {
          "answer": undefined,
          "id": "QUESTION_CONFIRMATION_OLDER_THAN_64",
          "title": "We’re here to help.",
        },
      ]
    `)
  })
})
