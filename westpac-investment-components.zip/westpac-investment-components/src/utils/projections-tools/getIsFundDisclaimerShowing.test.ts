import { getIsFundDisclaimerShowing } from './getIsFundDisclaimerShowing'

test('test that everything is working', () => {
  const func = getIsFundDisclaimerShowing;
  expect(func(20, 65, 22, 'conservative')).toBe(true);
  expect(func(20, 65, 24, 'conservative')).toBe(true);
  expect(func(20, 65, 80, 'conservative')).toBe(false);
  expect(func(20, 21, 0, 'conservative')).toBe(true);
  expect(func(20, 25, 0, 'conservative')).toBe(false);

  expect(func(20, 65, 25, 'moderate')).toBe(true);
  expect(func(20, 65, 26, 'moderate')).toBe(true);
  expect(func(20, 65, 27, 'moderate')).toBe(false);
  expect(func(20, 26, 0, 'moderate')).toBe(true);
  expect(func(20, 28, 0, 'moderate')).toBe(false);

  expect(func(30, 65, 38, 'balanced')).toBe(true);
  expect(func(30, 65, 39, 'balanced')).toBe(true);
  expect(func(30, 65, 50, 'balanced')).toBe(false);
  expect(func(30, 36, 0, 'balanced')).toBe(true);
  expect(func(30, 40, 0, 'balanced')).toBe(false);

  expect(func(40, 65, 44, 'growth')).toBe(true);
  expect(func(40, 65, 50, 'growth')).toBe(true);
  expect(func(40, 65, 51, 'growth')).toBe(false);
  expect(func(40, 27, 0, 'growth')).toBe(true);
  expect(func(40, 52, 0, 'growth')).toBe(false);
})
