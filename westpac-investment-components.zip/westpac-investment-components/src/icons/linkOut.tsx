import React from 'react'

export default React.memo((props) => (
  <svg
    width="14"
    height="14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M14 .114l-.114 5.173-2.04-2.04-3.178 3.178-1.13-1.13 3.177-3.179L8.6 0l5.402.114zM.536.955h-.5V13.72h12.763V7.337h-1v5.382H1.035V1.955h5.382v-1H.535z"
      fill="#222"
    />
  </svg>
))
