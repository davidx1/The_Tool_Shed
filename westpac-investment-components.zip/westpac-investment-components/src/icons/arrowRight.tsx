import React from 'react'

export default React.memo((props) => (
  <svg
    width="11"
    height="11"
    viewBox="0 0 11 11"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M5.96979 0.5L4.66492 1.78545L7.49558 4.59273H0V6.40727H7.49558L4.66492 9.21455L5.96979 10.5L11 5.5L5.96979 0.5Z"
      fill="#3C3C3C"
    />
  </svg>
))
