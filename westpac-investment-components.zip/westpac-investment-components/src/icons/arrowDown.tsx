import React from 'react'

export default React.memo((props) => (
  <svg
    width="22"
    height="13"
    viewBox="0 0 22 13"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path d="M21 1L11 11L1 1" stroke="#3C3C3C" strokeWidth="2" />
  </svg>
))
