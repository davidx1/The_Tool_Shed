import React from 'react'

export default React.memo((props) => (
  <svg
    width="60"
    height="60"
    viewBox="0 0 16 17"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M16 8.5C16 12.9183 12.4183 16.5 8 16.5C3.58172 16.5 0 12.9183 0 8.5C0 4.08172 3.58172 0.5 8 0.5C12.4183 0.5 16 4.08172 16 8.5ZM8.66667 7.16667V12.5H7.33333V7.16667H8.66667ZM8 5.83333C8.36819 5.83333 8.66667 5.53486 8.66667 5.16667C8.66667 4.79848 8.36819 4.5 8 4.5C7.63181 4.5 7.33333 4.79848 7.33333 5.16667C7.33333 5.53486 7.63181 5.83333 8 5.83333Z"
      fill="#9F4585"
    />
  </svg>
))
