import React from 'react'

export default React.memo((props) => (
  <svg
    width="56"
    height="56"
    viewBox="0 0 56 56"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <circle opacity="0.8" cx="28" cy="28" r="28" fill="#621A4B" />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M21.4961 16.8549C20.8295 16.474 20 16.9554 20 17.7232V38.2768C20 39.0446 20.8295 39.526 21.4961 39.1451L39.4806 28.8682C40.1524 28.4843 40.1524 27.5157 39.4806 27.1318L21.4961 16.8549Z"
      fill="white"
      fillOpacity="0.9"
    />
  </svg>
))
