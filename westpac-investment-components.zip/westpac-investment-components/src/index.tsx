import './polyfills'

/* -----------------------------------------------
                    Shared
----------------------------------------------- */

export type {
  IStep,
  IQuestion,
  IQuestionConfirmationModal,
  IQuestionDropdown,
  IQuestionRadio,
  IQuestionText,
  IQuestionDropdownText,
} from './components/navigation/IQuestionnaire'

export type {
  IColumnProps,
  IComparisonProps,
} from './components/dataDisplay/ComparisonBase'

export { InvestToolsProvider } from './components/InvestToolsProvider'

export { default as DialogFullScreen } from './components/dialog/DialogFullScreen'
export { default as DialogInfo } from './components/dialog/DialogInfo'
export { default as DisclaimerDialog } from './components/dialog/DisclaimerDialog'
export { default as ChoiceDialog } from './components/dialog/ChoiceDialog'

export { default as Pill } from './components/dataDisplay/Pill'
export { default as ListDisc } from './components/dataDisplay/ListDisc'
export { default as Comparison } from './components/dataDisplay/Comparison'
export { default as DynamicIcon } from './components/dataDisplay/DynamicIcon'
export {
  default as HTMLRenderer,
  DisclaimerText,
} from './components/dataDisplay/HTMLRenderer'
export { default as Typography } from './components/dataDisplay/Typography'

export { default as SectionBackground } from './components/layout/SectionBackground'
export { default as Container } from './components/layout/Container'
export { default as Box } from './components/layout/Box'

export { default as Questionnaire } from './components/navigation/Questionnaire'
export { default as SubQuestionnaire } from './components/navigation/SubQuestionnaire'
export { default as ResultsSubMenu } from './components/navigation/ResultsSubMenu'
export {
  LabelField,
  ValueField,
} from './components/navigation/SubQuestionnaire'

export {
  default as Button,
  SmallScreensButton,
} from './components/inputs/Button'
export { default as ArrowButton } from './components/inputs/ArrowButton'
export { default as LinkButton } from './components/inputs/LinkButton'
export { default as UnderlineButton } from './components/inputs/UnderlineButton'
export { default as FormTextField } from './components/inputs/FormTextField'
export { default as BigCheckbox } from './components/inputs/BigCheckbox'
export { default as ConfirmationAnswer } from './components/inputs/answer/ConfirmationAnswer'

export { default as LoadingProgress } from './components/feedback/LoadingProgress'

/* -----------------------------------------------
                     Hooks
----------------------------------------------- */

export type { IQuestionnaireBase } from './hooks/useQuestionnaire'
export type { ITimeoutConfig } from './hooks/useTimeout'

export { default as useQuestionnaire } from './hooks/useQuestionnaire'
export { default as useTimeout } from './hooks/useTimeout'
export { default as useErrorToast } from './hooks/useErrorToast'
export { default as useDialogState } from './hooks/useDialogState'
export { default as useScrollPosition } from './hooks/useScrollPosition'

/* -----------------------------------------------
            Kiwisaver fund chooser
----------------------------------------------- */

export type {
  IKiwisaverStep,
  IKiwisaverFundType,
  IKiwisaverFundItem,
  IKiwisaverFundChooserConfig,
} from './utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'

export { getFundColor } from './components/kiwiSaver/graph/graphFundUtils'
export { generateKiwisaverRecommendationFile } from './utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserFileUtils'

export { getNextStepFundChooser } from './utils/kiwi-saver-fund-chooser/kiwiSaverFundChooserUtils'
export { default as KiwiSaverRecommendationHeader } from './components/kiwiSaver/KiwiSaverRecommendationHeader'
export { default as KiwiSaverRecommendationGraph } from './components/kiwiSaver/KiwiSaverRecommendationGraph'
export { default as KiwiSaverRecommendationFeeDetails } from './components/kiwiSaver/KiwiSaverRecommendationFeeDetails'
export { default as KiwiSaverRecommendationFooter } from './components/kiwiSaver/KiwiSaverRecommendationFooter'
export { default as KiwiSaverJoinOrChange } from './components/kiwiSaver/KiwiSaverJoinOrChange'
export { default as KiwiSaverFundDetails } from './components/kiwiSaver/KiwiSaverFundDetails'
export { default as KiwiSaverRecommendationDisclaimer } from './components/kiwiSaver/KiwiSaverRecommendationDisclaimer'

/* -----------------------------------------------
            Interest frequency finder
----------------------------------------------- */

export type { IInterestFrequencyStep } from './utils/interest-frequency-finder/InterestFrequencyFinderUtils'
export { getNextStepInterestFrequency } from './utils/interest-frequency-finder/InterestFrequencyFinderUtils'

/* -----------------------------------------------
            Income tax rate finder
----------------------------------------------- */

export type { IIncomeTaxRateStep } from './utils/income-tax-rate-finder/IncomeTaxRateUtils'
export { getNextStepIncomeTaxRate } from './utils/income-tax-rate-finder/IncomeTaxRateUtils'

/* -----------------------------------------------
                  PIR Rate
----------------------------------------------- */

export type { IPIRRateStep } from './utils/pir-rate-finder/PIRRateUtils'
export { getNextStepPIRRate } from './utils/pir-rate-finder/PIRRateUtils'

/* -----------------------------------------------
              S&I Product Chooser
----------------------------------------------- */

export type {
  IProductChooserStep,
  IProductChooserProductType,
  IProductChooserProductItem,
  IProductChooserInterestRate,
  IProductChooserFees,
  IProductChooserFee,
  IProductChooserRecommendationDetails,
  IProductChooserConfig,
  IProductChooserRatesAndFees,
  IProductChooserRatesData,
} from './utils/product-chooser/productChooserUtils'

export {
  getCurrentRecommendationItems,
  getNextStepProductChooser,
} from './utils/product-chooser/productChooserUtils'

export { default as ProductChooserRecommendationBenefits } from './components/productChooser/ProductChooserRecommendationBenefits'
export { default as ProductChooserRecommendationDetails } from './components/productChooser/ProductChooserRecommendationDetails'
export { default as ProductChooserRecommendationDisclosures } from './components/productChooser/ProductChooserRecommendationDisclosures'
export { default as ProductChooserRecommendationFees } from './components/productChooser/ProductChooserRecommendationFees'
export { default as ProductChooserRecommendationHeader } from './components/productChooser/ProductChooserRecommendationHeader'
export { default as ProductChooserRecommendationInterest } from './components/productChooser/ProductChooserRecommendationInterest'
export { default as ProductChooserRecommendationOtherProduct } from './components/productChooser/ProductChooserRecommendationOtherProduct'
export { default as ProductChooserRecommendationFooter } from './components/productChooser/ProductChooserRecommendationFooter'
export { default as ProductChooserRecommendationVideo } from './components/productChooser/ProductChooserRecommendationVideo'
export { default as ProductChooserRecommendationApply } from './components/productChooser/ProductChooserRecommendationApply'

export { generateProductRecommendationFile } from './utils/product-chooser/productChooserFileUtils'
export { generateDisclaimerRecommendationFile } from './utils/disclaimer/disclaimerFileUtils'

/* -----------------------------------------------
           KiwiSaver Projections tool
----------------------------------------------- */

export { getNextStepProjectionsTool } from './utils/projections-tools/projectionsToolUtils'
export { getIsFundDisclaimerShowing } from './utils/projections-tools/getIsFundDisclaimerShowing'

export { projectionsCalculation } from './utils/projections-tools/projectionsCalculation'
export type {
  IProjectionsToolRecommendationStep,
  IProjectionsFundType,
  IKiwisaverContributionFrequencyType,
  IKiwisaverSalaryContributionRateType,
  IRelationshipStatusType,
  IKiwisaverProjectionsConfig,
} from './utils/projections-tools/projectionsToolUtils'
export { default as ProjectionsRecommendationMakeChange } from './components/projectionsTool/RecommendationMakeChange'
export { default as ProjectionsRecommendationFooter } from './components/projectionsTool/RecommendationFooter'
export { RecommendationSummary as ProjectionsRecommendationSummary } from './components/projectionsTool/RecommendationSummary'
export { Graph as ProjectionsRecommendationGraph } from './components/projectionsTool/RecommendationGraph/Graph'
export { Controls as ProjectionsRecommendationControls } from './components/projectionsTool/RecommendationControls/Controls'
export { RecommendationResponsiveWrapper as ProjectionsRecommendationResponsiveWrapper } from './components/projectionsTool/RecommendationResponsiveWrapper'
export { default as ProjectionsChangeFundChoiceDialog } from './components/projectionsTool/Dialogs/ChangeFundChoiceDialog'
export { default as ProjectionsMakeContributionChoiceDialog } from './components/projectionsTool/Dialogs/MakeContributionChoiceDialog'
export { default as ProjectionsAssumptionsInfoDialog } from './components/projectionsTool/Dialogs/AssumptionsInfoDialog'
export { default as ProjectionsInflationInfoDialog } from './components/projectionsTool/Dialogs/InflationInfoDialog'
export { default as ProjectionsChangeFundLoginChoiceDialog } from './components/projectionsTool/Dialogs/ChangeFundLoginChoiceDialog'
