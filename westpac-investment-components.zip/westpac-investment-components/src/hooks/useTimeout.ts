import { useEffect, useState, useCallback } from 'react'

export interface ITimeoutConfig {
  timeout: number | null
  callback: () => void
}

/**
 * Simple helper for controlling timeouts
 * Once the callback is executed, the only way to execute it again is
 * passing a new config or calling the resetTimeout Function
 */
export default function useTimeout(config: ITimeoutConfig | null) {
  const [resetCount, setResetCount] = useState(0)

  const resetTimeout = useCallback(() => {
    setResetCount(resetCount + 1)
  }, [resetCount])

  useEffect(() => {
    let timeout: number | null = null
    if (config && config.timeout) {
      timeout = setTimeout(config.callback, config.timeout)
    }
    return () => {
      if (timeout) {
        clearTimeout(timeout)
      }
    }
  }, [config, resetCount])

  return resetTimeout
}
