import { useState, useEffect } from 'react'

type IScreenChangeHandler = (
  delta: number,
  newHeight: number,
  oldHeight: number
) => void

export const useShortScreenState = (
  threshold: number,
  onScreenShrinkHandler: IScreenChangeHandler = () => {},
  onScreenGrowHandler: IScreenChangeHandler = () => {}
) => {
  const shortScreenThreshold = threshold;
  const [isShortScreen, setIsShortScreen] = useState(false)
  const [oldInnerHeight, setOldInnerHeight] = useState(0)

  useEffect(() => {
    const onResize = () => {
      if (oldInnerHeight) {
        const delta = window.innerHeight - oldInnerHeight
        if (delta < 0) {
          onScreenShrinkHandler(delta, window.innerHeight, oldInnerHeight)
        } else {
          onScreenGrowHandler(delta, window.innerHeight, oldInnerHeight)
        }
        setOldInnerHeight(window.innerHeight)
      }

      setIsShortScreen(window.innerHeight < shortScreenThreshold)
    }
    setOldInnerHeight(window.innerHeight)
    onResize()
    window.addEventListener('resize', onResize, false)
    return () => window.removeEventListener('resize', onResize, false)
  }, [oldInnerHeight, onScreenGrowHandler, onScreenShrinkHandler, shortScreenThreshold])

  return {isShortScreen}
}
