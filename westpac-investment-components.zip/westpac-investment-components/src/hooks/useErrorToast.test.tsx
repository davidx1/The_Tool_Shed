import React from 'react'
import useErrorToast from './useErrorToast'
import { renderHook, act } from '@testing-library/react-hooks'
import { InvestToolsProvider } from '../components/InvestToolsProvider'

describe('useErrorToast', () => {
  it('should create hook and display error', async () => {
    const wrapper: React.FC = ({ children }) => (
      <InvestToolsProvider>
        <div>{children}</div>
      </InvestToolsProvider>
    )
    const { result } = renderHook(() => useErrorToast(), {
      wrapper,
    })

    act(() => {
      result.current('Error', true)
    })
  })

  it('should crash if not inside the ErrorToastProvider', async () => {
    const { result } = renderHook(() => useErrorToast())

    expect(result.error.message).toBe(
      'useErrorToast must be used within a ErrorToastProvider'
    )
  })
})
