import React, { useCallback } from 'react'
import { ErrorToastActionsContext } from '../components/error/ErrorToastProvider'

export default function useErrorToast() {
  const context = React.useContext(ErrorToastActionsContext)
  if (context === undefined) {
    throw new Error('useErrorToast must be used within a ErrorToastProvider')
  }
  const showError = useCallback(
    (message: string = '', hideReload: boolean = false) => {
      if (context) {
        context({ type: 'open', message, hideReload })
      }
    },
    [context]
  )
  return showError
}
