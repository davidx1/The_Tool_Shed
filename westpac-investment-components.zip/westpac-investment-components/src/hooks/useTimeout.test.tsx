import useTimeout from './useTimeout'
import { act, renderHook } from '@testing-library/react-hooks'

jest.useFakeTimers()

describe.only('useTimeout', () => {
  it('should create hook and call timeout in the expected time', async () => {
    const callback = jest.fn()
    const { rerender, result } = renderHook(
      (timeout) => useTimeout(timeout !== null ? { timeout, callback } : null),
      { initialProps: 1000 as number | null }
    )
    expect(callback).not.toBeCalled()
    jest.advanceTimersByTime(1000)
    expect(callback).toBeCalledTimes(1)

    // check rerender passing a new initial value
    callback.mockClear()
    rerender(5000)
    jest.advanceTimersByTime(2000)
    expect(callback).not.toBeCalled()
    jest.advanceTimersByTime(3000)
    expect(callback).toBeCalledTimes(1)

    // check resetTimeout
    callback.mockClear()
    act(() => result.current()) // reset time out
    expect(callback).not.toBeCalled()
    jest.advanceTimersByTime(5000)
    expect(callback).toBeCalledTimes(1)

    // check disabled timeout
    callback.mockClear()
    rerender(null)
    expect(callback).not.toBeCalled()
    jest.advanceTimersByTime(100000)
    expect(callback).toBeCalledTimes(0)
  })
})
