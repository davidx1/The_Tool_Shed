import { act, renderHook } from '@testing-library/react-hooks'
import useDialogState from './useDialogState'

test('initial value is correct', () => {
  const { result } = renderHook(() => useDialogState(false))

  expect(result.current.isOpen).toBe(false)

  const { result: result2 } = renderHook(() => useDialogState(true))

  expect(result2.current.isOpen).toBe(true)
})

test('can be opened', () => {
  const { result } = renderHook(() => useDialogState(false))
  act(() => {
    result.current.open()
  })
  expect(result.current.isOpen).toBe(true)

  act(() => {
    result.current.open()
  })
  expect(result.current.isOpen).toBe(true)
})

test('can be closed', () => {
  const { result } = renderHook(() => useDialogState(true))
  act(() => {
    result.current.close()
  })
  expect(result.current.isOpen).toBe(false)

  act(() => {
    result.current.close()
  })
  expect(result.current.isOpen).toBe(false)
})

test('can be toggled', () => {
  const { result } = renderHook(() => useDialogState(true))
  act(() => {
    result.current.toggle()
  })
  expect(result.current.isOpen).toBe(false)

  act(() => {
    result.current.toggle()
  })
  expect(result.current.isOpen).toBe(true)
})

test('can be set', () => {
  const { result } = renderHook(() => useDialogState(true))
  act(() => {
    result.current.setIsOpen(false)
  })

  expect(result.current.isOpen).toBe(false)

  act(() => {
    result.current.setIsOpen(true)
  })
  expect(result.current.isOpen).toBe(true)

  act(() => {
    result.current.setIsOpen(true)
  })
  expect(result.current.isOpen).toBe(true)
})
