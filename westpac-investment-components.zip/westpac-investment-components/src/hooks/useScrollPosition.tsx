import { useEffect, useState } from 'react'

export default function useScrollPosition<T extends HTMLElement | null>(
  element: T
) {
  const [scrollPos, setScrollPos] = useState(0)

  useEffect(() => {
    if (element) {
      const handler = () => {
        setScrollPos(element.scrollLeft)
      }

      element.addEventListener('scroll', handler)
      return () => {
        element.removeEventListener('scroll', handler)
      }
    }
    return
  }, [element])

  return scrollPos
}
