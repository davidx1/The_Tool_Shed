import React from 'react'

import { Button } from '@material-ui/core'
import useErrorToast from './useErrorToast'

export default {
  title: 'Hooks/useErrorToast',
}

export const Basic = () => {
  const showError = useErrorToast()
  return (
    <Button variant="contained" color="primary" onClick={() => showError()}>
      Basic
    </Button>
  )
}

export const CustomMessage = () => {
  const showError = useErrorToast()
  return (
    <Button
      variant="contained"
      color="primary"
      onClick={() => showError('Message')}
    >
      Custom Message
    </Button>
  )
}

export const MessageWithoutReload = () => {
  const showError = useErrorToast()
  return (
    <Button
      variant="contained"
      color="primary"
      onClick={() => showError('Message', true)}
    >
      Without reload button
    </Button>
  )
}
