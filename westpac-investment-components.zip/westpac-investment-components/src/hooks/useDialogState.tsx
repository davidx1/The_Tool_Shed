import { useState, useCallback } from 'react'

export default function useDialogState(initVal: boolean) {
  const [isOpen, setIsOpen] = useState(initVal)
  const open = useCallback(() => setIsOpen(true), [])
  const close = useCallback(() => setIsOpen(false), [])
  const toggle = useCallback(() => setIsOpen(!isOpen), [isOpen])
  return { isOpen, open, close, toggle, setIsOpen }
}
