import React from 'react'
import useQuestionnaire from './useQuestionnaire'
import { renderHook, act } from '@testing-library/react-hooks'
import { InvestToolsProvider } from '../components/InvestToolsProvider'
import { IStep } from '../components/navigation/IQuestionnaire'

const getNextStep = async () => {
  return {
    type: 'question',
    question: {
      id: 'Q1',
      type: 'dropdown',
      title: 'Question',
      options: ['Option 1', 'Option 2', 'Option 3'],
      label: 'Placeholder',
    },
  } as IStep
}

describe('useQuestionnaire', () => {
  beforeAll(() => {
    window.Element.prototype.scrollBy = jest.fn()
  })

  it('should create hook and get next questions', async () => {
    const wrapper: React.FC = ({ children }) => (
      <InvestToolsProvider>{children}</InvestToolsProvider>
    )
    const { result, waitForNextUpdate } = renderHook(
      () => useQuestionnaire(getNextStep),
      { wrapper }
    )
    await waitForNextUpdate()

    const scrollContainer = document.createElement('div')
    act(() => {
      result.current.setScrollContainer(scrollContainer)
    })

    act(() => {
      scrollContainer.dispatchEvent(new Event('scroll'))
      result.current.moveToPreviousStep(0)
      result.current.moveToNextStep(0)
    })

    act(() => {
      result.current.changeValue(1, 'test', true)
    })
    await waitForNextUpdate()
    expect(result.current.steps.length).toBe(3)

    act(() => {
      result.current.moveToNextStep(0)
      result.current.setScrollContainer(null)
    })
  })
})
