import { useState, useEffect, useCallback, useRef } from 'react'
import { IStep } from '../components/navigation/IQuestionnaire'
import { scrollToAndFocusEl } from '../utils/elementUtils'
import useErrorToast from './useErrorToast'

export interface IQuestionnaireBase<Step> {
  isFetching: boolean
  steps: Step[]
  values: (string | number)[]
  moveToNextStep: (index: number, animateScroll?: boolean) => void
  moveToPreviousStep: (index: number, animateScroll?: boolean) => void
  changeValue: (
    index: number,
    value: number | string,
    submitValue: boolean
  ) => void
  setScrollContainer: React.Dispatch<
    React.SetStateAction<HTMLDivElement | null>
  >
  setQuestionRef: (index: number) => (ref: HTMLDivElement | null) => void
  isScrolling: boolean
  recommendation?: Step
}

function useQuestionnaire(
  getNextStepAPI: (userAnswers: (string | number)[]) => Promise<IStep | null>,
  setModalStep?: (step: IStep) => void
) {
  const [steps, setSteps] = useState<IStep[]>([])
  const [isFetching, setIsFetching] = useState(false)
  const [values, setValues] = useState<(string | number)[]>([])
  const [scrollContainer, setScrollContainer] = useState<HTMLDivElement | null>(
    null
  )
  const questionRefs = useRef<(HTMLDivElement | null)[]>([])

  const setQuestionRef = (index: number) => (ref: HTMLDivElement | null) => {
    questionRefs.current[index] = ref
  }

  const showError = useErrorToast()

  // call backend and return next question bases on options selected
  const getNextStep = useCallback(
    async (values: (string | number)[]) => {
      setIsFetching(true)

      try {
        const step = await getNextStepAPI(values)
        if (step) {
          if (step.question?.default) {
            setValues([...values, step.question.default])
          }
          if (step.question?.type === 'confirmationModal') {
            setModalStep?.(step)
          }
          setSteps((steps) => [...steps, step])
        }
      } catch (error) {
        showError(error.message, true)
      } finally {
        setIsFetching(false)
      }
    },
    [getNextStepAPI, setModalStep, showError]
  )

  // get initial form step
  useEffect(() => {
    getNextStep([])
  }, [getNextStep])

  // request or navigate to next question
  const moveToNextStep = useCallback(
    (currentIndex: number, animateScroll: boolean = true) => {
      if (currentIndex === steps.length - 1) {
        getNextStep(values)
      } else if (
        steps[currentIndex + 1].question?.type === 'confirmationModal' &&
        currentIndex === steps.length - 2
      ) {
        setModalStep?.(steps[currentIndex + 1])
      } else {
        const nextStepIndex = steps.findIndex(
          (step, iStep) =>
            iStep > currentIndex && step.question?.type !== 'confirmationModal'
        )
        const nextElement = questionRefs.current[nextStepIndex]
        if (nextElement) {
          scrollToAndFocusEl(scrollContainer, nextElement, animateScroll)
        }
      }
    },
    [getNextStep, scrollContainer, setModalStep, steps, values]
  )

  const moveToPreviousStep = useCallback(
    (currentIndex: number, animateScroll: boolean = true) => {
      let previousElement = null
      for (let i = currentIndex - 1; i >= 0; i--) {
        if (steps[i].question?.type !== 'confirmationModal') {
          previousElement = questionRefs.current[i]
          break
        }
      }
      if (previousElement) {
        scrollToAndFocusEl(scrollContainer, previousElement, animateScroll)
      }
    },
    [scrollContainer, steps]
  )

  const cleanUpNextSteps = useCallback(
    (position: number) => {
      setSteps([...steps.slice(0, position)])
    },
    [steps]
  )

  const changeValue = useCallback(
    (index: number, value: number | string, submitValue: boolean) => {
      const newValues = [...values.slice(0, index)]
      newValues[index] = value
      setValues(newValues)
      cleanUpNextSteps(index + 1)
      if (submitValue) {
        getNextStep(newValues)
      }
    },
    [cleanUpNextSteps, getNextStep, values]
  )

  // Scroll to and set focus when new question is added
  useEffect(() => {
    const questionRef = questionRefs.current
    return () => {
      scrollToAndFocusEl(scrollContainer, questionRef[steps.length])
    }
  }, [questionRefs, scrollContainer, steps.length])

  const timeoutScroll = useRef(0)
  const [isScrolling, setIsScrolling] = useState(false)

  useEffect(() => {
    if (scrollContainer) {
      const scrollHandler = () => {
        // Tracking scrolling status
        setIsScrolling(true)
        clearTimeout(timeoutScroll.current)
        timeoutScroll.current = setTimeout(() => {
          setIsScrolling(false)
        }, 50)
      }
      scrollContainer.addEventListener('scroll', scrollHandler)
      return () => {
        scrollContainer.removeEventListener('scroll', scrollHandler)
      }
    }
    return () => {}
  }, [scrollContainer])

  const lastStep = steps.slice().pop()
  let recommendation: IStep | undefined = undefined
  if (lastStep?.type === 'recommendation') {
    recommendation = lastStep
  }

  return {
    steps,
    isFetching,
    values,
    moveToNextStep,
    moveToPreviousStep,
    changeValue,
    setScrollContainer,
    setQuestionRef,
    isScrolling,
    recommendation,
  }
}

export default useQuestionnaire
