import React, { useCallback, useState } from 'react'

import { Button } from '@material-ui/core'
import useTimeout, { ITimeoutConfig } from './useTimeout'

export default {
  title: 'Hooks/useTimeout',
  component: useTimeout,
}

export const Basic = () => {
  const callback = useCallback(() => {
    window.alert('Time out!!')
  }, [])
  const [timeoutConfig, setTimeoutConfig] = useState<ITimeoutConfig>({
    timeout: null,
    callback,
  })
  const resetTimeout = useTimeout(timeoutConfig)

  return (
    <div>
      <h4>
        Timeout:{' '}
        {timeoutConfig.timeout ? `${timeoutConfig.timeout}ms` : 'disabled'}
      </h4>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setTimeoutConfig({ timeout: 3000, callback })}
      >
        3s
      </Button>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setTimeoutConfig({ timeout: 10000, callback })}
      >
        10s
      </Button>
      <Button variant="contained" color="primary" onClick={resetTimeout}>
        Reset
      </Button>
      <Button
        variant="contained"
        color="primary"
        onClick={() => setTimeoutConfig({ timeout: null, callback })}
      >
        Disable
      </Button>
    </div>
  )
}

Basic.parameters = {
  storyshots: false,
}
