import { engines } from '../package.json'

it('Node version is the same as specified in the package.json file', () => {
  expect(process.version.slice(1)).toEqual(engines.node)
})
