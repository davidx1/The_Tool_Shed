import { createMuiTheme } from '@material-ui/core/styles'
import { PaletteOptions } from '@material-ui/core/styles/createPalette'
import { fade } from '@material-ui/core/styles/colorManipulator'

// Fonts
const fontFamily = `National, Helvetica, Arial, sans-serif`
const fontFamilySecondary = `"Tiempos Text", Georgia, "Times New Roman", serif;`
const fontWeightLight = 300
const fontWeightRegular = 400
const fontWeightMedium = 500
const fontWeightBold = 700

const spacingUnit = 8
export const spacing = (multiplier: number) => spacingUnit * multiplier

export const palette: PaletteOptions = {
  primary: {
    main: '#621A4B',
    light: '#40BBC4',
    xlight: '#6897d3',
    dark: '#9F4585',
    contrastText: '#fff',
  },
  secondary: {
    main: '#9F4585',
    light: '#2A8289',
    dark: '#54314E',
    contrastText: '#ffffff',
  },
  tertiary: {
    main: '#D5002B',
    dark: '#b6000b',
    contrastText: '#ffffff',
  },
  highlight: {
    main: '#f4edf2',
    secondary: '#949494',
  },
  background: {
    light: '#F9FAFB',
    grey: '#F7F7F7',
    default: '#fff',
    darkGrey: '#dadada',
    dark: '#302e34',
    paper: '#fff',
  },
  disabled: {
    main: '#41313D',
    light: '#EBEBEB',
    xlight: '#f7f7f7',
  },
  info: {
    main: '#3F9AA5',
    light: '#9F4585',
    dark: '#622D7C',
  },
  success: {
    main: '#E41B13',
    light: '#CFFFD2',
    xlight: '#F5FDF7',
  },
  warning: {
    main: '#F3771C',
    light: '#D5002B',
    xlight: '#fffaea',
  },
  error: {
    main: '#D5002B',
    light: '#FBE3EE',
    xlight: '#fcedf4',
  },
  text: {
    primary: '#222222',
    secondary: '#636363',
    contrast: '#FFFFFF',
    hint: '#C9C9C9',
    disabled: '#E2E2E2',
  },
  divider: '#ECECEC',
  tooltip: {
    main: '#0b1f31',
    secondary: '#FFFFFF',
  },
  toast: {
    info: '#4B87FF',
    error: '#D2003C',
    success: '#84D584',
  },
  type: 'light',
}

const theme = createMuiTheme({
  palette,
  spacing,
  props: {
    MuiWithWidth: {
      initialWidth: 'xs',
    },
  },
  typography: {
    fontFamily,
  },
})

export const mobileLandscapeViewport = `@media (orientation: landscape) and (max-height: 400px)`
export const desktopViewport = `${theme.breakpoints.up(
  'sm'
)} and (min-height: 400px)`

// We can only use typography function such as pxToRem after the createMuiTheme
theme.typography = {
  ...theme.typography,
  fontFamily,
  fontWeightBold,
  fontWeightLight,
  fontWeightMedium,
  fontWeightRegular,
  fontFamilySecondary,
  h1: {
    ...theme.typography.h1,
    fontFamily: fontFamilySecondary,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(32),
    lineHeight: theme.typography.pxToRem(35),
    [desktopViewport]: {
      fontSize: theme.typography.pxToRem(64),
      lineHeight: theme.typography.pxToRem(70),
    },
  },
  h2: {
    ...theme.typography.h2,
    fontFamily: fontFamilySecondary,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(28),
    lineHeight: theme.typography.pxToRem(36),
    [desktopViewport]: {
      fontSize: theme.typography.pxToRem(40),
      lineHeight: theme.typography.pxToRem(50),
    },
  },
  h3: {
    ...theme.typography.h3,
    fontFamily: fontFamily,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(24),
    lineHeight: theme.typography.pxToRem(31),
    [desktopViewport]: {
      fontSize: theme.typography.pxToRem(28),
      lineHeight: theme.typography.pxToRem(36),
    },
  },
  h4: {
    ...theme.typography.h4,
    fontFamily: fontFamily,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(24),
    lineHeight: theme.typography.pxToRem(31),
  },
  h5: {
    ...theme.typography.h5,
    fontFamily: fontFamily,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(22),
    lineHeight: theme.typography.pxToRem(28),
  },
  h6: {
    ...theme.typography.h6,
    fontFamily: fontFamily,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(18),
    lineHeight: theme.typography.pxToRem(25),
  },
  subtitle1: {
    ...theme.typography.subtitle1,
    fontFamily: fontFamily,
    fontWeight: fontWeightRegular,
    fontSize: theme.typography.pxToRem(20),
    lineHeight: theme.typography.pxToRem(26),
    [desktopViewport]: {
      fontSize: theme.typography.pxToRem(24),
      lineHeight: theme.typography.pxToRem(30),
    },
  },
  subtitle2: {
    ...theme.typography.subtitle2,
    fontWeight: fontWeightMedium,
    fontSize: theme.typography.pxToRem(18),
  },
  body1: {
    ...theme.typography.body1,
    fontFamily: fontFamily,
    fontWeight: fontWeightRegular,
    fontSize: theme.typography.pxToRem(16),
    lineHeight: theme.typography.pxToRem(22),
  },
  body2: {
    ...theme.typography.body2,
    fontFamily: fontFamily,
    fontWeight: fontWeightRegular,
    fontSize: theme.typography.pxToRem(18),
    lineHeight: theme.typography.pxToRem(25),
  },
  button: {
    ...theme.typography.button,
    fontFamily: fontFamily,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(16),
    lineHeight: theme.typography.pxToRem(22),
    textTransform: 'none',
    letterSpacing: 0,
    borderRadius: 25,
  },
  caption: {
    ...theme.typography.caption,
    fontFamily: fontFamily,
    fontWeight: fontWeightBold,
    fontSize: theme.typography.pxToRem(18),
    lineHeight: theme.typography.pxToRem(25),
    color: theme.palette.text.hint,
  },
  overline: {
    fontFamily: fontFamily,
    fontWeight: fontWeightRegular,
    fontSize: theme.typography.pxToRem(14),
    lineHeight: theme.typography.pxToRem(18),
    display: 'block',
  },
}

const baselineStyles = {
  '& a, & a:visited': {
    color: theme.palette.text.primary,
    fontWeight: theme.typography.fontWeightMedium,
    '&:after': {
      content: 'none',
    },
  },
  [desktopViewport]: {
    '& a[href^="tel:"]': {
      textDecoration: 'none',
      cursor: 'default',
      color: theme.palette.text.primary,
    },
  },
  '& a:hover': {
    color: theme.palette.tertiary.main,
  },
  '& *:focus': {
    boxShadow: 'none',
  },
}

theme.overrides = {
  MuiScopedCssBaseline: {
    root: baselineStyles,
  },
  MuiPaper: {
    rounded: {
      borderRadius: 3,
    },
    elevation3: {
      '&&': {
        boxShadow: '0px 0px 8px rgba(0, 0, 0, 0.1)',
      },
    },
    elevation4: {
      '&&': {
        boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.15)',
      },
    },
    elevation8: {
      '&&': {
        boxShadow: '0px 0px 6px rgba(0, 0, 0, 0.15);',
      },
    },
  },
  MuiDialog: {
    root: {
      // Add missing baseline css to dialogs
      WebkitFontSmoothing: 'antialiased',
      MozOsxFontSmoothing: 'grayscale',
      boxSizing: 'border-box',
      WebkitTextSizeAdjust: '100%',
      color: theme.palette.text.primary,
      ...theme.typography.body2,
      '& *, & *::before, & *::after': {
        boxSizing: 'inherit',
      },
      '& strong, & b': {
        fontWeight: theme.typography.fontWeightBold,
      },
      ...baselineStyles,
    },
    paperWidthMd: {
      maxWidth: 862,
    },
    paperFullWidth: {
      width: `calc(100% - ${theme.spacing(4)}px)`,
    },
    paperScrollPaper: {
      maxHeight: `calc(100% - ${theme.spacing(4)}px)`,
    },
    paper: {
      margin: `${theme.spacing(2)}px`,
    },
  },
  MuiBackdrop: {
    root: {
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
    },
  },
  MuiIconButton: {
    root: {
      borderRadius: '50%',
      color: theme.palette.text.primary,
      '&:disabled, &:hover:disabled': {
        opacity: 0.4,
        color: theme.palette.disabled.main,
        backgroundColor: theme.palette.disabled.light,
        boxShadow: 'none',
      },
    },
    colorSecondary: {
      backgroundColor: theme.palette.background.default,
      color: theme.palette.text.primary,
      '&:focus:not(:hover)': {
        backgroundColor: theme.palette.background.default,
        color: theme.palette.text.primary,
      },
      '&:hover': {
        backgroundColor: theme.palette.tertiary.main,
        color: theme.palette.tertiary.contrastText,
        '@media(hover: none)': {
          backgroundColor: theme.palette.background.default,
          color: theme.palette.text.primary,
        },
      },
    },
  },
  MuiRadio: {
    root: {
      background: 'transparent',
      '&&:hover': {
        backgroundColor: 'rgba(0, 0, 0, 0.04)',
        color: theme.palette.primary.dark,
      },
      '&& input': {
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        margin: 0,
        opacity: 0,
        padding: 0,
        zIndex: 1,
        position: 'absolute',
      },
    },
  },
  MuiSelect: {
    select: {
      '&:focus': {
        backgroundColor: 'transparent',
      },
    },
  },
  MuiMenuItem: {
    root: {
      fontSize: theme.typography.pxToRem(18),
      lineHeight: theme.typography.pxToRem(40),

      '&&': {
        boxShadow: 'none',
      },
    },
  },
  MuiInputBase: {
    root: {
      color: theme.palette.primary.main,
    },
    input: {
      '&&': {
        color: 'currentColor',
        border: 0,
        padding: '6px 0 7px',
        background: 'inherit',
        fontSize: 'inherit',
      },
      '&&:focus': {
        boxShadow: 'none',
        backgroundColor: 'inherit',
      },
    },
  },
  MuiInput: {
    underline: {
      '&:before': {
        borderBottom: `2px solid ${fade(theme.palette.primary.main, 0.5)}`,
      },
    },
  },
  MuiCheckbox: {
    root: {
      boxShadow: 'none',
      backgroundColor: theme.palette.primary.contrastText,
      '&.Mui-disabled': {
        opacity: 0.7,
      },
      '&& input': {
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        margin: 0,
        opacity: 0,
        padding: 0,
        zIndex: 1,
        position: 'absolute',
      },
    },
  },
  MuiFormControlLabel: {
    root: {
      marginBottom: 0,

      '&.Mui-disabled': {
        opacity: 0.7,
      },
    },
    label: {
      fontWeight: fontWeightRegular,
      '&.Mui-disabled': {
        color: theme.palette.text.primary,
      },
    },
  },
  MuiFormHelperText: {
    root: {
      fontWeight: fontWeightMedium,
      fontSize: theme.typography.pxToRem(16),
      lineHeight: theme.typography.pxToRem(22),
    },
  },
  MuiListItemIcon: {
    root: {
      color: theme.palette.text.primary,
    },
  },
  MuiButtonBase: {
    root: {
      minWidth: 'auto',
      fontFamily,
    },
  },
  MuiButton: {
    contained: {
      padding: '14px 45px',
      fontWeight: fontWeightBold,
      fontSize: theme.typography.pxToRem(16),
      lineHeight: theme.typography.pxToRem(22),
      borderRadius: theme.typography.pxToRem(25),
      boxShadow: 'none',
      '&&:hover': {
        color: theme.palette.primary.contrastText,
        boxShadow: 'none',
      },
      '&&:focusVisible': {
        boxShadow: 'none',
      },
      '&&:active': {
        boxShadow: 'none',
      },
      '&&.Mui-disabled': {
        backgroundColor: fade(theme.palette.primary.main, 0.5),
        color: theme.palette.primary.contrastText,
      },
    },
    outlined: {
      padding: '14px 45px',
      fontWeight: fontWeightBold,
      fontSize: theme.typography.pxToRem(16),
      lineHeight: theme.typography.pxToRem(22),
      borderRadius: theme.typography.pxToRem(25),
      boxShadow: 'none',
      '&&:focus': {
        color: 'currentColor',
        backgroundColor: 'transparent',
        boxShadow: 'none',
      },
      '&&:hover': {
        color: 'currentColor',
        backgroundColor: 'transparent',
      },
    },
    outlinedPrimary: {
      color: theme.palette.text.primary,
      borderColor: theme.palette.tertiary.main,
      backgroundColor: 'transparent',
      '&&:hover': {
        borderColor: theme.palette.tertiary.main,
        color: theme.palette.tertiary.contrastText,
        backgroundColor: theme.palette.tertiary.main,
      },
      '&&:focus': {
        color: theme.palette.text.primary,
        borderColor: theme.palette.tertiary.main,
        backgroundColor: 'transparent',
      },
    },
    containedPrimary: {
      '&&, &&:visited': {
        color: theme.palette.primary.contrastText,
        fontWeight: fontWeightBold,
      },
      '&&:hover': {
        color: theme.palette.primary.contrastText,
        backgroundColor: theme.palette.primary.dark,
        boxShadow: 'none',
      },
      '&&:focus': {
        backgroundColor: theme.palette.primary.dark,
        color: theme.palette.primary.contrastText,
      },
    },
    containedSecondary: {
      backgroundColor: theme.palette.tertiary.main,
      '&&:hover': {
        color: theme.palette.tertiary.contrastText,
        backgroundColor: theme.palette.tertiary.dark,
      },
      '&&:focus': {
        color: theme.palette.tertiary.contrastText,
        backgroundColor: theme.palette.tertiary.dark,
      },
      '&&:disabled': {
        color: theme.palette.background.default,
        border: `1px solid ${fade(theme.palette.secondary.main, 0)}`,
        backgroundColor: `${fade(theme.palette.secondary.main, 0.66)}`,
      },
    },
    outlinedSizeLarge: {
      padding: '16px 40px',
      fontWeight: fontWeightMedium,
      fontSize: theme.typography.pxToRem(18),
      lineHeight: theme.typography.pxToRem(22),
      '&&:hover': {
        color: 'currentColor',
        backgroundColor: 'transparent',
      },
      '&&:focus': {
        color: 'currentColor',
        backgroundColor: 'transparent',
        boxShadow: 'none',
      },
    },
  },
  MuiLinearProgress: {
    root: {
      borderRadius: 3,
      height: 6,
    },
    bar: {
      borderRadius: 3,
    },
    barColorSecondary: {
      backgroundColor: theme.palette.primary.light,
    },
    colorSecondary: {
      backgroundColor: 'transparent',
      '&:before': {
        content: "''",
        position: 'absolute',
        width: '100%',
        height: 4,
        borderRadius: 2,
        top: 1,
        background: theme.palette.background.darkGrey,
      },
    },
  },
  MuiTypography: {
    root: {
      '&& strong, b': {
        fontWeight: theme.typography.fontWeightBold,
      },
    },
  },
  MuiListItem: {
    button: {
      '&&:hover': {
        backgroundColor: 'rgba(0, 0, 0, 0.04)',
      },
      '&&.Mui-selected': {
        backgroundColor: 'rgba(0, 0, 0, 0.08)',
      },
    },
  },
}

export default theme
