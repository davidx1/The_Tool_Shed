import { css, keyframes } from 'styled-components'

export const srOnly = css`
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
`

export const indicatorDot = css`
  content: '';
  display: inline-flex;
  width: 7px;
  min-width: 7px;
  height: 7px;
  min-height: 7px;
  border-radius: 50%;
  margin-right: 6px;
`
export const fadeInInitial = css`
  opacity: 0;
`

export const fadeIn = keyframes`
    from {
        ${fadeInInitial}
    }
    to {
        opacity: 1;
    }
`

export const fadeInUpInitial = css`
  opacity: 0;
  transform: translate3d(0, 15%, 0);
`

export const fadeInUp = keyframes`
    from {
        ${fadeInUpInitial}
    }
    to {
        opacity: 1;
        transform: translate3d(0, 0, 0);
    }
`

const offsetPath = keyframes`
  from {
    stroke-dashoffset: 2000;
  }
  to {
    stroke-dashoffset: 0;
  }
`

export const pathAnimation = css`
  stroke-dasharray: 2000;
  stroke-dashoffset: 2000;
  animation: ${offsetPath} 1.4s cubic-bezier(0.4, 0, 1, 1) forwards;
`

export const inputFocus = css`
  transition: ${({ theme }) => theme.transitions.create(['box-shadow'])};
  &:focus {
    border-color: ${({ theme }) => theme.palette.primary.main};
    box-shadow: 0 0 0 0.2rem ${({ theme }) => theme.palette.primary.main}77;
  }
`

// iOS 11 needs the animation name to change to toggle animation play states
export const forceAnimationPaused = css`
  animation-name: emptyAnimationToForceState;
  animation-play-state: paused;
`

// Override link styles for W1
export const urlCss = css`
  a {
    font-weight: ${({ theme }) => theme.typography.fontWeightMedium};
  }
  a[href^='tel:'] {
    text-decoration: none;
    cursor: default;
    color: ${({ theme }) => theme.palette.text.primary};
    @media screen and (max-width: 680px) {
      text-decoration: underline;
      cursor: pointer;
      &:hover {
        color: ${({ theme }) => theme.palette.text.primary};
      }
    }
  }
`
