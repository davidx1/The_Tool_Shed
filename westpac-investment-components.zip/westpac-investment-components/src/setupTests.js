import React from 'react'
import { configure, mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import 'jest-styled-components'
import 'jest-canvas-mock'
import { InvestToolsProvider } from './components/InvestToolsProvider'
import './polyfills'
import '@testing-library/jest-dom/extend-expect'

configure({ adapter: new Adapter() })

export function mountWithProvider(child) {
  return mount(child, {
    wrappingComponent: ({ children }) => (
      <InvestToolsProvider>{children}</InvestToolsProvider>
    ),
  })
}
