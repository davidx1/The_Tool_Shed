const actual = jest.requireActual('jspdf')

export const pdfTextFn = jest.fn()
export const saveFn = jest.fn()
export const addImageFn = jest.fn()

export class jsPDF {
  constructor(props: any) {
    return {
      ...actual.jsPDF(props),
      text: pdfTextFn,
      save: saveFn,
      addImage: addImageFn,
    }
  }
}
