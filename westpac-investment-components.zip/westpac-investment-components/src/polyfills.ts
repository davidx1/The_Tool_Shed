import 'intersection-observer'
import smoothscroll from 'smoothscroll-polyfill'

smoothscroll.polyfill()
