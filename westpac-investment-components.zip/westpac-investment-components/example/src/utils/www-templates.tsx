import React from 'react'

interface HeaderPageProps {
  title: string
  summary: string
}

export const HeaderPage: React.FC<HeaderPageProps> = ({ title, summary }) => (
  <section className="page-header page-header--show-graphic page-header--lifestyle page-header--has-image">
    <div className="container page-header__container">
      <div className="page-header__left">
        <h1 className="page-header__title">{title}</h1>
        <p className="page-header__summary lead">{summary}</p>
      </div>
    </div>
  </section>
)

export const Container: React.FC = (props) => (
  <div className="container" {...props} />
)

interface ContentBlockProps {
  title: string
}
export const ContentBlock: React.FC<ContentBlockProps> = ({
  title,
  children,
}) => (
  <div className="content-block content-block--white u-block">
    <h2 className="content-block__title">{title}</h2>
    <div className="content-block__content">{children}</div>
  </div>
)
