import React, { useState, useCallback } from 'react'
import {
  IQuestion,
  Questionnaire,
  useQuestionnaire,
  IQuestionnaireBase,
  getNextStepProductChooser,
  UnderlineButton,
  DialogInfo,
  Pill,
  IProductChooserStep,
  IProductChooserProductType,
  IProductChooserProductItem,
  IProductChooserRecommendationDetails,
  generateProductRecommendationFile,
  IProductChooserConfig,
  IProductChooserRatesData,
  Box,
  Typography,
} from 'w-invest-tools'
import Results from 'src/modules/productChooser/ProductChooserRecommendation'
import {
  QUESTION_WHAT_IS_YOUR_TAX_RATE_ID,
  QUESTION_NZ_TAX_RESIDENT_ID,
} from 'src/utils/constants'

// Dialogs
import Comparison from 'src/modules/productChooser/dialog/ProductChooserComparison'
import FindTaxRate from 'src/modules/productChooser/dialog/FindIncomeTaxRate'
import FindInterestFrequency from 'src/modules/productChooser/dialog/FindInterestFrequency'
import FindPIRRate from 'src/modules/productChooser/dialog/FindPIRRate'
import TaxResident from './dialog/TaxResident'

export type compareProducts = (
  recommendationItem: IProductChooserProductItem,
  comparisonData: IProductChooserProductItem[],
  recommendationDetails: IProductChooserRecommendationDetails
) => () => void

interface ProductChooserDialogInfo {
  open: boolean
  overline?: React.ReactNode
  underline?: React.ReactNode
  title?: string
  maxWidth?: false | 'md' | 'xs' | 'sm' | 'lg' | 'xl'
  type?:
    | 'sendEmail'
    | 'compareProducts'
    | 'findMyRate'
    | 'findInterestFrequency'
    | 'findPIRRate'
    | 'taxResident'
  actionText?: string
  indicatorColor?: string
  recommendationType?: IProductChooserProductType
  comparisonItemTitle?: string
  comparisonData?: IProductChooserProductItem[]
  disclaimerText?: string
  selectedRate?: { value: string }
  stepIndex?: number
}

interface Props {
  config: IProductChooserConfig
  ratesData: IProductChooserRatesData
}

const ProductChooserForm: React.FC<Props> = ({ config, ratesData }) => {
  /* 
    Questionnaire
  */
  const getNextStep = useCallback(
    async (userAnswers: (string | number)[]) => {
      return getNextStepProductChooser(userAnswers, config, ratesData)
    },
    [config, ratesData]
  )

  const questionnaire: IQuestionnaireBase<IProductChooserStep> = useQuestionnaire(
    getNextStep
  )

  /* 
    Dialogs
  */
  const [dialogInfo, setDialogInfo] = useState<ProductChooserDialogInfo>({
    open: false,
  })

  const closeDialogInfo = useCallback(() => {
    setDialogInfo({ ...dialogInfo, open: false })
  }, [dialogInfo])

  const compareProducts = useCallback(
    (
      recommendationItem: IProductChooserProductItem,
      comparisonData: IProductChooserProductItem[],
      recommendationDetails: IProductChooserRecommendationDetails
    ) => () => {
      setDialogInfo({
        open: true,
        title: 'Compare.',
        maxWidth: 'lg',
        type: 'compareProducts',
        actionText: 'Apply now',
        recommendationType: recommendationItem.type,
        underline: (
          <Box display="flex" flexDirection="column" alignItems="flex-start">
            <Typography gutterBottom>
              A quick comparison of the recommendations.
            </Typography>
            <Pill>Recommended for you</Pill>
          </Box>
        ),
        comparisonItemTitle: 'Product',
        comparisonData,
        disclaimerText: recommendationDetails.comparisonDisclaimer,
      })
    },
    []
  )

  const findMyRate = useCallback(
    (stepIndex: number) => () => {
      setDialogInfo({
        open: true,
        title: 'Find your income tax rate.',
        underline: 'Answer these questions below.',
        maxWidth: 'md',
        type: 'findMyRate',
        stepIndex,
      })
    },
    []
  )

  const taxResident = useCallback(
    (stepIndex: number) => () => {
      setDialogInfo({
        open: true,
        title: 'Are you a tax resident?',
        maxWidth: 'md',
        type: 'taxResident',
        stepIndex,
      })
    },
    []
  )

  const onSelectRate = useCallback(
    (value) => {
      setDialogInfo({
        ...dialogInfo,
        type: undefined,
        open: false,
        selectedRate: { value },
      })
      questionnaire.changeValue(dialogInfo.stepIndex as number, value, true)
    },
    [dialogInfo, questionnaire]
  )

  const downloadPdf = useCallback(() => {
    const file = generateProductRecommendationFile(
      questionnaire.values,
      config,
      ratesData
    )
    file.save()
  }, [config, questionnaire.values, ratesData])

  const findInterestFrequency = useCallback(
    (recommendationType: IProductChooserProductType) => {
      setDialogInfo({
        open: true,
        type: 'findInterestFrequency',
        title: `Find your ${
          recommendationType === 'termPIE' ? 'return' : 'interest'
        } pay out frequency.`,
        recommendationType,
      })
    },
    []
  )

  const findPIRRate = useCallback(() => {
    setDialogInfo({
      open: true,
      type: 'findPIRRate',
      title: 'Find your PIR rate.',
    })
  }, [])

  return (
    <>
      <Questionnaire
        name="Product Chooser"
        questionnaire={questionnaire}
        questionDetailRender={(question: IQuestion, stepIndex: number) =>
          (question.id === QUESTION_WHAT_IS_YOUR_TAX_RATE_ID && (
            <Box mt={6}>
              <UnderlineButton onClick={findMyRate(stepIndex)}>
                Find your tax rate.
              </UnderlineButton>
            </Box>
          )) ||
          (question.id === QUESTION_NZ_TAX_RESIDENT_ID && (
            <Box mt={6}>
              <UnderlineButton onClick={taxResident(stepIndex)}>
                Am I a New Zealand tax resident?
              </UnderlineButton>
            </Box>
          )) ||
          null
        }
        recommendationRender={(
          recommendationStep: IProductChooserStep,
          backToQuestions
        ) => (
          <Results
            step={recommendationStep}
            backToQuestions={backToQuestions}
            downloadPdf={downloadPdf}
            compareProducts={compareProducts}
            findInterestFrequency={findInterestFrequency}
            findPIRRate={findPIRRate}
            config={config}
          />
        )}
      />

      <DialogInfo
        dialogOverline={dialogInfo.overline}
        dialogTitle={dialogInfo.title}
        dialogUnderline={dialogInfo.underline}
        maxWidth={dialogInfo.maxWidth}
        onClose={closeDialogInfo}
        open={dialogInfo.open}
      >
        {dialogInfo.type === 'compareProducts' &&
          dialogInfo.recommendationType &&
          dialogInfo.comparisonData && (
            <Comparison
              title={dialogInfo.title}
              actionText={dialogInfo.actionText}
              indicatorColor={dialogInfo.indicatorColor}
              recommendationType={dialogInfo.recommendationType}
              comparisonItemTitle={dialogInfo.comparisonItemTitle}
              comparisonData={dialogInfo.comparisonData}
              disclaimerText={dialogInfo.disclaimerText}
              config={config}
            />
          )}
        {dialogInfo.type === 'findMyRate' && (
          <FindTaxRate onSelectRate={onSelectRate} />
        )}
        {dialogInfo.type === 'findInterestFrequency' && (
          <FindInterestFrequency
            recommendationType={dialogInfo.recommendationType}
            onClose={closeDialogInfo}
          />
        )}
        {dialogInfo.type === 'findPIRRate' && <FindPIRRate />}
        {dialogInfo.type === 'taxResident' && (
          <TaxResident onClose={closeDialogInfo} />
        )}
      </DialogInfo>
    </>
  )
}

export default ProductChooserForm
