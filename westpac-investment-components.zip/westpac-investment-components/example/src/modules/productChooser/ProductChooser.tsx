import React, { useEffect, useState } from 'react'
import {
  DialogFullScreen,
  HTMLRenderer,
  IProductChooserConfig,
  IProductChooserRatesData,
  DisclaimerText,
  useDialogState,
  Box,
  Button,
} from 'w-invest-tools'
import ProductChooserForm from 'src/modules/productChooser/ProductChooserForm'
import { Container, ContentBlock, HeaderPage } from 'src/utils/www-templates'

const ProductChooser: React.FC = () => {
  const { isOpen, open, close } = useDialogState(false)

  const [config, setConfig] = useState<IProductChooserConfig>()
  const [ratesData, setRatesData] = useState<IProductChooserRatesData>()
  useEffect(() => {
    // This is only a data sample, updated version is available in the assets.co.nz
    fetch(
      `/w1/savings-investment-chooser/SavingsInvestmentChooserConfig.json`
    ).then(async (data) => {
      setConfig((await data.json()) as IProductChooserConfig)
    })
    fetch(
      `/w1/savings-investment-chooser/SavingsInvestmentChooserRates.json`
    ).then(async (data) => {
      setRatesData((await data.json()) as IProductChooserRatesData)
    })
  }, [])

  const title = 'Savings & Investment Chooser Tool.'

  return config ? (
    <>
      <HeaderPage
        title={title}
        summary="This Savings and Investment Chooser tool gives you advice from Westpac New Zealand Limited on savings and investment options."
      />
      <Container>
        <ContentBlock title="About.">
          {/* Visible only for non-staff */}
          <HTMLRenderer value={config.disclaimer.join('')} />
          {/* Visible only for staff */}
          <HTMLRenderer value={config.disclaimerStaff.join('')} />
          <Box mt={[3, 4]}>
            <Button variant="contained" color="primary" onClick={open}>
              Open tool
            </Button>
          </Box>
        </ContentBlock>
        <DisclaimerText value={config.disclaimerSecondary.join('')} />
      </Container>
      <DialogFullScreen
        open={isOpen}
        onClose={close}
        title={title}
        shortTitle="Product Chooser"
        closeLabel="Exit Tool"
      >
        <ProductChooserForm config={config} ratesData={ratesData as IProductChooserRatesData} />
      </DialogFullScreen>
    </>
  ) : null
}

export default ProductChooser
