import React from 'react'
import {
  Comparison,
  LinkButton,
  IColumnProps,
  IComparisonProps,
  IProductChooserProductType,
  IProductChooserProductItem,
  DisclaimerText,
  IProductChooserConfig,
  Box,
} from 'w-invest-tools'

type DataFields =
  | 'ratesComparison'
  | 'feesComparison'
  | 'benefitsComparison'
  | 'thingsToKnowComparison'
interface ProductChooserComparisonProps
  extends IComparisonProps<
    IProductChooserProductItem,
    IProductChooserProductType,
    DataFields
  > {
  indicatorColor?: string | undefined
  disclaimerText?: string
  actionText?: string
  config: IProductChooserConfig
}

const comparisonColumns: IColumnProps<DataFields>[] = [
  {
    title: 'Benefits',
    dataField: 'benefitsComparison',
  },
  {
    title: 'Fees',
    dataField: 'feesComparison',
  },
  {
    title: 'Rates*',
    dataField: 'ratesComparison',
  },
  {
    title: 'Things to know',
    dataField: 'thingsToKnowComparison',
  },
]

const ProductChooserComparison: React.FC<ProductChooserComparisonProps> = ({
  actionText,
  disclaimerText,
  recommendationType,
  config,
  ...props
}) => {
  return (
    <>
      <Comparison
        actionButtonRender={(item, type) => (
          <LinkButton href={config.productItems[type].applyUrl}>
            {actionText}
          </LinkButton>
        )}
        columns={comparisonColumns}
        recommendationType={recommendationType}
        {...props}
      />

      <Box px={[3, 3, 2]} py={[4, 4, 3]}>
        {disclaimerText && <DisclaimerText value={disclaimerText} />}
      </Box>
    </>
  )
}

export default ProductChooserComparison
