import React, { useCallback } from 'react'
import {
  useQuestionnaire,
  IQuestionnaireBase,
  SubQuestionnaire,
  LabelField,
  ValueField,
  getNextStepIncomeTaxRate,
  IIncomeTaxRateStep,
  SmallScreensButton,
  Box,
  Typography,
} from 'w-invest-tools'

interface Props {
  onSelectRate: (rate: string) => void
}

const FindTaxRate: React.FC<Props> = ({ onSelectRate }) => {
  const getNextStep = useCallback(async (userAnswers: (string | number)[]) => {
    return getNextStepIncomeTaxRate(userAnswers)
  }, [])

  const questionnaire: IQuestionnaireBase<IIncomeTaxRateStep> = useQuestionnaire(
    getNextStep
  )

  return (
    <SubQuestionnaire
      questionnaire={questionnaire}
      resultContainerProps={{ pb: [1, 5] }}
      recommendationRender={(recommendationStep: IIncomeTaxRateStep) => (
        <>
          <Box flexDirection="row" display="flex" flexWrap="wrap" mb={5}>
            <LabelField>Your income tax rate:</LabelField>
            <ValueField>
              <Typography variant="h4">
                {recommendationStep.recommendation?.taxRate}
              </Typography>
            </ValueField>
          </Box>
          <SmallScreensButton
            color="primary"
            variant="contained"
            onClick={() =>
              onSelectRate(recommendationStep.recommendation?.taxRate as string)
            }
          >
            Add my rate
          </SmallScreensButton>
          <Box mt={[2, 4, 5]}>
            <Typography variant="body1" color="textSecondary">
              This rate only applies if you have provided your IRD number.
              Otherwise the 45% non-declaration tax applies.
            </Typography>
          </Box>
        </>
      )}
    />
  )
}

export default FindTaxRate
