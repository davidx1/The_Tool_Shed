import React, { useCallback } from 'react'
import {
  useQuestionnaire,
  IQuestionnaireBase,
  UnderlineButton,
  SubQuestionnaire,
  LabelField,
  ValueField,
  getNextStepInterestFrequency,
  IInterestFrequencyStep,
  IProductChooserProductType,
  Box,
  Typography,
} from 'w-invest-tools'

interface Props {
  onClose: () => void
  recommendationType?: IProductChooserProductType
}

const FindInterestFrequency: React.FC<Props> = ({
  onClose,
  recommendationType,
}) => {
  const getNextStep = useCallback(
    async (userAnswers: (string | number)[]) => {
      return getNextStepInterestFrequency(userAnswers, recommendationType)
    },
    [recommendationType]
  )

  const questionnaire: IQuestionnaireBase<IInterestFrequencyStep> = useQuestionnaire(
    getNextStep
  )

  return (
    <SubQuestionnaire
      questionnaire={questionnaire}
      resultContainerProps={{ pb: [3, 5] }}
      recommendationRender={(recommendationStep: IInterestFrequencyStep) => (
        <>
          <Box flexDirection="row" display="flex" flexWrap="wrap">
            <LabelField>
              Your {recommendationType === 'termPIE' ? 'rate of' : 'interest'}{' '}
              return:
            </LabelField>
            <ValueField>
              <Typography variant="h4">
                {recommendationStep.recommendation?.title}
              </Typography>
            </ValueField>
          </Box>
          <Box mt={[1, 3]} mb={[2, 3]}>
            <Typography color="textSecondary">
              {recommendationStep.recommendation?.description}
            </Typography>
          </Box>
          <UnderlineButton onClick={onClose}>
            Go back to recommendation
          </UnderlineButton>
        </>
      )}
    />
  )
}

export default FindInterestFrequency
