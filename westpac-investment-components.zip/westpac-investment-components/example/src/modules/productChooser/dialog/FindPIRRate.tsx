import React, { useCallback } from 'react'
import {
  useQuestionnaire,
  IQuestionnaireBase,
  SubQuestionnaire,
  LabelField,
  ValueField,
  getNextStepPIRRate,
  IPIRRateStep,
  Box,
  Typography,
} from 'w-invest-tools'

const FindPIRRate: React.FC = () => {
  const getNextStep = useCallback(async (userAnswers: (string | number)[]) => {
    return getNextStepPIRRate(userAnswers)
  }, [])

  const questionnaire: IQuestionnaireBase<IPIRRateStep> = useQuestionnaire(
    getNextStep
  )

  return (
    <SubQuestionnaire
      questionnaire={questionnaire}
      resultContainerProps={{ pb: [1, 3] }}
      recommendationRender={(recommendationStep: IPIRRateStep) => (
        <>
          <Box flexDirection="row" display="flex" flexWrap="wrap" mb={2}>
            <LabelField>Your PIR is:</LabelField>
            <ValueField>
              <Typography variant="h4">
                {recommendationStep.recommendation?.PIRRate}
              </Typography>
            </ValueField>
          </Box>
          {recommendationStep.recommendation?.description && (
            <Typography variant="body1" color="textSecondary" gutterBottom>
              {recommendationStep.recommendation?.description}
            </Typography>
          )}
        </>
      )}
    />
  )
}

export default FindPIRRate
