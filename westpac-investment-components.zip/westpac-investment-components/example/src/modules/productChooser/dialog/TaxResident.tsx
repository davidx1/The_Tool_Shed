import React from 'react'
import { Typography, Box, Button } from 'w-invest-tools'

interface Props {
  onClose: () => void
}

const TaxResident = ({ onClose }: Props) => {
  return (
    <Box px={[2, 4, 4]} pb={[3, 4, 4]} pt={3}>
      <Box mb={3}>
        <Typography component="div">
          <p>
            PIE investments have tax benefits which are only available for NZ
            tax residents. So, if you’re not a NZ tax resident we won’t
            recommend them to you.
          </p>
          <p>
            You’re a New Zealand tax resident (as an individual) if you have a
            'permanent place of abode' in New Zealand; or you have been in New
            Zealand for more than 183 days in total in any 12-month period and
            haven't become a non-resident (absent from New Zealand for more than
            325 days in total in a 12-month period).
          </p>
          <p>
            If you are unsure of your tax residency, you may wish to seek
            professional advice.
          </p>
        </Typography>
      </Box>
      <Button color="primary" variant="contained" onClick={onClose}>
        Close
      </Button>
    </Box>
  )
}

export default TaxResident
