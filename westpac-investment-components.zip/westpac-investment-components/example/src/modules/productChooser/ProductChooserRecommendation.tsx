import React from 'react'
import {
  ResultsSubMenu,
  ProductChooserRecommendationHeader,
  ProductChooserRecommendationInterest,
  ProductChooserRecommendationVideo,
  ProductChooserRecommendationBenefits,
  ProductChooserRecommendationFees,
  ProductChooserRecommendationApply,
  ProductChooserRecommendationDetails,
  ProductChooserRecommendationFooter,
  ProductChooserRecommendationDisclosures,
  ProductChooserRecommendationOtherProduct,
  getCurrentRecommendationItems,
  IProductChooserProductType,
  IProductChooserStep,
  IProductChooserConfig,
  SectionBackground,
  Container,
  Box,
} from 'w-invest-tools'
import { compareProducts } from 'src/modules/productChooser/ProductChooserForm'

interface Props {
  step: IProductChooserStep
  backToQuestions: () => void
  downloadPdf: () => void
  compareProducts: compareProducts
  findInterestFrequency: (
    recommendationType: IProductChooserProductType
  ) => void
  findPIRRate: () => void
  config: IProductChooserConfig
}

const Results: React.FC<Props> = ({
  step,
  backToQuestions,
  downloadPdf,
  compareProducts,
  findInterestFrequency,
  findPIRRate,
  config,
}) => {
  const { recommendation, recommendationDetails } = step
  if (!recommendation || !recommendationDetails) {
    return null
  }

  const recommendations = getCurrentRecommendationItems(
    recommendationDetails,
    recommendation
  )

  const openCompareProducts = compareProducts(
    recommendation,
    recommendations,
    recommendationDetails
  )

  return (
    <Box bgcolor="background.paper">
      <Container component="section">
        <ResultsSubMenu
          backToQuestions={backToQuestions}
          secondaryHandler={downloadPdf}
          secondaryLabel="Download recommendation"
        />
      </Container>
      <ProductChooserRecommendationHeader recommendation={recommendation} />
      <SectionBackground>
        <ProductChooserRecommendationInterest
          recommendation={recommendation}
          findInterestFrequency={findInterestFrequency}
          config={config}
        />
        <ProductChooserRecommendationVideo
          recommendation={recommendation}
          findPIRRate={findPIRRate}
        />
        <ProductChooserRecommendationBenefits recommendation={recommendation} />
        <ProductChooserRecommendationFees
          allFeesUrl={config.links.fees}
          recommendation={recommendation}
        />
        <ProductChooserRecommendationApply
          recommendation={recommendation}
          config={config}
        />
        <ProductChooserRecommendationDetails recommendation={recommendation} />
        <ProductChooserRecommendationOtherProduct
          recommendation={recommendation}
          recommendations={recommendations}
          openCompareProducts={openCompareProducts}
        />
        <ProductChooserRecommendationFooter config={config} />
      </SectionBackground>
      <ProductChooserRecommendationDisclosures
        recommendation={recommendation}
      />
    </Box>
  )
}

export default Results
