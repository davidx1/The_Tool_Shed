import React, { useState, useMemo, useCallback, useReducer } from 'react'
import {
  ResultsSubMenu,
  ProjectionsRecommendationSummary,
  ProjectionsRecommendationMakeChange,
  ProjectionsRecommendationFooter,
  ProjectionsRecommendationGraph,
  ProjectionsRecommendationControls,
  ProjectionsRecommendationResponsiveWrapper,
  ProjectionsMakeContributionChoiceDialog,
  ProjectionsChangeFundChoiceDialog,
  ProjectionsChangeFundLoginChoiceDialog,
  ProjectionsAssumptionsInfoDialog,
  ProjectionsInflationInfoDialog,
  IRelationshipStatusType,
  IProjectionsToolRecommendationStep,
  IKiwisaverContributionFrequencyType,
  IKiwisaverSalaryContributionRateType,
  projectionsCalculation,
  IProjectionsFundType,
  getIsFundDisclaimerShowing,
  Container,
  Box,
} from 'w-invest-tools'
import { IKiwisaverProjectionsConfig } from 'w-invest-tools/dist/utils/projections-tools/projectionsToolUtils'

interface Prop {
  backToQuestion: () => void
  recommendation: IProjectionsToolRecommendationStep
  scrollContainerRef: React.RefObject<HTMLElement>
  config: IKiwisaverProjectionsConfig
}
export const ProjectionsRecommendation = ({
  recommendation: { userAnswers: answers },
  config,
  backToQuestion,
  scrollContainerRef,
}: Prop) => {
  const initialState: IState = {
    originalVal: {
      fundType: answers.fundType,
      salaryContributionRate: answers.salaryContributionRate,
      voluntaryContributionRate: answers.voluntaryContributionRate,
      voluntaryContributionFrequency: answers.voluntaryContributionFrequency,
      relationshipStatus: 'single' as IRelationshipStatusType,
      isIncludingSuperannuation: false,
    },
    newVal: {
      fundType: answers.fundType,
      salaryContributionRate: answers.salaryContributionRate,
      voluntaryContributionRate: answers.voluntaryContributionRate,
      voluntaryContributionFrequency: answers.voluntaryContributionFrequency,
      relationshipStatus: 'single' as IRelationshipStatusType,
      isIncludingSuperannuation: false,
    },
    firstHomeWithdrawalAge: answers.firstHomeWithdrawalAge,
    retireAge: config.defaultRetirementAge,
    postRetirementIncomeFrequency: 'weekly' as IKiwisaverContributionFrequencyType,
  }

  const [
    {
      newVal,
      originalVal,
      firstHomeWithdrawalAge,
      retireAge,
      postRetirementIncomeFrequency,
    },
    dispatch,
  ] = useReducer(reducer, initialState)
  const { currentAge, initialBalance, salary } = answers

  const curriedNewCalculation = useCallback(
    (projectedAge: number) =>
      projectionsCalculation({
        investmentRate: config.investmentRates[newVal.fundType],
        calculationEndAge: projectedAge,
        voluntaryContributionRate: newVal.voluntaryContributionRate,
        voluntaryContributionFrequency: newVal.voluntaryContributionFrequency,
        salaryContributionRate: newVal.salaryContributionRate,
        initialBalance,
        currentAge,
        salary,
        firstHomeWithdrawalAge,
        isIncludingSuperannuation: newVal.isIncludingSuperannuation,
        relationshipStatus: newVal.relationshipStatus,
        config,
      }),
    [
      config,
      newVal.fundType,
      newVal.voluntaryContributionRate,
      newVal.voluntaryContributionFrequency,
      newVal.salaryContributionRate,
      newVal.isIncludingSuperannuation,
      newVal.relationshipStatus,
      initialBalance,
      currentAge,
      salary,
      firstHomeWithdrawalAge,
    ]
  )

  const curriedOldCalculation = useCallback(
    (projectedAge: number) =>
      projectionsCalculation({
        investmentRate: config.investmentRates[originalVal.fundType],
        calculationEndAge: projectedAge,
        voluntaryContributionRate: originalVal.voluntaryContributionRate,
        voluntaryContributionFrequency:
          originalVal.voluntaryContributionFrequency,
        salaryContributionRate: originalVal.salaryContributionRate,
        initialBalance,
        salary,
        currentAge,
        firstHomeWithdrawalAge,
        isIncludingSuperannuation: newVal.isIncludingSuperannuation,
        relationshipStatus: newVal.relationshipStatus,
        config,
      }),
    [
      config,
      originalVal.fundType,
      originalVal.voluntaryContributionRate,
      originalVal.voluntaryContributionFrequency,
      originalVal.salaryContributionRate,
      initialBalance,
      salary,
      currentAge,
      firstHomeWithdrawalAge,
      newVal.isIncludingSuperannuation,
      newVal.relationshipStatus,
    ]
  )

  const balanceAtRetirement = useMemo(() => curriedOldCalculation(retireAge), [
    retireAge,
    curriedOldCalculation,
  ])

  const balanceAtWithdrawal = useMemo(
    () => curriedOldCalculation(firstHomeWithdrawalAge),
    [firstHomeWithdrawalAge, curriedOldCalculation]
  )

  // Make a change dialogs
  const [openContribution, setOpenContribution] = useState(false)
  const [openChangeFund, setOpenChangeFund] = useState(false)
  const [isInflationDialogOpen, setIsInflationDialogOpen] = useState(false)
  const [isAssumptionDialogOpen, setIsAssumptionDialogOpen] = useState(false)
  const [isChangeFundLoginOpen, setIsChangeFundLoginOpen] = useState(false)

  const handleOpenChangeFundLogin = () => {
    setOpenChangeFund(false)
    setIsChangeFundLoginOpen(true)
  }

  const openFundChooser = () => {
    window.open(config.links.productChooserLandingPage, '_blank')
  }

  const openW1Login = () => {
    window.open(config.links.westpacOneLogin, '_blank')
  }

  const openKiwisaverNextStep = () => {
    window.open(config.links.kiwisaverNextStep, '_blank')
  }

  const isControlDirty = JSON.stringify(newVal) !== JSON.stringify(originalVal)
  const isFundDisclaimerShowing = getIsFundDisclaimerShowing(
    currentAge,
    retireAge,
    firstHomeWithdrawalAge,
    newVal.fundType
  )

  return (
    <div>
      <section>
        <Container>
          <ResultsSubMenu backToQuestions={backToQuestion} />
          <ProjectionsRecommendationSummary
            currentAge={currentAge}
            retireAge={retireAge}
            firstHomeWithdrawalAge={firstHomeWithdrawalAge}
            isIncludingSuperannuation={newVal.isIncludingSuperannuation}
            postRetirementIncomeFrequency={postRetirementIncomeFrequency}
            balanceAtRetirement={balanceAtRetirement}
            balanceAtWithdrawal={balanceAtWithdrawal}
            handleShowInflationInfo={() => setIsInflationDialogOpen(true)}
            config={config}
          />
        </Container>
      </section>
      <section>
        <Box
          bgcolor="background.paper"
          pt={[3, 5]}
          pb={[3, 9, 12]}
          mt={5}
          mb={5}
        >
          <ProjectionsRecommendationResponsiveWrapper
            leftChild={
              <ProjectionsRecommendationGraph
                scrollContainerRef={scrollContainerRef}
                currentAge={currentAge}
                retireAge={retireAge}
                firstHomeWithdrawalAge={firstHomeWithdrawalAge}
                setFirstHomeWithdrawalAge={(value) =>
                  dispatch({ type: 'setFirstHomeWithdrawalAge', value })
                }
                curriedNewCalculation={curriedNewCalculation}
                curriedOldCalculation={curriedOldCalculation}
                setRetireAge={(value) =>
                  dispatch({ type: 'setRetireAge', value })
                }
                postRetirementIncomeFrequency={postRetirementIncomeFrequency}
                setPostRetirementIncomeFrequency={(value) =>
                  dispatch({
                    type: 'setPostRetirementIncomeFrequency',
                    value,
                  })
                }
                isControlDirty={isControlDirty}
                config={config}
              />
            }
            rightChild={
              <ProjectionsRecommendationControls
                fundType={newVal.fundType}
                setNewFundType={(value) => dispatch({ type: 'setFund', value })}
                salaryContributionRate={newVal.salaryContributionRate}
                setNewSalaryContributionRate={(value) =>
                  dispatch({ type: 'setSalaryContributionRate', value })
                }
                voluntaryContributionFrequency={
                  newVal.voluntaryContributionFrequency
                }
                setNewVoluntaryContributionFrequency={(value) =>
                  dispatch({
                    type: 'setVoluntaryContributionFrequency',
                    value,
                  })
                }
                voluntaryContributionRate={newVal.voluntaryContributionRate}
                setNewVoluntaryContributionRate={(value) =>
                  dispatch({ type: 'setVoluntaryContributionRate', value })
                }
                isIncludingSuperannuation={newVal.isIncludingSuperannuation}
                setIsIncludingSuperannuation={(value) =>
                  dispatch({ type: 'setIsIncludingSuperannuation', value })
                }
                relationshipStatus={newVal.relationshipStatus}
                setRelationshipStatus={(value) =>
                  dispatch({ type: 'setRelationshipStatus', value })
                }
                salary={salary}
                isControlDirty={isControlDirty}
                isShowingFundDisclaimer={isFundDisclaimerShowing}
                resetControls={() => dispatch({ type: 'reset' })}
                config={config}
              />
            }
          ></ProjectionsRecommendationResponsiveWrapper>
        </Box>
      </section>
      <section>
        <Container>
          <ProjectionsRecommendationMakeChange
            onMakeContributionClick={() => setOpenContribution(true)}
            onChangeFundClick={() => setOpenChangeFund(true)}
            config={config}
          />
        </Container>
      </section>
      <section>
        <Box bgcolor="background.paper" mt={5} pt={[6, 5, 5]} pb={[8, 8, 10]}>
          <Container>
            <ProjectionsRecommendationFooter
              handleOpenAssumptions={() => setIsAssumptionDialogOpen(true)}
              config={config}
            />
          </Container>
        </Box>
      </section>

      <ProjectionsChangeFundChoiceDialog
        open={openChangeFund}
        onClose={() => setOpenChangeFund(false)}
        onLeftButtonClick={handleOpenChangeFundLogin}
        onRightButtonClick={openFundChooser}
        contents={config.dialog}
        isShowingFundDisclaimer={isFundDisclaimerShowing}
        fundDisclaimer={config.fundSelectionTooAggressiveDisclaimer}
      />
      <ProjectionsMakeContributionChoiceDialog
        open={openContribution}
        onClose={() => setOpenContribution(false)}
        onLeftButtonClick={openW1Login}
        onRightButtonClick={openKiwisaverNextStep}
        contents={config.dialog}
      />
      <ProjectionsAssumptionsInfoDialog
        open={isAssumptionDialogOpen}
        onClose={() => setIsAssumptionDialogOpen(false)}
        contents={config.dialog}
      />
      <ProjectionsInflationInfoDialog
        open={isInflationDialogOpen}
        onClose={() => setIsInflationDialogOpen(false)}
        contents={config.dialog}
      />
      <ProjectionsChangeFundLoginChoiceDialog
        open={isChangeFundLoginOpen}
        onClose={() => setIsChangeFundLoginOpen(false)}
        onLeftButtonClick={openW1Login}
        onRightButtonClick={openKiwisaverNextStep}
        contents={config.dialog}
      />
    </div>
  )
}

type IAction =
  | { type: 'setFund'; value: IProjectionsFundType }
  | {
      type: 'setSalaryContributionRate'
      value: IKiwisaverSalaryContributionRateType
    }
  | { type: 'setVoluntaryContributionRate'; value: number }
  | {
      type: 'setVoluntaryContributionFrequency'
      value: IKiwisaverContributionFrequencyType
    }
  | { type: 'setRelationshipStatus'; value: IRelationshipStatusType }
  | { type: 'setIsIncludingSuperannuation'; value: boolean }
  | { type: 'reset' }
  | { type: 'setRetireAge'; value: number }
  | {
      type: 'setPostRetirementIncomeFrequency'
      value: IKiwisaverContributionFrequencyType
    }
  | { type: 'setFirstHomeWithdrawalAge'; value: number }

type IValue = {
  fundType: IProjectionsFundType
  salaryContributionRate: IKiwisaverSalaryContributionRateType
  voluntaryContributionRate: number
  voluntaryContributionFrequency: IKiwisaverContributionFrequencyType
  relationshipStatus: IRelationshipStatusType
  isIncludingSuperannuation: boolean
}

type IState = {
  originalVal: IValue
  newVal: IValue
  firstHomeWithdrawalAge: number
  retireAge: number
  postRetirementIncomeFrequency: IKiwisaverContributionFrequencyType
}

const reducer = (state: IState, action: IAction) => {
  switch (action.type) {
    case 'setFirstHomeWithdrawalAge':
      return {
        ...state,
        firstHomeWithdrawalAge: action.value,
      }
    case 'setRetireAge':
      return {
        ...state,
        retireAge: action.value,
      }
    case 'setPostRetirementIncomeFrequency':
      return {
        ...state,
        postRetirementIncomeFrequency: action.value,
      }
    case 'reset':
      return {
        ...state,
        newVal: {
          ...state.originalVal,
        },
      }
    default: {
      return {
        ...state,
        newVal: { ...newValReducer(state.newVal, action) },
      }
    }
  }
}

const newValReducer = (state: IValue, action: IAction) => {
  switch (action.type) {
    case 'setFund':
      return {
        ...state,
        fundType: action.value,
      }
    case 'setSalaryContributionRate':
      return {
        ...state,
        salaryContributionRate: action.value,
      }
    case 'setVoluntaryContributionRate':
      return {
        ...state,
        voluntaryContributionRate: action.value,
      }
    case 'setVoluntaryContributionFrequency':
      return {
        ...state,
        voluntaryContributionFrequency: action.value,
      }
    case 'setRelationshipStatus':
      return {
        ...state,
        relationshipStatus: action.value,
      }
    case 'setIsIncludingSuperannuation':
      return {
        ...state,
        isIncludingSuperannuation: action.value,
      }
    default:
      return state
  }
}
