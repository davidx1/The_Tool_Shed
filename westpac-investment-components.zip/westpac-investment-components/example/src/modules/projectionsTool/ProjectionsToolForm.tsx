import React, { useState, useCallback } from 'react'
import { ProjectionsRecommendation } from './ProjectionsRecommendation'
import {
  ConfirmationAnswer,
  IStep,
  Questionnaire,
  useQuestionnaire,
  IQuestionnaireBase,
  getNextStepProjectionsTool,
  DialogInfo,
  IProjectionsToolRecommendationStep,
  IKiwisaverProjectionsConfig,
  IQuestionConfirmationModal,
} from 'w-invest-tools'

interface DialogInfo {
  open: boolean
  title?: string
  actionText?: string
  confirmationQuestion?: IQuestionConfirmationModal
}

interface Props {
  config: IKiwisaverProjectionsConfig
}

export const ProjectionsToolForm: React.FC<Props> = ({ config }) => {
  /* 
    Questionnaire
  */
  const setModalStep = useCallback((step: IStep) => {
    setDialogInfo({
      open: true,
      title: step.question?.title,
      confirmationQuestion: step.question as IQuestionConfirmationModal,
    })
  }, [])

  const getNextStep = useCallback(
    async (userAnswers: (string | number)[]) => {
      return getNextStepProjectionsTool(userAnswers, config)
    },
    [config]
  )

  const questionnaire: IQuestionnaireBase<
    IProjectionsToolRecommendationStep | IStep
  > = useQuestionnaire(getNextStep, setModalStep)

  const [dialogInfo, setDialogInfo] = useState<DialogInfo>({
    open: false,
  })

  const closeDialogInfo = useCallback(() => {
    setDialogInfo({ ...dialogInfo, open: false })
  }, [dialogInfo])

  const confirmStep = useCallback(
    (value: string) => {
      closeDialogInfo()
      const index = questionnaire.steps.findIndex(
        (step) => step.question?.id === dialogInfo.confirmationQuestion?.id
      )
      questionnaire.changeValue(index, value, true)
    },
    [closeDialogInfo, dialogInfo.confirmationQuestion, questionnaire]
  )

  return (
    <React.Fragment>
      <Questionnaire
        name="KiwiSaver Fund Finder"
        questionnaire={questionnaire}
        recommendationRender={(
          recommendation,
          backToQuestion,
          scrollContainerRef
        ) => {
          const projectionRecommendation = recommendation as IProjectionsToolRecommendationStep
          return (
            <ProjectionsRecommendation
              recommendation={projectionRecommendation}
              backToQuestion={backToQuestion}
              scrollContainerRef={scrollContainerRef}
              config={config}
            />
          )
        }}
      />
      {dialogInfo.confirmationQuestion && (
        <DialogInfo
          dialogTitle={dialogInfo?.title}
          onClose={closeDialogInfo}
          open={dialogInfo.open}
        >
          <ConfirmationAnswer
            question={dialogInfo.confirmationQuestion}
            confirmStep={confirmStep}
          />
        </DialogInfo>
      )}
    </React.Fragment>
  )
}
