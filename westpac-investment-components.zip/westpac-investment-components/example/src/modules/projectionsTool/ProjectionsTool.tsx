import React, { useEffect, useState } from 'react'
import {
  DialogFullScreen,
  HTMLRenderer,
  IKiwisaverProjectionsConfig,
  useDialogState,
  Button,
  Box,
} from 'w-invest-tools'
import { ProjectionsToolForm } from 'src/modules/projectionsTool/ProjectionsToolForm'
import { Container, HeaderPage, ContentBlock } from 'src/utils/www-templates'

export default function ProjectionsTool() {
  const { isOpen, open, close } = useDialogState(false)

  const [config, setConfig] = useState<IKiwisaverProjectionsConfig>()
  useEffect(() => {
    // This is only a data sample, updated version is available in the assets.co.nz
    fetch(
      `/w1/kiwisaver-projections-calculator/KiwiSaverProjectionsCalculatorConfig.json`
    ).then(async (data) => {
      setConfig((await data.json()) as IKiwisaverProjectionsConfig)
    })
  }, [])

  return config ? (
    <React.Fragment>
      <HeaderPage
        title="Westpac KiwiSaver Scheme Calculator."
        summary="Together we can get your KiwiSaver savings working hard to help you buy your first home or to use when you turn 65."
      />
      <Container>
        <ContentBlock title="About.">
          <HTMLRenderer value={config.disclaimer.join('')} />
          <Box mt={[3, 4]}>
            <Button variant="contained" color="primary" onClick={open}>
              Open the calculator
            </Button>
          </Box>
        </ContentBlock>
      </Container>
      <DialogFullScreen
        open={isOpen}
        onClose={close}
        title="Westpac KiwiSaver Scheme Calculator"
        closeLabel="Exit Calculator"
      >
        <ProjectionsToolForm config={config} />
      </DialogFullScreen>
    </React.Fragment>
  ) : null
}
