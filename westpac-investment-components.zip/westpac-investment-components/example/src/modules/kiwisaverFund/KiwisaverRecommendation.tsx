import React from 'react'
import {
  ResultsSubMenu,
  KiwiSaverRecommendationHeader,
  KiwiSaverRecommendationGraph,
  KiwiSaverRecommendationFooter,
  KiwiSaverRecommendationFeeDetails,
  KiwiSaverRecommendationDisclaimer,
  KiwiSaverJoinOrChange,
  Container,
  Box,
  IKiwisaverStep,
  IKiwisaverFundType,
  IKiwisaverFundItem,
  IKiwisaverFundChooserConfig,
} from 'w-invest-tools'

interface Props {
  step: IKiwisaverStep
  backToQuestions: () => void
  downloadPdf: () => void
  showMoreInfo: (
    fundData: IKiwisaverFundItem | IKiwisaverFundItem[],
    fund?: IKiwisaverFundType,
    isRecommended?: boolean
  ) => void
  kiwisaverFundChooserConfig: IKiwisaverFundChooserConfig
}

const Results: React.FC<Props> = ({
  step,
  showMoreInfo,
  downloadPdf,
  backToQuestions,
  kiwisaverFundChooserConfig,
}) => {
  const { recommendation, recommendationDetails } = step
  if (!recommendation || !recommendationDetails) {
    return null
  }
  const showMoreInfoHandler = (
    type: IKiwisaverFundType,
    showAllDetails = false
  ) => {
    if (!recommendationDetails?.comparisonTable) return
    const fundData = recommendationDetails.comparisonTable

    if (showAllDetails) {
      showMoreInfo(fundData, type)
    } else {
      const fundDetails = fundData.find((item) => item.type === type)
      if (fundDetails)
        showMoreInfo(
          fundDetails,
          type,
          recommendation?.type === fundDetails.type
        )
    }
  }

  const changeFund = () => {}

  const showOtherfunds = () => {
    showMoreInfo(recommendationDetails.comparisonTable, recommendation.type)
  }

  return (
    <React.Fragment>
      <Container component="section">
        <ResultsSubMenu
          backToQuestions={backToQuestions}
          secondaryHandler={downloadPdf}
          secondaryLabel="Download results"
        />
        <KiwiSaverRecommendationHeader
          title="Westpac recommends:"
          recommendation={recommendation}
        />
      </Container>
      <Box
        bgcolor="background.paper"
        pt={5}
        pb={[3, 5, 7]}
        mt={5}
        component="section"
      >
        <Container>
          <KiwiSaverRecommendationGraph
            recommendation={recommendation}
            recommendationDetails={recommendationDetails}
            showMoreInfoHandler={showMoreInfoHandler}
          />
        </Container>
      </Box>
      <Box pt={[4, 7]} pb={3} component="section">
        <Container>
          <KiwiSaverRecommendationFeeDetails
            recommendation={recommendation}
            changeFund={changeFund}
            showOtherfunds={showOtherfunds}
          />
        </Container>
      </Box>
      <Box
        pt={[3, 5, 7]}
        pb={[3, 4, 6]}
        bgcolor="background.paper"
        component="section"
      >
        <Container>
          <KiwiSaverJoinOrChange
            recommendedFund={recommendation}
            showOtherOptions={() =>
              showMoreInfoHandler(recommendation.type, true)
            }
            joinUrl={kiwisaverFundChooserConfig.links.joinWestpac}
            changeUrl={kiwisaverFundChooserConfig.links.changeFund}
          />
        </Container>
      </Box>
      <Box pt={5} pb={6} component="section">
        <Container>
          <KiwiSaverRecommendationFooter config={kiwisaverFundChooserConfig} />
        </Container>
      </Box>
      <Box bgcolor="background.paper" pt={[2, 4]} pb={[4, 6]}>
        <Container>
          <KiwiSaverRecommendationDisclaimer
            kiwisaverFundChooserConfig={kiwisaverFundChooserConfig}
          />
        </Container>
      </Box>
    </React.Fragment>
  )
}

export default Results
