import React, { useEffect, useState } from 'react'
import {
  DialogFullScreen,
  Button,
  IKiwisaverFundChooserConfig,
  HTMLRenderer,
  Box,
  useDialogState,
  DisclaimerDialog,
  DisclaimerText,
} from 'w-invest-tools'
import KiwisaverFundForm from 'src/modules/kiwisaverFund/KiwisaverFundForm'
import { Container, ContentBlock, HeaderPage } from 'src/utils/www-templates'

const KiwisaverFund: React.FC = () => {
  const {
    isOpen: isDisclaimerOpen,
    open: openDisclaimer,
    close: closeDisclaimer,
  } = useDialogState(false)
  const { isOpen, open, close } = useDialogState(false)

  const onContinue = () => {
    closeDisclaimer()
    open()
  }

  const [config, setConfig] = useState<IKiwisaverFundChooserConfig>()
  useEffect(() => {
    // This is only a data sample, updated version is available in the assets.co.nz
    fetch(`/w1/kiwisaver-fund-chooser/KiwiSaverFundChooserConfig.json`).then(
      async (data) => {
        setConfig((await data.json()) as IKiwisaverFundChooserConfig)
      }
    )
  }, [])

  return config ? (
    <React.Fragment>
      <HeaderPage
        title="Westpac KiwiSaver Scheme Fund Chooser."
        summary="The Westpac KiwiSaver Scheme Fund Chooser helps you choose the right Westpac KiwiSaver Scheme fund for your savings and takes less than five minutes to complete."
      />
      <Container>
        <ContentBlock title="About the Fund Chooser.">
          {/* Visible only for non-staff */}
          <HTMLRenderer value={config.beforeYouStart.join('')} />
          {/* Visible only for staff */}
          <HTMLRenderer value={config.beforeYouStartStaff.join('')} />
          <Box mt={[3, 4]}>
            <Button
              variant="contained"
              color="primary"
              onClick={openDisclaimer}
            >
              Open Fund Chooser
            </Button>
          </Box>
        </ContentBlock>
        <DisclaimerText value={config.beforeYouStartSecondary.join('')} />
      </Container>

      <DisclaimerDialog
        title="Before you get started."
        continueButtonText="I understand and agree"
        open={isDisclaimerOpen}
        onClose={closeDisclaimer}
        onContinue={onContinue}
      >
        <HTMLRenderer value={config.disclaimers.join('')} />
      </DisclaimerDialog>

      <DialogFullScreen
        open={isOpen}
        onClose={close}
        title="Westpac KiwiSaver Scheme Fund Chooser"
        shortTitle="Fund Chooser"
        closeLabel="Exit Tool"
      >
        <KiwisaverFundForm config={config} closeHandler={close} />
      </DialogFullScreen>
    </React.Fragment>
  ) : null
}

export default KiwisaverFund
