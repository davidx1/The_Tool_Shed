import React, { useMemo } from 'react'
import {
  ConfirmationAnswer,
  IKiwisaverFundChooserConfig,
  IQuestionConfirmationModal,
} from 'w-invest-tools'

export interface Props {
  onConfirm: (value: string) => void
  config: IKiwisaverFundChooserConfig
}

export const KiwiSaverVulnerableCustomerMessage: React.FC<Props> = ({
  onConfirm,
  config,
}) => {
  const confirmQuestion = useMemo(() => {
    const contact = config.links.kiwiSaverSpecialistsPhone
    return {
      confirmationModalOptions: {
        body: [
          `Are you having trouble understanding this page? 
          If you need some help please call us on <a href="${contact.url}">${contact.label}</a>.`,
          `If you were away from your screen you can continue.`,
        ],
        actionButtons: [{ value: 'Continue with Fund Chooser' }],
      },
    }
  }, [config])
  return (
    <ConfirmationAnswer
      question={confirmQuestion as IQuestionConfirmationModal}
      confirmStep={onConfirm}
    />
  )
}
