import React from 'react'
import {
  KiwiSaverFundDetails,
  IKiwisaverFundItem,
  IKiwisaverFundType,
  IKiwisaverFundChooserConfig,
} from 'w-invest-tools'

interface Props {
  fundItem: IKiwisaverFundItem
  allocatedFunds: IKiwisaverFundType[]
  config: IKiwisaverFundChooserConfig
  onChangeFund: (fundItem: IKiwisaverFundItem) => void
  goBack: () => void
}

const FundDetails: React.FC<Props> = ({
  fundItem,
  allocatedFunds,
  config,
  goBack,
  onChangeFund,
}) => {
  const hasFullAllocation =
    allocatedFunds.length === 1 && allocatedFunds[0] === fundItem.type
  const canChangeFund = fundItem.type !== 'defensive' && !hasFullAllocation
  return (
    <KiwiSaverFundDetails
      goBack={goBack}
      fundItem={fundItem}
      changeFund={canChangeFund ? onChangeFund : undefined}
      config={config}
    />
  )
}

export default FundDetails
