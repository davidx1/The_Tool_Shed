import React from 'react'
import {
  Comparison,
  LinkButton,
  IColumnProps,
  IComparisonProps,
  getFundColor,
  IKiwisaverFundItem,
  IKiwisaverFundType,
  HTMLRenderer,
  DisclaimerText,
  Box,
  IKiwisaverFundChooserConfig,
} from 'w-invest-tools'

type DataFields =
  | 'shortDescription'
  | 'averageAnnualReturn'
  | 'annualFundChargePercent'
  | 'adminFeePerYear'

interface KiwiSaverComparisonProps
  extends IComparisonProps<IKiwisaverFundItem, IKiwisaverFundType, DataFields> {
  getItemIndicatorColor?: (itemType?: IKiwisaverFundType) => string | undefined
  onChangeFund: (fund: IKiwisaverFundItem) => void
  allocatedFunds: IKiwisaverFundType[]
  config: IKiwisaverFundChooserConfig
}

const formatTextArray = (values: string[]) => (
  <HTMLRenderer value={`<p>${values.join('</p><p>')}</p>`} />
)
const formatPercent = (value: number) => <strong>{value}%</strong>
const formatCurrency = (value: number) => <strong>${value}</strong>
const formatTitle = (value: string) => `${value} Fund`

const comparisonColumns: IColumnProps<DataFields>[] = [
  {
    title: 'Fund description',
    dataField: 'shortDescription',
    renderColumnValue: formatTextArray,
  },
  {
    title: 'Average annual return*',
    dataField: 'averageAnnualReturn',
    renderColumnValue: formatPercent,
    width: 140,
  },
  {
    title: 'Estimated annual fund charge^',
    dataField: 'annualFundChargePercent',
    renderColumnValue: formatPercent,
    width: 120,
  },
  {
    title: 'Annual admin fee',
    dataField: 'adminFeePerYear',
    renderColumnValue: formatCurrency,
    width: 120,
  },
]

const FundComparison: React.FC<KiwiSaverComparisonProps> = ({
  onChangeFund,
  allocatedFunds,
  recommendationType,
  config,
  ...props
}) => {
  const getItemIndicatorColor = (fundType?: IKiwisaverFundType) =>
    fundType === recommendationType ? getFundColor(fundType) : undefined

  const getActionButton = (item: IKiwisaverFundItem) => {
    const hasFullAllocation =
      allocatedFunds.length === 1 && allocatedFunds[0] === item.type
    if (hasFullAllocation) {
      return 'Your current fund'
    } else if (item.type !== 'defensive') {
      return (
        <LinkButton onClick={() => onChangeFund(item)}>
          Change to this fund
        </LinkButton>
      )
    }
    return null
  }

  return (
    <>
      <Comparison
        actionButtonRender={getActionButton}
        cellBodyAlignment="top"
        columns={comparisonColumns}
        getItemIndicatorColor={getItemIndicatorColor}
        recommendationType={recommendationType}
        rowTitleValueRender={formatTitle}
        rowTitleField="shortname"
        {...props}
      />
      <Box px={[3, 3, 2]} py={[4, 4, 3]}>
        <DisclaimerText
          value={`
            <p>* Average annual return over five years (after annual fund charges and tax) as at ${config.returnsUpdatedAt}.</p>
            <p>^ Annual fund charges are percentages of the net asset values of a fund. These include estimates of manager and supervisor expenses and applicable underlying fund charges. Actual fund charges will depend on the expenses incurred and performance of the underlying funds and their investment managers and will vary from the estimates. Actual fund charges are available in the latest fund updates.</p>
          `}
        />
      </Box>
    </>
  )
}

export default FundComparison
