import React from 'react'
import {
  UnderlineButton,
  KiwiSaverJoinOrChange,
  IKiwisaverStep,
  IKiwisaverFundType,
  IKiwisaverFundItem,
  IKiwisaverFundChooserConfig,
  Box,
} from 'w-invest-tools'

interface Props {
  step: IKiwisaverStep
  fundDetails: IKiwisaverFundItem
  config: IKiwisaverFundChooserConfig
  goBack: (fundData: IKiwisaverFundItem[], fund: IKiwisaverFundType) => void
}

const DialogJoinOrChange: React.FC<Props> = ({
  step,
  config,
  fundDetails,
  goBack,
}) => {
  const { recommendation, recommendationDetails } = step
  if (!recommendation || !recommendationDetails) return null

  return (
    <React.Fragment>
      <KiwiSaverJoinOrChange
        recommendedFund={fundDetails}
        isContained
        joinUrl={config.links.joinWestpac}
        changeUrl={config.links.changeFund}
      />
      <Box justifyContent="center" display="flex" mb={[2, 4, 5]}>
        <UnderlineButton
          onClick={() =>
            goBack(recommendationDetails.comparisonTable, recommendation.type)
          }
        >
          Go back
        </UnderlineButton>
      </Box>
    </React.Fragment>
  )
}

export default DialogJoinOrChange
