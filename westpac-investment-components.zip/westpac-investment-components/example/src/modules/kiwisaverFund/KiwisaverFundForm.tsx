import React, { useCallback, useState } from 'react'
import {
  Questionnaire,
  useQuestionnaire,
  IQuestionnaireBase,
  ConfirmationAnswer,
  DialogInfo,
  Pill,
  getNextStepFundChooser,
  getFundColor,
  IKiwisaverStep,
  IKiwisaverFundItem,
  IKiwisaverFundType,
  generateKiwisaverRecommendationFile,
  IKiwisaverFundChooserConfig,
  ITimeoutConfig,
  useTimeout,
  IQuestionConfirmationModal,
} from 'w-invest-tools'
import Results from 'src/modules/kiwisaverFund/KiwisaverRecommendation'

// Dialogs
import DialogJoinOrChange from 'src/modules/kiwisaverFund/dialog/DialogJoinOrChange'
import FundDetails from 'src/modules/kiwisaverFund/dialog/FundDetails'
import FundComparison from 'src/modules/kiwisaverFund/dialog/FundComparison'
import { KiwiSaverVulnerableCustomerMessage } from './dialog/KiwiSaverVulnerableCustomersMessage'

interface KiwisaverDialogInfo {
  open: boolean
  title?: string
  tagline?: string
  maxWidth?: false | 'md' | 'xs' | 'sm' | 'lg' | 'xl'
  type?: 'confirmationStep' | 'fundDetails' | 'fundComparison' | 'joinOrChange'
  fund?: IKiwisaverFundType
  fundDetails?: IKiwisaverFundItem
  fundComparison?: IKiwisaverFundItem[]
  comparisonItemTitle?: string
  confirmationQuestion?: IQuestionConfirmationModal
}

const QUESTIONS_IDLE_TIMEOUT = 60000 // 1 min
const RECOMMENDATION_IDLE_TIMEOUT = 300000 // 5 mins
const getStepIdleTimeout = (isRecommendationView: boolean) =>
  isRecommendationView ? RECOMMENDATION_IDLE_TIMEOUT : QUESTIONS_IDLE_TIMEOUT

const allocatedFunds: IKiwisaverFundType[] = ['growth', 'defensive']

interface Props {
  config: IKiwisaverFundChooserConfig
  closeHandler: () => void
}

const KiwisaverFundForm: React.FC<Props> = ({ config, closeHandler }) => {
  /*
    Vulnerable Customer message

    - 1 min idle in the questions and 5 mins idle in the recommendation page
    - don't show message if comparison table is open
    - idle means the user is not progressing in the tool (answering questions or opening modals)
  */
  const [showVulnerableMessage, setShowVulnerableMessage] = useState(false)

  const openVulnerableMessage = useCallback(() => {
    setShowVulnerableMessage(true)
  }, [])
  const [timeoutConfig, setTimeoutConfig] = useState<ITimeoutConfig | null>(
    null
  )
  const resetVulnerableMessageTimeout = useTimeout(timeoutConfig)

  const closeVulnerableMessage = useCallback(() => {
    setShowVulnerableMessage(false)
    resetVulnerableMessageTimeout()
  }, [resetVulnerableMessageTimeout])

  const [dialogInfo, setDialogInfoImpl] = useState<KiwisaverDialogInfo>({
    open: false,
  })

  const setDialogInfo = useCallback(
    (state: KiwisaverDialogInfo) => {
      if (state.open && state.type === 'fundComparison') {
        setTimeoutConfig(null)
      } else {
        setTimeoutConfig({
          timeout: getStepIdleTimeout(state.type !== 'confirmationStep'),
          callback: openVulnerableMessage,
        })
      }
      setDialogInfoImpl(state)
    },
    [openVulnerableMessage]
  )

  /* 
    Questionnaire
  */
  const setModalStep = useCallback(
    (step: IKiwisaverStep) => {
      setTimeoutConfig(null)
      setDialogInfo({
        open: true,
        type: 'confirmationStep',
        title: step.question?.title,
        confirmationQuestion: step.question as IQuestionConfirmationModal,
      })
    },
    [setDialogInfo]
  )

  const getNextStep = useCallback(
    async (userAnswers: (string | number)[]) => {
      const step = getNextStepFundChooser(
        userAnswers,
        config,
        allocatedFunds.some((value) => value === 'defensive')
      )
      setTimeoutConfig({
        timeout: getStepIdleTimeout(!!step.recommendation),
        callback: openVulnerableMessage,
      })
      return step
    },
    [config, openVulnerableMessage]
  )

  const questionnaire: IQuestionnaireBase<IKiwisaverStep> = useQuestionnaire(
    getNextStep,
    setModalStep
  )

  /* 
    Dialogs
  */

  const closeDialogInfo = useCallback(() => {
    setDialogInfo({ ...dialogInfo, open: false })
  }, [dialogInfo, setDialogInfo])

  const showMoreInfo = useCallback(
    (
      fundData: IKiwisaverFundItem | IKiwisaverFundItem[],
      fund?: IKiwisaverFundType,
      isRecommended?: boolean
    ) => {
      if (Array.isArray(fundData)) {
        setDialogInfo({
          open: true,
          fundComparison: fundData,
          title: 'Fund comparison',
          maxWidth: 'lg',
          type: 'fundComparison',
          comparisonItemTitle: 'Fund',
          fund,
        })
      } else {
        setDialogInfo({
          open: true,
          fundDetails: fundData,
          title: `${fundData.shortname} Fund.`,
          type: 'fundDetails',
          tagline: isRecommended ? 'Recommended' : undefined,
        })
      }
    },
    [setDialogInfo]
  )

  const showJoinOrChange = useCallback(
    (fundDetails: IKiwisaverFundItem) => {
      setDialogInfo({
        open: true,
        title: 'Join or change your KiwiSaver.',
        maxWidth: 'md',
        type: 'joinOrChange',
        fundDetails,
      })
    },
    [setDialogInfo]
  )

  const downloadPdf = useCallback(() => {
    const file = generateKiwisaverRecommendationFile(
      questionnaire.values,
      config
    )
    file.save()
  }, [config, questionnaire.values])

  const confirmStep = useCallback(
    (value: string) => {
      closeDialogInfo()
      const index = questionnaire.steps.findIndex(
        (step) => step.question?.id === dialogInfo.confirmationQuestion?.id
      )
      questionnaire.changeValue(index, value, true)
    },
    [closeDialogInfo, dialogInfo.confirmationQuestion, questionnaire]
  )

  return (
    <React.Fragment>
      <Questionnaire
        name="KiwiSaver Fund Finder"
        questionnaire={questionnaire}
        recommendationRender={(
          recommendationStep: IKiwisaverStep,
          backToQuestions
        ) => (
          <Results
            step={recommendationStep}
            backToQuestions={backToQuestions}
            showMoreInfo={showMoreInfo}
            downloadPdf={downloadPdf}
            kiwisaverFundChooserConfig={config}
          />
        )}
      />

      <DialogInfo
        dialogOverline={dialogInfo?.tagline}
        dialogTitle={dialogInfo?.title}
        dialogUnderline={
          dialogInfo.fundComparison &&
          dialogInfo.fund && (
            <Pill bgColor={getFundColor(dialogInfo.fund)}>Recommended</Pill>
          )
        }
        maxWidth={dialogInfo.maxWidth}
        onClose={closeDialogInfo}
        open={dialogInfo.open}
      >
        {dialogInfo.type === 'joinOrChange' &&
          dialogInfo.fundDetails &&
          questionnaire.recommendation && (
            <DialogJoinOrChange
              step={questionnaire.recommendation}
              fundDetails={dialogInfo.fundDetails}
              goBack={closeDialogInfo}
              config={config}
            />
          )}
        {dialogInfo.type === 'fundDetails' && dialogInfo.fundDetails && (
          <FundDetails
            fundItem={dialogInfo.fundDetails}
            allocatedFunds={allocatedFunds}
            onChangeFund={showJoinOrChange}
            goBack={closeDialogInfo}
            config={config}
          />
        )}
        {dialogInfo.type === 'fundComparison' &&
          dialogInfo.fundComparison &&
          dialogInfo.fund && (
            <FundComparison
              title={dialogInfo.title}
              recommendationType={dialogInfo.fund}
              comparisonData={dialogInfo.fundComparison}
              comparisonItemTitle={dialogInfo.comparisonItemTitle}
              allocatedFunds={allocatedFunds}
              onChangeFund={showJoinOrChange}
              config={config}
            />
          )}
        {dialogInfo.type === 'confirmationStep' &&
          dialogInfo.confirmationQuestion && (
            <ConfirmationAnswer
              question={dialogInfo.confirmationQuestion}
              confirmStep={confirmStep}
              closeToolHandler={closeHandler}
            />
          )}
      </DialogInfo>
      <DialogInfo
        dialogTitle="We’re here to help."
        open={showVulnerableMessage}
        onClose={closeVulnerableMessage}
      >
        <KiwiSaverVulnerableCustomerMessage
          onConfirm={closeVulnerableMessage}
          config={config}
        />
      </DialogInfo>
    </React.Fragment>
  )
}

export default KiwisaverFundForm
