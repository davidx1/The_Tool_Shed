import './index.css'

import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import 'core-js'
import 'whatwg-fetch'

ReactDOM.render(<App />, document.getElementById('root'))
