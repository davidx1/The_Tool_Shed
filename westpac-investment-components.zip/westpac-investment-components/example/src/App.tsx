import React from 'react'

import KiwisaverFund from 'src/modules/kiwisaverFund/KiwisaverFund'
import ProductChooser from 'src/modules/productChooser/ProductChooser'
import ProjectionsTool from 'src/modules/projectionsTool/ProjectionsTool'
import { InvestToolsProvider } from 'w-invest-tools'

const App = () => {
  return (
    <InvestToolsProvider>
      <KiwisaverFund />
      <ProjectionsTool />
      <ProductChooser />
    </InvestToolsProvider>
  )
}

export default App
