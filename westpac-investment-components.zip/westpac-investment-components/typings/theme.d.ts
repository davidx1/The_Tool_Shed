import 'styled-components'
import { CSSProperties } from 'react'
import { Theme } from '@material-ui/core/styles'

declare module '@material-ui/core/styles/createPalette' {
  interface ToastPalette {
    info: string
    error: string
    success: string
  }

  interface ExtraPaletteOptions {
    toast: ToastPalette
    tooltip: SimplePaletteColorOptions
    disabled: SimplePaletteColorOptions
    highlight: SimplePaletteColorOptions
    tertiary: SimplePaletteColorOptions
  }

  interface Palette extends ExtraPaletteOptions {}

  interface PaletteOptions extends ExtraPaletteOptions {}

  interface SimplePaletteColorOptions {
    xlight?: string
    secondary?: string
  }

  interface TypeText {
    contrast: string
  }

  interface TypeBackground {
    grey: string
    darkGrey: string
    dark: string
    light: string
  }
}

declare module '@material-ui/core/styles/createTypography' {
  interface FontStyle {
    fontFamilySecondary: CSSProperties['fontFamily']
  }
}

// Extend the module declarations with our MuiTheme to give us type information inside styled-components
declare module 'styled-components' {
  export interface DefaultTheme extends Theme {}
}
