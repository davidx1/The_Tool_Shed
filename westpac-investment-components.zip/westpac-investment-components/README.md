# Westpac Investment Components

Investment UI Components used in the following tools:

- Westpac KiwiSaver Scheme Fund Chooser (WWW and WestpacOne)
- Westpac KiwiSaver Scheme Calculator (WWW and WestpacOne)
- Savings & Investment Product Chooser (WWW)

## Development e2e overview

This library is used for both WestpacOne (bank.westpac.co.nz) and WWW (westpac.co.nz).

A few manual steps are necessary in order to make changes in the library and to update the respective websites:

![Development e2e Workflow](docs/development-e2e-workflow.png?raw=true 'Development e2e Workflow')

## Step 1: Making changes in the library

### Installing

1. Clone the project locally

```bash
git clone ssh://git@stash.westpac.co.nz:7999/jsui/westpac-investment-components.git
```

2. Use the node version 12.12.0 to avoid version issues when running the snapshot tests, if using nvm run:

```bash
nvm use 12.12.0
```

3. Install the dependencies

```bash
npm ci
```

Note: If you are on MacOS Catalina 10.15.6 you MAY get an error that looks something like this:

```
gyp: No Xcode or CLT version detected!
gyp ERR! configure error
gyp ERR! stack Error: `gyp` failed with exit code: 1
gyp ERR! stack     at ChildProcess.onCpExit (/Users/davidx/.nvm/versions/node/v12.19.0/lib/node_modules/npm/node_modules/node-gyp/lib/configure.js:351:16)
gyp ERR! stack     at ChildProcess.emit (events.js:314:20)
gyp ERR! stack     at Process.ChildProcess._handle.onexit (internal/child_process.js:275:12)
gyp ERR! System Darwin 19.6.0
gyp ERR! command "/Users/davidx/.nvm/versions/node/v12.19.0/bin/node" "/Users/davidx/.nvm/versions/node/v12.19.0/lib/node_modules/npm/node_modules/node-gyp/bin/node-gyp.js" "rebuild"
gyp ERR! cwd /Users/davidx/Desktop/Dev/westpac-investment-components-confidential/node_modules/watchpack-chokidar2/node_modules/fsevents
gyp ERR! node -v v12.19.0
gyp ERR! node-gyp -v v5.1.0
gyp ERR! not ok
```

Then you might be missing the command line tool. You can install said tools via:

```bash
xcode-select --install
```

If you get an error that looks like this:

```bash
xcode-select: error: command line tools are already installed, use "Software Update" to install updates
```

Then you could remove it and reinstall with:

```bash
sudo rm -rf /Library/Developer/CommandLineTools
xcode-select --install
```

### Scripts available in the project

Main scripts

- `npm run storybook` - open storybook and keep watching for changes
- `npm run start` - compile the library and watch for file changes
- `npm run test:watch` - run unit tests and check the coverage in watch mode

Others (you probably don't need them)

- `npm run build` - create a compiled version of the library (used by Jenkins)
- `npm run test` - run test:link, test:unit and test:build (used by Jenkins)
- `npm run test:lint` - check for linting issues
- `npm run test:unit` - run unit tests and check the coverage
- `npm run test:build` - same as build
- `npm run release` - used by jenkins to publish a new library version (used by Jenkins)
- `npm run build-storybook` - create a deployable version of the storybook

### Example project

It combines all the components and simulates the final product. Useful for validating the components and making sure you're exposing them properly.

[Example project README](example/README.md)

### Development

---

#### GIT guidelines

The investment library uses the same git guidelines as WestpacOne.

- Branch names `<bugfix/feature/hotfix>/<story-ID>-<story-summary>`. E.g `feature/SPEDBNONO-470-update-informative-box`
- Commit messages `<story-ID> - <commit message description>`

---

#### Creating a new feature or making changes to the library components

1. Start storybook `npm run storybook`, this is the fastest way to create and maintain your components

2. If creating a new component, you'll need to create the `component.stories.tsx` file alongside the component

```js
import React from 'react'

import Pill from './Pill' // import all the components you want to simulate

export default {
  title: 'Data Display/Pill', // use the title to create the storybook menu hierarchy
  component: Pill, // set the component to display all its props in the docs
}

export const Basic = () => (
  // you can export one or more stories for the same component
  <Pill bgColor="#ff0000">Red colour</Pill>
)
```

3. Every story will automatically create snapshots for testing purposes but this can be disabled

```js
Basic.parameters = {
  storyshots: false,
}
```

4. The library has a minimum test coverage of 80% and use static analysis with Typescript to avoid new bugs being introduced to the library. Create the file `component.test.tsx` file alongside the component. This project uses the testing framework `jest` and the testing utilities provided by the `testing-library`. Avoid using `enzyme` whenever possible

5. Run the tests with `npm run test:watch` and make sure the coverage remains above 80% and no tests are failing

6. Best way to validate your components is to test in the example project. First, make sure you compile the library `npm run start`. The [Example project](example/README.md) needs to be running.
   Test the components as you would do inside WWW or WestpacOne. Make sure any component you need to expose from the library is added to the [index.tsx](src/index.tsx)

7. After finishing all the changes, create a PR and merge to master

---

#### Caveats

- Use relative paths instead of absolute paths - this will improve how other projects using the library navigates in the interfaces
- Import `FC` directly from `react` library instead of using `React.FC` - for typings to load correctly in Storyboard (this is a bug that may be fixed on newer versions of storybook)
- Use `React.Fragment` instead of `<></>` - microbundle-crl is not configured to understand `<></>` (it may be improved on newer versions)

## Step 2: Release a new library version

The release process is triggered manually using jenkins, and allow to make a patch, minor or major release.

1. Make sure you have access to [investment jenkins pipeline](https://jenkins-test.wone.westpac.co.nz/view/Westpac%20UI/job/westpac-investment-components-delivery/)

2. Log in and the left menu will be updated with extra links. Click on `Build with Parameters`

3. Select `patch, minor or major` and click in the `Build` button

4. Jenkins will run some internal scripts and do the following

   - test the library (linting, unit tests, coverage, build)
   - update master and tag the commit with the new version number
   - the library version is published to artifactory

5. Make sure the new version is built successfully and you can check the `Console Output` to see the new version number. E.g `@westpac/westpac-investment-components@2.4.0`

## Step 3: Usage

Here is a quick example of how to use the components inside WWW or WestpacOne.

```js
import React from 'react'
import ReactDOM from 'react-dom'

import { UnderlineButton } from '@westpac/westpac-investment-components'

function App() {
  return <UnderlineButton>Hello World!</UnderlineButton>
}

ReactDOM.render(<App />, document.querySelector('#app'))
```

## Step 3.1: Update Westpac One (only if the banking app needs to be update)

Follow WestpacOne development process for branches, commits and pull requests.

1. Install the new library version `npm install @westpac/westpac-investment-components@2.4.0 --save-exact`

2. Make any integration changes if needed

3. Make sure all the tests are passing and coverage is 100% (Westpac recommendation)

4. Create the PR and follow the Westpac process needed to releasing to prod

## Step 3.2: Update WWW (only if the Westpac website needs to be update)

Follow WWW development process for branches, commits and pull requests.

**To update the library inside WWW a manual process is required**

1. Download the new released version from `artifactory`. https://artifactory2.westpac.co.nz:443/api/npm/npm-combined/@westpac/westpac-investment-components/-/@westpac/westpac-investment-components-2.4.0.tgz

2. Create a new branch, clean up the `packages/westpac-investment-components` folder and extract the new files to it. See below how the structure will look like:

```
    .
    ├── ...
    ├── packages
    │   ├── westpac-investment-components
    │   │   ├── dist
    │   │   │   ├── ...       # all the compiled files (e.g index.js, index.d.ts, ...)
    │   │   ├── package.json
    │   │   ├── README.md
    ├── ...
```

3. Make any integration changes if needed

4. Make sure all the tests are passing

5. Create the PR and follow the WWW process needed to releasing to prod

## What is inside this library?

- [microbundle-crl](https://www.npmjs.com/package/microbundle-crl)
  - The zero-configuration bundler for tiny modules, powered by Rollup.
  - Compile the components to a CJS format to be consumed by other projects
  - Typescript support
- [typescript](https://www.typescriptlang.org/)
  - TypeScript extends JavaScript by adding types.
  - TypeScript saves you time catching errors and providing fixes before you run code.
  - Extra features for your javascript application (e.g Optional Chaining, Nullish coalescing, Throw Expressions, ...)
- [styled-components](https://styled-components.com/)
  - Use the best bits of ES6 and CSS to style your apps
  - Unique class names for your styles. You never have to worry about duplication, overlap or misspellings.
  - If the component is unused (which tooling can detect) and gets deleted, all its styles get deleted with it)
  - You never have to hunt across different files to find the styling affecting your component
  - Automatic vendor prefixing
  - Style the component based on its props or a global theme is simple and intuitive without having to manually manage dozens of classes.
- [material-ui](https://material-ui.com/)
  - React components for faster and easier web development
  - Highly customizable and supports theme
  - Performant. Components work in isolation and only inject the styles they need
  - Works well with styled-components
- [storybook](https://storybook.js.org/)
  - Makes it easy to build components in isolation
  - Increases developer awareness of existing components
  - Serves as a living style guide and documentation
- [vx](https://vx-demo.now.sh/)
  - A combination of React and d3 to create data visualization
  - All the calculations, math and power of d3 under the hood
  - Very customizable and reusable chart components

Other dependencies were added to align with others available inside WestpacOne.
E.g `jspdf` and `moment`.
